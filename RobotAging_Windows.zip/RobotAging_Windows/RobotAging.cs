﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

public class Aging
{
    public Action<string> Log = delegate { };
    public int Racks=2, InY=2, LeftX=5, LeftY=4, RightX=5, RightY=4, Timeout=180;
    public readonly int[] Rack={1,1,1}, XY={80,80,80}, Tilt={80,80,80}, Delay={500,500,500}, Pour={80,80,80}, Angle={45,45,45};
    public int Floor=1, Stage, Moves, Cycles, LogOffset, DebugOffset; public bool Running, Checking, Saving, Starting, LampOn, Paused;
    public string Pending="", State="연결 전", Robot="-", Address="", Motion="", PauseWhy="", LastError="", SaveState="미전송";
    public double AnimX=.5, AnimY=.82, FromX=.5, FromY=.82, ToX=.5, ToY=.82, Progress=1;
    public DateTime Started, End, Finished; public TimeSpan Duration=TimeSpan.FromHours(1);
    public readonly List<string> Lines=new List<string>(), DebugLines=new List<string>();
    public bool Connected { get { return client!=null; } } public bool LogConnected { get { return debug!=null; } }
    readonly Random random=new Random(Guid.NewGuid().GetHashCode()); readonly ConcurrentQueue<string> received=new ConcurrentQueue<string>(), debugReceived=new ConcurrentQueue<string>();
    TcpClient client, debug; string expected="", number="", waiting=""; TaskCompletionSource<bool> response;
    DateTime due, deadline, poll, tick=DateTime.UtcNow; bool continuing, keepAlive=true, lampEnding, hmiActive;
    public async Task Connect(string ip,int port)
    {
        var next=new TcpClient(); try { var task=next.ConnectAsync(ip,port); if(await Task.WhenAny(task,Task.Delay(5000))!=task) throw new IOException("연결 시간 초과"); await task; } catch { next.Close(); throw; }
        client=next; keepAlive=true; lampEnding=hmiActive=false; Address=ip+":"+port; State="연결됨 · 상태 조회"; Receive(next,false); Log("연결 "+Address); poll=DateTime.UtcNow; Send("C");
    }
    public async Task ConnectLog(string ip,int port)
    {
        DisconnectLog(); var next=new TcpClient(); try { var t=next.ConnectAsync(ip,port); if(await Task.WhenAny(t,Task.Delay(5000))!=t) throw new IOException("로그 연결 시간 초과"); await t; } catch { next.Close(); throw; }
        debug=next; Receive(next,true); debugReceived.Enqueue("로그 연결 "+ip+":"+port);
    }
    async void Receive(TcpClient source,bool logs)
    {
        var bytes=new byte[4096]; var frame=new StringBuilder(); bool inside=false; var decoder=Encoding.UTF8.GetDecoder(); var chars=new char[4096];
        try { for(;;) { int n=await source.GetStream().ReadAsync(bytes,0,bytes.Length); if(n==0 || source!=(logs?debug:client)) break;
            if(logs) { int c=decoder.GetChars(bytes,0,n,chars,0); debugReceived.Enqueue(new string(chars,0,c)); continue; }
            for(int i=0;i<n;i++) { if(bytes[i]==2) { frame.Clear(); inside=true; } else if(bytes[i]==3 && inside) { received.Enqueue(frame.ToString()); inside=false; } else if(inside) frame.Append((char)bytes[i]); }
        } } catch(Exception e) { if(source==(logs?debug:client)) (logs?debugReceived:received).Enqueue("!"+e.Message); }
        if(source==(logs?debug:client)) (logs?debugReceived:received).Enqueue("!연결 종료");
    }
    public void DisconnectLog() { if(debug!=null) debug.Close(); debug=null; string s; while(debugReceived.TryDequeue(out s)) {} }
    public void Disconnect()
    {
        Stop(); Pending=expected=number=""; if(client!=null) client.Close(); client=null; if(response!=null) response.TrySetResult(false); string s; while(received.TryDequeue(out s)) {} State="연결 해제";
    }
    public void Send(string text)
    {
        if(!Connected) { Log("미전송 · 연결되지 않음: "+text); return; } byte[] data=Encoding.ASCII.GetBytes("\x02"+text+"\x03");
        try { client.GetStream().Write(data,0,data.Length); } catch(Exception e) { Disconnect(); State="전송 실패"; Log(e.Message); return; } Log("TX [STX]"+text+"[ETX]");
    }
    public async Task<bool> Request(string text)
    {
        if(!Connected || response!=null) return false; waiting=text; var r=new TaskCompletionSource<bool>(); response=r; Send(text);
        await Task.WhenAny(r.Task,Task.Delay(5000)); bool ok=r.Task.IsCompleted && r.Task.Result; response=null; waiting=""; if(!ok) Log("명령 실패/시간 초과: "+text); return ok;
    }
    public void Start()
    {
        if(!Connected || Running || Checking || Starting || Saving || Pending!="") return; continuing=hmiActive=false; Checking=true; State="로봇 대기 상태 확인"; deadline=DateTime.UtcNow.AddSeconds(5); Send("C");
    }
    public void Stop() { Running=Checking=continuing=Paused=false; Finished=DateTime.UtcNow; State=Pending==""?"에이징 중지":"다음 명령 중지 · 현재 동작 완료 대기"; }
    public void Pause() { bool wasRunning=Running || Paused; Stop(); Paused=wasRunning; PauseWhy="M"; if(Connected) Send("S_1"); State="일시정지 요청 · 상태 응답 확인"; }
    public async Task Button(int b)
    {
        if(Saving) { Log("설정 저장 중: HMI 조작은 저장 완료 후 실행하세요."); return; }
        if(b==12) { Pause(); return; } bool resume=b==11 && Paused; LastError="";
        if(!await Request("H_"+b)) { if(LastError=="") LastError="응답 없음 또는 다른 명령 대기 중"; State="H_"+b+" 실패 · "+LastError; return; }
        keepAlive=true; if(!Running && !resume) hmiActive=true; poll=DateTime.UtcNow; State="H_"+b+" 접수 · 로봇 상태 확인";
        if(b==33) State="수동 전환 접수 · 대기/알람 05·06·07·10에서 허용";
        if(b==32 && (!Robot.Contains("_R") || Paused)) { Stop(); hmiActive=true; Pending=expected=number=Motion=""; Floor=1; Stage=0; State="리셋 접수 · 원점 상태 확인"; }
        if(resume) { continuing=true; hmiActive=false; State="재개 상태 확인 중"; }

    }
    public async Task<bool> SetLamp(bool on)
    {
        bool ok=await Request(on?"LL_1_2_10&L_2_2_10":"LL_1_2_00&L_2_2_00"); if(ok) LampOn=on; else LastError="녹색 램프 명령 ACK 확인 실패"; return ok;
    }
    async void Begin()
    {
        Starting=true; bool ok=await SetLamp(true); Starting=false; if(!ok) { State="램프 명령 실패 · 시작 중지"; return; }
        if(!Connected || State!="시작 램프 확인 중") { lampEnding=false; return; } Started=DateTime.UtcNow; Finished=DateTime.MinValue; End=Started+Duration; Running=true; keepAlive=true; lampEnding=false; State="에이징 실행 중"; due=Started;
    }
    async void FinishLamp()
    {
        lampEnding=true; if(await SetLamp(false)) { if(!hmiActive) keepAlive=false; Log(hmiActive?"녹색 OFF 확인 · HMI 상태 조회 유지":"녹색 OFF 확인 · 상태 조회 중지 · 보드 FI7 타임아웃(기본 20초) 대기"); }
    }
    public async Task EndConnection()
    {
        Stop(); if(Connected && !await SetLamp(false)) { State="램프 OFF 확인 실패 · 연결 유지"; return; } Disconnect();
    }
    void Animate(string cmd)
    {
        Motion=cmd; var a=cmd.Split('_'); FromX=AnimX; FromY=AnimY; ToX=.5; ToY=a[0]=="MI"?.16:.82;
        if(a[0]=="PO") { ToX=int.Parse(a[1])%2==1?.10:.90; ToY=.25+(int.Parse(a[3])-1)*.13; } Progress=0;
    }
    public void Tick()
    {
        string s; while(received.TryDequeue(out s)) { if(s.StartsWith("!")) { Disconnect(); State="통신 끊김 · 에이징 중지"; Log(s); break; } Handle(s); }
        while(debugReceived.TryDequeue(out s)) { DebugLines.Add(DateTime.Now.ToString("HH:mm:ss.fff ")+s); if(DebugLines.Count>3000) { DebugLines.RemoveRange(0,500); DebugOffset+=500; } if(s.StartsWith("!")) { if(debug!=null) debug.Close(); debug=null; } }
        var now=DateTime.UtcNow; double dt=(now-tick).TotalSeconds; tick=now;
        if(Motion!="" && (Pending=="" || !Robot.Contains("_P")) && !Robot.Contains("_A_")) { Progress=Math.Min(Pending==""?1:.92,Progress+dt/(Pending==""?.18:2.5)); AnimX=FromX+(ToX-FromX)*Progress; AnimY=FromY+(ToY-FromY)*Progress; }
        if(Running && now>=End) { Stop(); State="설정 시간 종료 · 현재 동작 완료 대기"; }
        if((Checking || Pending!="") && now>=deadline) { Stop(); continuing=false; State="응답 시간 초과 · 전송 중지"; deadline=DateTime.MaxValue; }
        if(!Connected) return; if(!Running && !Paused && !continuing && !Checking && !Starting && !Saving && Pending=="" && LampOn && !lampEnding && response==null) FinishLamp(); if(Running && Pending=="" && now>=due && !Saving && !Robot.Contains("_P")) Next(); if(keepAlive && now>=poll) { poll=now.AddSeconds(2); Send("C"); }
    }
    public void Handle(string raw)
    {
        Log("RX [STX]"+raw.Replace("\x06","[ACK]").Replace("\x15","[NAK]")+"[ETX]"); string no=raw.Length>=2 && char.IsDigit(raw[0]) && char.IsDigit(raw[1])?raw.Substring(0,2):"";
        string body=raw.Substring(no.Length); bool nak=body.StartsWith("\x15"), ack=body.StartsWith("\x06"); if(nak || ack) body=body.Substring(1);
        bool controlReply=response!=null && (nak || ack && body==waiting); if(controlReply) response.TrySetResult(!nak);
        if(nak) { LastError=body; if(!controlReply && Pending!="" && number=="") { Stop(); Pending=expected=number=""; } State="명령 거절 "+body; return; }
        if(ack && Pending!="" && number=="" && body==Pending) { number=no; Animate(Pending); }
        if(body.StartsWith("S_")) { Robot=body; PauseWhy=body.Contains("_P")?PauseWhy:""; }
        if(body.Contains("_A_") || body.Contains("ESTOP")) { Stop(); Pending=expected=number=""; Motion=""; continuing=false; State="로봇 알람 · "+body; return; }
        if(body.StartsWith("PPAUSE")) { PauseWhy=body.Substring(body.LastIndexOf(':')+1); if(PauseWhy=="M") { Paused |= Running; Running=false; } State="로봇 일시정지 "+PauseWhy; }
        if(continuing && ack && body.StartsWith("S_")) {
            var states=Regex.Matches(body,@"(?:^|&)S_\d+_([^&]+)"); bool active=states.Count==Racks; foreach(Match m in states) active &= m.Groups[1].Value=="W" || m.Groups[1].Value=="R";
            if(active) { continuing=Paused=false; Running=true; Finished=DateTime.MinValue; State="에이징 재개"; deadline=DateTime.UtcNow.AddSeconds(Timeout); }
        }
        if(Checking && ack && body.StartsWith("S_")) { Checking=false; var states=Regex.Matches(body,@"(?:^|&)S_\d+_([^&]+)"); bool ready=states.Count==Racks; foreach(Match m in states) ready &= m.Groups[1].Value=="W";
            if(!ready) { State="시작 불가 · 원점/대기 상태 확인"; return; } State="시작 램프 확인 중"; Begin();
        }
        if(body==expected && expected!="" && !ack && number!="" && no==number) { Send(body); Pending=expected=number=""; Moves++;
            Stage++; if(Stage==3) { Stage=0; Cycles++; } due=DateTime.UtcNow.AddMilliseconds(300); State=Running?"에이징 실행 중":"현재 동작 완료 · 중지"; if(!Running) Finished=DateTime.UtcNow;
        }
    }
    void Next()
    {
        int rack=Rack[Stage], col=1, floor=random.Next(1,InY+1); string op=Stage==0?"MI":Stage==1?"MO":"PO";
        if(Stage!=0) { col=random.Next(1,(rack%2==1?RightX:LeftX)+1); floor=random.Next(1,(rack%2==1?RightY:LeftY)+1); }
        Floor=floor; Pending=string.Format("{0}_{1}_{2}_{3}_{4:000}_{5:000}_{6:000}_{7:000}_{8:000}",op,rack,col,floor,XY[Stage],Tilt[Stage],Delay[Stage],Pour[Stage],Angle[Stage]); expected=(Stage==0?"AI":Stage==1?"AO":"EO")+"_"+rack+"_"+col+"_"+floor; number=""; deadline=DateTime.UtcNow.AddSeconds(Timeout); Send(Pending);
    }
}
public class Program : Form
{
    Aging aging=new Aging(); readonly List<Aging> robots=new List<Aging>(); readonly Dictionary<string,NumericUpDown> values=new Dictionary<string,NumericUpDown>();
    readonly DataGridView network=new DataGridView { Dock=DockStyle.Fill,AllowUserToAddRows=true,RowHeadersVisible=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,SelectionMode=DataGridViewSelectionMode.FullRowSelect,MultiSelect=false };
    readonly RichTextBox log=new RichTextBox { Dock=DockStyle.Fill,ReadOnly=true,BackColor=Color.FromArgb(19,28,45),ForeColor=Color.White,Font=new Font("Consolas",9),WordWrap=false };
    readonly Label state=new Label { Dock=DockStyle.Top,Height=94 }; readonly PictureBox hmi=new PictureBox { Width=319,Height=478,SizeMode=PictureBoxSizeMode.StretchImage };
    readonly Panel map=new Panel { Dock=DockStyle.Fill,BackColor=Color.White }; readonly FlowLayoutPanel settings=new FlowLayoutPanel { Dock=DockStyle.Fill,AutoScroll=true };
    readonly DataGridView fram=new DataGridView { Dock=DockStyle.Fill,AllowUserToAddRows=false,RowHeadersVisible=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill };
    readonly TextBox logIp=new TextBox { Width=140,Text="172.20.0.101" }; readonly NumericUpDown logPort=new NumericUpDown { Minimum=1,Maximum=65535,Value=50001,Width=80 };
    readonly ComboBox logMode=new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList,Width=140 }; readonly CheckBox all=new CheckBox { Text="FRAM: 연결된 전체 로봇에 적용",AutoSize=true };
    readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer { Interval=33 }; int screen, shown=-1, shownOffset=-1; bool busy, closing; readonly string home=AppDomain.CurrentDomain.BaseDirectory;
    readonly string[] defaults={"1_S_2_1_2_5_4_5_4","1710","40_690","1500_1236_824_412_0","0_515_1030_1540","1500_1236_824_412_0","0_515_1030_1540","0_57_165_100","0","0","0","2500_0_0","0_0_208","1618_0"};
    [STAThread] public static void Main() { Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false); Application.Run(new Program()); }
    public Program()
    {
        Text="Robot Aging · 최대 50대 / HMI / FRAM"; Size=new Size(1560,1000); MinimumSize=new Size(1250,850); Font=new Font("Malgun Gothic",9); StartPosition=FormStartPosition.CenterScreen;
        var root=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=3,RowCount=3,Padding=new Padding(14),BackColor=Color.FromArgb(237,242,248) }; root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,340)); root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,340)); root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100)); root.RowStyles.Add(new RowStyle(SizeType.Absolute,58)); root.RowStyles.Add(new RowStyle(SizeType.Percent,65)); root.RowStyles.Add(new RowStyle(SizeType.Percent,35)); Controls.Add(root);
        var top=new FlowLayoutPanel { Dock=DockStyle.Fill }; root.Controls.Add(top,0,0); root.SetColumnSpan(top,3); top.Controls.Add(new Label { Text="ROBOT AGING",AutoSize=true,Font=new Font("Segoe UI",21,FontStyle.Bold),Width=240 });
        AddButton(top,"전체 에이징 시작",Color.SeaGreen).Click+=delegate { StartAll(true); }; AddButton(top,"전체 에이징 중지",Color.SlateGray).Click+=delegate { foreach(var a in robots) a.Stop(); };
        AddButton(top,"전체 일시정지",Color.DarkGoldenrod).Click+=delegate { foreach(var a in robots.Where(x=>x.Connected)) a.Pause(); };
        var left=new TableLayoutPanel { Dock=DockStyle.Fill,RowCount=3,ColumnCount=1 }; left.RowStyles.Add(new RowStyle(SizeType.Absolute,80)); left.RowStyles.Add(new RowStyle(SizeType.Percent,100)); left.RowStyles.Add(new RowStyle(SizeType.Absolute,110)); root.Controls.Add(left,0,1);
        var nb=new FlowLayoutPanel { Dock=DockStyle.Fill }; left.Controls.Add(nb); AddButton(nb,"입력 IP 연결",Color.RoyalBlue).Click+=async delegate { await ConnectAll(); }; AddButton(nb,"선택 연결 해제",Color.SlateGray).Click+=async delegate { await aging.EndConnection(); }; AddButton(nb,"IP 목록 저장",Color.SlateGray).Click+=delegate { SaveList(); };
        network.Columns.Add("IP","로봇 IP"); network.Columns.Add("Port","포트"); network.Columns.Add("State","상태"); network.Columns[2].ReadOnly=true; network.Columns[0].FillWeight=150; network.Columns[1].FillWeight=65; left.Controls.Add(network);
        network.SelectionChanged+=delegate { int i=network.CurrentCell==null?-1:network.CurrentCell.RowIndex; if(i>=0 && i<robots.Count) SelectRobot(i); }; network.DefaultValuesNeeded+=delegate(object s,DataGridViewRowEventArgs e) { e.Row.Cells[1].Value="2500"; };
        network.UserAddedRow+=delegate { if(network.Rows.Count>51) network.AllowUserToAddRows=false; }; network.UserDeletingRow+=delegate(object s,DataGridViewRowCancelEventArgs e) { e.Cancel=true; MessageBox.Show("행 삭제 대신 IP 칸을 비워 주세요."); };
        var sel=new FlowLayoutPanel { Dock=DockStyle.Fill }; left.Controls.Add(sel); AddButton(sel,"선택 에이징 시작",Color.SeaGreen).Click+=delegate { StartAll(false); }; AddButton(sel,"선택 에이징 중지",Color.SlateGray).Click+=delegate { aging.Stop(); }; sel.Controls.Add(all);
        var hp=new Panel { Dock=DockStyle.Fill,AutoScroll=true }; root.Controls.Add(hp,1,1); hp.Controls.Add(hmi); hmi.Location=new Point(6,4); HmiScreen(0); hmi.MouseClick+=HmiClick; hmi.Paint+=HmiState;
        hp.Controls.Add(new Label { Dock=DockStyle.Bottom,Height=58,Text="현재 STM: PC HMI는 일시정지만 지원\n시작·재개·수동은 실제 HMI 사용\n에이징 시작: 왼쪽 / 상단 버튼",ForeColor=Color.Firebrick });
        var tabs=new TabControl { Dock=DockStyle.Fill }; root.Controls.Add(tabs,2,1); var sim=new TabPage("이동 시뮬레이션"); sim.Controls.Add(map); sim.Controls.Add(state); tabs.TabPages.Add(sim); map.Paint+=DrawMap; typeof(Panel).GetProperty("DoubleBuffered",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(map,true,null);
        var conf=new TabPage("FRAM 설정"); tabs.TabPages.Add(conf); var fp=new TableLayoutPanel { Dock=DockStyle.Fill,RowCount=3 }; fp.RowStyles.Add(new RowStyle(SizeType.Absolute,52)); fp.RowStyles.Add(new RowStyle(SizeType.Percent,100)); fp.RowStyles.Add(new RowStyle(SizeType.Absolute,82)); conf.Controls.Add(fp);
        fp.Controls.Add(new Label { Text="STM 코드 기준 · FP 8~10은 누적 보정(별도 적용)\nFS 좌우 X=5로 좌표 개수 일치 / 저장 중 에이징 중지",Dock=DockStyle.Fill }); fp.Controls.Add(fram);
        fram.Columns.Add("Command","항목"); fram.Columns.Add("Meaning","의미 / 순서"); fram.Columns.Add("Value","값 (_ 구분)"); fram.Columns[0].ReadOnly=fram.Columns[1].ReadOnly=true; fram.Columns[0].FillWeight=40; fram.Columns[1].FillWeight=160; fram.Columns[2].FillWeight=180;
        string[] meanings={"장비/형식/렉수/입고X/Y/좌X/Y/우X/Y","입고 X","입고 Y","좌측 X","좌측 Y","우측 X","우측 Y","리프트 보정/각도/상승거리/속도","Lift 누적 보정","Tilt 누적 보정","Travel 누적 보정","속도: Travel/Tilt/Lift","가감속: Travel/Tilt/Lift","안전위치: Travel/Lift"}; for(int i=0;i<14;i++) fram.Rows.Add(i==0?"FS":"FP "+i,meanings[i],defaults[i]);
        var fb=new FlowLayoutPanel { Dock=DockStyle.Fill }; fp.Controls.Add(fb); AddButton(fb,"FS+FP 저장",Color.RoyalBlue).Click+=async delegate { await SaveFram(false); }; AddButton(fb,"보정 8~10 적용",Color.DarkGoldenrod).Click+=async delegate { await SaveFram(true); }; AddButton(fb,"기본값 입력",Color.SlateGray).Click+=delegate { for(int i=0;i<14;i++) fram.Rows[i].Cells[2].Value=defaults[i]; };
        var opts=new TabPage("에이징 설정"); tabs.TabPages.Add(opts); opts.Controls.Add(settings); Number(settings,"Hours","운전 시간",1,0,999); Number(settings,"Minutes","운전 분",0,0,59); Number(settings,"TimeoutMinutes","완료 제한 분",3,1,1440);
        Number(settings,"Racks","렉 수",2,1,4); Number(settings,"InY","MI 최대 단",2,1,5); Number(settings,"LeftX","좌측 열",5,1,9); Number(settings,"LeftY","좌측 단",4,1,9); Number(settings,"RightX","우측 열",5,1,9); Number(settings,"RightY","우측 단",4,1,9); 
        settings.SetFlowBreak(settings.Controls[settings.Controls.Count-1],true);
        foreach(string op in new[]{"MI","MO","PO"}) {
            var group=new GroupBox { Text=op+" 직접 입력",Width=500,Height=150,Margin=new Padding(3,8,3,3) }; var row=new FlowLayoutPanel { Dock=DockStyle.Fill }; group.Controls.Add(row); settings.Controls.Add(group); settings.SetFlowBreak(group,true);
            Number(row,op+"Rack","렉",1,1,V("Racks")); Number(row,op+"XY","XY 속도 %",80,1,100); Number(row,op+"Tilt","틸트 속도 %",80,1,100); Number(row,op+"Delay","이동 후 대기 ms",500,0,9999); Number(row,op+"Pour","복귀 대기 ×10ms",80,20,300); Number(row,op+"Angle","틸팅 각도 °",45,20,90);
        }
        values["Racks"].ValueChanged+=delegate { foreach(string op in new[]{"MI","MO","PO"}) values[op+"Rack"].Maximum=V("Racks"); };
        settings.SizeChanged+=delegate { foreach(GroupBox group in settings.Controls.OfType<GroupBox>()) group.Width=Math.Max(390,settings.ClientSize.Width-28); };
        settings.Controls.Add(new Label { Text="MI → MO → PO 반복 / 열·단만 랜덤 (MI 열=1)\n최대 열·단은 보드 FRAM의 FS와 같게 입력하세요.\nMI·MO는 속도만 사용, 대기·각도는 PO에서 사용합니다.\n입력값은 에이징 시작 시 적용 / 종료 시 현재 동작 완료 대기",AutoSize=true });
        var logs=new TableLayoutPanel { Dock=DockStyle.Fill,RowCount=2 }; logs.RowStyles.Add(new RowStyle(SizeType.Absolute,80)); logs.RowStyles.Add(new RowStyle(SizeType.Percent,100)); root.Controls.Add(logs,0,2); root.SetColumnSpan(logs,3);
        var lb=new FlowLayoutPanel { Dock=DockStyle.Fill }; logs.Controls.Add(lb); logMode.Items.AddRange(new object[]{"통신 로그","TCP 디버그 로그"}); logMode.SelectedIndex=0; logMode.SelectedIndexChanged+=delegate { shown=-1; }; lb.Controls.Add(logMode); lb.Controls.Add(new Label { Text="로그 IP",AutoSize=true,Padding=new Padding(0,9,0,0) }); lb.Controls.Add(logIp); lb.Controls.Add(logPort);
        AddButton(lb,"로그 연결",Color.RoyalBlue).Click+=async delegate { var a=aging; try { await a.ConnectLog(logIp.Text.Trim(),(int)logPort.Value); logMode.SelectedIndex=1; } catch(Exception e) { MessageBox.Show(e.Message); } }; AddButton(lb,"로그 해제",Color.SlateGray).Click+=delegate { aging.DisconnectLog(); }; AddButton(lb,"로그 저장",Color.SlateGray).Click+=delegate { using(var d=new SaveFileDialog { Filter="Log|*.log",FileName="aging_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".log" }) if(d.ShowDialog()==DialogResult.OK) File.WriteAllLines(d.FileName,logMode.SelectedIndex==0?aging.Lines:aging.DebugLines,Encoding.UTF8); }; logs.Controls.Add(log);
        string path=Path.Combine(home,"robots.tsv"); if(File.Exists(path)) foreach(string row in File.ReadAllLines(path).Take(50)) { var a=row.Split('\t'); if(a.Length>=2) network.Rows.Add(a[0],a[1]); } if(network.Rows.Count==1) network.Rows.Add("172.20.0.101","2500");
        timer.Tick+=delegate { foreach(var a in robots) a.Tick(); RefreshView(); }; timer.Start(); FormClosing+=async delegate(object s,FormClosingEventArgs e) { if(closing) return; e.Cancel=true; if(robots.Any(x=>x.Pending!="") && MessageBox.Show("현재 로봇 동작은 자동 정지되지 않습니다. 종료할까요?","종료",MessageBoxButtons.YesNo)!=DialogResult.Yes) return; SaveList(); await Task.WhenAll(robots.Where(x=>x.Connected).Select(x=>x.EndConnection())); if(robots.Any(x=>x.Connected)) return; closing=true; timer.Stop(); foreach(var a in robots) a.DisconnectLog(); Close(); };

    }
    int V(string key) { return (int)values[key].Value; }
    void Number(FlowLayoutPanel parent,string key,string title,int value,int min,int max) { var box=new FlowLayoutPanel { FlowDirection=FlowDirection.TopDown,AutoSize=true,WrapContents=false,Margin=new Padding(6) }; box.Controls.Add(new Label { Text=title,AutoSize=true }); var n=new NumericUpDown { Minimum=min,Maximum=max,Value=value,Width=110 }; values.Add(key,n); box.Controls.Add(n); parent.Controls.Add(box); }
    void Style(Button b,string text,Color color) { b.Text=text; b.AutoSize=true; b.Height=34; b.Padding=new Padding(8,3,8,3); b.FlatStyle=FlatStyle.Flat; b.BackColor=color; b.ForeColor=Color.White; b.Margin=new Padding(3); }
    Button AddButton(FlowLayoutPanel p,string text,Color color) { var b=new Button(); Style(b,text,color); p.Controls.Add(b); return b; }
    void Write(string text) { Write(aging,text); }
    void Write(Aging a,string text) { a.Lines.Add(DateTime.Now.ToString("HH:mm:ss.fff ")+text); if(a.Lines.Count>3000) { a.Lines.RemoveRange(0,500); a.LogOffset+=500; } }
    void SelectRobot(int i) { aging=robots[i]; logIp.Text=network.Rows[i].Cells[0].Value+""; shown=-1; RefreshView(); }
    async Task ConnectAll()
    {
        if(busy) return; network.EndEdit(); var rows=network.Rows.Cast<DataGridViewRow>().Where(r=>!r.IsNewRow).ToArray(); if(rows.Length>50) { MessageBox.Show("최대 50행입니다."); return; }
        var endpoints=new HashSet<string>(); foreach(var r in rows) { string ip=Convert.ToString(r.Cells[0].Value).Trim(); if(ip=="") continue; int port; System.Net.IPAddress parsed; if(!System.Net.IPAddress.TryParse(ip,out parsed) || !int.TryParse(Convert.ToString(r.Cells[1].Value),out port) || port<1 || port>65535 || !endpoints.Add(ip+":"+port)) { MessageBox.Show("IP·포트 형식 또는 중복 주소를 확인해 주세요."); return; } }
        busy=true; network.ReadOnly=true; while(robots.Count<rows.Length) { var a=new Aging(); a.Log=s=>Write(a,s); robots.Add(a); }
        await Task.WhenAll(rows.Select(async r=>{ var a=robots[r.Index]; string ip=Convert.ToString(r.Cells[0].Value).Trim(), endpoint=ip+":"+r.Cells[1].Value; if(a.Connected && a.Address!=endpoint) { Write(a,"연결 중인 IP 변경: 먼저 연결 해제하세요."); return; } if(ip=="" || a.Connected) return; try { r.Cells[2].Value="연결 중"; await a.Connect(ip,int.Parse(r.Cells[1].Value.ToString())); } catch(Exception e) { a.State="연결 실패"; Write(a,e.Message); } }));
        busy=false; network.ReadOnly=false; network.Columns[2].ReadOnly=true; if(robots.Count>0) SelectRobot(network.CurrentCell==null?0:Math.Min(network.CurrentCell.RowIndex,robots.Count-1));
    }
    void SaveList() { network.EndEdit(); File.WriteAllLines(Path.Combine(home,"robots.tsv"),network.Rows.Cast<DataGridViewRow>().Where(r=>!r.IsNewRow).Take(50).Select(r=>r.Cells[0].Value+"\t"+r.Cells[1].Value),Encoding.UTF8); }
    IEnumerable<Aging> Targets() { return all.Checked?robots.Where(a=>a.Connected).ToArray():new[]{aging}; }
    void StartAll(bool every)
    {
        if(V("Hours")==0 && V("Minutes")==0) { MessageBox.Show("운전 시간을 1분 이상 설정해 주세요."); return; }
        foreach(var a in every?robots.Where(x=>x.Connected):new[]{aging}) { foreach(var p in values) { var f=typeof(Aging).GetField(p.Key); if(f!=null && f.FieldType==typeof(int)) f.SetValue(a,(int)p.Value.Value); } for(int i=0;i<3;i++) { string op=new[]{"MI","MO","PO"}[i]; a.Rack[i]=V(op+"Rack"); a.XY[i]=V(op+"XY"); a.Tilt[i]=V(op+"Tilt"); a.Delay[i]=V(op+"Delay"); a.Pour[i]=V(op+"Pour"); a.Angle[i]=V(op+"Angle"); } a.Timeout=V("TimeoutMinutes")*60; a.Duration=TimeSpan.FromMinutes(V("Hours")*60+V("Minutes")); a.Start(); }
    }
    async Task SaveFram(bool offsets)
    {
        fram.EndEdit(); var targets=Targets().ToArray(); if(targets.Length==0 || targets.Any(a=>!a.Connected || a.Running || a.Checking || a.Starting || a.Pending!="" || a.Saving)) { MessageBox.Show("연결된 로봇의 에이징과 현재 동작을 먼저 끝내 주세요."); return; }
        string[] v=fram.Rows.Cast<DataGridViewRow>().Select(r=>Convert.ToString(r.Cells[2].Value).Trim()).ToArray(); string error=ValidateFram(v,offsets); if(error!="") { MessageBox.Show(error); return; }
        foreach(var a in targets) a.Saving=true; fram.Enabled=false;
        try { await Task.WhenAll(targets.Select(async a=>{ int count=0; foreach(int i in offsets?new[]{8,9,10}:new[]{0,1,2,3,4,5,6,7,11,12,13}) { string command=i==0?"FS_"+v[i]:"FP_1_"+i+"_"+v[i]; if(offsets && v[i]=="0") continue; if(!await a.Request(command)) { a.SaveState="실패 · "+(i==0?"FS":"FP "+i)+" / 이전 항목은 저장됨"; return; } count++; a.SaveState=count+"개 저장 ACK"; } a.SaveState=offsets?"누적 보정 적용 완료":"FS+FP 저장 완료"; if(!offsets) { var fs=v[0].Split('_'); a.Racks=int.Parse(fs[2]); a.InY=int.Parse(fs[4]); a.LeftX=int.Parse(fs[5]); a.LeftY=int.Parse(fs[6]); a.RightX=int.Parse(fs[7]); a.RightY=int.Parse(fs[8]); } })); if(offsets && targets.All(a=>a.SaveState=="누적 보정 적용 완료")) for(int i=8;i<=10;i++) fram.Rows[i].Cells[2].Value="0"; if(!offsets && targets.All(a=>a.SaveState=="FS+FP 저장 완료")) { var f=v[0].Split('_'); string[] keys={"Racks","InY","LeftX","LeftY","RightX","RightY"}; int[] ids={2,4,5,6,7,8}; for(int j=0;j<keys.Length;j++) values[keys[j]].Value=int.Parse(f[ids[j]]); } }
        finally { foreach(var a in targets) a.Saving=false; fram.Enabled=true; }
    }
    public static string ValidateFram(string[] v,bool offsets)
    {
        int n; if(offsets) { for(int i=8;i<=10;i++) if(!int.TryParse(v[i],out n)) return "FP 8~10은 정수 하나씩 입력하세요."; return ""; }
        var fs=v[0].Split('_'); if(fs.Length!=9 || fs[0]!="1" || fs[1]!="S" && fs[1]!="I") return "FS 형식: 1_S_렉수_입고X_입고Y_좌X_좌Y_우X_우Y";
        for(int i=2;i<9;i++) if(!int.TryParse(fs[i],out n) || n<1 || n>(i==2?4:i==3?1:i==4?5:9)) return "FS 개수 범위를 확인하세요.";
        int[] lengths={0,1,int.Parse(fs[4]),int.Parse(fs[5]),int.Parse(fs[6]),int.Parse(fs[7]),int.Parse(fs[8]),4,1,1,1,3,3,2};
        for(int i=1;i<14;i++) { if(i>=8 && i<=10) continue; var a=v[i].Split('_'); if(a.Length!=lengths[i]) return "FP "+i+" 값 개수가 FS 또는 항목 형식과 다릅니다."; foreach(string s in a) if(!int.TryParse(s,out n) || i==11 && (n<0 || n>3000)) return "FP "+i+" 숫자/속도 범위를 확인하세요."; } return "";
    }
    void HmiScreen(int page) { screen=page; string f=Path.Combine(home,"assets",page==0?"Main_screen.png":page==1?"Manual_screen.png":"Setup_screen.png"); if(hmi.Image!=null) hmi.Image.Dispose(); hmi.Image=Image.FromFile(f); }
    async void HmiClick(object sender,MouseEventArgs e)
    {
        int x=e.X*319/hmi.ClientSize.Width,y=e.Y*478/hmi.ClientSize.Height; if(screen==0) { if(y>=192 && y<=261 && x>=90 && x<=226) await aging.Button(11); else if(y>=296 && y<=367 && x>=90 && x<=226) await aging.Button(12); else if(y>=397 && y<=444) { if(x>=24 && x<=122) HmiScreen(2); else if(x>=194 && x<=291) HmiScreen(1); } }
        else if(screen==1) { if(y>=410 && y<=455 && x>=88 && x<=232) HmiScreen(0); else { int b=y>=103 && y<=149?21:y>=217 && y<=264?23:y>=331 && y<=377?25:0; if(b!=0 && (x>=40 && x<=137 || x>=181 && x<=278)) await aging.Button(b+(x>=160?1:0)); } }
        else { if(y>=409 && y<=455 && x>=88 && x<=232) HmiScreen(0); else if(y>=107 && y<=154 && x>=50 && x<=264) await aging.Button(31); else if(y>=269 && y<=314) { if(x>=28 && x<=125) { await aging.Button(32); if(aging.LastError=="") HmiScreen(0); } else if(x>=193 && x<=290) { await aging.Button(33); if(aging.LastError=="") HmiScreen(1); } } }
    }
    void RefreshView()
    {
        for(int i=0;i<robots.Count;i++) { if(!Equals(network.Rows[i].Cells[2].Value,robots[i].State)) network.Rows[i].Cells[2].Value=robots[i].State; network.Rows[i].Cells[0].ReadOnly=network.Rows[i].Cells[1].ReadOnly=robots[i].Connected; } var elapsed=aging.Started==DateTime.MinValue?TimeSpan.Zero:(aging.Finished==DateTime.MinValue?DateTime.UtcNow:aging.Finished)-aging.Started; var remain=aging.End>DateTime.UtcNow?aging.End-DateTime.UtcNow:TimeSpan.Zero;
        state.Text=aging.Address+"  |  "+aging.State+"\n"+aging.Robot+"\n완료 "+aging.Moves+" / 순환 "+aging.Cycles+" / 최근 "+aging.Floor+"단 · 경과 "+HM(elapsed)+" / 남음 "+HM(remain)+"\nFRAM: "+aging.SaveState+"  | 로그 "+(aging.LogConnected?"연결":"해제")+"  |  "+aging.LastError;
        var lines=logMode.SelectedIndex==0?aging.Lines:aging.DebugLines; int offset=logMode.SelectedIndex==0?aging.LogOffset:aging.DebugOffset; bool changed=false;
        if(shown<0 || shownOffset!=offset || shown>offset+lines.Count) { log.Text=string.Join(Environment.NewLine,lines)+(lines.Count==0?"":Environment.NewLine); shown=offset+lines.Count; shownOffset=offset; changed=true; }
        else if(shown<offset+lines.Count) { log.AppendText(string.Join(Environment.NewLine,lines.Skip(shown-offset))+Environment.NewLine); shown=offset+lines.Count; changed=true; }
        if(changed && log.TextLength>0) { log.SelectionStart=log.TextLength; log.ScrollToCaret(); } map.Invalidate(); hmi.Invalidate();

    }
    void HmiState(object sender,PaintEventArgs e)
    {
        if(screen!=0) return; string task=!aging.Connected?"미연결":aging.Robot.Contains("_A_")?"알람":aging.Robot.Contains("_I")?"원점복귀":aging.Robot.Contains("_R")?"운전 중":aging.Robot.Contains("_W")?"대기":"상태 확인";
        string[] text={task,aging.Robot.Contains("_P")?"일시정지 "+aging.PauseWhy:"없음",aging.Robot.Contains("_A_")?aging.Robot.Split('&').FirstOrDefault(x=>x.Contains("_A_")):"없음"};
        for(int i=0;i<3;i++) { e.Graphics.FillRectangle(Brushes.White,115,26+i*54,176,31); using(var font=new Font(Font.FontFamily,13)) e.Graphics.DrawString(text[i]??"-",font,Brushes.Black,117,28+i*54); }
    }
    static string HM(TimeSpan t) { return ((int)t.TotalHours)+"시간 "+t.Minutes+"분"; }
    void DrawMap(object sender,PaintEventArgs e)
    {
        var g=e.Graphics; g.SmoothingMode=SmoothingMode.AntiAlias; float w=map.Width,h=map.Height,span=Math.Min(340,w-32),left=(w-span)/2,rack=90;
        g.DrawString("명령 기반 애니메이션 · 실측 위치 아님",Font,Brushes.SlateGray,12,8); g.DrawString("1렉 · 왼쪽",Font,Brushes.Black,left,35); g.DrawString("2렉 · 오른쪽",Font,Brushes.Black,left+span-rack,35);
        float top=70,bottom=Math.Max(top+80,h-65); for(int side=0;side<2;side++) { float x=side==0?left:left+span-rack; g.DrawRectangle(Pens.Black,x,top,rack,bottom-top); for(int i=1;i<8;i++) g.DrawLine(Pens.Gray,x,top+(bottom-top)*i/8,x+rack,top+(bottom-top)*i/8); }
        using(var pen=new Pen(Color.LightGray,10)) g.DrawLine(pen,w/2,top,w/2,bottom); float rx=left+(float)(span*aging.AnimX),ry=top+(float)(aging.AnimY*(bottom-top)); g.FillEllipse(Brushes.Black,rx-13,ry-13,26,26); g.DrawString("MI ↑   MO ↓   PO ← 1렉 / 2렉 →",Font,Brushes.Black,Math.Max(8,w/2-145),h-42); g.DrawString(aging.Motion,Font,Brushes.SlateGray,12,h-23);

    }
}
