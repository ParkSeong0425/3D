/*
 * modbus.c : 모터 글 모양 (Modbus RTU) — a_motor (t_motor) 가 씀 (11/23 : 모터 파일마다 따로 있던 crc16 · read_reg · read_regs 를 하나로)
 *
 *  MB_Crc    CRC16 계산 (쓰기 · 읽기 글 끝 2바이트)
 *  MB_Read   FC03 읽기 : [ID][03][reg H][reg L][00][qty][CRC L][CRC H] → 대답 [ID][03][qty×2][데이터 …][CRC L][CRC H]
 *  MB_Write  06 · 10 쓰기 : 드라이브 칸에 값을 넣음 (11/25 : threeD_roder 11/24 것 그대로)
 *
 *  32비트 값을 두 칸으로 나누는 순서 (위 칸 먼저 / 아래 칸 먼저) 는 드라이브마다 달라서 모터 파일이 정함
 */
#include "modbus.h"
#include "usart.h"          /* UART2_Xfer · UART2_Send (선 · 열쇠 · DMA), MOTOR_RETRY */
#include <string.h>         /* memcmp */

/* CRC16 Modbus : 0xFFFF 에서 시작, 바이트마다 8번 밀면서 0xA001 로 섞음 */
uint16_t MB_Crc(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;

    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 1) crc = (crc >> 1) ^ 0xA001;     /* 맨 아래 비트 1 : 밀고 섞음 */
            else         crc = crc >> 1;                /* 0 : 밀기만 */
        }
    }
    return crc;
}

/* FC03 읽기 : 성공 1 / tries 번 다 실패 0 (대답 없음 · 길이 · ID · 기능 · CRC 중 하나라도 틀림) */
int MB_Read(uint8_t id, uint16_t reg, uint8_t qty, uint16_t *out, uint8_t tries, uint32_t wait_ms)
{
    uint8_t tx[8], rx[32];
    uint16_t n = 5 + qty * 2;                           /* 대답 길이 : ID 기능 길이 + 데이터 qty×2 + CRC 2 */
    uint16_t crc;

    tx[0] = id;          tx[1] = 0x03;                  /* 1. 물음 만들기 */
    tx[2] = reg >> 8;    tx[3] = (uint8_t)reg;
    tx[4] = 0;           tx[5] = qty;
    crc = MB_Crc(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);  /*    CRC 만 작은 바이트 먼저 */

    for (uint8_t retry = 0; retry < tries; retry++) {
        if (UART2_Xfer(tx, 8, rx, n, wait_ms) == 0) continue;          /* 2. 묻고 받기 (안 오면 다시) */
        crc = MB_Crc(rx, n - 2);
        if (rx[0] == id && rx[1] == 0x03 && rx[2] == qty * 2           /* 3. 검사 : 누가 · 무슨 기능 · 길이 */
                && rx[n - 2] == (uint8_t)crc && rx[n - 1] == (uint8_t)(crc >> 8)) {   /*    CRC */
            for (uint8_t i = 0; i < qty; i++)
                out[i] = ((uint16_t)rx[3 + i * 2] << 8) | rx[4 + i * 2];   /* 4. 칸마다 큰 바이트 먼저 */
            return 1;
        }
    }
    return 0;
}

/* 06 한 칸   보내기 : ID · 06 · 주소 2 · 값 2 · CRC 2                                    대답 = 보낸 것 그대로
   10 여러 칸 보내기 : ID · 10 · 시작 주소 2 · 워드 수 2 · 데이터 바이트 수 · 값들 · CRC 2   대답 = ID · 10 · 주소 2 · 워드 수 2 · CRC 2
   ID 0 = 방송 (대답 없음).  예) 틸트 속도 01 06 00 36 00 64 68 2F */
int MB_Write(uint8_t id, uint16_t reg, uint8_t reg_gaesu, const uint16_t *data, uint32_t wait_ms)
{
    uint8_t tx[32], rx[8];                  /* 보낼 글 (워드 11개까지) · 받을 글 */
    uint16_t len, crc;

    /* 보내기 */
    if (reg_gaesu == 1) {                   /* 06 */
        tx[0] = id;  tx[1] = 0x06;  tx[2] = reg >> 8;  tx[3] = reg & 0xFF;  tx[4] = data[0] >> 8;  tx[5] = data[0] & 0xFF;
        len = 6;
    } else {                                /* 10 */
        tx[0] = id;  tx[1] = 0x10;  tx[2] = reg >> 8;  tx[3] = reg & 0xFF;  tx[4] = 0;  tx[5] = reg_gaesu;  tx[6] = reg_gaesu * 2;
        for (uint8_t i = 0; i < reg_gaesu; i++) {
            tx[7 + i * 2] = data[i] >> 8;  tx[8 + i * 2] = data[i] & 0xFF;      /* 값 : 큰 바이트 먼저 */
        }
        len = 7 + reg_gaesu * 2;
    }
    crc = MB_Crc(tx, len);
    tx[len] = crc & 0xFF;  tx[len + 1] = crc >> 8;                          /* CRC 작은 것 먼저 */
    len = len + 2;

    if (id == 0) return UART2_Send(tx, len);                                /* 방송 : 대답 없음 */

    /* 대답 : 앞 6바이트가 보낸 글과 같고 CRC 맞으면 성공 */
    for (uint8_t n = 0; n < MOTOR_RETRY; n++) {
        if (UART2_Xfer(tx, len, rx, 8, wait_ms) == 0) continue;
        if (memcmp(rx, tx, 6) == 0 && MB_Crc(rx, 6) == rx[6] + rx[7] * 256) return 1;
    }
    return 0;
}
