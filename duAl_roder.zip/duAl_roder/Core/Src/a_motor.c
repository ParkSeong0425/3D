#include "a_motor.h"
#include "usart.h"
#include "modbus.h"        /* MB_Read · MB_Write : 글 모양 (11/23 · 25) */
#include "flag.h"          /* BOARD_NEW : 칠판 새로 적음 초인종 */
#include "cmsis_os2.h"
#include "save.h"          /* save.fp 속도 · 가감속 (speed_rpm · accdec_ms) */
#include "status.h"        /* Motor_Stop : 긴급정지 · 알람이면 안 움직임 */
#include "alarm.h"         /* MOVE_MS (AM_Arrive 기다림 제한 8초) */
#include "fram.h"          /* FRAM_YRead : Y init 끝에 FRAM 높이로 칠판 맞춤 (11/27) */
#include <stdarg.h>
#include <stdlib.h>

/* 통신 */
/* DI Function / Logic */
#define R_DI1_FUNC      0x0302   /* H03_02 : Home Switch */
#define R_DI2_LOGIC     0x0305   /* H03_05 : Servo Enable */
#define R_DI4_LOGIC     0x0309   /* H03_09 : Position Run */
#define R_DI5_LOGIC     0x030B   /* H03_11 : Emergency Stop */
#define R_DI8_FUNC      0x0310   /* H03_16 : JOG_CMD+ (18) */
#define R_DI8_LOGIC     0x0311   /* H03_17 */
#define R_DI9_LOGIC     0x0313   /* H03_19 : JOG_CMD- */
#define R_JOG_SPEED     0x0604   /* H06_04 JOG 속도 rpm */
#define R_TORQUE_MAX    0x0709   /* H07_09 + 토크 제한 (다음 칸 0x070A = H07_10 - 토크 제한, 2칸 같이 씀) : X 만 (11/26) */
/* 위치 / HOME */
#define R_MODE          0x0200   /* H02_00 Control mode */
#define R_PULSE_REV     0x0509   /* H05_09 모터 1바퀴 펄스 (32bit, 바로 적용) */
#define R_POS_SOURCE    0x0500   /* H05_00 Position source */
#define R_HOME_START    0x051E   /* H05_30 */
#define R_HOME_MODE     0x051F   /* H05_31 */
#define R_HOME_FAST     0x0520   /* H05_32 */
#define R_HOME_SLOW     0x0521   /* H05_33 */
#define R_HOME_ACC      0x0522   /* H05_34 */
#define R_HOME_TIMEOUT  0x0523   /* H05_35 */
#define R_HOME_OFFSET   0x0524   /* H05_36 : 32bit */
#define R_HOME_TORQUE   0x053A   /* H05_58 */
/* 상태 */
#define R_TORQUE        0x0B02   /* H0B_02 지금 토크 (0.1%, 부호) : X 칠판 묶어 읽기 시작 (11/26) */
#define R_REAL_POS      0x0B07   /* H0B_07 Absolute position (2칸, 아래 칸 먼저) */
#define R_ALARM         0x0B22   /* H0B_34 Fault code (34 = 0x22 : 다른 주소처럼 뒤 번호를 16진수로) */
#define R_ALARM_RESET   0x0D01   /* H0D_01 Error reset */
#define R_DO1_FUNC      0x0400   /* H04_00 DO1 function */
#define R_DO2_FUNC      0x0402   /* H04_02 DO2 function */
#define R_DO_STATE      0x0B05   /* H0B_05 DO monitor */
#define R_POS_DONE_GAP  0x0515   /* H05_21 Position complete gap */
/* 다단 위치운전 */
#define R_RUN_MODE      0x1100   /* H11_00 Single cycle */
#define R_MOVE_TYPE     0x1104   /* H11_04 1=Absolute */
#define R_MOVE_POS      0x110C   /* H11_12 ~ H11_16 */
/* EEPROM */
#define R_ADDR          0x0C00   /* H0C_00 Servo axis address */
#define R_BAUD          0x0C02   /* H0C_02 Baud rate */
#define R_EEPROM_SAVE   0x0C0D   /* H0C_13 Save EEPROM */
#define R_RESET         0x0D00   /* H0D_00 Software reset */
#define OLD_BAUD        57600    /* A motor 공장 설정 */
#define BAUD_CODE       6        /* H0C_02 : 6 = 115200 */
#define SAVE_WAIT       100      /* EEPROM 기록 대기 */
#define RESET_WAIT      3000     /* 드라이브 재시작 대기 */

int32_t y_home_setting[Dual_ID + 1];   /* 켤 때 Y 높이 (코드 방향 펄스, 1 · 4 만) : 칠판 = 드라이브 + 이것. AM_Init 끝에 FRAM 으로 넣음 (Y 는 브레이크라 믿음) · Y 원점 끝나면 0 (11/27) */
int Remember_pos[Dual_ID + 1];         /* 1 = 그 대 칠판 위치가 진짜 → run.c REG_FRAM 이 FRAM 에 적음 (11/27)
                                          Y (1 · 4) : init 때 FRAM 으로 맞추거나 Y 원점 끝 / X (3 · 6) : X 원점 끝 / 대답 MOTOR_MISS 번 없음 (꺼짐) = 0 */
volatile MOTOR am[Dual_ID + 1];    /* 칠판 6대 : 칸 번호 = 드라이브 주소 (am[3] = A 의 X, [0] 안 씀). 위치는 펄스 (코드 방향 : 위 = + · x2 쪽 = +). Bus_Task AM_Read 가 MOTOR_MS 마다 적음 (듀얼) */

/* 드라이브 6대 설정표 [현장] : 한 줄 = 한 대 (칸 번호 = 주소)
   칸 모양 = a_motor.h Dual_roder_information. 방향은 표가 아니라 AM_Move · AM_Read · AM_Jog 의 "거꾸로 달린 모터 (1 · 4 · 3)" 줄 (11/26)
   x1 · x2 는 H02_02 둘 다 1 인데 조립 차이로 반대로 감 → x1 만 거꾸로 (11/25 0B07 로 확인) */
static const Dual_roder_information ax[Dual_ID + 1] = {
/*     1바퀴         이동   원점     오프셋       토크 */
    {  0,            0,    0,     0,         0     },   /* 0 안 씀 */
    {  Y_PULSE_REV,  1,    10,   -Y_MM(50),  1000  },   /* 1 y1 : 거꾸로 (드라이브 + = 아래) → 아래 벽 = + 쪽(10) · 50mm 위 = - · 서 있기만 59 ~ 68% */
    {  T_PULSE_REV,  1,    0,     0,         1000  },   /* 2 t1 : 보류 (TL57, 다음 주). + = 1렉 · 센서가 DI2 로 들어와 서보 안 켜짐 (11/26) */
    {  X_PULSE_REV,  0,    11,    X_MM(50),  1000  },   /* 3 x1 : 거꾸로 (드라이브 + = 원점 벽 쪽, 조립이 x2 와 반대) · 100% 로 가짜 닿음 (11/25) */
    {  Y_PULSE_REV,  1,    10,   -Y_MM(50),  1000  },   /* 4 y2 : y1 과 같음 (거꾸로) */
    {  T_PULSE_REV,  1,    0,     0,         1000  },   /* 5 t2 : 보류 (TL57, 다음 주). + = 2렉 */
    {  X_PULSE_REV,  0,    10,   -X_MM(50),  1000  },   /* 6 x2 : 드라이브 + = 먼 벽 쪽 → 원점 벽 = - 쪽(10) */
};

/* 06 · 10 쓰기 : 줄줄이 받은 값을 칸 배열로 모아 MB_Write 에 넘김 (글 모양 · 다시 묻기 · 검사는 modbus.c, 11/25)
   id = 드라이브 주소 1 ~ 6, qty = 칸 수 (1 = 06 · 2 이상 = 10). 기다림 Y_RX_MS (AIM, comm.h) 는 여기 한 곳 */
static int write_regs(uint8_t id, uint16_t reg, uint8_t qty, ...)
{
    uint16_t data[11];                          /* 쓸 칸들 (MB_Write 한 번에 11칸까지) */
    va_list ap;

    if (qty > 11) return 0;                     /* 너무 많음 */
    va_start(ap, qty);
    for (uint8_t i = 0; i < qty; i++)
        data[i] = (uint16_t)va_arg(ap, int);    /* 값 하나씩 꺼내 칸에 */
    va_end(ap);
    return MB_Write(id, reg, qty, data, Y_RX_MS);
}
/* 03H : 16bit / 32bit 읽기. qty 1 = 16bit / qty 2 = 32bit (아래 칸이 먼저). 읽었으면 1
   tries = 묻는 횟수 · rx_ms = 대답 기다림 (Bus_Task : 1번 · MOTOR_WAIT_MS / 그 밖 · CLI : MOTOR_RETRY · Y_RX_MS)
   (11/26 : 안쪽 read_regs 와 CLI 용 포장 AM_ReadReg 를 하나로) */
int AM_ReadReg(uint8_t id, uint16_t reg, int32_t *out, uint8_t qty, uint8_t tries, uint32_t rx_ms)
{
    uint16_t w[2];                                      /* 받은 칸 : [0] 아래 칸 · [1] 위 칸 */

    if (MB_Read(id, reg, qty, w, tries, rx_ms) == 0) return 0;   /* 글 모양 · 검사는 modbus.c (11/23) */
    if (qty == 1) { *out = w[0]; return 1; }            /* 16비트 */
    *out = (int32_t)(((uint32_t)w[1] << 16) | w[0]);    /* 32비트 : Y(AIM) 는 아래 칸 먼저 (장치 지식) */
    return 1;
}

/* % → rpm : 100% = FP 11 Y 속도 (0 이면 AM_MAX_RPM) */
static int speed_rpm(int percent)
{
    if (save.fp.speed_y == 0) return percent * AM_MAX_RPM / 100;    /* 안 정함 : 기본값 */
    return percent * save.fp.speed_y / 100;                         /* FP 11 */
}

/* 가감속 ms : FP 12 Y (0 이면 AM_ACC_DEC_MS) */
static int accdec_ms(void)
{
    if (save.fp.accdec_y == 0) return AM_ACC_DEC_MS;    /* 안 정함 : 기본값 */
    return save.fp.accdec_y;                            /* FP 12 */
}
/* id 통신 확인 : H0C_00 주소가 id 와 같나 */
static int check_id(uint8_t id)
{
    int32_t address;
    return AM_ReadReg(id, R_ADDR, &address, 1, MOTOR_RETRY, Y_RX_MS) && address == id;
}

/* 모터 기능 */
/* id 드라이브를 pulse 자리로 이동 (원점 0 기준 자리, 6대 다 같음) (H11_12 ~ 16 : 위치 · 속도 · 가감속 · 기다림 → DI4 켜면 출발)
   설정표 이동 칸이 상대 (0, 지금 X) 인 대는 여기서 "목표 − 칠판 지금" 으로 바꿔 보냄 → 부르는 쪽은 늘 자리만 넘김
   (모터가 절대로 바뀌면 설정표 칸만 1 로. 11/27) ⚠ 칠판은 MOTOR_MS 마다 적힘 → 멈춘 뒤 바로 다시 보낼 땐 2 × MOTOR_MS 기다림
   pulse = 코드 방향 (위 = + · x2 쪽 = + · t1 1렉 · t2 2렉 = +). 먼저 AM_Init(id)
   긴급정지 · 알람이면 안 움직임 (알람이어도 수동 모드면 움직임 : 끼임 풀기) */
int AM_Move(uint8_t id, int32_t pulse, int percent)
{
    uint32_t raw;                                           /* 보낼 32비트 → 두 칸으로 : 아래 칸 먼저 (AIM) */

    if (ax[id].move_type == 0) pulse = pulse - am[id].pos;  /* 상대 이동 대 (X) : 목표 자리 − 지금 자리 = 갈 거리 */
    pulse = pulse - y_home_setting[id];                     /* 칠판 위치 → 드라이브 위치 (켤 때 FRAM Y 높이 뺌, Y 만 · 나머지 0) */
    if (id == 1 || id == 4 || id == 3) pulse = -pulse;      /* 거꾸로 달린 모터 (y1 · y2 · x1) : 반대로 */
    if (id == 2 || id == 5 || id == 6) pulse = pulse;       /* 바로 달린 모터 (t1 · t2 · x2) : 그대로 */
    raw = (uint32_t)pulse;

    if (Motor_Stop()) return 0;                            /* 문 2 : 긴급정지 · 알람이면 안 움직임 (status.c) */
    return write_regs(id, R_DI4_LOGIC, 1, 0)
        && write_regs(id, R_MOVE_POS, 5,
            (uint16_t)raw,
            (uint16_t)(raw >> 16),
            speed_rpm(percent),
            accdec_ms(),
            AM_WAIT_MS)
        && write_regs(id, R_DI4_LOGIC, 1, 1);
}

/* 원점 출발 (안 기다림) : 속도 · 토크 → H05_30 = 4. 벽 닿으면 드라이브가 오프셋 (H05_36, 5cm) 까지 스스로 감
   끝은 AM_HomeEnd 로 물음 (기다림 · 60초 제한은 부르는 쪽 run.c I). 보냈으면 1 */
int AM_Home(uint8_t id)
{
    write_regs(id, R_HOME_FAST,    1, AM_HOME_HI_RPM);   /* 즉시 바뀌는 것만 (Enable OFF 항목은 AM_Init) */
    write_regs(id, R_HOME_SLOW,    1, AM_HOME_LO_RPM);
    write_regs(id, R_HOME_TORQUE,  1, ax[id].home_torque);   /* 축마다 (설정표) */

    if (write_regs(id, R_HOME_START, 1, 4) == 0) return 0;   /* 원점 출발 (못 보내면 바로 실패) */
    osDelay(AM_HOME_ACC_MS);       /* 이전 원점완료 신호 꺼질 시간 */
    return 1;
}

/* 원점 끝났나 (한 번 물음) : 벽 닿음 (DO2) → AM_ACC_DEC_MS 기다림 → 5cm 도착 (COIN) → 그 자리 0 잡고 1 / 아직 0
   닿은 순간엔 아직 5cm 출발 전이라 COIN 이 켜져 있을 수 있음 → 기다린 뒤 다시 읽어 COIN 을 믿음 (11/26 : touch 배열 대신 기다림) */
int AM_HomeEnd(uint8_t id)
{
    int32_t state;                                                      /* DO 상태 H0B_05 : 1 = COIN (도착) · 2 = 원점 닿음 */

    if (AM_ReadReg(id, R_DO_STATE, &state, 1, MOTOR_RETRY, Y_RX_MS) == 0) return 0;
    if ((state & 2) == 0) return 0;                                     /* 아직 안 닿음 */
    osDelay(AM_ACC_DEC_MS);                                             /* 닿음 → 5cm 출발할 때까지 */
    if (AM_ReadReg(id, R_DO_STATE, &state, 1, MOTOR_RETRY, Y_RX_MS) == 0) return 0;
    if ((state & 1) == 0) return 0;                                     /* 5cm 가는 중 */
    if (write_regs(id, R_HOME_START, 1, 6) == 0) return 0;              /* 지금 자리 = 0 */
    y_home_setting[id] = 0;                                             /* 진짜 0 을 잡음 → 더할 FRAM 높이 없앰 */
    Remember_pos[id] = 1;                                               /* 이제 칠판 위치가 진짜 → FRAM 에 적어도 됨 */
    return 1;
}

/* 멈춤 : 이동 · 원점 · JOG 따로 다 보냄 (하나 실패해도 나머지는 세움) */
int AM_Stop(uint8_t id)
{
    int a = write_regs(id, R_DI4_LOGIC, 1, 0);  /* 1. 이동 멈춤 */
    int b = write_regs(id, R_HOME_START, 1, 0); /* 2. 원점 멈춤 */
    int c = AM_Jog(id, 0, 0);                   /* 3. JOG 멈춤 (DI8 · DI9 끔, 11/26 : 전엔 stop · E_S 해도 JOG 는 계속 감) */
    return a && b && c;
}
/* 비상정지 DI5 켜기 · 끄기 : 6대 따로 다 보냄 (하나 실패해도 나머지는 보냄), 다 되면 1 */
int AM_EStop(int on)
{
    int ok = 1;

    for (uint8_t id = 1; id <= Dual_ID; id++)
        if (write_regs(id, R_DI5_LOGIC, 1, on) == 0) ok = 0;
    return ok;
}

/* 수동 JOG (DI 기능 18 JOG_CMD+ · 19 JOG_CMD-, 속도 H06_04) : 켜 있는 동안 감, 끄면 섬
   dir +1 = 코드 + 쪽 (Y 위 · x2 쪽 · t1 1렉 · t2 2렉) / -1 = 반대 / 0 = 멈춤 (따로 다 보냄) */
int AM_Jog(uint8_t id, int dir, int percent)
{
    /* 멈춤 */
    if (dir == 0) {
        int a = write_regs(id, R_DI8_LOGIC, 1, 0);      /* JOG+ 끔 */
        int b = write_regs(id, R_DI9_LOGIC, 1, 0);      /* JOG- 끔 */
        return a && b;
    }
    if (Motor_Stop()) return 0;                     /* 문 2 : 긴급정지 · 알람이면 안 움직임 */

    if (id == 1 || id == 4 || id == 3) dir = -dir;  /* 거꾸로 달린 모터 (y1 · y2 · x1) : 반대로 (AM_Move 와 같은 줄) */
    if (id == 2 || id == 5 || id == 6) dir = dir;   /* 바로 달린 모터 (t1 · t2 · x2) : 그대로 */

    if (write_regs(id, R_JOG_SPEED, 1, speed_rpm(percent)) == 0) return 0;   /* 속도 */
    if (dir == 1) return write_regs(id, R_DI8_LOGIC, 1, 1);     /* + 로 (JOG+) */
    return write_regs(id, R_DI9_LOGIC, 1, 1);                    /* - 로 (JOG-) */
}

/* id 가 pulse 자리에 도착할 때까지 기다림 (최대 MOVE_MS) : 도착 1 / 못 감 · 긴급정지 · 알람 0 (알람은 run.c 가 A_06)
   선에 묻지 않고 칠판(am[id], Bus_Task 가 MOTOR_MS 마다 적음)만 봄 (11/17 B1) */
int AM_Arrive(uint8_t id, int32_t pulse)
{
    uint32_t start = osKernelGetTickCount();

    while (abs(am[id].pos - pulse) >= 100) {                            /* 아직 100펄스 넘게 멂 (Y 10mm) */
        if (osKernelGetTickCount() - start > MOVE_MS) return 0;         /* MOVE_MS 넘음 */
        if (Motor_Stop()) return 0;                                     /* 긴급정지 · 알람 */
        osThreadFlagsWait(BOARD_NEW, osFlagsWaitAny, 2 * MOTOR_MS);   /* 칠판 새로 적힐 때까지 (Bus_Task 초인종) */
    }
    return 1;
}

/* (Bus_Task) id → 칠판 am[id] : 한 번씩만 (MOTOR_WAIT_MS). 받으면 1
   ① 위치 H0B_07 (0B07 부터 2칸) → pos (펄스 그대로). 못 받으면 칠판 그대로 + miss 올림 (다음 바퀴에 다시)
      X (3 · 6) 는 0B02 부터 6칸 한 번에 : 토크 + 위치 (11/26). AIM 은 없는 번호 (0B04 · 0B06) 를 건너뛰고 다음 칸을 이어 보냄 (매뉴얼 69쪽)
      (11/17 의 0B05 부터 4칸 묶어 읽기가 위치 -6553 처럼 나온 건 0B06 을 한 칸으로 센 탓으로 보임 → 11/27 보드로 확인)
   ② 고장 코드 H0B_34 (0B22) → alarm. 드라이브 알람은 드라이브가 스스로 서는 고장이라 대마다 1초에 한 번이면 충분
      6대가 같은 바퀴에 몰리지 않게 시작 칸을 2바퀴씩 어긋나게 → 한 바퀴에 많아야 한 대만 더 물음 (듀얼) */
int AM_Read(uint8_t id)
{
    static uint8_t count[Dual_ID + 1] = {0, 0, 2, 4, 6, 8, 10};   /* 대마다 몇 바퀴째 (고장 코드 묻기용, 어긋나게 시작) */
    int32_t pulse;              /* 위치 펄스 */
    int32_t code;               /* 고장 코드 */

    if (id == 3 || id == 6) {                                               /* ① X : 토크 · DI · DO · 위치 한 번에 (11/26) */
        uint16_t w[6];                                                      /*    0B02 토크 · 0B03 DI 2칸 · 0B05 DO · 0B07 위치 2칸 */
        if (MB_Read(id, R_TORQUE, 6, w, 1, MOTOR_WAIT_MS) == 0) {
            am[id].miss++;
            if (am[id].miss >= MOTOR_MISS) Remember_pos[id] = 0;            /*    대답 3번 연달아 없음 = 꺼짐 → 위치 잃음 (FRAM 안 덮어씀) */
            return 0;
        }
        am[id].torque = (int16_t)w[0];
        pulse = (int32_t)(((uint32_t)w[5] << 16) | w[4]);                   /*    위치 : 아래 칸 먼저 (AIM) */
    }
    else if (AM_ReadReg(id, R_REAL_POS, &pulse, 2, 1, MOTOR_WAIT_MS) == 0) {   /* ① Y · 틸트 : 위치만 (매 바퀴) */
        am[id].miss++;
        if (am[id].miss >= MOTOR_MISS) Remember_pos[id] = 0;                /*    대답 3번 연달아 없음 = 꺼짐 → 위치 잃음 */
        return 0;
    }
    if (id == 1 || id == 4 || id == 3) pulse = -pulse;      /* 거꾸로 달린 모터 (y1 · y2 · x1) : 반대로 (AM_Move 와 같은 줄) */
    if (id == 2 || id == 5 || id == 6) pulse = pulse;       /* 바로 달린 모터 (t1 · t2 · x2) : 그대로 */
    am[id].pos  = pulse + y_home_setting[id];               /* 코드 방향 펄스 + 켤 때 FRAM Y 높이 (Y 만). mm 는 부르는 쪽 */
    am[id].miss = 0;

    count[id]++;
    if (count[id] >= 1000 / MOTOR_MS) {                       /* ② 고장 코드 : 대마다 약 1초에 한 번 */
        count[id] = 0;
        if (AM_ReadReg(id, R_ALARM, &code, 1, 1, MOTOR_WAIT_MS)) am[id].alarm = (uint16_t)code;   /* 못 받으면 그대로 (1초 뒤 다시) */
    }
    return 1;
}
/* 드라이브 알람 리셋 (H0D_01) : 6대 따로 다 보냄, 다 되면 1 */
int AM_AlarmReset(void)
{
    int ok = 1;

    for (uint8_t id = 1; id <= Dual_ID; id++)
        if (write_regs(id, R_ALARM_RESET, 1, 1) == 0) ok = 0;
    return ok;
}
/* id 확인 + DI + 이동 + 토크 HOME 설정 + 서보 켜기. id = 드라이브 주소 1 ~ 6 (듀얼)
   Y (1 · 4) 는 끝에 FRAM 높이로 칠판을 맞춤 (11/27) : 드라이브가 꺼졌다 켜지면 위치 · 1바퀴 펄스가 바뀌니 init 뒤가 맞는 때 */
int AM_Init(uint8_t id)
{
    int ok;                                                 /* 1 = 설정 · 서보 켜기 다 됨 */
    int a_y, b_y;                                           /* FRAM Y 높이 mm (A · B) */
    int32_t now;                                            /* 지금 드라이브 위치 (펄스) */

    if (check_id(id) == 0) return 0;
    if ((id == 3 || id == 6) && write_regs(id, R_TORQUE_MAX, 2, X_TORQUE_MAX, X_TORQUE_MAX) == 0) return 0;   /* X 만 힘 제한 (+ · - 같은 값, 11/26) */
    ok = write_regs(id, R_DI1_FUNC, 10,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        && write_regs(id, R_DI1_FUNC, 10,
            31, 0,
            1,  0,
            32, 0,
            28, 0,
            34, 0)
        && write_regs(id, R_DI8_FUNC, 4, 18, 0, 19, 0)  /* DI8 = JOG+ · DI9 = JOG- (끈 채로) */
        && write_regs(id, R_DO1_FUNC, 2, 5, 0)              /* DO1 = COIN (도착) */
        && write_regs(id, R_DO2_FUNC, 2, 16, 0)             /* DO2 = 원점 닿음 */
        && write_regs(id, R_POS_DONE_GAP, 1, AM_DONE_GAP)
        && write_regs(id, R_MODE, 1, 1)
        && write_regs(id, R_POS_SOURCE, 1, 2)
        && write_regs(id, R_PULSE_REV, 2, ax[id].pulse_rev, ax[id].pulse_rev >> 16)   /* 1바퀴 펄스 (설정표, 32bit : 아래 16 → 위 16) */
        && write_regs(id, R_RUN_MODE, 3, 0, 1, 0)
        && write_regs(id, R_MOVE_TYPE, 1, ax[id].move_type)   /* Enable OFF 에서만 변경 (서보 켜기 전) : 설정표 */
        && write_regs(id, R_HOME_MODE, 1, ax[id].home_mode)   /* Enable OFF 에서만 변경 (서보 켜기 전) : 설정표 */
        && write_regs(id, R_HOME_ACC,     1, AM_HOME_ACC_MS)
        && write_regs(id, R_HOME_TIMEOUT, 1, AM_HOME_TIMEOUT_MS)
        && write_regs(id, R_HOME_OFFSET,  2, ax[id].offset, ax[id].offset >> 16)   /* 설정표, 32bit : 아래 16 → 위 16 */
        && write_regs(id, R_DI2_LOGIC, 1, 1);             /* 서보 켜기 (DI2) */
    if (ok == 0) return 0;

    /* Y : FRAM 높이를 믿음 (브레이크라 꺼져도 안 움직임) → 칠판이 FRAM 높이가 되게 → 이제부터 FRAM 에 적음 */
    if ((id == 1 || id == 4) && FRAM_YRead(&a_y, &b_y)) {
        if (AM_ReadReg(id, R_REAL_POS, &now, 2, MOTOR_RETRY, Y_RX_MS) == 0) return 0;   /* 지금 드라이브 위치 (1바퀴 펄스 바꾼 뒤) */
        if (id == 4) a_y = b_y;                             /* B 의 Y 면 B 높이 */
        y_home_setting[id] = Y_MM(a_y) + now;               /* 칠판 = -드라이브 (Y 거꾸로) + 이것 = FRAM 높이 */
        Remember_pos[id] = 1;
    }
    return 1;
}
///////////////////////////EEPROM///////////////////////////////////////////
/* STM UART2 속도 */
static void uart_speed(uint32_t baud)
{
    HAL_UART_DeInit(&huart2);
    huart2.Init.BaudRate = baud;
    HAL_RS485Ex_Init(&huart2, UART_DE_POLARITY_HIGH, 0, 0);
}

/* A motor 속도를 AM_BAUD로 저장 후 재시작
   ⚠ 듀얼 : 지금은 한 대 (AM_ID) 만 바꿈 → 그대로 쓰면 보드는 AM_BAUD, 나머지 5대는 옛 속도라 끊김 (6대 다 바꾸고 ioc 도, 11/27) */
int AM_BaudInit(void)
{
    if (check_id(AM_ID))
        return 1;

    /* 1. 옛 속도로 접속 */
    uart_speed(OLD_BAUD);

    /* 2. 속도 변경(ER.941) 후 저장 */
    write_regs(AM_ID, R_BAUD, 1, BAUD_CODE);
    write_regs(AM_ID, R_EEPROM_SAVE, 1, 1);
    osDelay(SAVE_WAIT);

    /* 3. 드라이브 재시작 */
    write_regs(AM_ID, R_RESET, 1, 1);

    /* 4. STM 복귀 후 확인 */
    uart_speed(AM_BAUD);
    osDelay(RESET_WAIT);

    return check_id(AM_ID);
}
