/*
 * cli.c : UART1 디버그 창 (Tera Term 115200, 로컬 에코 켬 — 보드는 친 글자를 안 돌려보냄)
 *   받기   usart.c 인터럽트가 cli_buf 에 넣음 → CLI_Run (Comm_Task 1ms) 이 꺼내 한 줄 → CLI_Command
 *   명령   축 이름 = 축 글자 + 로더 번호 : y1 · t1 · x1 (로더 A = ID 1 · 2 · 3) / y2 · t2 · x2 (로더 B = ID 4 · 5 · 6) (듀얼 11/23)
 *          x1 init                                               그 드라이브 설정 + 서보 켜기 (움직이기 전에 한 번)
 *          y1 mm %     예) y1 360 3                               원점에서 360mm 자리로 (Y · X 같음) · 3%
 *          x1 주소     예) x1 0B07                                레지스터 읽기 16 · 32비트 (16진수)
 *          HOME                                                  6대 init → 원점 (run.c I : FRAM 으로 1 · 2 · 3번 고름)
 *          y1 home  ·  y2 home                                   Y 원점 (벽). X 는 HOME 으로 · 틸트는 보류 (TL57, 다음 주)
 *          x1 jog 1 3  ·  x1 jog 0                               JOG 코드 + 쪽 3% · 멈춤 (멈출 때 꼭 jog 0 또는 stop, 11/26)
 *          stop                                                  6대 멈춤 (E_S). 원점 (home) 중에는 CLI 가 멈춰 있어서 안 먹음
 *          DATA                                                   6대 주요 레지스터 한 번에 + RAM (힙 · 태스크 스택 가장 적게 남았던 양)
 *          IP  ·  FRAM                                           저장된 네트워크 · FRAM 값 (끝에 [FY] · [FX] 로더 위치)
 *          FRAMCLR                                               FRAM 로더 위치 지우기 (실제와 다를 때 → 다음 HOME 은 Y 원점부터, 11/27)
 *   읽는 동안 Comm_Task 가 멈춤 (PC 통신도) → 모터가 서 있을 때만
 *   원점 결과 · 통신 실패 · 2500 끊김 이유는 CLI 가 아니라 로그 50001 (debug.c)
 */
#include "cli.h"
#include "a_motor.h"
#include "run.h"            /* E_S (stop : 6대 멈춤) */
#include "save.h"
#include "fram.h"           /* FRAM_YRead · FRAM_XRead (FRAM 명령의 [FY] · [FX] 줄) */
#include "usart.h"
#include "FreeRTOS.h"       /* xPortGetMinimumEverFreeHeapSize (DATA 의 RAM 줄) */
#include <stdio.h>
#include <string.h>

#define CLI_SIZE 32         /* 한 줄 최대 글자 (명령은 길어야 10글자 정도) */

/* UART1 출력 */
static void CLI_Print(const char *text)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)text, strlen(text), 100);
}


/* 실행 결과 출력 : 이름 + OK / ERR  예) X_MOVE OK */
static void CLI_Result(const char *name, int ok)
{
    char text[32];

    snprintf(text, sizeof(text), "%s %s\r\n> ", name, ok ? "OK" : "ERR");
    CLI_Print(text);
}


/* FRAM 배열 출력 */
static void CLI_List(const char *name, int32_t *data, int count, int max)
{
    char buf[32];

    CLI_Print(name);

    if (count > max)
        count = max;

    for (int i = 1; i <= count; i++)                 /* FRAM 표는 1 번 칸부터 ([0] 안 씀) */
    {
        snprintf(buf, sizeof(buf), "%ld ", (long)data[i]);
        CLI_Print(buf);
    }

    CLI_Print("\r\n");
}


/* FRAM 저장값 출력 */
static void CLI_FRAM(void)
{
    char buf[500];
    int a_y, b_y;               /* FRAM 로더 Y 높이 mm (A · B) */
    int a_x, b_x;               /* FRAM 로더 X 위치 mm (A · B) */

    snprintf(buf, sizeof(buf),
             "\r\n[FS]\r\n"
             "RACK         = %d\r\n"
             "TYPE         = %c\r\n"
             "CHANNEL      = %d\r\n"
             "IN_X         = %d\r\n"
             "IN_Y         = %d\r\n"
             "LEFT_X       = %d\r\n"
             "LEFT_Y       = %d\r\n"
             "RIGHT_X      = %d\r\n"
             "RIGHT_Y      = %d\r\n"
             "\r\n[FP]\r\n"
             "IN_X = %ld\r\n",
             save.fs.rack,
             save.fs.type,
             save.fs.rack_channel,
             save.fs.in_x,
             save.fs.in_y,
             save.fs.left_x,
             save.fs.left_y,
             save.fs.right_x,
             save.fs.right_y,
             (long)save.fp.in_x);

    CLI_Print(buf);

    CLI_List("IN_Y = ", save.fp.in_y, save.fs.in_y, 5);             /* FRAM 배열 그대로 */
    CLI_List("LEFT_X = ", save.fp.left_x, save.fs.left_x, 9);
    CLI_List("LEFT_Y = ", save.fp.left_y, save.fs.left_y, 9);
    CLI_List("RIGHT_X = ", save.fp.right_x, save.fs.right_x, 9);
    CLI_List("RIGHT_Y = ", save.fp.right_y, save.fs.right_y, 9);

    snprintf(buf, sizeof(buf),
             "\r\n"
             "LIFT Y OFFSET = %ld\r\n"
             "TILT ANGLE    = %ld\r\n"
             "TILTING Y     = %ld\r\n"
             "TILTING SPEED = %ld\r\n"
             "Y OFFSET      = %ld\r\n"
             "TILT OFFSET   = %ld\r\n"
             "X OFFSET      = %ld\r\n"
             "SPEED X       = %ld\r\n"
             "SPEED TILT    = %ld\r\n"
             "SPEED Y       = %ld\r\n"
             "ACCDEC X      = %ld\r\n"
             "ACCDEC TILT   = %ld\r\n"
             "ACCDEC Y      = %ld\r\n"
             "SAFE X        = %ld\r\n"
             "SAFE Y        = %ld\r\n",
             (long)save.fp.lift_y_offset,
             (long)save.fp.tilt_angle,
             (long)save.fp.tilting_y,
             (long)save.fp.tilting_y_speed,
             (long)save.fp.y_offset,
             (long)save.fp.tilt_offset,
             (long)save.fp.x_offset,
             (long)save.fp.speed_x,
             (long)save.fp.speed_tilt,
             (long)save.fp.speed_y,
             (long)save.fp.accdec_x,
             (long)save.fp.accdec_tilt,
             (long)save.fp.accdec_y,
             (long)save.fp.safe_x,
             (long)save.fp.safe_y);

    CLI_Print(buf);

    /* [FY] · [FX] 로더 Y 높이 · X 위치 (run.c REG_FRAM 이 원점 뒤 1초마다 적음, 11/27) : 적힌 적 없으면 "모름" */
    if (FRAM_YRead(&a_y, &b_y))
        snprintf(buf, sizeof(buf), "\r\n[FY]\r\nA_Y = %d mm\r\nB_Y = %d mm\r\n", a_y, b_y);
    else
        snprintf(buf, sizeof(buf), "\r\n[FY]\r\nA_Y · B_Y = 모름 (HOME 끝나고 1초부터 적힘)\r\n");
    CLI_Print(buf);
    if (FRAM_XRead(&a_x, &b_x))
        snprintf(buf, sizeof(buf), "[FX]\r\nA_X = %d mm\r\nB_X = %d mm\r\n> ", a_x, b_x);
    else
        snprintf(buf, sizeof(buf), "[FX]\r\nA_X · B_X = 모름 (HOME 끝나고 1초부터 적힘)\r\n> ");
    CLI_Print(buf);
}


/* (디버그) 레지스터 하나 읽어 한 줄 출력 : id = 드라이브 주소 1 ~ 6, qty 1 = 16bit / 2 = 32bit (아래 칸 먼저는 AM_ReadReg 가 합침)
   읽으면 1 / 대답 없음 0 */
static int reg_line(uint8_t id, uint16_t reg, uint8_t qty, const char *name)
{
    int32_t value = 0;
    char buf[64];
    int ok = AM_ReadReg(id, reg, &value, qty, MOTOR_RETRY, Y_RX_MS);   /* 3번 묻기 · AIM 기다림 */

    if (ok) snprintf(buf, sizeof(buf), " %04X %-14s = %ld (0x%lX)\r\n", reg, name, (long)value, (unsigned long)value);
    else    snprintf(buf, sizeof(buf), " %04X %-14s = FAIL\r\n", reg, name);
    CLI_Print(buf);
    return ok;
}

/* (디버그) DATA : 6대 주요 레지스터를 한 번에 출력
   대마다 첫 줄이 대답 없으면 나머지는 안 물음 (줄마다 대답 없음 시간을 버리지 않게)
   Comm_Task 라 읽는 동안 PC 통신이 멈춤 → 모터가 서 있을 때만 */
static void CLI_Data(void)
{
    char buf[100];

    for (uint8_t id = 1; id <= Dual_ID; id++) {
        snprintf(buf, sizeof(buf), "\r\n[ID %d]\r\n", id);
        CLI_Print(buf);
        if (reg_line(id, 0x0509, 1, "pulse/rev")) {                     /* H05_09 : 320 이어야 */
            reg_line(id, 0x0B07, 2, "position pulse");
            reg_line(id, 0x0B22, 1, "fault");
            reg_line(id, 0x0B05, 1, "DO state");
            reg_line(id, 0x051F, 1, "home mode");
            reg_line(id, 0x053A, 1, "home torque");
            reg_line(id, 0x0515, 1, "done gap");
            reg_line(id, 0x0C02, 1, "baud code");
            reg_line(id, 0x0709, 1, "torque max +");                    /* H07_09 · H07_10 : X 는 X_TORQUE_MAX (11/26) */
            reg_line(id, 0x070A, 1, "torque max -");
        }
        snprintf(buf, sizeof(buf), " board    pos %ld  torque %d (0.1%%)\r\n",   /* 칠판 (Bus_Task) : X 는 묶어 읽기 — 위 0B07 과 같아야 (11/26) */
                 (long)am[id].pos, am[id].torque);
        CLI_Print(buf);
    }

    /* RAM 재기 : 켠 뒤 가장 적게 남았던 양 (0 에 가까우면 넘치기 직전 → ioc 에서 늘림 / 많이 남으면 나중에 줄여도 됨) */
    snprintf(buf, sizeof(buf), "[RAM] min free  heap %u B  stack Event %lu B  Motor %lu B  Comm %lu B\r\n",
             (unsigned)xPortGetMinimumEverFreeHeapSize(),                /* 힙 20KB 중 (ioc TOTAL_HEAP_SIZE) */
             (unsigned long)osThreadGetStackSpace(Event_TaskHandle),     /* 태스크 스택 (ioc Tasks) */
             (unsigned long)osThreadGetStackSpace(Motor_TaskHandle),
             (unsigned long)osThreadGetStackSpace(Comm_TaskHandle));
    CLI_Print(buf);
    CLI_Print("> ");
}

/* 문자열 명령 처리 */
static void CLI_Command(char *text)
{
    long mm;                    /* 이동 거리 mm (Y_MM 으로 펄스) */
    int persent = 0;            /* 속도 % (jog 0 처럼 안 적으면 0) */
    int dir;                    /* JOG 방향 : 1 = + 쪽 · -1 = 반대 · 0 = 멈춤 (11/26) */
    unsigned int reg;          /* (디버그) 읽을 레지스터 주소 : 0B07 · 0509 (16진수) */
    char axis;                  /* 축 글자 x · y · t */
    int n;                      /* 로더 번호 1 · 2 */
    int id = 0;                 /* 드라이브 주소 1 ~ 6 (축 이름이 아니면 0) */
    char buf[300];

    /* 축 이름 → 드라이브 주소 : y1 1 · t1 2 · x1 3 (로더 A) / y2 4 · t2 5 · x2 6 (로더 B) */
    if (sscanf(text, "%c%d", &axis, &n) == 2 && n >= 1 && n <= 2) {
        if (axis == 'y') id = n * 3 - 2;
        if (axis == 't') id = n * 3 - 1;
        if (axis == 'x') id = n * 3;
    }

    /* 네트워크 값 */
    if (strcmp(text, "IP") == 0)
    {
        snprintf(buf, sizeof(buf),
                 "\r\n[IP]\r\n"
                 "IP      = %d.%d.%d.%d\r\n"
                 "SUBNET  = %d.%d.%d.%d\r\n"
                 "GATEWAY = %d.%d.%d.%d\r\n"
                 "DEST IP = %d.%d.%d.%d\r\n"
                 "PORT    = %d\r\n"
                 "MODE    = %d\r\n"
                 "TIMEOUT = %lu\r\n> ",
                 save.fi.ip[0], save.fi.ip[1],
                 save.fi.ip[2], save.fi.ip[3],
                 save.fi.sn[0], save.fi.sn[1],
                 save.fi.sn[2], save.fi.sn[3],
                 save.fi.gw[0], save.fi.gw[1],
                 save.fi.gw[2], save.fi.gw[3],
                 save.fi.dip[0], save.fi.dip[1],
                 save.fi.dip[2], save.fi.dip[3],
                 save.fi.port, save.fi.mode,
                 (unsigned long)save.fi.timeout);

        CLI_Print(buf);
        return;
    }

    /* FRAM 값 */
    if (strcmp(text, "FRAM") == 0)
    {
        CLI_FRAM();
        return;
    }

    /* FRAM 로더 위치 지우기 (11/27) : FRAM 높이가 실제와 다를 때 → 다음 HOME 은 Y 원점부터 (떼어 놓고). 칠판도 "모름" 으로 (안 그러면 바로 다시 적음) */
    if (strcmp(text, "FRAMCLR") == 0)
    {
        for (uint8_t id = 1; id <= Dual_ID; id++) {
            Remember_pos[id] = 0;                           /* 지금 칠판 위치 안 믿음 → FRAM 에 안 적음 */
            y_home_setting[id] = 0;                         /* FRAM 으로 더한 높이 없앰 */
        }
        CLI_Result("FRAMCLR", clearFRAM());
        return;
    }

    /* (시험) 원점 : HOME → 6대 설정 + 서보 → FRAM 으로 1번 (Y 먼저) · 2번 (X 먼저) · 3번 (멈춤) (run.c motor_basic_init · I). 끝날 때까지 CLI 기다림
       ⚠ FRAM 모름이면 두 로봇 X 떼어 놓기 · 틸트 가운데. Motor_Run 켜면 시작 버튼 · PC I 로 */
    if (strcmp(text, "HOME") == 0)
    {
        CLI_Result("HOME", motor_basic_init());
        return;
    }

    /* 모터 이동 : 축 mm 속도%  예) y1 360 3 = 원점에서 360mm 자리로 / x1 1460 3 = 1460mm 자리로 (X 는 AM_Move 가 목표 − 지금). 먼저 init
       Y · X 둘 다 1mm = 10펄스라 한 줄 (틸트도 ×10 이 되지만 지금 안 씀 : TL57 로 바뀐 뒤 단위) */
    if (id && sscanf(text, "%c%d %ld %d", &axis, &n, &mm, &persent) == 4)
        CLI_Result("MOVE", AM_Move(id, Y_MM(mm), persent));

    /* JOG : t1 jog 1 3 (+ 쪽 3%) · t1 jog -1 3 (반대) · t1 jog 0 (멈춤). + = Y 위 · t1 1렉 · t2 2렉 · x2 쪽
       ⚠ 켜 둔 채 CLI 로 돌아옴 → 멈출 때 꼭 jog 0 (또는 stop) (11/26) */
    else if (id && sscanf(text, "%c%d jog %d %d", &axis, &n, &dir, &persent) >= 3)
        CLI_Result("JOG", AM_Jog(id, dir, persent));

    /* Y 원점 : y1 home · y2 home → 출발 → 끝날 때까지 물음 (최대 60초, 그동안 CLI 는 기다림). X 는 HOME 으로 · 틸트는 보류 (TL57, 다음 주) */
    else if (id && axis == 'y' && strstr(text, "home")) {
        uint32_t start = osKernelGetTickCount();            /* 출발 시각 */
        int ok = AM_Home(id);                               /* 출발 */
        while (ok && AM_HomeEnd(id) == 0) {                 /* 닿고 5cm 가서 0 잡을 때까지 */
            if (osKernelGetTickCount() - start > 60000) { AM_Stop(id); ok = 0; }   /* 60초 넘음 : 멈추고 실패 */
            osDelay(20);                                    /* 쉬었다 다시 묻기 (버스 비워 두기) */
        }
        CLI_Result("HOME", ok);
    }

    /* 설정 + 서보 켜기 : x1 init (움직이기 전에 축마다 한 번) */
    else if (id && strstr(text, "init"))
        CLI_Result("INIT", AM_Init(id));

    /* (디버그) 레지스터 읽기 : 축 이름 + 16진수 주소 하나 (숫자 둘이면 위의 이동). H0B_34 = 0B22 처럼 뒤 번호를 16진수로 */
    else if (id && sscanf(text, "%c%d %x", &axis, &n, &reg) == 3) {   /* x1 0B07 */
        reg_line(id, (uint16_t)reg, 1, "16bit");
        reg_line(id, (uint16_t)reg, 2, "32bit");
        CLI_Print("> ");
    }

    /* (디버그) 6대 주요 레지스터 한 번에 */
    /* 멈춤 : stop → 6대 다 멈춤 (run.c E_S, 따로 다 보냄). 알람 · 상태는 안 바꿈 → 리셋 없이 바로 다시 움직일 수 있음 */
    else if (strcmp(text, "stop") == 0)
        CLI_Result("STOP", E_S());

    else if (strcmp(text, "DATA") == 0)
        CLI_Data();

    else
        CLI_Print("BAD COMMAND\r\n> ");
}


/* UART1 CLI (Comm_Task 1ms 마다) : 보관함(cli_buf, usart.c 인터럽트가 넣음)에 온 글자를 전부 꺼내 한 줄 만들기
   글자 → 줄에 붙이고 화면에 다시 보여 줌 / 지우기 → 하나 빼고 화면에서도 지움 / 엔터 → 명령 실행 */
void CLI_Run(void)
{
    static char line[CLI_SIZE];             /* 지금 치는 한 줄 */
    static uint8_t index = 0;               /* 줄에서 다음 글자 넣을 칸 */
    static uint8_t tail = 0;                /* 보관함에서 다음에 꺼낼 칸 */
    char c;                                 /* 꺼낸 글자 1개 */

    while (tail != cli_head) {                                  /* 보관함에 글자 있는 만큼 */
        c = cli_buf[tail];
        tail = (tail + 1) % CLI_BUF;                            /* 다음 칸 (끝이면 처음으로) */

        if (c == '\r' || c == '\n') {                           /* 엔터 : 한 줄 끝 */
            if (index == 0) continue;                           /*   빈 줄 (CR 뒤 LF) 은 무시 */
            line[index] = 0;
            index = 0;
            CLI_Print("\r\n");
            CLI_Command(line);
        }
        else if (c == '\b' || c == 0x7F) {                      /* 지우기 (Backspace · Delete) */
            if (index == 0) continue;                           /*   지울 글자 없음 */
            index--;
            CLI_Print(" \b");                                   /*   화면 : Tera Term 이 이미 한 칸 뒤로 감 → 빈칸으로 덮고 다시 뒤로 */
        }
        else if (index < CLI_SIZE - 1) {                        /* 글자 : 줄에 붙이기 (꽉 차면 무시) */
            line[index++] = c;                                  /*   화면은 Tera Term 로컬 에코가 보여 줌 (보드는 안 돌려보냄) */
        }
    }
}
