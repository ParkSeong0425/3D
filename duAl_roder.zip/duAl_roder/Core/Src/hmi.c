/*
 * hmi.c : 터치패드 통신 + 수동 JOG (RUN · STOP · RESET · 음소거 · 수동 모드는 event.c hmi_event)
 *
 * 묻고 대답하기 (11/16) : STM 만 먼저 말함 → 선 위에서 안 부딪힘
 * STM -> HMI : STX '1' 'C' 작업 일시정지 알람 센서20 ETX (27바이트) — 20ms 마다 늘 (= "버튼 있어?" 질문)
 * HMI -> STM : STX '1' 버튼 ETX (버튼 = 번호 + '0') — 질문 받자마자 대답. 버튼 없으면 '0'
 *              같은 버튼을 대답 3번에 실음 (잡음으로 하나 깨져도 안 사라짐) → STM 은 바뀐 순간만 처리
 *              11 RUN / 12 일시정지 / 20 JOG 뗌 / 21~26 JOG 누름 / 31~33 설정
 *  한 바퀴 20ms = 물음 2.3ms + 대답 0.4ms + 쉼 약 17ms. 버튼 최대 늦음 = 터치 10 + 물음 20 + 3 = 약 33ms
 *
 *  HMI_Send     (Event_Task)       20ms 마다 상태 글자 (질문) + 물은 횟수 hmi_miss +1
 *  HMI_Receive  (UART4 인터럽트)   ESP 대답 → hmi_miss 0 · 버튼이 바뀌었으면 EventQueue
 *  hmi_miss     연달아 대답 없는 횟수 → alarm.c A_01 (3번 = 60ms = 알람 01)
 *  HMI_Manual   (Event_Task)       JOG : 누름 = 드라이브 JOG 시작 / 뗌 = 멈춤
 */

#include "hmi.h"
#include "usart.h"
#include "status.h"
#include "event.h"
#include "manjae.h"
#include "rfid.h"
#include "a_motor.h"
#include "alarm.h"
#include "save.h"
#include "main.h"
#include "cmsis_os2.h"
#include <stdint.h>

#define STX     0x02
#define ETX     0x03

/* ESP 묻는 박자 HMI_MS 는 comm.h (usart.h 가 불러 옴) */
#define JOG_PERCENT     5       /* JOG 속도 % (아주 느리게) */

volatile int hmi_miss;                  /* 물었는데 대답 없는 횟수 (HMI_Send +1 · HMI_Receive 0) → alarm.c A_01 */

/* 보낼 틀 : 고정 칸은 처음부터 채워 두고, 바뀌는 칸(작업 일시정지 알람, 만재 8칸)만 매번 쓴다 */
static uint8_t tx[27] = { STX, '1', 'C',
                          '0', '0', '0',                /* 작업 / 일시정지 / 알람 */
                          '0', '0', '0', '0', '0',      /* 화면 왼쪽 칸  : 렉2 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 화면 오른쪽 칸 : 렉1 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 3번째 칸 : 안 씀 */
                          '0', '0', '0', '0', '0',      /* 4번째 칸 : 안 씀 */
                          ETX };

/* 작업 칸 (ESP TaskString 번호) : 상태 하나 → 번호 하나
   0 초기상태 · 1 대기 · 2 운전 · 3 일시정지 · 5 원점설정 · 6 알람. 수동은 전 상태 그대로 (알람 칸이 "수동") */
static char hmi_task(void)
{
    char now = state.now;

    if (now == 'M') now = state.prev;                     /* 수동 : 전 상태 (대기 · 초기상태) */
    if (now == 'E' || now == 'A') return '6';         /* 알람 */
    if (now == 'H')  return '5';                            /* 원점설정 (원점 중) */
    if (now == 'I')  return '0';                            /* 초기상태 (켠 직후 · RESET 뒤, 시작 기다림) */
    if (now == 'S')  return '3';                            /* 일시정지 (멈춤) */
    if (now == 'R')   return '2';                            /* 운전 */
    if (manjae_1 || manjae_2 || card_1 || card_2) return '3';   /* 대기인데 만재 2초 넘음 · 시딩월 이탈 알림 (시작 까지) */
    return '1';                                                 /* 대기 */
}

/* 일시정지 칸 : 0 없음, 1 시딩월(카드 없음), 2 만재, 3 틸트, 4 사용자 */
static char hmi_pause(void)
{
    if (state.now == 'S') {                     /* 멈춤이면 이유대로 */
        if (state.why == 'F') return '2';           /* 만재 */
        if (state.why == 'S') return '1';           /* 시딩월 */
        if (state.why == 'T') return '3';           /* 틸트 */
        return '4';                                 /* 사용자 */
    }
    if (card_1 || card_2)     return '1';           /* 시딩월 이탈 (RUN 까지) */
    if (manjae_1 || manjae_2) return '2';           /* 만재 2초 넘음 (RUN 까지) */
    return '0';
}

/* 알람 : 걸린 알람 번호 그대로 (ESP 표 hmi.cpp AlarmString 과 같음)
   2 주행모터 3 리프팅 4 틸팅 5~7 이탈 9 비상정지 10 원점 11 모터에러 12 랜선뽑힘 / 01 HMI 통신 → 13 터치에러 (ESP 1 칸은 "수동")
   수동 모드면 1, 없으면 0. 글자 = '0' + 번호 (10 ':' · 11 ';' · 12 '<' · 13 '=') → ESP 가 '0' 을 빼서 읽음 (11/16 ESP 표 13 까지) */
static char hmi_alarm(void)
{
    if (state.now == 'E')  return '9';             /* 비상정지 */
    if (state.now == 'M') return '1';             /* 수동 (HMI 가 수동 화면 · 버튼을 열게) */
    if (state.alarm == 1)       return '0' + 13;        /* 01 HMI 통신 : 다시 이어지면 "터치에러" 로 보임 (RESET 까지) */
    if (state.alarm >= 2)       return '0' + state.alarm;   /* 02 ~ 12 그대로 */
    return '0';
}

/* (Event_Task) 20ms 마다 상태 글자 = ESP 에 "버튼 있어?" (바뀐 게 없어도 늘 같은 박자, ESP 는 받자마자 대답)
   버튼 · 만재로 일찍 깬 바퀴는 그냥 지나감 (20ms 안 됨) */
void HMI_Send(void)
{
    static uint32_t sent_at;                /* 지난번 물은 시각 */

    if (osKernelGetTickCount() - sent_at < HMI_MS) return;    /* 20ms 안 됨 : 칸 채우기도 안 함 */

    /* 만재 8칸 : 2초 그대로였던 값 (스침은 화면에 안 나옴, 바뀌는 2초 동안은 전 화면 그대로) */
    tx[6]  = manjae_2s(2, 1) ? '1' : '0';      /* 왼쪽 칸 : 렉2 */
    tx[7]  = manjae_2s(2, 2) ? '1' : '0';
    tx[8]  = manjae_2s(2, 3) ? '1' : '0';
    tx[9]  = manjae_2s(2, 4) ? '1' : '0';

    tx[11] = manjae_2s(1, 1) ? '1' : '0';      /* 오른쪽 칸 : 렉1 */
    tx[12] = manjae_2s(1, 2) ? '1' : '0';
    tx[13] = manjae_2s(1, 3) ? '1' : '0';
    tx[14] = manjae_2s(1, 4) ? '1' : '0';

    tx[3]  = hmi_task();                /* 작업 */
    tx[4]  = hmi_pause();               /* 일시정지 */
    tx[5]  = hmi_alarm();               /* 알람 */

    if (UART4_Send(tx, sizeof(tx)) == 0) return;    /* 앞 글 보내는 중 (20ms 마다라 거의 없음) : 다음 바퀴에 */
    hmi_miss++;                                     /* 물었음 : 대답 오면 HMI_Receive 가 0 (대답은 2.5ms 뒤라 여기와 안 겹침) */
    sent_at = osKernelGetTickCount();
}

/* (UART4 인터럽트) ESP 대답 : STX '1' 버튼 ETX 가 맞으면 → 살아 있음 + 버튼이 바뀐 순간만 EventQueue (기다림 0)
   버튼 = ESP 가 번호 + '0'(48) 으로 보냄 (STX 2, ETX 3 과 안 겹치게) → 48 을 빼서 진짜 번호
   ESP 는 같은 버튼을 3번 실음 → 바뀐 순간만. JOG 가 안 실려 오면(0) = 뗌 (뗌 글자가 깨져도 · ESP 화면이 멈춰도 섬) */
void HMI_Receive(uint8_t *rx, uint16_t size)
{
    static uint8_t last;                                /* 지난 대답의 버튼 */
    uint8_t task_copy = rx[2] - '0';                    /* 주문서 : 버튼 번호 */

    if (size != 4 || rx[0] != STX || rx[1] != '1' || rx[3] != ETX) return;   /* 잡음 · 꼬임 */
    hmi_miss = 0;                                       /* ESP 대답함 = 살아 있음 */
    if (task_copy == last) return;                      /* 전과 같음 : 한 번만 (3번 실려 와도) */

    if (task_copy == 0 && last >= BTN_TILT_Lift && last <= BTN_TRAVEL_Back) task_copy = BTN_JOG_STOP;   /* JOG 끊김 = 뗌 */
    last = rx[2] - '0';                                 /* 이번 버튼 기억 (뗌으로 바꾼 것 말고 받은 그대로) */
    if (task_copy != 0) osMessageQueuePut(EventQueueHandle, &task_copy, 0, 0);   /* 0 = 버튼 없음 */
}

/* 수동 JOG (Event_Task) : 드라이브 JOG 기능 그대로 (매뉴얼). 누름 = 그 방향으로 아주 느리게 / 뗌(20) = 멈춤
   수동 모드 아니면 안 함. 비상정지 · 알람은 모터 문 Motor_Stop 이 막음. 뗌 글자가 사라져도 JOG 끊김 = 뗌 (HMI_Receive) · ESP 대답 3번 없음 → 알람 01
   듀얼 : 지금은 A 의 Y 만 (X · 틸트 · 로더 B 버튼은 화면 정한 뒤) */
void HMI_Manual(int button)
{
    if (state.now == 'M') {                     /* 수동일 때만 */
        switch (button)
        {
        case BTN_LIFT_UP:   AM_Jog(AM_ID,  1, JOG_PERCENT); break;   /* Y 위 */
        case BTN_LIFT_Down: AM_Jog(AM_ID, -1, JOG_PERCENT); break;   /* Y 아래 */
        case BTN_JOG_STOP:  AM_Jog(AM_ID,  0, 0);           break;   /* 뗌 : JOG 신호 끔 */
        }
    }
}
