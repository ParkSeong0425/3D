/*
 * fram.c : FRAM 칩 읽기 · 쓰기만 (SPI1). 무엇을 어디에 둘지는 save.h 의 FRAM 지도 (HEAD · FS · FP · FI _ADDR)
 *
 *   FRAM_Write(주소, 칸, 크기) : 주소부터 크기만큼 쓰기
 *   FRAM_Read (주소, 칸, 크기) : 주소부터 크기만큼 읽기
 *
 *   FRAM_YWrite(로더, mm) · FRAM_YRead(&A, &B) : 로더 Y 높이 (FY_ADDR, 11/25) — 켤 때 누가 위인지
 *
 *   명령 = [명령 1바이트][주소 2바이트][데이터 …]  (주소 2바이트 = 최대 64KB 칩)
 *   FRAM 은 지우기 없이 바로 써지고, 거의 무한히 다시 써도 됨
 */
#include "fram.h"
#include "save.h"           /* FRAM 지도 (FY_ADDR) */
#include "spi.h"
#include "cmsis_os2.h"

#define WREN   0x06     /* 쓰기 허용 */
#define WRITE  0x02     /* 쓰기 */
#define READ   0x03     /* 읽기 */

#define Y_CHECK     0x0425      /* FY 덩어리 표시 (save.c SAVE_MAGIC 과 같은 숫자) : 이게 있어야 값을 믿음 */
#define Y_UNKNOWN   (-1000000)  /* 아직 한 번도 안 적은 로더 = 모름 */

/* FY 덩어리 (FRAM 에 이 모양 그대로) */
typedef struct
{
    uint16_t check;     /* Y_CHECK 이면 아래 값을 믿음 (한 번도 안 적은 FRAM = 아무 값) */
    int32_t  a_y;       /* A 로더 Y 높이 mm (원점 0, 위 = +) */
    int32_t  b_y;       /* B 로더 Y 높이 mm */
} Y_HEIGHT;

/* 칩 선택 (NSS) : 1 = 선택(Low), 0 = 해제(High) */
static void chip(int on)
{
    if (on) {
        __HAL_SPI_ENABLE(&hspi1);
    }
    else {
        __HAL_SPI_DISABLE(&hspi1);
        osDelay(2);        /* 풀업으로 High 될 때까지 */
    }
}

/* addr 번지부터 data 를 size 바이트 쓰기. 성공 1 / 실패 0 */
int FRAM_Write(uint16_t addr, void *data, int size)
{
    uint8_t wren = WREN;
    uint8_t cmd[3] = { WRITE, addr >> 8, addr & 0xFF };     /* 쓰기 + 주소 (높은 바이트 먼저) */
    int ok;

    /* 1. 쓰기 허용 : NSS 가 High 로 올라가야 적용됨 */
    chip(1);
    ok = HAL_SPI_Transmit(&hspi1, &wren, 1, 100) == HAL_OK;
    chip(0);
    if (ok == 0) return 0;

    /* 2. 명령 + 주소 → 데이터 */
    chip(1);
    ok = HAL_SPI_Transmit(&hspi1, cmd, 3, 100) == HAL_OK
      && HAL_SPI_Transmit(&hspi1, (uint8_t *)data, size, 100) == HAL_OK;
    chip(0);

    return ok;
}

/* addr 번지부터 size 바이트 읽어 data 에. 성공 1 / 실패 0 */
int FRAM_Read(uint16_t addr, void *data, int size)
{
    uint8_t cmd[3] = { READ, addr >> 8, addr & 0xFF };      /* 읽기 + 주소 */
    int ok;

    chip(1);
    ok = HAL_SPI_Transmit(&hspi1, cmd, 3, 100) == HAL_OK
      && HAL_SPI_Receive(&hspi1, (uint8_t *)data, size, 100) == HAL_OK;
    chip(0);

    return ok;
}

/* 로더 Y 높이 저장 : loader 1 = A / 2 = B, mm (원점 0, 위 = +). 다른 로더 값은 그대로. 성공 1 / 실패 0 */
int FRAM_YWrite(int loader, int mm)
{
    Y_HEIGHT y;

    if (FRAM_Read(FY_ADDR, &y, sizeof(y)) == 0) return 0;       /* 1. 지금 값 읽기 (다른 로더 값 지키려고) */
    int known = (y.check == Y_CHECK);                            /*    1 = 전에 적은 적 있음 */
    if (known == 0) {                                            /*    처음 : 둘 다 모름으로 시작 */
        y.check = Y_CHECK;
        y.a_y = Y_UNKNOWN;
        y.b_y = Y_UNKNOWN;
    }
    if (loader == 1) y.a_y = mm;                                 /* 2. 그 로더만 바꿈 */
    if (loader == 2) y.b_y = mm;
    return FRAM_Write(FY_ADDR, &y, sizeof(y));                   /* 3. 저장 */
}

/* 켤 때 두 로더 Y 높이 읽기 → *a_y · *b_y. 둘 다 적힌 적 있으면 1 / 모름 0 (그때 값은 안 믿음) */
int FRAM_YRead(int *a_y, int *b_y)
{
    Y_HEIGHT y;

    if (FRAM_Read(FY_ADDR, &y, sizeof(y)) == 0) return 0;       /* 읽기 실패 = 모름 */
    *a_y = y.a_y;
    *b_y = y.b_y;
    if (y.check == Y_CHECK && y.a_y > Y_UNKNOWN && y.b_y > Y_UNKNOWN) return 1;   /* 표시 있음 + 둘 다 적힘 */
    return 0;
}
