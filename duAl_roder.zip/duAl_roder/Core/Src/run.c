/*
 * run.c : 로더 동작 — a_motor 의 기본 움직임을 모아 원점 · MI · MO · PO 를 만듦
 *   주문     Motor_Request (아무 태스크 : 큐 MoveQueue 에 넣기) → Motor_Run (Motor_Task : 주문서 flag 하나 실행 → move_done 완료응답 · 로그)
 *   동작     motor_basic_init · I · MI · MO · PO · E_S   (MI · MO · PO 는 좌표 · 높이 숫자를 받음, 표 찾기는 Motor_Run 한 곳)
 *   블록     po_stop (만재 F · 카드 S) · pour_wait (기울인 채)   (쏟기 = 틸트 JOG, 다음에 짬)
 *   정지선   while (state.now == 'S') osDelay(20);  멈춤(S)이면 풀릴 때까지 (MI · MO 끝 · PO 쏟기 전 · 쏟은 뒤)
 *
 *  듀얼 (11/23 ~) : 모터 6대 AIM, 주소 1 A-Y · 2 A-틸트 · 3 A-X · 4 B-Y · 5 B-틸트 · 6 B-X
 *   AM_Move · AM_Arrive 는 (주소, 펄스) → Y mm 는 Y_MM(mm) 로 바꿔 넘김 (a_motor.h, 1mm = 10펄스 · 위 = +)
 *   지금 : 설정 · 멈춤 = 6대 / 원점 = A · B 의 Y 만 / MI · MO · PO = A 의 Y (AM_ID) 만 (threeD 에서 온 것, 듀얼 순서로 다시 짬)
 */
#include "run.h"
#include "a_motor.h"
#include "debug.h"
#include "event.h"
#include "cmsis_os2.h"
#include "FreeRTOS.h"
#include "queue.h"          /* xQueuePeek (주문 보기만) */
#include "status.h"
#include "cmd.h"
#include "alarm.h"
#include "manjae.h"
#include "rfid.h"
#include "save.h"
#include "fram.h"           /* FRAM_YWrite (Y_Remember : Y 높이 저장) */
#include <stdio.h>
#include <stdlib.h>         /* abs (x_apart 높이 차이 · 토크 크기) */

/* 원점 뒤 Y 높이 (mm, 원점 = 아래 벽 + 50mm 가 0) : 나중에 FRAM in_y · safe_y 로 */
#define Y_IN_MM         800     /* [현장] 입고 높이 : Y 원점 먼저 끝난 로더 (11/25 눈으로 맞춤) */
#define Y_WAIT_MM       20     /* [현장] 입고 대기 높이 (= 1단) : 나중에 끝난 로더 */
#define Y_UP_PERCENT    10      /* [현장] 원점 뒤 올라가는 속도 % (3% 면 800mm 에 17초 → AM_Arrive 8초 넘음) */

/* 켤 때 X 벌리기 (x_apart, 11/26) */
#define X_APART_MM      550     /* [현장] 두 X 가 벌릴 합 (보통 각자 275) = X 안전 거리 */
#define X_APART_PERCENT 3       /* [현장] 벌리는 JOG 속도 % */
#define X_APART_MS      30000   /* 벌리기 최대 시간 (넘으면 실패) */
#define Y_PASS_MM       340     /* [현장] FRAM 높이 차이가 이보다 작으면 겹쳐 있을 수 없음 → 안 벌림 */

static int y_known = 0;         /* 1 = Y 원점 끝 → 칠판 Y 가 진짜 높이. 0 이면 FRAM 안 덮어씀 (켜자마자 칠판 0 이 1200 을 지우지 않게, 11/26) */

/* 원점 (켤 때 · 시작 · PC I) : H → 드라이브 설정 (6대 따로 다 보냄) → 원점 → W / 못 가면 알람 10. 도착 1 / 실패 0 */
int motor_basic_init(void)
{
    int ok = 1;                         /* 1 = 6대 다 설정됨 */

    state.now = 'H';                  /* 원점 중 → 램프 원점 깜빡 · 화면 원점설정 */
    Log_Debug(LOG_HOME_START);

    /* 서보 ON : 틸트 → Y → X (하나 실패해도 나머지는 함) */
    if (AM_Init(2) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 2); ok = 0; }   /* A 틸트 */
    if (AM_Init(5) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 5); ok = 0; }   /* B 틸트 */
    if (AM_Init(1) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 1); ok = 0; }   /* A Y */
    if (AM_Init(4) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 4); ok = 0; }   /* B Y */
    if (AM_Init(3) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 3); ok = 0; }   /* A X */
    if (AM_Init(6) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 6); ok = 0; }   /* B X */

    if (ok && I() && Motor_Stop() == 0) {   /* 설정 다 됨 → 원점 도착 (도중에 알람 · 긴급정지 없었음) */
        state.now = 'W';              /* 대기 → 램프 rfid */
        Log_Debug(LOG_HOME_DONE);
        return 1;
    }

    A_10(0, 0);                        /* 못 감 → 알람 10 (이미 알람이면 그대로) : RESET → RUN 으로 다시 */
    Log_Debug(LOG_HOME_FAIL);
    return 0;
}


/* ── 블록 (PO 가 부름) : 판단(if · while)이 들어간 것만. 모터 한 줄짜리는 모터 함수를 그대로 부름 ── */

/* PO 정지선 (쏟기 전) : ① 확인 → ② 문제면 멈춤 → ③ 정지선
   만재 : 2초 봐서 진짜면 F (비우고 시작 · 억지로는 PC D) / 카드 없음 : S (카드 들어오면 저절로 · 시작). MI · MO 는 상관없음 */
static void po_stop(int rack, int dan)
{
    while (manjae_on(rack, dan) && manjae_2s(rack, dan) == 0) osDelay(20);    /* ① 만재면 스친 건지 2초 봄 */
    if (manjae_on(rack, dan)) Pause_Set(rack, 'F');                          /* ② 진짜 만재 → 멈춤 F (PPAUSE: F) */
    while (state.now == 'S') osDelay(20);                                    /* ③ 비우고 시작 · PC D 까지 */

    if (card_on(rack) == 0) Pause_Set(rack, 'S');                            /* ② 카드 없음 → 멈춤 S (리더 끄면 늘 있음이라 안 멈춤) */
    while (state.now == 'S' && state.why == 'S' && card_on(rack) == 0) osDelay(20);   /* ③ 카드 들어올 때까지 (시작으로도 풀림) */
    if (state.now == 'S' && state.why == 'S') Pause_Clear();                 /*    들어왔으면 저절로 이어서 */
}

/* PO 기울인 채 : ① 검사면 FP 7 안에 그 단 센서가 닿나 봄 → ② 닿음 · 검사 안 함 = 복귀 대기 / 안 닿음 = 틸팅 에러 (멈춤 T) → ③ 정지선
   검사 = PC 명령 마지막 자리 1 && FS 옵션 마지막 자리 1 && 렉 1 · 2. 복귀 대기 = PC 명령 값 × 10ms (080 → 0.8초) */
static void pour_wait(int rack, int dan, int return_delay, int tilt_check)
{
    int check = (tilt_check == 1 && save.fs.option[4] == 1 && rack <= 2);     /* 검사할까 */
    uint32_t start = osKernelGetTickCount();                                   /* 검사 시작 시각 */

    while (check && manjae_on(rack, dan) == 0 && osKernelGetTickCount() - start < save.fp.tilt_check_time) osDelay(20);
                                                                               /* ① 검사 : 닿을 때까지 (최대 FP 7) */
    if (check && manjae_on(rack, dan) == 0) Pause_Set(rack, 'T');              /* ② 안 닿음 → 틸팅 에러 (PPAUSE: T) */
    else osDelay(return_delay * 10);                                           /*    닿음 · 검사 안 함 → 복귀 대기 */
    while (state.now == 'S') osDelay(20);                                      /* ③ 정지선 : 기울인 채 시작 · D 까지 */
}


/* ── 동작 (좌표 · 높이 숫자를 받음, 나머지는 프로토콜 순서 그대로. 안 쓰는 칸도 받음) ──
   긴급정지 · 알람이 걸리면 그 뒤 이동 · 기다림은 모터 함수가 알아서 안 함 (문 2, status.c Motor_Stop) → 마지막에 결과만 */

/* 입고 : y = 그 단 안전 높이 → A 의 Y 만 (듀얼 : X · 틸트 · 로더 B 는 다시 짬) */
int MI(int y, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle)
{
    osDelay(delay);                                                             /* 1. 출발 대기 */
    AM_Move(AM_ID, Y_MM(y), lift_speed);                                        /* 2. Y 그 단 안전 높이로 */
    A_06(AM_Arrive(AM_ID, Y_MM(y)));                                            /*    도착 (못 가면 알람 06) */
    while (state.now == 'S') osDelay(20);                                       /* 3. 정지선 */
    return Motor_Stop() == 0;                                                   /* 긴급정지 · 알람 없었으면 성공 */
}

/* 출고 : 렉 좌표 (x, y) 로 (이동만). PO 도 1번에 이걸 부름 → A 의 Y 만 (듀얼 : X · 틸트 · 로더 B 는 다시 짬) */
int MO(int x, int y, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle)
{
    osDelay(delay);                                                             /* 1. 출발 대기 */
    AM_Move(AM_ID, Y_MM(y), lift_speed);                                        /* 2. Y 렉 높이로 */
    A_06(AM_Arrive(AM_ID, Y_MM(y)));                                            /*    도착 (못 가면 알람 06) */
    while (state.now == 'S') osDelay(20);                                       /* 3. 정지선 */
    return Motor_Stop() == 0;                                                   /* 긴급정지 · 알람 없었으면 성공 */
}

/* 분배 : 렉으로 → 정지선 → 쏟기 (틸트, 다음에 짬) → 기울인 채 → 렉 자리로 (끝 = MO 위치) */
int PO(int rack, int x, int y, int dan, int lift_speed, int tilt_speed,
       int delay, int return_delay, int tilt_angle, int tilt_check)
{
    MO(x, y, lift_speed, tilt_speed, delay, return_delay, tilt_angle);  /* 1. 렉으로 */
    po_stop(rack, dan);                                                 /* 2. 정지선 : 만재 F · 카드 S */
    /* 3. 쏟기 : 틸트 + JOG → 걸림 → JOG 끔 (다음에 짬, 11/26 threeD 의 Y 올려 쏟기 tilt_pour 지움) */
    pour_wait(rack, dan, return_delay, tilt_check);                     /* 4. 기울인 채 : 틸팅 검사 / 복귀 대기 */
    AM_Move(AM_ID, Y_MM(y), lift_speed);                                /* 5. Y 렉 자리로 */
    A_06(AM_Arrive(AM_ID, Y_MM(y)));
    return Motor_Stop() == 0;                                           /* 긴급정지 · 알람 없었으면 성공 */
}

/* 켤 때 X 벌리기 (11/26) : 겹쳐 있을 수 있으면 A (3) 원점 쪽 · B (6) 먼 벽 쪽 JOG → 벌어진 합이 X_APART_MM 되면 멈춤
   벽에 닿아 토크가 X_TORQUE_HIT 를 넘은 쪽만 먼저 멈춤 → 다른 쪽이 모자란 만큼 더 감
   FRAM 높이 차이 < Y_PASS_MM 이면 안 겹침 (이미 550 넘게 떨어짐) → 안 함. FRAM 모름이면 함. 성공 1 / 실패 (시간 · 'H' 아님 · 둘 다 막힘) 0 */
static int x_apart(void)
{
    int a_y, b_y;                                   /* FRAM Y 높이 mm */
    int32_t gap0 = am[6].pos - am[3].pos;           /* 출발 때 둘 사이 (칠판 펄스) */
    uint32_t start = osKernelGetTickCount();        /* 출발 시각 (X_APART_MS 제한) */

    if (FRAM_YRead(&a_y, &b_y) && abs(a_y - b_y) < Y_PASS_MM) return 1;   /* 1. 높이 비슷 = 안 겹침 → 안 벌림 */

    AM_Jog(3, -1, X_APART_PERCENT);                 /* 2. A 원점 쪽 */
    AM_Jog(6,  1, X_APART_PERCENT);                 /*    B 먼 벽 쪽 */
    while (am[6].pos - am[3].pos - gap0 < X_MM(X_APART_MM)                 /* 3. 합이 550 될 때까지 */
           && osKernelGetTickCount() - start < X_APART_MS && state.now == 'H') {
        if (abs(am[3].torque) >= X_TORQUE_HIT) AM_Jog(3, 0, 0);   /*    A 벽에 닿음 → A 만 멈춤 */
        if (abs(am[6].torque) >= X_TORQUE_HIT) AM_Jog(6, 0, 0);   /*    B 벽에 닿음 → B 만 멈춤 */
        osDelay(MOTOR_MS);                                          /*    칠판 한 바퀴 */
    }
    AM_Jog(3, 0, 0);                                /* 4. 둘 다 멈춤 */
    AM_Jog(6, 0, 0);
    return am[6].pos - am[3].pos - gap0 >= X_MM(X_APART_MM);   /* 550 벌어졌으면 성공 */
}

/* 두 대 같이 원점 : 출발 → 둘 다 끝날 때까지 물음 (끝난 대도 또 물음 : 같은 자리를 다시 0 으로 잡을 뿐).
   먼저 끝난 주소 / 실패 (60초 · 원점 중 'H' 아님 = 긴급정지 · 알람) 0 */
static uint8_t home_two(uint8_t a, uint8_t b)
{
    uint32_t start = osKernelGetTickCount();    /* 출발 시각 (60초 제한) */
    uint8_t first = 0;                          /* 먼저 끝난 주소 */
    int a_end;                                  /* 이번 바퀴에 a 가 끝났나 (1 / 0) */
    int b_end;                                  /* 이번 바퀴에 b 가 끝났나 */

    AM_Home(a);                                                 /* 1. 둘 같이 출발 */
    AM_Home(b);
    while (osKernelGetTickCount() - start < 60000 && state.now == 'H') {   /* 2. 60초 · 원점 중일 때만 */
        a_end = AM_HomeEnd(a);
        b_end = AM_HomeEnd(b);
        if (first == 0 && a_end) first = a;                     /*    먼저 끝난 대 기억 */
        if (first == 0 && b_end) first = b;
        if (a_end && b_end) return first;                       /* 3. 둘 다 끝 */
        osDelay(ARRIVE_MS);
    }
    AM_Stop(a);                                                 /* 실패 : 둘 다 멈춤 (따로 다 보냄) */
    AM_Stop(b);
    Log_Debug(LOG_HOME_Y_FAIL, a);                              /* 앞 주소 (Y 면 1 · X 면 3) */
    return 0;
}

/* 원점 : X 벌리기 (FRAM 높이로 판단) → Y 둘 같이 → 먼저 닿은 대 입고 높이 · 나중 대 입고 대기 → X 둘 같이 (높이가 달라 지나가도 됨). 성공 1 / 실패 0
   ⚠ 틸트는 보류 (TL57, 다음 주) : 켜기 전 틸트 가운데 */
int I(void)
{
    uint8_t first;                                          /* Y 원점 먼저 끝난 주소 */
    uint8_t later = 4;                                      /* 나중 = 다른 하나 */

    if (x_apart() == 0) return 0;                           /* 0. X 벌리기 (겹쳐 있으면 위 판이 아래 판을 찍지 않게, 11/26) */
    first = home_two(1, 4);                                 /* 1. Y 둘 같이 원점 → 먼저 닿은 주소 */
    if (first == 0) return 0;
    y_known = 1;                                            /*    Y 원점 끝 : 이제부터 FRAM 에 높이 적음 (Y_Remember) */
    if (first == 4) later = 1;
    AM_Move(first, Y_MM(Y_IN_MM), Y_UP_PERCENT);            /* 2. 먼저 → 입고 높이 */
    AM_Move(later, Y_MM(Y_WAIT_MM), Y_UP_PERCENT);          /*    나중 → 입고 대기 */
    if (AM_Arrive(first, Y_MM(Y_IN_MM)) == 0) return 0;     /* 3. 둘 다 도착 */
    if (AM_Arrive(later, Y_MM(Y_WAIT_MM)) == 0) return 0;
    return home_two(3, 6) > 0;                              /* 4. X 둘 같이 원점 벽 → 50mm */
}

/* (Comm_Task) 1초마다 두 로더 Y 높이를 FRAM 에 적음 → 끄고 켜도 누가 위인지 앎 (11/26)
   FRAM 은 Comm_Task 만 씀 (설정 저장과 같은 태스크 = 잠금 필요 없음). 칠판은 보기만 */
void Y_Remember(void)
{
    static uint32_t last = 0;                               /* 마지막으로 적은 시각 */

    if (y_known == 0) return;                               /* 아직 Y 원점 전 : 칠판 높이를 못 믿음 */
    if (osKernelGetTickCount() - last < 1000) return;       /* 1초 안 지남 */
    last = osKernelGetTickCount();
    FRAM_YWrite(1, am[1].pos / 10);                         /* A 의 Y : 펄스 → mm (1mm = 10펄스) */
    FRAM_YWrite(2, am[4].pos / 10);                         /* B 의 Y */
}

/* 긴급정지 : 6대 모두 멈춤. 하나가 통신 실패해도 나머지는 꼭 보냄 (멈추기 = 따로 다 보내고 결과만 합침) */
int E_S (void)
{
	int ok = 1;            /* 1 = 다 멈춤 보냄 */

	for (uint8_t id = 1; id <= Dual_ID; id++)    /* 나중에 방송 ID 0 한 번으로 */
		if (AM_Stop(id) == 0) ok = 0;
	return ok;             /* 하나라도 실패면 0 */
}

/* ======================= 모터 문 : 주문 큐 MoveQueue (ioc, 1칸) → Motor_Task =======================
   Motor_Task 는 주문을 "보기만" 하고 실행 → 끝나면 꺼냄. 그래서 큐에 1개 있음 = 동작 중 (다음 주문은 넣기 실패 = NAK) */

/* 주문 받기 (아무 태스크) : 지금 상태에서 받을 수 있고 큐가 비었으면 넣고 1 (Motor_Task 가 깸) / 아니면 0 (= NAK)
   'W' 대기 : 원점 · MI · MO · PO / 'I' 초기상태 : 원점만 / 'R' 운전 : MI · MO · PO 만 (MO 뒤 PO) / 그 밖 ('H' 'S' 'M' 'E' 'A') 못 받음 */
int Motor_Request(MOVE flag)
{
    int ok = 0;                                                         /* 1 = 지금 상태에서 받을 수 있음 */
    int move = (flag.cmd == CMD_MI || flag.cmd == CMD_MO || flag.cmd == CMD_PO);   /* 1 = 움직이는 명령 (0 = 원점) */

    if (state.now == 'W') ok = 1;
    if (state.now == 'I' && move == 0) ok = 1;
    if (state.now == 'R' && move == 1) ok = 1;
    if (ok == 0) return 0;
    return osMessageQueuePut(MoveQueueHandle, &flag, 0, 0) == osOK;   /* 동작 중이면 큐가 차 있어 실패 */
}

/* 동작 끝 : 성공이면 완료응답 AI · AO · EO (cmd.c 가 보내고 W 도 cmd.c) + 완료 로그 (걸린 시간) */
static void move_done(MOVE flag, uint32_t start, int ok)
{
    char done[24];

    if (ok) {
        snprintf(done, sizeof(done), "%c%c_%d_%d_%d", flag.cmd == CMD_PO ? 'E' : 'A', flag.cmd & 0xFF, flag.rack, flag.col, flag.dan);
        Done_Send(done);                                                /* AI_1_1_2 / AO_1_3_2 / EO_1_3_2 */
    }
    Log_Debug(LOG_MOVE_DONE, flag.cmd >> 8, flag.cmd & 0xFF, flag.rack, flag.col, flag.dan,
              ok ? "Complete" : "FAIL", (unsigned long)(osKernelGetTickCount() - start));
}

/* (Motor_Task 한 바퀴) 주문 올 때까지 잠 → 보기만 (큐에 남음 = 동작 중) → 하나 실행 → 끝나면 꺼냄 (큐 빔 = 다음 주문 받음)
   원점이면 motor_basic_init / 아니면 FRAM 표에서 좌표 찾기 → 'R' → MI · MO · PO → move_done
   표 찾기는 여기 한 곳 : FRAM 표는 1 번 칸부터라 열 · 단 번호 그대로 (2 열 = [2]) */
void Motor_Run(void)
{
    MOVE flag;                                                         /* 주문서 */
    uint32_t start;                                                    /* 시작 시각 (완료 로그) */
    int x, y;                                                          /* 렉 좌표 (FRAM 표) */

    xQueuePeek((QueueHandle_t)MoveQueueHandle, &flag, portMAX_DELAY);  /* 주문 올 때까지 잠, 보기만 */
    if (flag.cmd == CMD_I) motor_basic_init();                         /* 원점 : 시작 · 끝 다 motor_basic_init */
    else {
        start = osKernelGetTickCount();
        if (flag.rack % 2 == 1) { x = save.fp.right_x[flag.col]; y = save.fp.right_y[flag.dan]; }   /* 홀수 렉 = 오른쪽 표 */
        else                    { x = save.fp.left_x[flag.col];  y = save.fp.left_y[flag.dan];  }   /* 짝수 렉 = 왼쪽 표 */

        state.rack = flag.rack;                                        /* 이 렉 운전 */
        if (state.now == 'S') state.prev = 'R';                        /* 출발 직전에 일시정지 눌림 : 풀면 운전 (첫 정지선에서 섬) */
        else state.now = 'R';
        if (flag.cmd == CMD_MI) move_done(flag, start, MI(save.fp.safe_y[flag.dan], flag.lift_speed, flag.tilt_speed, flag.delay, flag.return_delay, flag.tilt_angle));
        if (flag.cmd == CMD_MO) move_done(flag, start, MO(x, y, flag.lift_speed, flag.tilt_speed, flag.delay, flag.return_delay, flag.tilt_angle));
        if (flag.cmd == CMD_PO) move_done(flag, start, PO(flag.rack, x, y, flag.dan, flag.lift_speed, flag.tilt_speed,
                                                            flag.delay, flag.return_delay, flag.tilt_angle, flag.tilt_check));
    }
    osMessageQueueGet(MoveQueueHandle, &flag, NULL, 0);                /* 끝 → 꺼냄 */
}

/* PO 가 서 있는 그 칸이 아직 만재면 1 (event.c btn_run 이 일시정지 풀기 전에 물음 → 치우고 RUN, 억지로는 PC D)
   지금 주문서는 큐에 남아 있으니 꺼내지 않고 보기만 (xQueuePeek, 0 = 안 기다림) */
int PO_manjae(void)
{
    MOVE flag;
    return xQueuePeek((QueueHandle_t)MoveQueueHandle, &flag, 0) == pdTRUE && flag.cmd == CMD_PO && manjae_on(flag.rack, flag.dan);
}
