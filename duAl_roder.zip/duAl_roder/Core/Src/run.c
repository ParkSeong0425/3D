/*
 * run.c : 로더 동작 — a_motor 의 기본 움직임을 모아 원점 · MI · MO · PO 를 만듦
 *   주문     Motor_Request (아무 태스크 : 큐 MoveQueue 에 넣기) → Motor_Run (Motor_Task : 주문서 flag 하나 실행 → move_done 완료응답 · 로그)
 *   동작     motor_basic_init · I · MI · MO · PO · E_S   (MI · MO · PO 는 좌표 · 높이 숫자를 받음, 표 찾기는 Motor_Run 한 곳)
 *   원점 블록 home_two (두 대 같이 원점) · y_park (800 · 20) · x_go (X mm 만큼 비킴) · home_y_first (Y → 800 · 20 → X)
 *   PO 블록  po_stop (만재 F · 카드 S) · pour_wait (기울인 채)   (쏟기 = 틸트 JOG, 다음에 짬)
 *   FRAM     REG_FRAM (Comm_Task, 칠판 한 바퀴마다 X · Y 위치 저장)
 *   정지선   while (state.now == 'S') osDelay(20);  멈춤(S)이면 풀릴 때까지 (MI · MO 끝 · PO 쏟기 전 · 쏟은 뒤)
 *
 *  듀얼 (11/23 ~) : 모터 6대 AIM, 주소 1 A-Y · 2 A-틸트 · 3 A-X · 4 B-Y · 5 B-틸트 · 6 B-X (그 로더 X 주소 = Y 주소 + 2)
 *   AM_Move · AM_Arrive 는 (주소, 펄스) → mm 는 Y_MM · X_MM 로 바꿔 넘김 (a_motor.h, 1mm = 10펄스 · Y 위 = + · X x2 쪽 = +)
 *   지금 : 설정 · 멈춤 = 6대 / 원점 = 6대 (틸트 빼고) / MI · MO · PO = 로더 n 별 (n = 1 A · 2 B, 태스크 둘, 방어벽 · PASS 는 MO 한 곳, 11/27)
 */
#include "run.h"
#include "a_motor.h"
#include "debug.h"
#include "event.h"
#include "cmsis_os2.h"
#include "FreeRTOS.h"
#include "queue.h"          /* xQueuePeek (주문 보기만) */
#include "status.h"
#include "cmd.h"
#include "alarm.h"
#include "manjae.h"
#include "rfid.h"
#include "save.h"
#include "fram.h"           /* yFRAM · xFRAM (REG_FRAM) · FRAM_YRead · FRAM_XRead (I) */
#include <stdio.h>
#include <stdlib.h>         /* abs (I 의 FRAM 높이 차이) */

/* 원점 숫자 (mm, Y 의 0 = 아래 벽 + 50mm · X 의 0 = 입고대 벽 + 50mm) */
#define Y_UP_PERCENT    10      /* [현장] 원점 뒤 움직이는 속도 % (3% 면 800mm 에 17초 → AM_Arrive 8초 넘음) */
#define X_FAR_MM        1600    /* [현장] 겹친 자리 FRAM X 가 이 이상이면 먼 벽 가까이 → + 로 못 비킴 → X 작은 로봇이 − 로 비킴 */
#define SAFE_WAIT_MS    60000   /* [현장] 방어벽 앞에서 상대가 비키기를 기다리는 최대 ms → 넘으면 안 가고 실패 */
#define TURN_WAIT_MS    300000  /* [현장] 상대 명령이 끝나기를 (차례) 기다리는 최대 ms (상대 PO 만재 · 카드 기다림 포함, 5분) → 넘으면 실패 */
/* 입고 · 대기 높이와 방어벽은 PC 설정 (save) : FP 1_2 in_y[1] 입고 800 · in_y[2] 대기 20 / FP 13 safe_x 550 · safe_y 340 */

/* 원점 (켤 때 · 시작 · PC I) : H → 드라이브 설정 (6대 따로 다 보냄) → 원점 → W / 못 가면 알람 10. 도착 1 / 실패 0 */
int motor_basic_init(void)
{
    int ok = 1;                         /* 1 = 6대 다 설정됨 */

    state.now = 'H';                  /* 원점 중 → 램프 원점 깜빡 · 화면 원점설정 */
    Log_Debug(LOG_HOME_START);

    /* 서보 ON : 틸트 → Y → X (하나 실패해도 나머지는 함) */
    if (AM_Init(2) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 2); ok = 0; }   /* A 틸트 */
    if (AM_Init(5) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 5); ok = 0; }   /* B 틸트 */
    if (AM_Init(1) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 1); ok = 0; }   /* A Y */
    if (AM_Init(4) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 4); ok = 0; }   /* B Y */
    if (AM_Init(3) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 3); ok = 0; }   /* A X */
    if (AM_Init(6) == 0) { Log_Debug(LOG_HOME_NO_ANSWER, 6); ok = 0; }   /* B X */

    if (ok && I() && Motor_Stop() == 0) {   /* 설정 다 됨 → 원점 도착 (도중에 알람 · 긴급정지 없었음) */
        state.now = 'W';              /* 대기 → 램프 rfid */
        Log_Debug(LOG_HOME_DONE);
        return 1;
    }

    A_10(0, 0);                        /* 못 감 → 알람 10 (이미 알람이면 그대로) : RESET → RUN 으로 다시 */
    Log_Debug(LOG_HOME_FAIL);
    return 0;
}


/* ── 블록 (PO 가 부름) : 판단(if · while)이 들어간 것만. 모터 한 줄짜리는 모터 함수를 그대로 부름 ── */

/* PO 정지선 (쏟기 전) : ① 확인 → ② 문제면 멈춤 → ③ 정지선
   만재 : 2초 봐서 진짜면 F (비우고 시작 · 억지로는 PC D) / 카드 없음 : S (카드 들어오면 저절로 · 시작). MI · MO 는 상관없음 */
static void po_stop(int rack, int dan)
{
    while (manjae_on(rack, dan) && manjae_2s(rack, dan) == 0) osDelay(20);    /* ① 만재면 스친 건지 2초 봄 */
    if (manjae_on(rack, dan)) Pause_Set(rack, 'F');                          /* ② 진짜 만재 → 멈춤 F (PPAUSE: F) */
    while (state.now == 'S') osDelay(20);                                    /* ③ 비우고 시작 · PC D 까지 */

    if (card_on(rack) == 0) Pause_Set(rack, 'S');                            /* ② 카드 없음 → 멈춤 S (리더 끄면 늘 있음이라 안 멈춤) */
    while (state.now == 'S' && state.why == 'S' && card_on(rack) == 0) osDelay(20);   /* ③ 카드 들어올 때까지 (시작으로도 풀림) */
    if (state.now == 'S' && state.why == 'S') Pause_Clear();                 /*    들어왔으면 저절로 이어서 */
}

/* PO 기울인 채 : ① 검사면 FP 7 안에 그 단 센서가 닿나 봄 → ② 닿음 · 검사 안 함 = 복귀 대기 / 안 닿음 = 틸팅 에러 (멈춤 T) → ③ 정지선
   검사 = PC 명령 마지막 자리 1 && FS 옵션 마지막 자리 1 && 렉 1 · 2. 복귀 대기 = PC 명령 값 × 10ms (080 → 0.8초) */
static void pour_wait(int rack, int dan, int return_delay, int tilt_check)
{
    int check = (tilt_check == 1 && save.fs.option[4] == 1 && rack <= 2);     /* 검사할까 */
    uint32_t start = osKernelGetTickCount();                                   /* 검사 시작 시각 */

    while (check && manjae_on(rack, dan) == 0 && osKernelGetTickCount() - start < save.fp.tilt_check_time) osDelay(20);
                                                                               /* ① 검사 : 닿을 때까지 (최대 FP 7) */
    if (check && manjae_on(rack, dan) == 0) Pause_Set(rack, 'T');              /* ② 안 닿음 → 틸팅 에러 (PPAUSE: T) */
    else osDelay(return_delay * 10);                                           /*    닿음 · 검사 안 함 → 복귀 대기 */
    while (state.now == 'S') osDelay(20);                                      /* ③ 정지선 : 기울인 채 시작 · D 까지 */
}


/* ── 동작 (좌표 · 높이 숫자를 받음, 나머지는 프로토콜 순서 그대로. 안 쓰는 칸도 받음) ──
   긴급정지 · 알람이 걸리면 그 뒤 이동 · 기다림은 모터 함수가 알아서 안 함 (문 2, status.c Motor_Stop) → 마지막에 결과만 */

/* ── 이동 블록 (듀얼 11/27) : n = 로더 1 A (모터 Y 1 · X 3) / 2 B (Y 4 · X 6), 상대 = 3 - n. 위치는 mm ── */

/* 로더 n 의 X · Y 지금 자리 mm (칠판) */
static int now_x(int n) { return am[n * 3].pos / 10; }
static int now_y(int n) { return am[n * 3 - 2].pos / 10; }

/* 로더 n 의 주문 큐 (A MoveQueue · B MoveQueueB) */
static osMessageQueueId_t loader_q(int n)
{
    if (n == 2) return MoveQueueBHandle;
    return MoveQueueHandle;
}

/* 상대가 내 길 안에 있나 : 내 지금 자리 → 목표 를 둘러싼 네모를 방어벽 (X 550 · Y 340) 만큼 넓혀서 그 안이면 1
   (네모 가운데에서 상대까지 거리 < 네모 반 + 방어벽. 양쪽에 2 를 곱해 반으로 나누기를 없앰) */
static int in_path(int n, int x, int y)
{
    return abs(2 * now_x(3 - n) - now_x(n) - x) < abs(now_x(n) - x) + 2 * save.fp.safe_x
        && abs(2 * now_y(3 - n) - now_y(n) - y) < abs(now_y(n) - y) + 2 * save.fp.safe_y;
}

/* 방어벽 : 상대가 내 길 안에 있으면 비킬 때까지 기다림. 비었음 1 / SAFE_WAIT_MS 넘음 0 (안 감) */
static int path_wait(int n, int x, int y)
{
    uint32_t start = osKernelGetTickCount();

    while (in_path(n, x, y) && osKernelGetTickCount() - start < SAFE_WAIT_MS) osDelay(20);
    if (in_path(n, x, y) == 0) return 1;
    Log_Debug(LOG_SAFE_WAIT, n, x, y);
    return 0;
}

/* PASS : 상대가 입고대 앞 20 에서 기다리면 (R · X 550 안 · Y 20 근처), 내 X 가 550 을 넘을 때 상대 → 입고 800 · 'W'. 늘 1 */
static int pass_up(int n, int x)
{
    uint32_t start = osKernelGetTickCount();

    if (x < save.fp.safe_x) return 1;                                           /* 550 안쪽으로 감 : 안 함 */
    if (loader[3 - n].now_doing == 'R' && now_x(3 - n) < save.fp.safe_x && abs(now_y(3 - n) - save.fp.in_y[2]) < 10) {
        while (now_x(n) < save.fp.safe_x && osKernelGetTickCount() - start < MOVE_MS) osDelay(20);   /* 내 X 가 550 넘을 때까지 */
        AM_Move((3 - n) * 3 - 2, Y_MM(save.fp.in_y[1]), Y_UP_PERCENT);         /* 상대 Y → 입고 800 */
        loader[3 - n].now_doing = 'W';
    }
    return 1;
}

/* 도착 : X (못 가면 알람 05) → Y (06) → 칠판 새로 적힐 때까지 (다음 구간 X 상대 이동이 맞은 자리에서 계산). 도착 1 / 못 감 0 */
static int arrive(int n, int x, int y)
{
    if (A_05(AM_Arrive(n * 3, X_MM(x)))) return 0;
    if (A_06(AM_Arrive(n * 3 - 2, Y_MM(y)))) return 0;
    osDelay(2 * MOTOR_MS);
    return Motor_Stop() == 0;
}

/* 한 구간 : 길 비었나 → X · Y 출발 → PASS → 도착. 성공 1 / 못 감 0 */
static int leg(int n, int x, int y, int speed)
{
    return path_wait(n, x, y)
        && AM_Move(n * 3, X_MM(x), speed)
        && AM_Move(n * 3 - 2, Y_MM(y), speed)
        && pass_up(n, x)
        && arrive(n, x, y);
}

/* 정지선 : 멈춤 (S) 이면 풀릴 때까지. 긴급정지 · 알람 없었으면 1 */
static int stop_line(void)
{
    while (state.now == 'S') osDelay(20);
    return Motor_Stop() == 0;
}

/* 쏟기 : 정지선 (만재 F · 카드 S) → 'T' (상대 기다림) → 쏟기 (틸트, 다음 주 TL57) → 기울인 채 → 'O' (EO 끝). 성공 1 */
static int pour(int n, int rack, int dan, int return_delay, int tilt_check)
{
    po_stop(rack, dan);
    loader[n].now_doing = 'T';
    pour_wait(rack, dan, return_delay, tilt_check);
    loader[n].now_doing = 'O';                                                  /* dan 은 남김 : 상대 MI 가 높이 고를 때 */
    return Motor_Stop() == 0;
}

/* MI 지나갈 높이 : 상대가 800 대기 (W) 이거나 3 · 4단 일 · 내가 1 · 2단이면 아래 20 / 아니면 지금 높이 (위로 지나감) */
static int pass_y(int n)
{
    if (loader[3 - n].now_doing == 'W' || loader[3 - n].dan >= 3 || loader[n].dan <= 2) return save.fp.in_y[2];
    return now_y(n);
}

/* MI 끝 높이 : 상대가 800 에 있으면 (W) 입고 대기 20 / 아니면 입고 800 */
static int mi_y(int n)
{
    if (loader[3 - n].now_doing == 'W') return save.fp.in_y[2];
    return save.fp.in_y[1];
}

/* MI 끝 : 800 이면 'W' (PO · MO 받음) / 20 이면 'R' (입고 대기 : 상대 PASS 때 800). 늘 1 */
static int mi_end(int n)
{
    loader[n].dan = 0;
    loader[n].now_doing = 'W';
    if (loader[3 - n].now_doing == 'W') loader[n].now_doing = 'R';
    return 1;
}


/* ── 동작 (좌표 · 높이 숫자를 받음, 나머지는 프로토콜 순서 그대로. 안 쓰는 칸도 받음) ──
   긴급정지 · 알람이 걸리면 그 뒤 이동 · 기다림은 모터 함수가 알아서 안 함 (문 2, status.c Motor_Stop) → 마지막에 결과만 */

/* 출고 : 로더 n 을 (x, y mm) 로. X 는 늘 높은 쪽 높이에서 다님 (11/27 비스듬히 가다 스쳐 부딪힘)
   올라감 = Y 먼저 → X / 내려감 · 같음 = X 먼저 → Y. 구간마다 방어벽 · PASS */
int MO(int n, int x, int y, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle)
{
    osDelay(delay);                                                                                         /* 1. 출발 대기 */
    if (y > now_y(n)) return leg(n, now_x(n), y, lift_speed) && leg(n, x, y, lift_speed) && stop_line();    /* 2. 올라감 : Y → X */
    return leg(n, x, now_y(n), lift_speed) && leg(n, x, y, lift_speed) && stop_line();                      /*    내려감 : X → Y */
}

/* 분배 : 렉으로 → 쏟기 → EO 끝 'O' (빈 채 렉 앞, MI 만 받음) */
int PO(int n, int rack, int x, int y, int dan, int lift_speed, int tilt_speed,
       int delay, int return_delay, int tilt_angle, int tilt_check)
{
    return MO(n, x, y, lift_speed, tilt_speed, delay, return_delay, tilt_angle)   /* 1. 렉으로 */
        && pour(n, rack, dan, return_delay, tilt_check);                         /* 2. 쏟기 */
}

/* 입고 : 그 자리에서 지나갈 높이 → 그 높이로 X 0 → 입고 높이 (800, 상대가 800 이면 20) → W / R */
int MI(int n, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle)
{
    return MO(n, now_x(n), pass_y(n), lift_speed, tilt_speed, delay, return_delay, tilt_angle)   /* 1. 높이만 */
        && MO(n, 0, pass_y(n), lift_speed, tilt_speed, 0, return_delay, tilt_angle)             /* 2. 입고대 쪽 X 0 */
        && MO(n, 0, mi_y(n), lift_speed, tilt_speed, 0, return_delay, tilt_angle)               /* 3. 800 (또는 20) */
        && mi_end(n);                                                                           /* 4. W (또는 R) */
}

/* 두 대 같이 원점 : 출발 → 둘 다 끝날 때까지 물음 (끝난 대도 또 물음 : 같은 자리를 다시 0 으로 잡을 뿐).
   먼저 끝난 주소 / 실패 (60초 · 원점 중 'H' 아님 = 긴급정지 · 알람) 0 */
static uint8_t home_two(uint8_t a, uint8_t b)
{
    uint32_t start = osKernelGetTickCount();    /* 출발 시각 (60초 제한) */
    uint8_t first = 0;                          /* 먼저 끝난 주소 */
    int a_end;                                  /* 이번 바퀴에 a 가 끝났나 (1 / 0) */
    int b_end;                                  /* 이번 바퀴에 b 가 끝났나 */

    AM_Home(a);                                                 /* 1. 둘 같이 출발 */
    AM_Home(b);
    while (osKernelGetTickCount() - start < 60000 && state.now == 'H') {   /* 2. 60초 · 원점 중일 때만 */
        a_end = AM_HomeEnd(a);
        b_end = AM_HomeEnd(b);
        if (first == 0 && a_end) first = a;                     /*    먼저 끝난 대 기억 */
        if (first == 0 && b_end) first = b;
        if (a_end && b_end) return first;                       /* 3. 둘 다 끝 */
        osDelay(ARRIVE_MS);
    }
    AM_Stop(a);                                                 /* 실패 : 둘 다 멈춤 (따로 다 보냄) */
    AM_Stop(b);
    Log_Debug(LOG_HOME_Y_FAIL, a);                              /* 앞 주소 (Y 면 1 · X 면 3) */
    return 0;
}

/* ── 원점 블록 (I 가 부름) ── */

/* Y 자리 : high → 입고 높이 · low → 입고 대기 (같이 출발 → 둘 다 도착). 성공 1 / 못 감 0 */
static int y_park(uint8_t high, uint8_t low)
{
    AM_Move(high, Y_MM(save.fp.in_y[1]), Y_UP_PERCENT);
    AM_Move(low,  Y_MM(save.fp.in_y[2]), Y_UP_PERCENT);
    loader[(high + 2) / 3].now_doing = 'W';                 /* 800 로더 = 대기 (짐 받으면 PO) · Y 주소 1 → 로더 1, 4 → 2 */
    loader[(low + 2) / 3].now_doing = 'R';                  /* 20 로더 = 입고 대기 (상대 PASS 때 800 으로) */
    loader[1].dan = 0;
    loader[2].dan = 0;
    return AM_Arrive(high, Y_MM(save.fp.in_y[1])) && AM_Arrive(low, Y_MM(save.fp.in_y[2]));
}

/* X 를 지금 자리에서 mm 만큼 (+ = x2 쪽). X 원점 전에도 됨. 성공 1 / 못 감 0 */
static int x_go(uint8_t id, int mm)
{
    int32_t target = am[id].pos + X_MM(mm);                 /* 갈 자리 = 지금 칠판 자리 + mm (AM_Move 는 자리를 받음) */

    AM_Move(id, target, Y_UP_PERCENT);
    return AM_Arrive(id, target);
}

/* Y 원점 → 먼저 끝난 대 입고 높이 · 나중 대 입고 대기 → X 원점 한 번. 성공 1 / 실패 0 */
static int home_y_first(void)
{
    uint8_t first = home_two(1, 4);                         /* Y 둘 같이 원점 → 먼저 끝난 주소 */
    uint8_t later = 4;

    if (first == 0) return 0;
    if (first == 4) later = 1;
    return y_park(first, later)                             /* 800 · 20 */
        && home_two(3, 6);                                  /* X 원점 한 번 (높이 780 차이라 엇갈려도 됨) */
}

/* 원점 (켤 때 · 시작 · PC I) : FRAM 으로 두 로더 자리를 보고 경우마다 움직임 (11/27). 성공 1 / 실패 0
   위에서부터 먼저 맞는 경우 하나만 함. 방어벽 = save.fp.safe_x (550) · safe_y (340), 먼 벽 = X_FAR_MM (1600)
   주소 : A-X 3 · B-X 6 / X + = x2 쪽 (먼 벽) · − = 입고대 쪽
   틸트는 보류 (TL57, 다음 주) : 켜기 전 틸트 가운데 */
int I(void)
{
    int a_y = 0, b_y = 0;                                   /* FRAM Y 높이 mm (A · B) */
    int a_x = 0, b_x = 0;                                   /* FRAM X 위치 mm (A · B) */

    /* PC 설정 없음 (FP 1_2 입고 · FP 13 방어벽 = 0) → 원점 안 함 (방어벽 0 이면 늘 "떨어짐" 으로 보여 부딪힘) */
    if (save.fp.in_y[1] == 0 || save.fp.safe_x == 0 || save.fp.safe_y == 0) {
        Log_Debug(LOG_FP_EMPTY);
        return 0;
    }
    /* 0 : FRAM 없음 · 깨짐 → 사람이 떼어 놓았다고 보고 바로 원점 */
    else if (FRAM_YRead(&a_y, &b_y) == 0 || FRAM_XRead(&a_x, &b_x) == 0) {
        Log_Debug(LOG_FY_UNKNOWN);
        return home_y_first();
    }
    /* 1 : X 떨어짐 (550 이상) → 부딪힐 일 없음 → 바로 원점 */
    else if (abs(a_x - b_x) >= save.fp.safe_x) {
        return home_y_first();
    }
    /* 2 : X 가깝고 높이 비슷 (340 미만) → Y 내리면 위 로봇이 아래 로봇을 찍음 → 멈춤
           (사람이 벌리고 FRAMCLR → HOME) */
    else if (abs(a_y - b_y) < save.fp.safe_y) {
        Log_Debug(LOG_POS_CLOSE, a_y, b_y, a_x, b_x);
        return 0;
    }
    /* 3 : 겹침 · 입고대 쪽 (둘 중 하나라도 1600 미만) · A 가 아래 → A 가 먼 벽 쪽 (+) 으로 550 비킴 → 원점 */
    else if ((a_x < X_FAR_MM || b_x < X_FAR_MM) && a_y < b_y) {
        if (x_go(3, save.fp.safe_x) == 0) return 0;
        return home_y_first();
    }
    /* 4 : 겹침 · 입고대 쪽 (둘 중 하나라도 1600 미만) · B 가 아래 → B 가 먼 벽 쪽 (+) 으로 550 비킴 → 원점 */
    else if (a_x < X_FAR_MM || b_x < X_FAR_MM) {
        if (x_go(6, save.fp.safe_x) == 0) return 0;
        return home_y_first();
    }
    /* 5 : 겹침 · 먼 벽 쪽 (x1 · x2 둘 다 1600 이상) · A 가 입고대 쪽 → A 가 입고대 쪽 (−) 으로 550 비킴 → 원점 */
    else if (a_x < b_x) {
        if (x_go(3, -save.fp.safe_x) == 0) return 0;
        return home_y_first();
    }
    /* 6 : 겹침 · 먼 벽 쪽 (x1 · x2 둘 다 1600 이상) · B 가 입고대 쪽 → B 가 입고대 쪽 (−) 으로 550 비킴 → 원점 */
    else {
        if (x_go(6, -save.fp.safe_x) == 0) return 0;
        return home_y_first();
    }
}

/* (Comm_Task) 칠판 한 바퀴 (MOTOR_MS) 마다 두 로더 Y 높이 · X 위치를 FRAM 에 적음 → 끄고 켜도 기억 (11/26 · 27)
   두 대 다 진짜 위치일 때만 (Remember_pos, a_motor.c) : 하나라도 모르면 그 쌍은 안 적음 (모르는 값으로 덮어쓰지 않게)
   FRAM 은 Comm_Task 만 씀 (설정 저장과 같은 태스크 = 잠금 필요 없음). 칠판은 보기만 */
void REG_FRAM(void)
{
    static uint32_t last = 0;                               /* 마지막으로 적은 시각 */

    if (state.now == 'H') return;                           /* 원점 중 : Motor_Task 의 I() · AM_Init 이 FRAM 을 읽음 → SPI 겹치지 않게 안 적음 (11/27) */
    if (osKernelGetTickCount() - last < MOTOR_MS) return;   /* 칠판 한 바퀴 안 지남 */
    last = osKernelGetTickCount();
    if (Remember_pos[1] && Remember_pos[4]) yFRAM(am[1].pos / 10, am[4].pos / 10);   /* Y : A · B 높이 (펄스 → mm) */
    if (Remember_pos[3] && Remember_pos[6]) xFRAM(am[3].pos / 10, am[6].pos / 10);   /* X : A · B 위치 */
}

/* 긴급정지 : 6대 모두 멈춤. 하나가 통신 실패해도 나머지는 꼭 보냄 (멈추기 = 따로 다 보내고 결과만 합침) */
int E_S (void)
{
    int ok = 1;            /* 1 = 다 멈춤 보냄 */

    for (uint8_t id = 1; id <= Dual_ID; id++)    /* 나중에 방송 ID 0 한 번으로 */
        if (AM_Stop(id) == 0) ok = 0;
    return ok;             /* 하나라도 실패면 0 */
}

/* ======================= 모터 문 : 주문 큐 MoveQueue (A) · MoveQueueB (B) (ioc, 1칸) → Motor_Task · Motor_B_Task =======================
   태스크는 주문을 "보기만" 하고 실행 → 끝나면 꺼냄. 그래서 큐에 1개 있음 = 그 로더 동작 중 (다음 주문은 넣기 실패 = NAK) */

/* 주문 받기 (아무 태스크) : 기계 상태로 받을 수 있나 → 받을 로더 고르기 → 그 로더 큐에 넣고 1 / 아니면 0 (= NAK)
   기계 'W' 대기 : 원점 · MI · MO · PO / 'I' 초기상태 : 원점만 / 'R' 운전 : MI · MO · PO 만 / 그 밖 ('H' 'S' 'M' 'E' 'A') 못 받음
   로더 고르기 (듀얼 11/27) : 원점 → A 태스크 / MI → 'O' (EO 끝) 로더, 없으면 'W' (이미 800 → 바로 완료) / MO · PO → 'W' (800 에서 짐 받은) 로더 */
int Motor_Request(MOVE flag)
{
    int ok = 0;                                                         /* 1 = 지금 상태에서 받을 수 있음 */
    int move = (flag.cmd == CMD_MI || flag.cmd == CMD_MO || flag.cmd == CMD_PO);   /* 1 = 움직이는 명령 (0 = 원점) */
    int n = 0;                                                          /* 받을 로더 (1 A · 2 B, 0 = 없음) */

    if (state.now == 'W') ok = 1;
    if (state.now == 'I' && move == 0) ok = 1;
    if (state.now == 'R' && move == 1) ok = 1;
    if (ok == 0) return 0;

    if (move == 0) n = 1;                                                               /* 원점 : A 태스크가 두 로더 다 */
    if (flag.cmd == CMD_MI && loader[2].now_doing == 'W') n = 2;                        /* MI : 800 에 있는 로더 (바로 완료) */
    if (flag.cmd == CMD_MI && loader[1].now_doing == 'W') n = 1;
    if (flag.cmd == CMD_MI && loader[2].now_doing == 'O') n = 2;                        /*      EO 끝 로더가 먼저 */
    if (flag.cmd == CMD_MI && loader[1].now_doing == 'O') n = 1;
    if ((flag.cmd == CMD_MO || flag.cmd == CMD_PO) && loader[2].now_doing == 'W') n = 2;   /* MO · PO : 800 에서 짐 받은 로더 */
    if ((flag.cmd == CMD_MO || flag.cmd == CMD_PO) && loader[1].now_doing == 'W') n = 1;
    if (n == 0) return 0;                                                               /* 받을 로더 없음 */
    return osMessageQueuePut(loader_q(n), &flag, 0, 0) == osOK;                        /* 그 로더 큐 (동작 중이면 차 있어 실패) */
}

/* 동작 끝 : 성공이면 완료응답 AI · AO · EO (cmd.c 가 보내고 W 도 cmd.c) + 완료 로그 (걸린 시간) */
static void move_done(MOVE flag, uint32_t start, int ok)
{
    char done[24];

    if (ok) {
        snprintf(done, sizeof(done), "%c%c_%d_%d_%d", flag.cmd == CMD_PO ? 'E' : 'A', flag.cmd & 0xFF, flag.rack, flag.col, flag.dan);
        Done_Send(done);                                                /* AI_1_1_2 / AO_1_3_2 / EO_1_3_2 */
    }
    Log_Debug(LOG_MOVE_DONE, flag.cmd >> 8, flag.cmd & 0xFF, flag.rack, flag.col, flag.dan,
              ok ? "Complete" : "FAIL", (unsigned long)(osKernelGetTickCount() - start));
}

/* 상대가 움직이는 차례인가 (A 가 먼저) : B 는 A 가 명령 중 (A 큐 참) 이면 / A 는 B 가 움직이는 중 (B 큐 참 + R · T) 이면 1 */
static int other_moving(int n)
{
    if (n == 2) return osMessageQueueGetCount(loader_q(1)) > 0;
    return osMessageQueueGetCount(loader_q(2)) > 0 && (loader[2].now_doing == 'R' || loader[2].now_doing == 'T');
}

/* 차례 : 한 번에 한 로더만 움직임 (11/27 두 로더가 같이 움직이다 스쳐 부딪힘) → 상대가 끝날 때까지 기다림. 됨 1 / TURN_WAIT_MS 넘음 0 */
static int wait_turn(int n)
{
    uint32_t start = osKernelGetTickCount();

    while (other_moving(n) && osKernelGetTickCount() - start < TURN_WAIT_MS) osDelay(20);
    return other_moving(n) == 0;
}

/* 렉 좌표 mm (FRAM 표, 1 번 칸부터라 열 · 단 번호 그대로) : 홀수 렉 = 오른쪽 표 / 짝수 렉 = 왼쪽 표 */
static int rack_x(MOVE f)
{
    if (f.rack % 2 == 1) return save.fp.right_x[f.col];
    return save.fp.left_x[f.col];
}
static int rack_y(MOVE f)
{
    if (f.rack % 2 == 1) return save.fp.right_y[f.dan];
    return save.fp.left_y[f.dan];
}

/* 명령 하나 : MI 인데 이미 800 이면 바로 완료 / 아니면 'R' → MI · MO · PO. 성공 1 / 실패 0 */
static int run_one(int n, MOVE f)
{
    if (f.cmd == CMD_MI && loader[n].now_doing == 'W') return 1;      /* MI : 이미 800 → 바로 완료 */

    state.rack = f.rack;                                               /* 이 렉 운전 */
    if (state.now == 'S') state.prev = 'R';                            /* 출발 직전에 일시정지 눌림 : 풀면 운전 (첫 정지선에서 섬) */
    else state.now = 'R';
    loader[n].now_doing = 'R';                                         /* 이 로더 운전 */

    if (f.cmd == CMD_MI) return MI(n, f.lift_speed, f.tilt_speed, f.delay, f.return_delay, f.tilt_angle);
    loader[n].dan = f.dan;                                             /* 몇 단 (상대 MI 가 높이 고를 때) */
    if (f.cmd == CMD_MO) return MO(n, rack_x(f), rack_y(f), f.lift_speed, f.tilt_speed, f.delay, f.return_delay, f.tilt_angle);
    return PO(n, f.rack, rack_x(f), rack_y(f), f.dan, f.lift_speed, f.tilt_speed, f.delay, f.return_delay, f.tilt_angle, f.tilt_check);
}

/* (로더 n 태스크 한 바퀴 : A Motor_Task 는 Motor_Run(1) · B Motor_B_Task 는 Motor_Run(2))
   주문 올 때까지 잠 → 보기만 (큐에 남음 = 동작 중) → 하나 실행 → 끝나면 꺼냄 (큐 빔 = 다음 주문 받음)
   원점이면 motor_basic_init / 아니면 FRAM 표에서 좌표 찾기 → 'R' → MI · MO · PO → move_done
   표 찾기는 여기 한 곳 : FRAM 표는 1 번 칸부터라 열 · 단 번호 그대로 (2 열 = [2]) */
void Motor_Run(int n)
{
    MOVE flag;                                                         /* 주문서 */
    uint32_t start;                                                    /* 시작 시각 (완료 로그) */

    xQueuePeek((QueueHandle_t)loader_q(n), &flag, portMAX_DELAY);      /* 주문 올 때까지 잠, 보기만 */
    start = osKernelGetTickCount();
    if (flag.cmd == CMD_I) motor_basic_init();                         /* 원점 : 시작 · 끝 다 motor_basic_init (A 만) */
    else move_done(flag, start, wait_turn(n) && run_one(n, flag));    /* 차례 기다림 → 하나 실행 → 완료응답 */
    osMessageQueueGet(loader_q(n), &flag, NULL, 0);                    /* 끝 → 꺼냄 */
}

/* 그 로더 큐에 PO 가 있고 그 칸이 아직 만재면 1 */
static int po_full(int n)
{
    MOVE flag;

    return xQueuePeek((QueueHandle_t)loader_q(n), &flag, 0) == pdTRUE && flag.cmd == CMD_PO && manjae_on(flag.rack, flag.dan);
}

/* PO 가 서 있는 그 칸이 아직 만재면 1 (event.c btn_run 이 일시정지 풀기 전에 물음 → 치우고 RUN, 억지로는 PC D)
   지금 주문서는 큐에 남아 있으니 꺼내지 않고 보기만 (xQueuePeek, 0 = 안 기다림). 로더 A · B 둘 다 봄 */
int PO_manjae(void)
{
    return po_full(1) || po_full(2);
}
