/*
 * alarm.c : 알람 조건 확인 + 걸기 (조건 · 숫자는 전부 여기, 부르는 곳은 한 줄씩)
 *
 *  알람 번호 · 부르는 곳
 *   01 HMI 통신         Event_Task 스위치판        A_01()                   ESP 대답 3번 없음
 *   02 · 03 · 04 드라이브 Bus_Task Alarm_Drive        A_03() (AIM 6대, 듀얼)  칠판 알람 칸에 코드가 있음 → X 02 · Y 03 · 틸트 04
 *   02 X 부딪힘          Bus_Task Alarm_Drive        x_hit                    X 토크가 X_TORQUE_HIT 를 3바퀴 넘음 (11/26, PC 에는 02 로)
 *   05 · 06 · 07 위치    run.c MI · MO · PO          A_06(AM_Arrive(…)) …    8초 안에 못 감
 *                대답 없음 Bus_Task Alarm_Drive    bus_alarm                그 축 하나만 MOTOR_MISS 번 연속 대답 없음 (로그에 주소)
 *   09 비상정지          event.c estop_event         A_09()
 *   10 원점              a_motor AM_Home · run.c     A_10(far, start)
 *   11 모터 선 끊김       Bus_Task Alarm_Drive        bus_alarm                6대 다 MOTOR_MISS 번 연속 대답 없음 (UART2 선 · 전원)
 *   12 랜선 빠짐          net.c Net_On_Off            A_12()
 *   풀기 : Alarm_Clear (HMI RESET · PC I) / PC 로 알림 : Alarm_PC (Comm_Task)
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */
#include "alarm.h"
#include "buzzer.h"
#include "status.h"
#include "run.h"
#include "hmi.h"
#include "net.h"
#include "debug.h"
#include "a_motor.h"
#include "event.h"
#include "flag.h"
#include "main.h"
#include "cmsis_os2.h"
#include "comm.h"           /* 대답 없음 횟수 HMI_MISS · MOTOR_MISS · HMI_BOOT_MS */
#include <stdlib.h>         /* abs (x_hit 토크 크기) */

#define HOME_FAST_MS    2000    /* 10 : 멀리 있었는데 이 시간 안에 닿으면 걸림 */
#define X_HIT_COUNT     3       /* [현장] 02 X 부딪힘 : 토크가 X_TORQUE_HIT (a_motor.h) 를 이만큼 바퀴 (× MOTOR_MS 60 = 180ms) 연달아 넘으면 (11/26) */
/* 01 · 05 ~ 07 · 11 대답 없음 횟수는 comm.h */

/* 알람 번호는 status.h state.alarm (11/16 상태 하나로) */


/* 알람 걸기 (공통) : 로그 + 세우기 + 번호 + 상태 A + PC 알림(CommQueue 'A') + 부저 */
static void alarm_go(int code, const char *log)
{
    uint8_t task_copy = PC_ALARM;                                       /* 주문서 : 알람 */

    Log_Debug("%s", log);                                               /* 어떤 알람 · 이유 (debug.h LOG_A..) */
    HMI_Manual(BTN_JOG_STOP);                                           /* 수동 JOG 중이면 세움 (상태 A 가 되면 뗌 글자를 안 받아서 Y JOG 신호가 남음) */
    E_S();                                                              /* 6대 멈춤 */
    state.alarm = code;                                                 /* 번호 */
    state.why = 0;                                                      /* 멈춤 이유 지움 (알람이 우선 → 정지선 기다림 끝) */
    state.now = 'A';                                                 /* 상태 A (수동 · 멈춤 중이었어도) */
    osMessageQueuePut(CommQueueHandle, &task_copy, 0, 0);               /* PC 로 알림 : S_1_A_09 → Comm_Task (Alarm_PC) */
    Buzzer_On();                                                        /* 부저 켬 (HMI 음소거 · RESET 으로 끔) */
}

/* 05 · 06 · 07 공통 : 도착 못 함(arrived 0)이면 알람. 이미 멈춤(긴급정지 · 알람)이면 덮어쓰지 않음. 걸면 1 */
static int arrive_alarm(int arrived, int code, const char *log)
{
    if (arrived || Motor_Stop()) return 0;
    alarm_go(code, log);
    return 1;
}

/* 01 HMI 통신 : 20ms 마다 물었는데 ESP 가 연달아 3번 대답 안 함 (꺼짐 · 선 빠짐 · 재시작) → 알람 (E_S 로 JOG 도 멈춤)
   시간이 아니라 횟수 : Event_Task 가 모터 열쇠를 기다려 못 물은 동안은 안 셈 (가짜 알람 없음). 이미 멈춤(긴급정지 · 알람)이면 다시 안 걸음 */
void A_01(void)
{
    if (hmi_miss < HMI_MISS || osKernelGetTickCount() < HMI_BOOT_MS || Motor_Stop()) return;
    HMI_Manual(BTN_JOG_STOP);           /* HMI 끊김 : JOG 멈춤 (Y JOG 신호 끔) — 뗌 글자가 영영 안 오니까 (11/13) */
    alarm_go(1, LOG_A01);
}

/* 02 · 03 · 04 드라이브 알람 (AIM 6대, 듀얼 11/23) : 칠판 고장 코드(H0B_34)가 있는 첫 대 → 그 축 번호로 알람. 걸면 1
   축 번호 = 주소 % 3 : 1 Y (1 · 4) → 03 / 2 틸트 (2 · 5) → 04 / 0 X (3 · 6) → 02
   빼는 것 (알람 아님) : ER.950 · 952 리밋 경고, ER.601 원점 시간 초과 */
int A_03(void)
{
    for (uint8_t id = 1; id <= Dual_ID; id++) {
        uint16_t code = am[id].alarm;                                   /* 칠판 (Bus_Task AM_Read) */
        int no = 3;                                                     /* 알람 번호 : Y 03 */
        char *text;                                                     /* 알람 이름 */

        if (code == 0 || code == 0x950 || code == 0x952 || code == 0x601) continue;   /* 정상 · 빼는 것 : 다음 대 */
        if (id % 3 == 2) no = 4;                                        /* 틸트 */
        if (id % 3 == 0) no = 2;                                        /* X */

        if      (code == 0xB00) text = "position error";
        else if (code == 0x400) text = "over voltage";
        else if (code == 0x410) text = "under voltage";
        else if (code == 0x620) text = "overload";
        else if (code == 0x630) text = "motor stall";
        else if (code == 0x201) text = "hardware over current";
        else if (code == 0x207) text = "software over current";
        else if (code == 0x500) text = "over speed";
        else if (code == 0x650) text = "over temperature";
        else if (code == 0x668) text = "home mode mismatch";
        else if (code == 0xA33) text = "encoder fault";
        else if (code == 0x941) text = "parameter needs power off";
        else if (code == 0x900) text = "emergency stop DI on";
        else                    text = "see manual (ER. = value)";

        alarm_go(no, LOG_A03_REASON);                                   /* 데이터시트 보라 */
        Log_Debug(LOG_A03_REASON_REG, no, id, code, text);              /* 번호 · 주소 · 값 · 이름 */
        return 1;
    }
    return 0;
}

/* 02 X 부딪힘 (11/26) : 칠판 X 토크 (am[3] · am[6].torque) 가 X_TORQUE_HIT 를 X_HIT_COUNT 바퀴 연달아 넘음 → 알람 02 (X) + 로그에 토크. 걸면 1
   드라이브 힘 제한 (H07_09 · 10 = X_TORQUE_MAX, AM_Init) 이 먼저 세게 못 밀게 막고, 이건 6대를 멈춰 세움 (E_S)
   원점 중 (벽 밀기 · x_apart) 은 Alarm_Drive 가 안 봄 */
static int x_hit(void)
{
    static int count = 0;                                               /* 연달아 넘은 바퀴 수 */

    if (abs(am[3].torque) < X_TORQUE_HIT && abs(am[6].torque) < X_TORQUE_HIT) { count = 0; return 0; }   /* 둘 다 보통 */
    count++;
    if (count < X_HIT_COUNT) return 0;                                  /* 한두 바퀴 튄 건 봐줌 (출발 · 멈춤 순간) */
    count = 0;
    alarm_go(2, LOG_A03_REASON);
    Log_Debug(LOG_A02_HIT, am[3].torque, am[6].torque);                 /* 두 X 토크 */
    return 1;
}

/* 대답 없음 (칠판 am[1 ~ 6] 의 miss) : 걸면 1
   ① 6대 다 MOTOR_MISS 번 연속 대답 없음 → 11 (모터 선 UART2 · 전원)
   ② 한 대만 (다른 하나라도 대답함) → 그 축 05 X · 06 Y · 07 틸트 + 어느 주소인지 로그
      선이 뽑히는 순간엔 한 바퀴 안에서 먼저 놓친 축이 생김 → "다른 하나라도 대답함" 일 때만 한 대로 봄 (아니면 ① 을 기다림) */
static int bus_alarm(void)
{
    int alive = 0;                                                      /* 1 = 하나라도 이번에 대답함 */
    int dead = 0;                                                       /* MOTOR_MISS 번 넘게 대답 없는 대 수 */

    for (uint8_t id = 1; id <= Dual_ID; id++) {
        if (am[id].miss == 0) alive = 1;
        if (am[id].miss >= MOTOR_MISS) dead++;
    }
    if (alive == 0 && dead == Dual_ID) { alarm_go(11, LOG_A11); return 1; }   /* ① 6대 다 */
    if (alive == 0) return 0;                                           /*    선이 막 뽑힌 바퀴 : ① 을 기다림 */

    for (uint8_t id = 1; id <= Dual_ID; id++) {                        /* ② 한 대만 : 그 축 번호 */
        if (am[id].miss >= MOTOR_MISS) {
            int no = 6;                                                 /* Y 06 */
            const char *log = LOG_A06;
            if (id % 3 == 2) { no = 7; log = LOG_A07; }                 /* 틸트 07 */
            if (id % 3 == 0) { no = 5; log = LOG_A05; }                 /* X 05 */
            alarm_go(no, log);
            Log_Debug(LOG_A_MISS, no, id);                              /* 어느 주소인지 */
            return 1;
        }
    }
    return 0;
}

/* (Bus_Task MOTOR_MS) 칠판 보고 알람 : 선은 안 씀 (읽기는 바로 앞 AM_Read 6대가 함)
   안 보는 때 : 긴급정지 · 알람 (이미 멈춤) · I 원점 전 · H 원점 중 (threeD 때 원점 끝에서 대답이 늦은 적 있음) */
void Alarm_Drive(void)
{
    if (Motor_Stop() || state.now == 'I' || state.now == 'H') return;

    if (bus_alarm()) return;    /* 대답 없음 11 · 05 ~ 07 */
    if (x_hit()) return;        /* X 부딪힘 → 02 (11/26) */
    A_03();                     /* AIM 6대 드라이브 알람 → 02 X · 03 Y · 04 틸트 (듀얼) */
}

/* 05 · 06 · 07 위치 : A_06(AM_Arrive(id, 펄스)) 처럼 — MOVE_MS 안에 도착 못 함이면 알람 → E_S 로 그 자리에서 멈춤. 걸면 1 */
int A_05(int arrived) { return arrive_alarm(arrived, 5, LOG_A05); }    /* X */
int A_06(int arrived) { return arrive_alarm(arrived, 6, LOG_A06); }    /* Y */
int A_07(int arrived) { return arrive_alarm(arrived, 7, LOG_A07); }    /* 틸트 */

void A_09(void) { alarm_go(9, LOG_A09); state.now = 'E'; }          /* 비상정지 : 알람 09 + 상태 E (풀면 event.c 가 A 로) */

/* 10 원점 (걸면 1) — 두 가지
   ① 원점 중 : A_10(far, start)  AM_Home 이 닿은 순간. 200mm 넘게 떨어져 있었는데 2초 안에 닿음 = 가는 길에 걸림
   ② 원점 실패 : A_10(0, 0)      motor_basic_init 끝. 60초 초과 · 드라이브 대답 없음 → 무조건 (사수 · 문서 "원점복귀실패") */
int A_10(int32_t far, uint32_t start)
{
    if (start == 0) {                                                   /* ② 원점 실패 */
        if (Motor_Stop()) return 0;                                     /* 이미 알람(09 · 10 · 11) : 번호 그대로 */
        alarm_go(10, LOG_A10);
        return 1;
    }
    if (far <= 200 && far >= -200) return 0;                            /* ① 원점 200mm 안쪽이었음 (켠 직후 0 도 여기) */
    if (osKernelGetTickCount() - start >= HOME_FAST_MS) return 0;       /* ① 시간 걸려서 닿음 : 정상 */
    alarm_go(10, LOG_A10_REASON);                                       /* ① 걸림 */
    return 1;
}

/* 12 랜선 빠짐 : PC 와 연결된 채로 보드 랜선이 빠지면 알람 (대기 · 운전 · 일시정지 · 원점 모두, net.c Net_On_Off 가 부름)
   PC 로는 안 보냄 (선이 없어서 못 감 + PC 프로토콜은 11 까지) → 로그 · 램프 · 부저로만 */
void A_12(void)
{
    if (Motor_Stop()) return;                                           /* 이미 멈춤 : 덮어쓰지 않게 */
    alarm_go(12, LOG_A12);                                              /* PC 알림은 Alarm_PC 가 안 보냄 (선이 빠져서 못 감) */
}

/* PC 로 알람 (Comm_Task) : 'A' 받으면 S_1_A_09&S_2_A_09 (C 대답과 같은 글자, cmd.c CMD_Event 가 부름) */
void Alarm_PC(void)
{
    char b[64];

    if (state.alarm == 12) return;                      /* 랜선 빠짐 : PC 로 못 감 + PC 프로토콜은 11 까지 */
    Status_Text(b, sizeof(b));                          /* 알람이면 렉마다 S_n_A_번호 (status.c) */
    send_event(b);
}

/* RESET (HMI RESET · PC I) : 무엇이든 처음으로 → I 초기상태. 원점은 안 감 (원점은 시작만)
   JOG 멈춤 → 드라이브 알람 리셋 (6대) → 비상정지 해제 (6대) → 번호 · 이유 지움 → I → 부저 끔
   안 되는 때 : E 긴급정지 눌림 · R 운전 · H 원점중 · 운전 중 멈춤 (하던 동작이 이어져 버림 → 시작으로 풀기)
   과전류 · 과전압 같은 드라이브 알람은 전원을 껐다 켜야 풀림. PC 는 C 로 앎 */
void Alarm_Clear(void)
{
    if (state.now == 'E' || state.now == 'R' || state.now == 'H') return;
    if (state.now == 'S' && state.prev == 'R') return;
    HMI_Manual(BTN_JOG_STOP);   /* 수동 JOG 중이었으면 세움 (상태 바꾸기 전에) */
    Log_Debug(LOG_ALARM_CLEAR);
    AM_AlarmReset();            /* 드라이브 알람 리셋 (6대) */
    AM_EStop(0);                /* 비상정지 해제 (6대) */
    state.alarm = 0;            /* 알람 번호 지움 */
    state.why = 0;              /* 멈춤 이유 지움 */
    state.now = 'I';          /* 초기상태 : 시작 누르면 원점 */
    Buzzer_Off();               /* 알람 부저 끔 */
}
