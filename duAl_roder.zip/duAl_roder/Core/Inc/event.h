/*
 * event.h
 */
#ifndef INC_EVENT_H_
#define INC_EVENT_H_


/* 긴급정지 · 수동은 상태 하나로 (status.h state.now == ST_ESTOP · ST_MANUAL, 11/16) */

/* Event_Task 블록 (순서 = app_freertos.c Start_Event_Task) */
void Event_Wait(void);              /* 주문 기다림 (최대 20ms) → 꺼내 둠 */
void estop_event(void);             /* 긴급정지 핀 → 'E' / 풀림 → 'A' */
void hmi_event(void);               /* 꺼내 둔 터치 버튼 처리 */
void lamp_event(void);              /* 램프 */
void btn_run(void);                 /* 시작 : 원점 (I) · 이어서 (S). 켤 때 원점도 (Comm_Task) */
void btn_manual(void);              /* 수동 켜기 / 끄기 (HMI 33 · CLI MANUAL) */

#endif
