/*
 * fram.h
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#ifndef INC_FRAM_H_
#define INC_FRAM_H_

#include "main.h"

int FRAM_Write(uint16_t addr, void *data, int size);   /* addr 번지부터 size 바이트 쓰기 */
int FRAM_Read(uint16_t addr, void *data, int size);    /* addr 번지부터 size 바이트 읽기 */
int FRAM_YWrite(int loader, int mm);                   /* 로더 1 = A / 2 = B 의 Y 높이 mm 저장 (이동 전 목표 · 끝난 뒤 실제). 다른 로더 값은 그대로 */
int FRAM_YRead(int *a_y, int *b_y);                    /* 켤 때 두 로더 Y 높이 읽기. 둘 다 적힌 적 있으면 1 / 모름 0 */


#endif
