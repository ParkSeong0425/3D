/*
 * fram.h
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#ifndef INC_FRAM_H_
#define INC_FRAM_H_

#include "main.h"

int FRAM_Write(uint16_t addr, void *data, int size);   /* addr 번지부터 size 바이트 쓰기 */
int FRAM_Read(uint16_t addr, void *data, int size);    /* addr 번지부터 size 바이트 읽기 */
/* 로더 위치 (11/27) : 켤 때 겹쳐 있는지 판단. 쓰기는 run.c REG_FRAM 이 1초마다 */
int yFRAM(int a_y, int b_y);                           /* A · B 의 Y 높이 mm 저장 (원점 0 = 아래 벽 + 50mm, 위 = +) */
int xFRAM(int a_x, int b_x);                           /* A · B 의 X 위치 mm 저장 (원점 0 = 입고대 벽 + 50mm, x2 쪽 = +) */
int clearFRAM(void);                                   /* Y · X 위치 지우기 (CLI FRAMCLR) → 다음 HOME 은 Y 원점부터 */
int FRAM_YRead(int *a_y, int *b_y);                   /* 켤 때 두 로더 Y 높이 읽기. 적힌 적 있으면 1 / 모름 0 */
int FRAM_XRead(int *a_x, int *b_x);                    /* 켤 때 두 로더 X 위치 읽기. 적힌 적 있으면 1 / 모름 0 */


#endif
