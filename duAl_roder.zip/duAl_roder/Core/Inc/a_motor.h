#ifndef INC_A_MOTOR_H_
#define INC_A_MOTOR_H_

#include "main.h"
#include "usart.h"      /* MOTOR (칠판 한 칸) */

/* H05_09 모터 1바퀴 펄스 (AM_Init 이 축마다 씀) : Y · X 는 1mm = 딱 10펄스가 되게 (11/25 잰 값) */
#define Y_PULSE_REV        320      /* [현장] Y (1 · 4) : 1바퀴 160mm (2000펄스 = 17cm 잼) × 10 ÷ 감속 5 */
#define X_PULSE_REV        450      /* [현장] X (3 · 6) : 1바퀴 180.0mm (7469펄스 = 105cm 잼) × 10 ÷ 감속 4 */
#define T_PULSE_REV        320      /* 틸트 (2 · 5) : 나중에 (TL57 로 바뀔 예정) */
/* 방향 · 원점 방향 · 오프셋 = a_motor.c 맨 위 "드라이브 6대 설정표" ax[] (한 줄 = 한 대) */
#define Y_MM(mm)           ((mm) * 10)    /* Y mm → 펄스 (1mm = 10펄스, 위 = +) */
#define X_MM(mm)           ((mm) * 10)    /* X mm → 펄스 (1mm = 10펄스, x2 쪽이 +) */

/* X 힘 제한 · 부딪힘 (11/26) : X 는 무게가 없어 주로 부딪히는 축 → 드라이브가 이 힘 이상 못 밀게 + 칠판 토크로 알아챔 */
#define X_TORQUE_MAX       1000     /* [현장] H07_09 · H07_10 (0.1%) : X 가 밀 수 있는 최대 힘 (1000 = 100%). 11/27 움직일 때 토크 재고 줄임 */
#define X_TORQUE_HIT       (X_TORQUE_MAX * 9 / 10)   /* 칠판 토크가 이걸 넘으면 "부딪힘" (알람 13 · x_apart 멈춤) */


/* AIM 드라이브 6대 (듀얼 11/23) : 1 A-Y · 2 A-틸트 · 3 A-X · 4 B-Y · 5 B-틸트 · 6 B-X */
#define Dual_ID             6       /* 드라이브 수 = 마지막 주소 (표 · 칠판은 0 ~ 6 의 7칸, 0 안 씀) */
#define AM_ID               1       /* threeD 에서 온 Y 동작 (run.c MI · MO · PO · HMI JOG) 이 쓰는 A 의 Y */
#define AM_BAUD             115200
#define AM_MAX_RPM          3000

/* 1구간 절대위치 이동 */
#define AM_ACC_DEC_MS       500
#define AM_WAIT_MS          0
#define AM_DONE_GAP         10

/* Reverse mechanical torque home */
#define AM_HOME_HI_RPM      300     /* H05_32 */
#define AM_HOME_LO_RPM      100     /* H05_33 */
#define AM_HOME_ACC_MS      500     /* H05_34 : [현장] 원점 출발 가속. 짧으면 (50) 출발 토크가 튀어 가짜 닿음 (11/25 X) */
#define AM_HOME_TIMEOUT_MS  60000   /* H05_35 */
/* 원점 토크 H05_58 = 설정표 home_torque 칸 (축마다 다름) */

/* 드라이브 한 대 설정 (값은 a_motor.c 맨 위 설정표 ax[], 한 줄 = 한 대)
   H02_02 (회전 방향) 은 6대 다 손대지 않음 → 방향은 a_motor.c AM_Move · AM_Read · AM_Jog 의 "거꾸로 달린 모터" 줄이 맞춤 (1 · 4 · 3) */
typedef struct {
    /* ── A : AM_Init 이 드라이브에 그대로 씀 (드라이브 기준 값) ── */
    int32_t pulse_rev;   /* H05_09 모터 1바퀴 펄스 */
    int     move_type;   /* H11_04 : 1 절대 / 0 상대 */
    int     home_mode;   /* H05_31 : 10 = 드라이브 + 쪽 벽 / 11 = 드라이브 - 쪽 벽 */
    int32_t offset;      /* H05_36 : 벽에서 빠지는 거리 (드라이브 + / - 펄스) */
    int     home_torque; /* H05_58 : 원점 "벽 닿음" 토크 (0.1%, 0 ~ 3000). 짐을 움직이는 토크보다 커야 함 (AM_Home 이 씀) */
} Dual_roder_information;

/* 기본 기능 (id = 드라이브 주소 : 1 A-Y · 2 A-틸트 · 3 A-X · 4 B-Y · 5 B-틸트 · 6 B-X, 듀얼 11/23) */
int AM_Init(uint8_t id);                            /* id 설정 + 서보 켜기 */
int AM_Move(uint8_t id, int32_t pulse, int percent);    /* 펄스 이동 : Y · 틸트 절대 / X 상대 (mm 는 재는 중) */
int AM_Home(uint8_t id);                            /* 토크 원점 출발 (안 기다림) */
int AM_HomeEnd(uint8_t id);                         /* 원점 끝났나 (한 번 물음) : 닿음 + 5cm 도착 → 0 잡고 1 / 아직 0 */
int AM_Stop(uint8_t id);
int AM_Jog(uint8_t id, int dir, int percent);      /* 수동 JOG : +1 위 / -1 아래 / 0 멈춤 (DI8 · DI9) */
int AM_EStop(int on);                               /* 비상정지 DI5 : 6대 다 */
/* 상태 읽기 */
/* 위치 · 상태 = 칠판 am[id] (아래, Bus_Task 가 MOTOR_MS 마다 적음). AM_Arrive 는 칠판만 봄 */
int AM_ReadReg(uint8_t id, uint16_t reg, int32_t *out, uint8_t qty, uint8_t tries, uint32_t rx_ms);
                                            /* id 레지스터 읽기 : qty 1 = 16bit · 2 = 32bit, tries 번 묻고 rx_ms 기다림 (보통 MOTOR_RETRY · Y_RX_MS) */
int AM_Arrive(uint8_t id, int32_t pulse);   /* pulse 자리에 도착할 때까지 기다림 (±100펄스 창. 8초 넘으면 실패 0) */
int AM_Read(uint8_t id);                    /* (Bus_Task) 위치 0B07 + 고장 코드 0B22 → 칠판 am[id] (한 번씩, MOTOR_WAIT_MS). 받으면 1 */

extern volatile MOTOR am[Dual_ID + 1];     /* 칠판 6대 : 칸 번호 = 드라이브 주소. 위치 펄스 · 고장 코드 H0B_34 · 놓친 횟수 (state 는 안 씀) */

/* 보조 기능 */
int AM_AlarmReset(void);                    /* 드라이브 알람 리셋 : 6대 다 */

/* 보드레이트 변경 : 드라이브 통신 속도 처음 바꿀 때 한 번 쓰는 도구 */
int AM_BaudInit(void);

#endif /* INC_A_MOTOR_H_ */
