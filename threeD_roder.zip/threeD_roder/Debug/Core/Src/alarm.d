Core/Src/alarm.o: ../Core/Src/alarm.c ../Core/Inc/alarm.h \
 ../Core/Inc/buzzer.h ../Core/Inc/status.h ../Core/Inc/run.h \
 ../Core/Inc/hmi.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h
../Core/Inc/alarm.h:
../Core/Inc/buzzer.h:
../Core/Inc/status.h:
../Core/Inc/run.h:
../Core/Inc/hmi.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h:
