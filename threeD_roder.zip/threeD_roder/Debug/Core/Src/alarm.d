Core/Src/alarm.o: ../Core/Src/alarm.c ../Core/Inc/alarm.h \
 ../Core/Inc/status.h ../Core/Inc/run.h
../Core/Inc/alarm.h:
../Core/Inc/status.h:
../Core/Inc/run.h:
