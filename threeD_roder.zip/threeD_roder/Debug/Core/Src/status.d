Core/Src/status.o: ../Core/Src/status.c ../Core/Inc/status.h \
 ../Core/Inc/main.h ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal.h \
 ../Core/Inc/stm32g4xx_hal_conf.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_rcc.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g473xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32G4xx/Include/system_stm32g4xx.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_rcc_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_gpio.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_gpio_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_dma.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_dma_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_cortex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_exti.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_fdcan.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_i2c.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_i2c_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pwr.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pwr_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_spi.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_spi_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_tim.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_tim_ex.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_uart.h \
 ../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_uart_ex.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h \
 ../Core/Inc/event.h ../Core/Inc/run.h ../Core/Inc/net.h \
 ../Core/Inc/main.h ../Core/Inc/debug.h ../Core/Inc/alarm.h \
 ../Core/Inc/save.h ../Core/Inc/buzzer.h
../Core/Inc/status.h:
../Core/Inc/main.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal.h:
../Core/Inc/stm32g4xx_hal_conf.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_rcc.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g4xx.h:
../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g473xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32G4xx/Include/system_stm32g4xx.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_rcc_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_gpio.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_gpio_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_dma.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_dma_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_cortex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_exti.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_fdcan.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_flash_ramfunc.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_i2c.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_i2c_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pwr.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_pwr_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_spi.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_spi_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_tim.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_tim_ex.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_uart.h:
../Drivers/STM32G4xx_HAL_Driver/Inc/stm32g4xx_hal_uart_ex.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h:
../Core/Inc/event.h:
../Core/Inc/run.h:
../Core/Inc/net.h:
../Core/Inc/main.h:
../Core/Inc/debug.h:
../Core/Inc/alarm.h:
../Core/Inc/save.h:
../Core/Inc/buzzer.h:
