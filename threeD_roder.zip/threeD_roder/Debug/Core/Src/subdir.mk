################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/a_motor.c \
../Core/Src/alarm.c \
../Core/Src/app_freertos.c \
../Core/Src/buzzer.c \
../Core/Src/cli.c \
../Core/Src/cmd.c \
../Core/Src/dma.c \
../Core/Src/eeprom.c \
../Core/Src/event.c \
../Core/Src/fdcan.c \
../Core/Src/fram.c \
../Core/Src/gpio.c \
../Core/Src/hmi.c \
../Core/Src/i2c.c \
../Core/Src/i_motor.c \
../Core/Src/lamp.c \
../Core/Src/main.c \
../Core/Src/manjae.c \
../Core/Src/net.c \
../Core/Src/rfid.c \
../Core/Src/run.c \
../Core/Src/save.c \
../Core/Src/spi.c \
../Core/Src/status.c \
../Core/Src/stm32g4xx_hal_msp.c \
../Core/Src/stm32g4xx_hal_timebase_tim.c \
../Core/Src/stm32g4xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32g4xx.c \
../Core/Src/t_motor.c \
../Core/Src/usart.c 

OBJS += \
./Core/Src/a_motor.o \
./Core/Src/alarm.o \
./Core/Src/app_freertos.o \
./Core/Src/buzzer.o \
./Core/Src/cli.o \
./Core/Src/cmd.o \
./Core/Src/dma.o \
./Core/Src/eeprom.o \
./Core/Src/event.o \
./Core/Src/fdcan.o \
./Core/Src/fram.o \
./Core/Src/gpio.o \
./Core/Src/hmi.o \
./Core/Src/i2c.o \
./Core/Src/i_motor.o \
./Core/Src/lamp.o \
./Core/Src/main.o \
./Core/Src/manjae.o \
./Core/Src/net.o \
./Core/Src/rfid.o \
./Core/Src/run.o \
./Core/Src/save.o \
./Core/Src/spi.o \
./Core/Src/status.o \
./Core/Src/stm32g4xx_hal_msp.o \
./Core/Src/stm32g4xx_hal_timebase_tim.o \
./Core/Src/stm32g4xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32g4xx.o \
./Core/Src/t_motor.o \
./Core/Src/usart.o 

C_DEPS += \
./Core/Src/a_motor.d \
./Core/Src/alarm.d \
./Core/Src/app_freertos.d \
./Core/Src/buzzer.d \
./Core/Src/cli.d \
./Core/Src/cmd.d \
./Core/Src/dma.d \
./Core/Src/eeprom.d \
./Core/Src/event.d \
./Core/Src/fdcan.d \
./Core/Src/fram.d \
./Core/Src/gpio.d \
./Core/Src/hmi.d \
./Core/Src/i2c.d \
./Core/Src/i_motor.d \
./Core/Src/lamp.d \
./Core/Src/main.d \
./Core/Src/manjae.d \
./Core/Src/net.d \
./Core/Src/rfid.d \
./Core/Src/run.d \
./Core/Src/save.d \
./Core/Src/spi.d \
./Core/Src/status.d \
./Core/Src/stm32g4xx_hal_msp.d \
./Core/Src/stm32g4xx_hal_timebase_tim.d \
./Core/Src/stm32g4xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32g4xx.d \
./Core/Src/t_motor.d \
./Core/Src/usart.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G473xx -c -I../Core/Inc -I../Drivers/Ethernet/W6100 -I../Drivers/Ethernet -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/a_motor.cyclo ./Core/Src/a_motor.d ./Core/Src/a_motor.o ./Core/Src/a_motor.su ./Core/Src/alarm.cyclo ./Core/Src/alarm.d ./Core/Src/alarm.o ./Core/Src/alarm.su ./Core/Src/app_freertos.cyclo ./Core/Src/app_freertos.d ./Core/Src/app_freertos.o ./Core/Src/app_freertos.su ./Core/Src/buzzer.cyclo ./Core/Src/buzzer.d ./Core/Src/buzzer.o ./Core/Src/buzzer.su ./Core/Src/cli.cyclo ./Core/Src/cli.d ./Core/Src/cli.o ./Core/Src/cli.su ./Core/Src/cmd.cyclo ./Core/Src/cmd.d ./Core/Src/cmd.o ./Core/Src/cmd.su ./Core/Src/dma.cyclo ./Core/Src/dma.d ./Core/Src/dma.o ./Core/Src/dma.su ./Core/Src/eeprom.cyclo ./Core/Src/eeprom.d ./Core/Src/eeprom.o ./Core/Src/eeprom.su ./Core/Src/event.cyclo ./Core/Src/event.d ./Core/Src/event.o ./Core/Src/event.su ./Core/Src/fdcan.cyclo ./Core/Src/fdcan.d ./Core/Src/fdcan.o ./Core/Src/fdcan.su ./Core/Src/fram.cyclo ./Core/Src/fram.d ./Core/Src/fram.o ./Core/Src/fram.su ./Core/Src/gpio.cyclo ./Core/Src/gpio.d ./Core/Src/gpio.o ./Core/Src/gpio.su ./Core/Src/hmi.cyclo ./Core/Src/hmi.d ./Core/Src/hmi.o ./Core/Src/hmi.su ./Core/Src/i2c.cyclo ./Core/Src/i2c.d ./Core/Src/i2c.o ./Core/Src/i2c.su ./Core/Src/i_motor.cyclo ./Core/Src/i_motor.d ./Core/Src/i_motor.o ./Core/Src/i_motor.su ./Core/Src/lamp.cyclo ./Core/Src/lamp.d ./Core/Src/lamp.o ./Core/Src/lamp.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/manjae.cyclo ./Core/Src/manjae.d ./Core/Src/manjae.o ./Core/Src/manjae.su ./Core/Src/net.cyclo ./Core/Src/net.d ./Core/Src/net.o ./Core/Src/net.su ./Core/Src/rfid.cyclo ./Core/Src/rfid.d ./Core/Src/rfid.o ./Core/Src/rfid.su ./Core/Src/run.cyclo ./Core/Src/run.d ./Core/Src/run.o ./Core/Src/run.su ./Core/Src/save.cyclo ./Core/Src/save.d ./Core/Src/save.o ./Core/Src/save.su ./Core/Src/spi.cyclo ./Core/Src/spi.d ./Core/Src/spi.o ./Core/Src/spi.su ./Core/Src/status.cyclo ./Core/Src/status.d ./Core/Src/status.o ./Core/Src/status.su ./Core/Src/stm32g4xx_hal_msp.cyclo ./Core/Src/stm32g4xx_hal_msp.d ./Core/Src/stm32g4xx_hal_msp.o ./Core/Src/stm32g4xx_hal_msp.su ./Core/Src/stm32g4xx_hal_timebase_tim.cyclo ./Core/Src/stm32g4xx_hal_timebase_tim.d ./Core/Src/stm32g4xx_hal_timebase_tim.o ./Core/Src/stm32g4xx_hal_timebase_tim.su ./Core/Src/stm32g4xx_it.cyclo ./Core/Src/stm32g4xx_it.d ./Core/Src/stm32g4xx_it.o ./Core/Src/stm32g4xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32g4xx.cyclo ./Core/Src/system_stm32g4xx.d ./Core/Src/system_stm32g4xx.o ./Core/Src/system_stm32g4xx.su ./Core/Src/t_motor.cyclo ./Core/Src/t_motor.d ./Core/Src/t_motor.o ./Core/Src/t_motor.su ./Core/Src/usart.cyclo ./Core/Src/usart.d ./Core/Src/usart.o ./Core/Src/usart.su

.PHONY: clean-Core-2f-Src

