# threeD_roder (3D 로더) 펌웨어 — Claude 작업 안내서

STM32G473VCT6 (170MHz) + FreeRTOS(CMSIS-RTOS2) + STM32CubeIDE 1.19 프로젝트.
3축 로봇(X / Y / TILT)을 RS485 Modbus RTU 드라이브로 제어하고, PC와 TCP(W6100)로 통신한다.
사용자는 펌웨어를 배우는 중이다. 설명은 **한국어, 쉬운 비유, 그림(다이어그램) 포함**으로 한다.

## 작업 방식 (반드시 지킬 것)

1. **바꾸기 전에 계획부터**: "어느 파일 → 어느 함수 → 무엇을" 표 + 개념 + 왜 그렇게 하는지 + 그림.
2. 사용자가 **"그렇게 하자"** 라고 하면 그 단계 전체를 한 번에 적용한다.
3. 적용 후 **파일별로 바뀐 줄**을 보여준다. 가능하면 ARM GCC로 문법 검사.
4. 하루 작업이 끝나면 **노션 "코텍전자" 페이지 맨 아래**에 날짜 페이지로 정리한다 (질문·해결·개념·변경·다음 할 일).
5. **코드 구조는 사용자가 먼저 짠다.** Claude는 추천과 설명, 그리고 수정.
6. GitHub `main`에는 사용자 허락 없이 올리지 않는다. 리뷰·제안은 별도 브랜치나 REVIEW 문서로.
7. **사용자가 직접 다시 짠 코드를 리뷰하는 방식**(10/2부터): 사용자가 짠 코드를 읽고 → 맞는지 / 왜 안 되는지 설명 → 고칠 때도 **사용자 스타일 그대로**. 문제가 생길 때마다 변수·플래그·함수를 덧붙이지 말고, 사용자가 만든 함수 안에서 해결한다.
8. 판단 기준은 **CPU 효율과 메모리(RAM, 스택, 버스 점유) 효율**. 리뷰할 때 "이 코드가 CPU를 얼마나 쓰는지, 버스를 얼마나 잡는지, 메모리를 얼마나 쓰는지"를 같이 설명한다.
9. **하루 작업이 끝나면 Claude가 이 CLAUDE.md를 업데이트한다**: "현재 상태", "그날 바뀐 것", "남은 일"을 그날 기준으로 고치고, 바뀐 부분을 사용자에게 보여준다. (집 ↔ 회사는 zip으로 옮기므로, 이 파일이 다음 세션의 유일한 기억이다.) 사용자가 "끝", "마무리", "오늘은 여기까지" 같은 말을 하면 반드시 먼저 한다.
10. **코드는 사용자가 "수정하자 / 바꾸자" 라고 할 때만 바꾼다** (10/11). 그 전에는 읽고 설명·리뷰만. 새 상수·함수·변수 제안(예: `X_TWIST`)도 사용자가 원할 때만. 정리를 부탁받으면 **지금 상태만** 적고 "앞으로 할 것"은 적지 않는다.
11. **하루 흐름** (10/11 사용자 결정) : **09:00 전 = 공부** — 노션 「임베디드 데일리 브리핑」·「C 기초 다지기」(클라우드 루틴이 평일 07:30 자동 생성) 링크를 알려 주고, 물으면 자세히 설명 · 문제 채점 (`~/.claude/CLAUDE.md` 규칙). **09:00 부터 = 프로젝트** — 사용자 질문에 맞춰 이 프로젝트를 진행. 그날 코드에 나오는 어려운 용어(예: 버스, 뮤텍스, DMA, 인터럽트, 폴링)는 나올 때 쉬운 비유 + 그림으로 설명하고, 교재 「혼자 공부하는 C언어」(서현우, 한빛미디어)의 해당 장도 같이 짚는다.
    - 사용자가 부탁한 설명 : **fdcan.c, rfid.c 를 어떻게 만들었는지** (10/11 요청).

## 코드 스타일 (사용자 스타일 유지)

- `run.c`의 `I()` 수준으로 **짧고 쉽게**, 단계마다 한글 한 줄 주석.
- `if (!Func())` 금지 → `if (Func() == 0)` 처럼 쓴다. `== 1` 은 안 씀 → `if (Func())` (10/13).
- 성공 1 / 실패 0 반환, 실패는 `return 0`으로 위로 전달.
- **새 파일 · 새 함수 · 새 상수는 꼭 필요할 때만**, 반드시 계획에서 승인받고. 구조를 크게 바꾸지 않는다 (예전에 bus.c 분리했다가 되돌림).
- **모든 while 기다림에는 시간 제한** (`osKernelGetTickCount()` 시작 시각 비교). 예외 : 일시정지(PAUSE) 대기.
- `save.c`, `cmd.c`의 풀어서 쓴 구조(left_x1 ~ left_x9 등)는 **일부러 그런 것** → 배열로 바꾸자고 하지 않는다.
- CubeMX 생성 파일은 **USER CODE BEGIN ~ END 안에만** 쓴다. 설정은 ioc에서.
- 파일은 CRLF 줄바꿈. sed로 수정하면 LF로 바뀌니 주의.
- 디버그 출력은 원인 찾으면 지운다.

## 구조 (10/8 사용자 그림 기준)

**사용자가 원하는 구조** (10/8 손그림):
- 모터 파일(i/a/t_motor) = **레지스터로 움직이는 기본 함수** → run.c 가 그걸 모아 **로더 동작 함수**(I, MI, MO, PO, E_S)를 만든다.
- rfid · lamp · alarm · 만재(manjae) · status · hmi = **켜기/끄기·읽기만 하는 기본 함수** → event.c 가 그걸 써서 **"이런 상황이 생기면 이렇게"** 함수를 만든다.
- 상황 처리는 **event.c 안에서** (run.c PO 는 순수 동작 그대로 두고, event.c `PO_event` 가 PO 줄을 나눠 단계 사이에 상황 처리).
- RTOS 는 유지 (이유: `I()` 처럼 위에서 아래로 쓰려면 기다리는 동안 다른 태스크가 돌아야 함. 없으면 step 상태기계가 됨).

**사용자가 원하는 모양 = 레고 (10/21 확정, 코드 리뷰 · 수정의 기준)** — 함수 안에 다른 파일의 함수(블록)가 레고처럼 붙어 있는 모양. 좋은 예 : `I()` · `MI` · `Rfid_Init` · `NET_Run`. 노션 「레고처럼 짜기」 참고.
- R1 블록 = 한 가지 일 (한 줄로 말할 수 있음), 성공 1 / 실패 0.
- R2 조립 함수 = 블록 나열 + 최소 if (레지스터 · 긴 계산 없음).
- R3 판단(조건 · 숫자)은 **그 데이터를 가진 파일의 블록 안** (알람 조건 alarm.c, 상태 규칙 status.c). 조립하는 쪽은 부르기만.
- R4 아래 층(장치 · 모터 파일)은 위 층(run · event · alarm)을 모름. 지금 예외 : `IM_Home`/`AM_Home` → `A_10`, 모터 가드의 `estop` · `manual` (알고 남겨 둔 것).
- R5 switch 의 case 는 블록 한 줄.
- R6 장치 지식(레지스터 · 알람 코드 이름표)은 장치 파일 (예 : `A_02` 의 iCL 코드 이름표 → i_motor.c 로 옮길 후보).
- R7 태스크 사이는 상태판 · 표시 변수만 (보내기는 주인 태스크).
- 새 함수보다 **있는 함수(블록) 안으로 옮기기**가 먼저. 함수 개수 늘리는 것 싫어함.
- 지금 상태 : 레고 ✅ run · rfid · lamp · net · manjae · 모터 파일 / 덜 레고 ⚠️ event.c `hmi_event`(case 안 판단), alarm.c `A_02~04`(이름표), cmd.c `CMD_Run`(case 안 읽기 · 범위 · 실행) · `CMD_Event`(이벤트). → **사용자가 집에서 직접 고칠 예정** (10/21).
- 성능 목표(사용자) : 통신 대기 줄이기 · CPU · RAM 아끼기. 순서 = 안전(긴급정지 반응) > 버스(RS485) > CPU > RAM. 폴링은 "장치가 먼저 안 알려 주는 것"만. 노션 「성능 설계 개념」 참고.
- UART2 뮤텍스 `Uart2LockHandle` 은 ioc 가 아니라 **app_freertos.c USER CODE(RTOS_MUTEX) 의 `osMutexNew`** (Claude 가 넣음). UART2 를 Motor · Event · Comm(CLI) 세 태스크가 써서 필요. 열쇠는 `UART2_Xfer` 한 곳에서만.

```
태스크 층   app_freertos.c : Event_Task(High) / Motor_Task(AboveNormal, 10/15 : 초인종 4개 기다렸다가 CMD_Done(flag, Motor_Run(flag))) / Comm_Task(Normal)
명령 층     cmd.c (TCP 명령 확인 → NAK / ACK + 초인종 · 완료응답 CMD_Done) · cli.c (UART1 CLI) · hmi.c (UART4 터치패드)
이벤트      event.c : 100ms 순회 (긴급정지, HMI 버튼, 만재, 드라이브 알람 02~04, 램프) — PO 상황은 run.c PO_pause · PO_tilt, 카드는 Rfid_Timer
동작 층     run.c : I / MI / MO / PO / E_S / motor_basic_init / motor_basic_run(CLI 시험) / Motor_Run(초인종 → 함수 하나, 원점 시작 · 끝 전부)
장치 층     i_motor.c (X, ID3) · a_motor.c (Y, ID1) · t_motor.c (TILT, ID2) · fram.c · net.c · save.c · rfid.c · lamp.c · manjae.c · status.c · alarm.c(조건 + 걸기) · buzzer.c(10/13)
통신 부품   usart.c USER CODE : UART2_Xfer (모터, DMA + 인터럽트 + 뮤텍스) · UART4_Xfer (HMI, 인터럽트)
```

- 명령 경로 (10/19) : W6100 소켓 0 → `net.c Socket0_Line`(STX~ETX 사이 내용만, ETX 순간 `last`) → `send_cmd`(서비스 `[TX]` + `CMD_Run(Roder_Number(), s)` : **번호는 따로, 명령 배열엔 PC 내용만**) → `cmd.c CMD_Run`(Comm_Task) 확인 → `cmd_answer(no, NAK, …)` / `cmd_answer(no, ACK, s)` + 주문서 `order_*` + `order_no` + 완료응답 글자 `done_text`(AI_렉_열_단) 미리 + `Status_RUN` + 초인종 → 바로 돌아감. **Motor_Task** 는 `Motor_Run(flag)` 한 줄 (run.c : `(flag & MI_FLAG) && MI(…)` 이면 `Status_WAIT(order_rack)`, 원점은 `motor_basic_init`). **`CMD_Done` 없음** → `CMD_Event` 가 **상태판(R → W)** 을 보고 1초마다 `08AI_1_1_2`, PC 가 `AI_1_1_2`(번호 · ACK 없이) 돌려주면 `order_no = 0` (대답 없음).
- RTOS 도구: 시간(`osDelay`, `osKernelGetTickCount`) / 플래그 / 뮤텍스(usart.c 안에만) / **소프트웨어 타이머(10/14, ioc : `Manjae_Timer` Once · `Rfid_Timer` Periodic, 콜백은 app_freertos.c USER CODE)**. **큐는 10/8 ioc 에서 삭제**. `osTimerStart` 는 인터럽트 안에서 못 부름 (태스크에서만).
- **스레드 플래그 번호표 (한 태스크 안에서 겹치면 안 됨)** : `0x01 XFER_DONE`(usart.c, UART2·UART4 응답 → 통신한 태스크) / `0x02 ESTOP_FLAG` · `0x04 FULL_FLAG`(event.c, EXTI → Event_Task) / `0x08 MOTOR_FLAG`(cmd.h, 원점 → Motor_Task) / `0x20 MI_FLAG` · `0x40 MO_FLAG` · `0x80 PO_FLAG`(cmd.h, 10/15, PC 명령 → Motor_Task). 0x10 은 비어 있음 (10/16 `TOUCH_FLAG` 삭제). 10/12 에 MOTOR_FLAG 를 0x01 로 했다가 XFER_DONE 과 겹쳐 UART2 가 죽었음.
- **공유 변수 규칙 (10/16)** : 변수는 주인 파일의 `.h` 에 `extern` 한 번, 쓰는 파일은 `#include` 만. app_freertos.c 의 RTOS 것들(`Event_TaskHandle`, `Motor_TaskHandle`, `Manjae_TimerHandle`, `Rfid_TimerHandle`, `Uart2LockHandle`)은 짝 헤더가 없어 **main.h USER CODE(ET)** 에 extern (`cmsis_os2.h` include). `.c` 안에 extern 직접 쓰지 않음.
- **변수 두 종류 (10/16 사용자와 정리)** : ① 상태 (`estop`, `card_ok_1`, `tcp_on`, `pause_why`…) = 그 상황인 동안 유지 ② 처리 대기 (`무엇_event_on`) = 생긴 순간 1, cmd.c `CMD_Event` 가 PC 로 보내며 바로 0 (보내기 **전에** 0). 장치에서 바로 읽을 수 있으면 변수 대신 함수(`manjae_on`, `card_on`, `IM_Pos`).
- **W6100(send/recv)은 Comm_Task 에서만** 부른다 (SPI 를 두 태스크가 같이 쓰면 명령이 섞임). 다른 태스크는 표시(`*_event_on`, 상태판)나 `Log_Debug`(쌓기만)만. PC 로 나가는 길은 net.c `send_socket`(2500 + 서비스 `[RX]`) 하나 — cmd.c 대답은 `cmd_answer`, 이벤트는 net.c `send_event`(새 번호 자동).
- 인터럽트 우선순위: FreeRTOS 함수를 부르면 5 이상 ("Uses FreeRTOS functions"). DMA 5, EXTI1 5(W6100 INT, 10/14), EXTI15_10 5, FDCAN 5, USART2 6, USART1 7, UART4 7.
- 시계: FreeRTOS tick(SysTick, 1ms) / HAL tick(**TIM6 — 지우면 안 됨**) / DWT(µs 측정 전용, `dwt.h`, `uart2_us`).
- 대기 규칙: 이동 10초(`MOVE_MS`, alarm.h), 원점 60초 제한. 10/16 부터 **기다림은 모터 파일 `IM_Arrive(x)` · `AM_Arrive(y)` · `TM_Arrive(deg)`**(최대 10초, 알람 안 검, osDelay 없이 위치 반복 읽기), **알람은 run.c 가 그 뒤 `A_05(x)` · `A_06(y)` · `A_07(deg)`**(한 번 확인 → 없으면 알람). 버스는 이동 중 거의 늘 바쁨 → 보드 시험 후 "걸릴 시간 계산해서 자기" 정할 것.
- 폴링이 맞는 것: FRAM, EEPROM (짧고 드묾).

## 10/2 회사에서 바뀐 것 (Claude 가 수정, 사용자가 집에서 다시 읽고 정리할 예정)

- Y 배율 원인: Y 드라이브 H05_09 = 320 (1회전 320펄스) → `Y_PULSE 320`, `Y_GEAR 5`, `Y_PI 160`. X 는 `X_PI 100`. 원점 후 이동 Y `AM_Move(150, 50)`, X `IM_Move(100, 30)` (사용자 값).
- 상태(status)는 W 대기 / R 운전 / I 원점 / P 일시정지 / A 알람 / N 초기상태(10/7 부터 `RESTART`)만. 만재·카드는 상태가 아니라 `full_1/2`, `card_ok_1/2` 변수로만 본다.
- **렉1 = 오른쪽 렉, 렉2 = 왼쪽 렉** (cmd.c PO 에서 rack 1 → right_x/right_y). 만재 핀 FULL_1_x · 경광등 _1 핀 · FDCAN1 = 렉1 (핀 이름 그대로 맞음). HMI 화면은 왼쪽 칸 = Sensor[0] 이라 `hmi.c` 에서 왼쪽 칸에 렉2, 오른쪽 칸에 렉1 을 넣는다. 같은 렉 안 R/Y 만 배선이 반대라 `lamp_rfid`/`lamp_manjae` 에서 바꿔 씀.
- 긴급정지: 인터럽트는 깨우기만, `estop_event` 가 핀을 직접 읽음. 모든 대기(`wait_xy`, `wait_tilt`, 원점, CLI 이동)에 `if (estop == 1) return 0;`. 흐름: 긴급정지 → 알람 → 리셋(처음 상태 INITIAL) → 시작(원점).
- HMI: ESP32 프로토콜(`STX '1' 'C' 작업 일시정지 알람 센서20 ETX`)에 맞춰 `hmi.c` 가 상태를 채워 보냄. 수동 버튼은 설정→수동(33)으로 수동 모드일 때만.
- PO: 틸트 전·복귀 전에 **그 단** 만재(`floor_full(rack, y_no)`) / **그 렉** 카드 없음이면 `PPAUSE:F` / `PPAUSE:S` 한 번 보내고 대기, 풀리면 자동 진행. 같은 렉이라도 다른 단은 진행. MI/MO 는 그대로 이동. `PO(rack, x, y, y_no, …)` 로 단 번호를 받음.
- TCP: 완료응답 AI/AO/EO 를 PC 승인(`번호-AI_…`)까지 1초마다, 승인 전 MI/MO/PO 는 NAK. 원점 완료 `번호<ACK>homing done` 한 번. 램프 명령 `LL_번호_색_모드_시간`(번호 홀수 렉1 / 짝수 렉2, 색 1 적 2 녹 3 황). PC 연결 중 램프는 PC 가, 안 연결이면 STM 이.
- RFID: 0.5초마다 리더에 'C' 질문, 2초 동안 못 읽으면 카드 없음. 리더 ID = 200 + DIP (두 렉 다 201, CAN 선이 따로라 같아도 됨).
- 램프: 타이머 안 씀. `blink()` 가 시간으로 켬/끔 → 렉1·2 같은 박자. 긴급정지·알람 빠르게, 원점·일시정지 느리게.
- 넷: 마지막 명령 후 20초 조용하면 끊김 (전에는 접속 후 20초에 무조건 끊김).
- 가감속(사용자 값): X `IM_ACC/DEC_MS 900`, Y `AM_ACC_DEC_MS 100`, TILT `TM_ACC/DEC_MS 200`.
- X 토크 원점(사용자 값): `IM_HOME_HI_RPM 180`, `IM_HOME_LO_RPM 80`, `IM_HOME_ACC/DEC_MS 1000`, `IM_HOME_TIME_MS 20`, `IM_HOME_FORCE 35`. 목표 = "쾅 부딪히지 않고 살짝 닿으면 원점". 원칙: **토크(FORCE)만 낮추면 마찰·가속 토크에 오인식**(X 는 모터 2대라 한쪽만 먼저 잡히면 비틀림) → 먼저 **속도를 낮추고**, 판단 시간(TIME)은 너무 짧으면 순간 튀는 토크에 오인식. 지금 TIME 20ms 는 짧은 편이라 테스트로 확인 필요.

## 10/7 회사에서 바뀐 것 (event · hmi · run · status 정리, 일시정지 T/F/S/M)

- **안 쓰는 함수 삭제**: `AM_Speed/AM_Torque/AM_Read`, `IM_AlarmRead/IM_DIPRead/IM_Read`, `TM_Read`, `Home_lamp/Alarm_lamp`, `NET_Link`, run.c `Motor_Check`·`CHECK_COUNT`, event.h `Alarm_Set/Clear` 선언(본문은 event.c 에 주석으로 남김). 헤더도 같이 지움.
- **상태 이름**: 초기상태 = `RESTART`(사용자가 INITIAL → RESTART 로 바꿈, CRC 레지스터 이름과 겹쳐서). 전원 켜지면 `status_1/2 = RESTART`. `Status_INIT()` 이 RESTART 로 만듦.
- **S() 를 status.c 로**: S 는 "멈춰라 표시"만 (`Status_PAUSE` 두 렉 + `pause_why='M'` + PC 알림). 모터를 바로 세우지 않음. MI/MO 는 도착 후, PO 는 쏟기 전·복귀 전에 멈춤.
- **hmi.c**: 보낼 27바이트 틀 `tx` 를 static 으로 미리 채우고 바뀌는 11칸만 씀. 버튼 = `rx[2] - '0'`. `hmi_pause` 가 `pause_why` 대로 1 시딩월 / 2 만재 / 3 틸트 / 4 사용자.
- **event.c hmi_event**: 수동 버튼(21~26)은 `manual == 1` 일 때만. RUN = 초기상태면 `Status_HOME`(→ Motor_Task 가 원점), 일시정지 M·T 면 풀기. STOP → `S()`. RESET → 알람 리셋 + 초기상태. 설정→수동(33) 토글.
- **긴급정지 EXTI 콜백**: 주석 처리돼 있어서 긴급정지가 이동 끝난 뒤에야 먹던 것 → 사용자가 주석 풂 (테스트 필요).
- **manjae.c**: `floor_full(rack, dan)` 공개(manjae.h). `Full_Read` 는 `GPIOE->IDR & 0x7F80` 으로 만재 8칸 한 번에 읽고 바뀔 때만 나눔.
- **PO 일시정지 (T/F/S/M)**: run.c PO = 이동 → `PO_event(rack, y_no, 1)` → Y 올리며 틸트 → `touch = PO_pour(…)` → `PO_event(rack, y_no, touch)` → 복귀. `PO_pour`/`PO_event` 는 event.c 에 있지만 **Motor_Task 가 실행**.

  | 이유 | 언제 | 풀기 | HMI |
  |---|---|---|---|
  | T 틸트 | 쏟는 동안 그 단 센서에 한 번도 안 닿음 | HMI RUN | 3 |
  | F 만재 | 그 단 만재 | 센서 풀리면 자동 / PC `01D` | 2 |
  | S 시딩월 | 그 렉 카드 없음 | 카드 들어오면 자동 | 1 |
  | M 사용자 | STOP 버튼 / S 명령 | HMI RUN | 4 |
- **cmd.c**: `CMD_D ('D' << 8)` 추가 — 만재(F)로 멈춘 것만 억지로 풀기.
- 이름 정리: `full_new/pause_new` → `full_event_on/pause_event_on`.
- 미룸: TM `GO_ABS 0x03 → 0x07`(움직이는 중 새 목표 받기, 틸트 즉시 멈춤·재개용) — 사용자가 직접 고쳐 볼 예정. TCP W6100 인터럽트 · CAN 은 다음 주.

### 10/7 결론 : 구조가 마음에 안 듦 → 집에서 "왜 이렇게 짰나" 공부부터

사용자 생각: **10/2 코드는 Claude 가 거의 다 짠 것**이라 내 코드가 아니다. 앞으로는 **내가 구조를 짜고 싶고, 어떻게 짜야 하는지 알면서** 하고 싶다.
특히 고쳐야 할 것 같은 곳: **status.c, run.c (Motor_Run), cmd.c**.

- Motor_Run 이 지저분한 이유(10/7 에 본 것): 켜질 때 원점 / HMI RUN 원점 / 큐 명령 3가지 일을 한 함수에서 함. 원점 길이 3개(켜질 때·HMI = `motor_basic_init`, PC·CLI 의 I = `I()` 만)로 다름. 시작·끝 상태를 `cmd.command == CMD_…` 로 명령마다 따로 정함 (MI→W, MO→R 유지, PO→W).
- Claude 가 낸 안 2개는 **사용자가 거절**: ① `home_run`/`cmd_run` 새 함수 ("I 함수가 있는데 왜 또 함수를"), ② `cmd.command ==` 줄을 옮기는 안 ("커멘드들이 보기 싫다"). → 다음엔 사용자가 구조를 먼저 짜고 Claude 는 설명·리뷰만.
- 상태(status)를 바꾸는 곳이 흩어져 있음: run.c(Motor_Run), event.c(hmi_event, PO_event, estop_event), status.c(S), cmd.c(D). status.c 를 어떻게 할지 사용자가 정할 것.

**집에서 할 수업 (다음 세션 첫 일)**: 파일마다, **함수마다** 아래를 자세히 설명.
1. 이 함수가 하는 일 (한 줄) + 누가 부르나 / 어느 태스크가 실행하나
2. **왜 이렇게 짰나** (다른 방법과 비교, 장단점)
3. 그림 (호출 흐름, 시간 흐름, 메모리 · 버스)
4. 나오는 **C 개념** (static, volatile, extern, 구조체 값 전달, 포인터, `'0'` 빼기, 비트 마스크 `& 0x7F80`, `<< 8` 등)
5. 나오는 **펌웨어 개념** (태스크 · 우선순위, 큐, 스레드 플래그, 뮤텍스, DMA, IDLE 인터럽트, EXTI, Modbus RTU, 폴링 vs 인터럽트, 시간 제한)
6. CPU / 버스 / RAM 을 얼마나 쓰나

순서 추천: status → run → event → cmd → hmi → net → 모터(i/a/t_motor) → manjae · rfid · lamp → usart.c USER CODE (UART2_Xfer, UART4_Xfer).

## 10/8 회사에서 바뀐 것 (구조 다시 잡기 + 보드 테스트)

**방향** : 사용자 손그림 구조(위 "구조")로. 사용자가 run.c 를 직접 다시 씀 → Claude 는 사용자 함수에 맞춰 나머지 수정.

- **큐 · 구조체 삭제** : ioc 에서 MotorQueue 삭제. `MotorCommand`, `job/job_on`, `Motor_Run` 없음. Motor_Task 는 `osThreadExit();` (ioc 에선 지우지 말 것 — 1단계에서 다시 씀).
- **cmd.c 가 동작을 직접 부름** : MI/MO/PO/I 는 `ack(s)` → `Status_RUN(rack)` → `CMD_Done(s, MI(x, y, …))`. PO 는 `CMD_Done(s, PO_event(…))`. I 는 `Status_HOME(); CMD_Done(s, motor_basic_init());`. 좌표는 지역 변수 `x`, `y`.
- **`CMD_Done(char *s, int ok)`** : 받은 글자 s 에서 번호 · 렉 · 열(yeol) · 단(dan) 꺼내 `AI/AO/EO`, I 는 `homing done` + 대기 / 실패 초기상태. ok 0 이면 완료 아님(상태 그대로).
- **입구 확인** (MI/MO/PO) : `status_1 != WAIT || status_2 != WAIT || manual == 1 || done_text[0] != 0` → NAK `can_not_command`.
- **cli.c** : 모터 함수 직접. `motor_basic_run(command, pulse, deg, rpm)` (사용자 수정, 명령만 보내고 도착 안 기다림, 진짜 결과 반환).
- **Comm_Task** : `Save_Init → NET_Init → Status_HOME` 후 반복에서 `status_1 == HOME` 이면 `motor_basic_init()` (켤 때 · HMI RUN 원점). **원점 끝나야 TCP 시작** (1단계에서 Motor_Task 로 옮김).
- **run.c (사용자)** : MI/MO/PO 오류 `if` 없앰 (오류는 알람으로 할 예정). `I()` = `TM_Home() && IM_Home() && AM_Home()`. **`E_S()`** 긴급정지 = TM_Estop · IM_Stop · AM_EStop(1) 을 **따로 다 보내고** 결과만 합침 (멈추기는 `&&` 금지, 움직이기는 `&&`). `S` 삭제. `wait_xy/wait_tilt` static 해제(event.c 가 씀). run.c PO 는 순수 동작 그대로(지금 안 씀).
- **일시정지 = B 방식(신호등)** : STOP(HMI) · `S_1`(PC) · `S`(CLI) → `Status_PAUSE(1/2)` + `pause_why='M'` 표시만. MI 끝 · PO 쏟은 뒤 "정지선"에서 기다림 → HMI RUN 으로 진행. status.c 의 `S()` 삭제.
- **event.c `PO_event`** (PC PO 명령용) : run.c PO 줄을 가져와 단계 사이에 상황 처리. 이동 → `PO_arrive`(그 단 만재 F / 카드 S / 일시정지 → 풀릴 때까지) → 틸트 → `PO_pour`(쏟는 동안 센서 스쳤나) → `PO_poured`(안 스쳤으면 T, **RUN → 복귀 → EO 완료**) → 복귀. 세 도우미는 static. **MI/MO 는 만재 · 카드 상관없음 (확정)**.
- **긴급정지** : `estop_event` 누름 / 풀림 **엣지만** (폴링 반복 안 함). 누름 = `Status_Alarm(); E_S();`, 풀림 = `AM_EStop(0); Status_Alarm();` (눌린 사이 대기로 바뀌었어도 다시 알람). **NC 배선이 하드웨어로 모터를 끊음** (사용자 확인). RESET 에 `IM_MapInit(); AM_Init(); TM_Init();` 추가 (긴급정지로 드라이브 전원이 끊겼으면 설정 다시) → 시험 필요.
- **net.c** : `net_timeout` 을 켤 때 복사 → FI 1·2·3·5·6·7 · FD 전부 **재부팅 후 적용** (FI 4 목적지 IP 는 클라이언트 모드용, 안 씀. DNS 아님). 랜선 뽑히면 `wizphy_getphylink() == PHY_LINK_OFF` → `close()` (disconnect 는 PC 대답 기다려서 멈춤). `tcp_on` 중복 삭제. 20초 규칙 = 연결 후 / 마지막 명령 후 20초 명령 없으면 끊기 (이미 그렇게 됨).
- **cmd.c 이벤트 번호 삭제** : `event_number` 없음, 이벤트는 `STX + 내용 + ETX` (번호 없음).
- 빌드 : 전체 빌드 통과. Flash 약 90KB / 256KB, RAM 약 28.5KB / 128KB (힙 20KB 고정).

**프로토콜 정리 (사용자 문서가 전부, 예시 로그 사진은 무시)**
- 일련번호 : PC 가 01 → 99 → 01. 로봇은 **받은 번호 그대로** ACK / NAK / 완료응답(AI·AO·EO·homing done) — `s[0] s[1]` 복사로 자동.
- PC 완료 승인 : `번호-AI_…` (코드는 `s[2] == '-'`).
- 이벤트(만재 FF · 일시정지 PPAUSE · 카드 U · 알람 S) : 번호 없음.
- TCP 는 글자 흐름이라 두 메시지가 한 줄에 붙어 보일 수 있음 → STX~ETX 로 나누면 정상.

**10/8 보드 테스트에서 나온 문제**
1. `FF… PPAUSE:F 03EO` 가 **동작 끝난 뒤 한꺼번에** 나옴 → Comm_Task 가 PO 를 실행하느라 CMD_Event 를 못 돎. 원하는 것 = 도착 → 바로 PPAUSE:F/S → 해제 → 진행 → EO / 쏟은 뒤 안 스치면 바로 PPAUSE:T. → **남은 일 1단계**.
2. 틸팅 에러 해제 = 일시정지와 같음 (RUN → 복귀 → 명령 완료). 작업자 확인 후 처리. → 이미 구현, 1단계 후 시험.
3. 긴급정지(도착 후) → 풀기 → RESET → HMI "초기상태/없음" → RUN 해도 원점 안 됨 → 드라이브 전원이 끊겨 설정이 사라졌을 가능성 → RESET 에 드라이브 재설정 넣음, **시험 필요**.
4. 랜선 다시 꽂으면 한참 뒤 연결 → PC 가 옛 연결을 붙잡고 있는 것으로 추정. 커먼체크에서 직접 끊기 → 연결로 확인.
5. HMI ESP 소스 확인 (Downloads\HMI.zip → HMI_Kor_260702.zip → HMI_JC3248W535_v1.2/src) : 버튼 11 Run, 12 Pause, 13 Stop, 21~26 수동, 31 SoundOff, 32 Reset, 33 Manual, 34 Origin. 응답은 `STX '1' (버튼+0x30) ETX`. 60초 동안 못 받으면 ESP 재시작. 알람 글자 : 0 없음 1 수동 2 주행모터 3 리프팅모터 4 틸팅모터 5 주행이탈 6 리프트이탈 7 틸트이탈 8 안전센서 9 비상정지 10 원점설정.

### 남은 일 (다음)
1. **1단계 : 동작은 Motor_Task, TCP 는 Comm_Task** (계획까지 함, 사용자 승인 대기)
   - cmd.c `CMD_Run`(Comm_Task) : MI/MO/PO/I 확인 · 좌표 찾기 → `ack` → `order[160]` 에 받은 글자, `order_x/order_y`, `order_on = 1` → 바로 돌아감. 바쁘면(`order_on == 1`) NAK.
   - cmd.c `CMD_Move`(새 함수, Motor_Task 가 10ms 마다) : `order` 보고 MI / MO / `PO_event` / 원점 → `CMD_Done` → `order_on = 0`. **Motor_Task 는 send 금지** (표시만).
   - app_freertos.c : Motor_Task = 켤 때 원점 + HMI RUN 원점 + `CMD_Move()`. Comm_Task = TCP · CLI · CMD_Event 만 (켜자마자 접속 가능).
2. **알람** : 사용자가 alarm.c/h 기본 함수(`Alarm_Set(code)` = Status_Alarm + alarm_1/2 + alarm_new, `Alarm_Clear()`) → event.c 가 사용.
   - 긴급정지 9 / 이동 끝났는데 목표 ±GAP 밖 → 5 주행이탈 · 6 리프트이탈 · 7 틸트이탈 (`IM_Pos/AM_Pos/TM_Pos` 로 확인) / 위치 못 읽음 → 2·3·4 모터 / 원점 실패 · 60초 초과 → 10 / 원점이 3초 안에 끝남(이물질) → 10 (**원점 근처에서 시작하면 정상인데도 3초 안일 수 있음 → 기준 시험 필요**).
   - hmi.c `hmi_alarm` 이 `'0' + 알람 번호` 보내기. RESET 에 `Alarm_Clear()`.
3. 집 : 지금까지 한 것 정리 + 10/7 "함수마다 왜 이렇게 짰나" 공부 계속.
4. cmd.c 정리 (선택) : MO · PO 좌표 찾기 합치기, `0x02/0x06/0x15` → `STX/ACK/NAK` 이름, 주석. net.c (선택) : 상태 한 번만 읽기, 한 번에 recv.
5. 기존 : GO_ABS 0x07 (틸트 즉시 멈춤·재개), X 원점 살짝 닿기, HMI 센서 칸 순서 / PC 단 1 = FULL_x_1 확인, 수동 버튼이 `*_Pos` 실패를 안 봄, CMD_S `S_1` 만 받음.
6. 다음 주 : TCP W6100 인터럽트, CAN.

## 10/11 (집) 바뀐 것 · 지금 상태 (사실만)

- 집 PC = `threeD_roder (1).zip`(10/11 19:01, 10/8 회사 버전)으로 맞춘 뒤 아래만 바뀜. 전체 문법 검사 통과(에러·경고 0). 보드 시험 안 함.
- **alarm.c / alarm.h** : 알람 **켜기만** (구조상 판단은 event.c). `A_01(rack)` ~ `A_10(rack)` = 공통 `static alarm_on(rack, 번호)` 한 줄씩 (rack 1, 2 / 0 = 두 렉 → 상태 A + `alarm_1/2` 번호 + `alarm_event_on = 1`). `Alarm_Clear()` = 번호만 0. `alarm_1/2` 는 status.c 에서, 알람 번호 상수(`ALARM_*`)는 event.h 에서 지움.
  - 번호 뜻(사용자) : 01 HMI 통신(끊김·꼬임·버튼 안 먹음) / 02~04 X·Y·틸트 모터 / 05~07 X·Y·틸트 위치(시간 초과, 가는 중 엔코더 그대로) / 08 안전센서 / 09 비상정지 / 10 원점(너무 빨리 끝남 = 이물질, 리셋→RUN 했는데 통신 안 됨). ※ 프로토콜 문서 · HMI ESP 는 01 = 수동모드.
  - 지금 거는 곳 : 비상정지 눌림 `A_09(0)` (event.c estop_event). RESET 에 `Alarm_Clear()`. 나머지 번호는 아직 아무도 안 부름.
- **이벤트 일련번호** : cmd.c `event_send` 안 `static int number` → `STX + 01~99(99 다음 01) + 내용 + ETX`. 만재 FF · PPAUSE · 카드 U · 알람 S 모두. 완료응답(AI/AO/EO) · 체크(C) 응답은 PC 가 보낸 번호 그대로.
- **알람 이벤트** : 걸린 렉만 `S_1_A_09` / 둘 다면 `S_1_A_09&S_2_A_09`. 알람 풀릴 때는 안 보냄(원점 완료 메시지로 앎). 체크(C) 응답은 원래대로 `S_1_..&S_2_..&F_1_....&F_2_....`.
- i_motor.c 주석 고침 : `100% = IM_MAX_RPM (1000rpm)`.
- **확인한 사실 (코드 읽기)** :
  - UART2 모터 : 송신 DMA + 수신 DMA(ReceiveToIdle) + IDLE 인터럽트가 플래그로 깨움 + 뮤텍스(Uart2Lock). UART4 HMI = 인터럽트(DMA 아님). UART1 CLI 송신 DMA, **수신은 폴링**(`CLI_Run` 이 RXNE 확인).
  - mm/도 ↔ 펄스 : X 100 펄스/mm, Y 10 펄스/mm(부호 반대, 양쪽 다 뒤집어 맞음), 틸트 20000 펄스/360도. 보내기 · 읽기 왕복 맞음.
  - X 위치는 1번 모터(IM_1_ID)만 읽음. X·Y 도착은 위치(±GAP 10mm)만 봄, 틸트는 위치 + `TM_Done`. MI/MO 는 이동 · 기다림 결과를 안 봄. `wait_xy` 는 쉬지 않고 위치를 물어 이동 중 RS485 버스가 거의 늘 바쁨.
  - **폴링 · 고정 간격으로 도는 곳** : Event_Task 100ms 순회(HMI 묻기, RFID 0.5초 질문, 램프) / Comm_Task `osDelay(1)` 반복(CLI 수신 · W6100 `getSn_SR`·`recv` 확인 · CMD_Event, 그리고 MI/MO/PO/원점을 직접 실행) / `PO_arrive`·`PO_pour`·`PO_poured` 20ms 반복 / `wait_xy`·`wait_tilt`. Motor_Task 는 `osThreadExit()`. W6100 INT 핀(PE1, `W610_INT`)은 입력으로만 있고 안 씀.
  - **인터럽트 · RTOS 로 깨우는 곳** : UART2 응답(플래그), UART4 응답(플래그), 긴급정지 · 만재 EXTI(Event_Task 플래그), FDCAN 수신 콜백.
- **공부 루틴 (프로젝트 밖)** : 클라우드 루틴 2개가 평일 07:30 노션에 자동 생성 — 「임베디드 데일리 브리핑」(RTOS · 동시성 비중 높음), 「C 기초 다지기」(15강 커리큘럼, 교재 연계, 사용자 실제 실수 예시). 09:00 전 공부 / 09:00 부터 프로젝트 (작업 방식 11).

## 10/12 회사에서 바뀐 것 (하루에 아주 많이 바뀜 — 집에서 하나씩 다시 읽을 것)

**1. 렉 개수 설정 (rack_channel)** : FRAM `save.fs.rack_channel`(1~4)만큼 렉이 생김. **홀수 렉 = 오른쪽(렉1 처럼), 짝수 = 왼쪽(렉2 처럼)**, 렉 3·4 는 같은 쪽이 X 로 길어진 것.
- status.c : `status_1 ~ status_4`(처음 RESTART). `Status_WAIT/RUN(rack)` 1~4, `Status_PAUSE(0)` = 모든 렉. HOME · Resume · INIT · Alarm 은 4개 다.
- alarm.c : `alarm_1 ~ alarm_4`. cmd.c MI/MO/PO 렉 확인 `rack < 1 || rack > save.fs.rack_channel` → NAK, MO/PO 좌표는 `rack % 2` 로 오른쪽/왼쪽 표. C 응답 · 알람 이벤트는 rack_channel 만큼만. hmi.c · lamp.c 상태 확인도 3·4 포함.
- 렉 3·4 : 위치 표(FP 10~19)와 센서는 **나중에**. 지금 `PO_event` 는 렉 3·4 면 만재·카드 안 봄.
- ⚠️ CLI `FRAM` 의 CHANNEL 이 0 이면 MI/MO/PO 가 전부 NAK.

**2. 1단계 : 동작은 Motor_Task, TCP 는 Comm_Task** (계획대로 됨, 원점 · MI 도착 보드 확인)
- cmd.c : `static char order[160]`(받은 글자 복사 — `s` 는 net.c 받는 칸이라 다음 명령에 덮어써짐), `static volatile int order_on`(바쁨 표시), `extern osThreadId_t Motor_TaskHandle`.
- `CMD_Run` MI/MO/PO/I : 입구 확인(`order_on == 1` / 렉 상태 WAIT 아님 / manual / 완료응답 승인 전 → NAK) → `ack` → `Status_RUN` → `strcpy(order, s); order_on = 1; osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);`
- `CMD_Move`(Motor_Task) : CMD_Run 과 같은 `switch (cmd)` 모양. 맨 앞 = 원점 요청(`status_1 == HOME && order_on == 0` → `IM_MapInit · AM_Init · TM_Init` 드라이브 설정 다시 → `motor_basic_init` → 성공 대기 / 실패 초기상태). 그다음 `order` 의 MI/MO/PO/I 실행 → `CMD_Done` → `order_on = 0`.
- app_freertos.c : Motor_Task = `for (;;) { osThreadFlagsWait(MOTOR_FLAG, osFlagsWaitAny, osWaitForever); CMD_Move(); }` (폴링 아님 — 초인종 올 때까지 잠). Comm_Task = `Save_Init → NET_Init → Status_HOME → 플래그(켤 때 원점)` 후 `CLI_Run · NET_Run · CMD_Event · osDelay(1)`. **켜자마자 TCP 접속 가능.**
- HMI RUN(초기상태) → `Status_HOME` + 플래그 → Motor_Task 가 원점. CMD_D(만재 F 풀기)·PPAUSE 가 이제 **동작 중에도 바로** 나감.

**3. PO 상황 (event.c, 사용자 방식 — 그대로 둠)** : `PO_event(rack, dan, move_done, sensor_check)` → `PO_manjae`(도착 때 그 단 만재 → F, 센서 풀리거나 D 까지) / `PO_rfid`(도착 때 카드 없음 → S) / `PO_tilt`(쏟는 sensor_check ms 동안 센서 안 스침 → T, RUN 까지). run.c PO : `PO_event(rack, dan, 1, 0)` 도착 / `PO_event(rack, dan, 0, return_delay * 10)` 쏟기.

**4. 긴급정지 · 정지**
- usart.c UART2_Xfer · UART4_Xfer : `!= XFER_DONE` → `(… & XFER_DONE) == 0` (9/28 리뷰 숙제). 다른 플래그(긴급정지 0x02 등)가 같이 오면 HMI 응답을 실패로 버려 **RESET 버튼을 놓치던 문제**.
- RESET 에서 드라이브 재설정 빼고 RUN(원점 요청) 때 함. 긴급정지 → 풀기 → RESET → RUN **보드 확인됨**.
- `E_S()` (사용자 수정) : `TM_Stop()`(감속 정지) · `IM_Stop()` · `AM_Stop()`. 알람이면 무조건 `E_S` (alarm.c `alarm_on` 안).
- **X `IM_Stop`** : 가는 중엔 드라이브가 새 PR 명령을 안 받음(매뉴얼 Pr8.02 "0x001P not yet responding") → quick stop 만 됨. 그래서 `0x6017(Pr8.23 quick stop 감속 시간) ← IM_DEC_MS`(두 모터 먼저) → `0x6002 ← 0x40`(두 모터). 시도했다 버린 것 : PR0 속도 모드 0rpm(도착 후에야 멈춤 + 원점이 이상해짐).
- ⚠️ 0x6017 은 드라이브 RAM 에 남아서 **긴급정지 후 X 원점이 "닿고 더 밀다 늦게 돌아옴"** 이 될 수 있음 (원점 때 닿고 서는 것도 0x6017 을 쓰는 듯). **사용자 결정 : 원점 코드는 원래대로, 손대지 말 것.** 시험 결과 보고 정함. 시험 전 X 드라이브 전원 한 번 끄기.
- Y 원점 오프셋(H05_36, 0x0524 32bit) 시험 → 안 올라와서 **옛날 방식 `AM_Move(150, 50)` 로 되돌림**. `R_HOME_OFFSET` 이름만 남김. 매뉴얼 H05_37~40 (오프셋으로 이동하는 옵션) 확인 필요.

**5. 알람 (alarm.c = 켜기만, 판단은 각 자리)**
- 공통 `alarm_on(rack, code)` : 상태 A + `alarm_n` 번호 + `alarm_event_on` + **`E_S()`**. RESET = `IM_AlarmReset`(0x1801 ← 0x1111) · `AM_AlarmReset` · `TM_AlarmReset`(PA_04F ← 0x0300) · `AM_EStop(0)` · `Alarm_Clear` · `Status_INIT` → RUN 으로 원점. (과전류 · 과전압 등은 전원 껐다 켜야 풀림)
- 01 HMI 통신 : `HMI_Run` 실패 · 꼬임 = `HMI_FAIL`(-1, hmi.h). event.c `hmi_event` `case HMI_FAIL` : 20번 연속(약 3초) → `A_01(0)`.
- 02 · 03 · 04 모터 : event.c `alarm_event`(1초마다 X 0x2203 / Y H0B_34 / 틸트 PA_004 Fault) — **지금 `Event_Run` 에서 주석으로 뺌**. 이유 : 드라이브가 대답 안 하면 재시도(500ms × 3) 동안 Event_Task 가 멈춰 → 카드 리더에 못 물어봄 → 카드 빠짐으로 착각 → UT 이벤트 2.5초마다 반복. 다시 넣을 때 "읽기 실패 = 알람" 으로 한 번만 막히게 + `wait_xy` 에 `status_1 == ALARM` 이면 그만. Y H0B_34 가 "지금 알람"인지 매뉴얼 확인.
- 05 · 06 · 07 위치 : run.c `wait_xy` 30초 → 못 간 축 `A_05`/`A_06`, `wait_tilt` 30초 → `A_07`. `MI` · `PO` 의 wait 줄마다 `== 0 → return 0` (알람이면 PO 가 틸트 안 함, MI 는 AI 안 보냄).
- 08 안전센서 : 없음. 09 비상정지 : `estop_event` → `A_09(0)`. 10 원점 : 기준 정할 것 (주석).
- 아직 : hmi.c `hmi_alarm` 이 어떤 알람이든 `'9'` 를 보냄 (번호 보내기 안 함).

**6. 램프 명령 = 프로토콜 문서 형식** : `01LL_렉_램프_모드시간&L_렉_램프_모드시간…` (램프 1 적 2 녹 3 황 / 모드 '0' 끔 '1' 켬 '2' 깜빡 / 시간 '0'~'l' = 0~60초, '0' 계속, 10초 = ':'). cmd.c `case CMD_LAMP` : `s + 3` 부터 `sscanf(p, "L_%d_%d_%c%c")` 반복 + `strchr(p, '&')`. 홀수 렉 → 램프1, 짝수 → 램프2. 하나라도 틀리면 NAK (앞 묶음은 이미 켜짐). **보드 시험 안 함.**

**7. 랜선 (net.c)** : 뽑히면 `tcp_on = 0; unplug = 1;`(close 안 함), 다시 꽂히면 `disconnect()` 로 PC 에 끊는다고 알림 → PC 가 바로 새로 연결. (전에는 STM 이 조용히 close → PC 가 옛 연결을 붙잡고 한참 뒤 재접속.) **보드 시험 안 함.** 뽑힌 동안 이벤트 `send()` 가 잠깐 막힐 수 있음.

**10/12 보드 확인** : 원점 · MI 도착 · 긴급정지 → RESET → RUN 됨. 로그 해석 : `11UT_1_…` = 카드 이벤트(완료응답 아님), `55S_1_A_05&…&F_1_0000…` = PC `55C` 상태조회 대답.

**사용자 의견 (10/12)** : 하루에 너무 많이 바뀌어 cmd.c · event.c 가 헷갈림 (cmd.c 처음 구조와 쉬운 부분은 사용자가 짠 것). 원점처럼 **요청 안 한 곳은 절대 같이 고치지 말 것.** 설명은 짧고 쉽게.

## 10/13 회사에서 바뀐 것 (모터 파일 · 알람 · event · 만재 · 부저 정리)

**사용자 결정 · 규칙 (10/13)**
- `if (함수() == 1)` 쓰지 않음 → `if (함수())`. "아니면"은 `== 0` (`!` 금지는 그대로).
- 여러 레지스터 쓰기 : **움직이기 · 설정 = `&&`**(앞이 실패하면 뒤 안 함) / **멈추기 = 따로 다 보내고 `a && b`**(하나 실패해도 나머지는 세움). 둘 다 실패면 0.
- 알람 **조건 · 숫자는 alarm.c 한 곳**, 부르는 자리는 한 줄씩. 긴급정지도 `alarm_go`.
- 요청 안 한 곳(특히 **원점**)은 같이 고치지 말 것. 새 함수 · 변수 · 상수는 사용자 승인 후.
- PO 만재 · 카드 · 틸트 판단은 **run.c 안**(`PO_pause` · `PO_tilt`), event.c 는 Event_Task 함수만.

**1. 모터 파일 (a · i · t_motor)**
- Y 원점 오프셋 : **H05_36 은 Enable OFF(서보 꺼진 동안만 씀)** 라 `AM_Home` 에서 쓰면 거절됐던 것 → `AM_Init` 의 서보 켜기 전으로 옮김 (H05_34 · H05_35 도). `AM_HOME_OFFSET (-150 * Y_PULSE * Y_GEAR / Y_PI)`(a_motor.h), `write_regs(R_HOME_OFFSET, 2, AM_HOME_OFFSET, AM_HOME_OFFSET >> 16)`(write_regs 가 안에서 16비트로 자름). 원점 후 `AM_Move(150, 50)` 삭제 → 드라이브가 스스로 150mm. **보드 시험 필요** (ER.668 이면 부호 반대).
- `!` → `== 0` 통일, `AM_Stop` 따로 보내기, `IM_Move` `&&`, 원점 시작 명령 실패면 바로 0.
- 안에서만 쓰는 함수 `static` (`AM_Servo/Done/HomeDone/Zero`, `IM_Zero/State/Done`), `TM_Estop` · 안 쓰는 상수 삭제. `TM_Move` 는 수동 버튼 때문에 공개. t_motor.c `HOME` → `START_HOME` (status.h 의 상태 `HOME` 과 이름 충돌).
- **FP 11 · 12 반영** : `speed_rpm()`(100% = FP 11 rpm, 0 이면 `*_MAX_RPM`) · `accdec_ms()`(FP 12, 0 이면 기본). save.c FP 11 범위 확인 `SPEED_MAX 3000`. X 원점 후 100mm 이동은 `write_move(…, 100, IM_ACC_MS)` 로 **기본값 고정**(사용자가 rpm 100 으로 바꿈, 주석은 아직 150).
- **이동 함수 맨 앞 가드** : `IM_Move` · `AM_Move` · `TM_Move` 에 `if (estop == 1 || status_1 == ALARM) return 0;` → 그래서 run.c MI · PO 는 `if` 없이 함수만 나열, 끝에 `return (estop == 0 && status_1 != ALARM);`. 멈춤 함수(`*_Stop`)엔 가드 없음. ❓ **사용자 고민 중 : 꼭 모터 함수 안에 넣어야 하나** (다음에 다시 보기).
- 매뉴얼 확인 : ALM COIN = **추종 오차 < H05_21** (가는 중에도 켜질 수 있음 → 도착 판단엔 위치 비교 유지), 73쪽 "다단 운전 중 DI4 끄면 즉시 멈춤"(AM_Stop OK). iCL Pr8.02 "가는 중엔 새 PR 안 받음, quick stop 만" → X 감속 정지는 0x6017 + 0x40.
- `wait_xy` 를 Done 방식으로 바꾸는 안은 **안 함**(PO 절반 지점은 위치가 필요, Y COIN 은 도착 신호가 아님).

**2. 알람 (alarm.c)**
- `static alarm_go(rack, code)` = **E_S + 상태 A + 번호 + PC 알림 + Buzzer_On**.
- `A_01(button)` HMI_FAIL 20번 연속 / `A_05 · A_06 · A_07(start, arrived)` 10초 못 감 (걸면 1) / `A_09(rack)` 긴급정지 / `A_10(far, start)` 원점 시작 전 200mm 넘게 떨어져 있었는데 2초 안에 닿음 (걸면 1) / 02~04 · 08 은 `alarm_go` 한 줄 (02~04 는 아직 아무도 안 부름 → 내일).
- 상수 : `HMI_FAIL_MAX 20`, `MOVE_MS 10000`, `HOME_NEAR_MM 200`, `HOME_FAST_MS 2000` (전부 alarm.c).
- 부르는 곳 : event.c `estop_event`(A_09) · `hmi_event`(A_01) / run.c `wait_xy`(A_05 · 06) · `wait_tilt`(A_07) / `IM_Home` · `AM_Home`(A_10 : "닿은 순간"을 아는 곳). cmd.c 원점 실패는 `if (status_1 != ALARM) Status_INIT();` (알람 덮어쓰지 않게).

**3. event.c** : 머리 주석 = 1. Event_Task / 2. 인터럽트. `hmi_event` = A_01 · RUN · STOP · RESET(+Buzzer_Off) · 수동 모드 · 음소거(Buzzer_Off), 수동 버튼 21~26 은 `if (manual == 1) HMI_Manual(button);` (움직임은 **hmi.c `HMI_Manual`**, 틸트 수동은 `TM_Move(now ± MANUAL_TILT)` 로 고침 — 전엔 반대쪽으로 튐). PO 묶음(`PO_event` 등)은 **run.c `PO_pause` · `PO_tilt` 로 옮김**(event.c 에서 삭제).

**4. run.c PO** : `MO → PO_pause(만재 · 카드면 멈춤, 풀리면 이어서) → Y 올리며 틸트 → PO_tilt(touch_time 동안 센서 안 닿으면 T) → PO_pause(사용자가 넣음, 쏟은 뒤 만재면 기울인 채 대기) → 복귀`. `PO_pause` · `PO_tilt` 맨 앞 `if (estop == 1 || status_1 == ALARM) return 0;` (ALARM 을 PAUSE 로 덮어쓰지 않게). 05~07 시간 30초 → **10초**. ❗ 사용자 의견 : **PO 부분과 wait 부분이 지저분 → 다음에 깨끗하게**.

**5. 만재 (manjae.c, 사용자 모양)** : 함수 3개만, 변수 없음. `manjae_off(rack, dan)` = 핀 그대로(3.3V 빈칸 = 1) / `manjae_on(rack, dan)` = `manjae_off(…) == 0` / `manjae_change()` = 8칸(`GPIOE->IDR & 0x7F80`) 바뀌었으면 1. `floor_full` · `Full_Read` · `full_1_1`~`full_2_4` · `full_1/2` 삭제 → run · event · cmd · hmi · lamp 가 `manjae_on(…)` 으로. hmi.c 화면 칸은 `manjae_on(2, 1) ? '1' : '0'` (원래 모양).

**6. 부저 (buzzer.c 새 파일)** : `Buzzer_On` · `Buzzer_Off` (PD0 = DO9). **능동 · 단속음 부저**라 핀을 켜 두면 스스로 삐 · 삐 (깜빡이게 하면 이상하게 들림). 켜기 = 원점 시작(cmd.c) · `alarm_go` · 만재 생김(event.c `manjae_event`) · PC `01B_렉_1` / 끄기 = 원점 성공(cmd.c) · RESET · 음소거 · 만재 다 풀림 · PC `01B_렉_0`. **"순간"에만 켜고 끔**(0.1초마다 끄던 줄 삭제) → PC 와 STM 이 안 부딪힘, 음소거에 변수 필요 없음. 알람 중 만재가 풀리면 부저도 꺼짐(사용자 결정 : 안전 코드 안 넣음). TIM8 PWM 으로 해 봤다가 안 울려서 GPIO 로 되돌림(ioc 도 되돌림).
- cmd.c **B 명령** : `CMD_BUZZER (('B' << 8) | '_')`, `01B_렉_1/0`, 렉은 범위 확인만.

**7. 기타** : 켤 때 Y 서보가 두 번 켜지는 원인 = CMD_Move 원점 요청에서 `AM_Init` 등을 부르고 `motor_basic_init` 이 또 부름 (`AM_Init` 은 DI 기능을 0 으로 지워 서보를 껐다 켬). 고치는 안(CMD_Move 세 줄 삭제 + `motor_basic_init` 맨 앞 `x_ok = y_ok = t_ok = 0`) **보류**.
- 빌드 : 새 파일(buzzer.c)은 명령줄 makefile(`Debug/Core/Src/subdir.mk`, `Debug/objects.list`)에 손으로 넣음 → **CubeIDE 에서 한 번 빌드하면 다시 만들어짐**. ⚠️ CubeIDE 에 예전 내용으로 열린 탭이 저장되면 Claude 수정이 덮어써짐(10/13 run.c) → 탭 Revert / Refresh(F5).
- Flash 약 93.7KB / 256KB, RAM 약 28.6KB / 128KB. 경고 1개(안 쓰는 `alarm_event`).

## 10/14 회사에서 바뀐 것 (네트워크 추가 · W6100 인터럽트 · 타이머) — 보드 시험 전부 안 함

**작업 방식 (10/14 사용자)** : "Claude 가 하는 걸 내가 따라 치는" 방식. 한 단계씩 작게, 개념 먼저, 사용자가 치고 Claude 가 빌드 · 리뷰. 모르는 상수 · 새 구조보다 **있는 것을 이용**하는 쪽을 좋아함. 사용자가 이해 못 한 채 넘어간 곳이 많음 → **집에서 만재 → RFID → net.c `NET_Run` 순으로 질문하면서 다시 볼 예정**.

**1. 네트워크 요구 (사용자 문서)** : 기본 IP 172.20.0.1 / 255.255.255.0 / 포트 2500 / 서버 (save.c `Network_Default` 에 이미 있음). 창구 3개 :
| 소켓 | 포트 | 용도 |
|---|---|---|
| 0 `TCP_SOCK` | `net_port`(2500) | PC 명령. **20초 명령 없으면 끊기(FI 7)는 여기만** |
| 1 `Service_SOCK` | 58080 | 모니터링 : 2500 에서 오간 것을 `[TX] 내용` (PC 가 보냄) / `[RX] 내용` (PC 가 받음) 으로. 지금은 **STX · ACK · ETX 를 그대로** 보냄 (안 보이는 글자로 나올 수 있음 → 시험 보고 결정) |
| 2 `LOG_SOCK` | 50001 | 로그 : 중요한 것만 영어로 (알람, 상태 바뀜, 모터 통신 에러, 원점 · 이동 시간). **`[숫자]` 앞머리 없음. 구조는 사용자와 같이 짤 것 → 아직 아무것도 안 보냄** |
- 노트북 선만 스위치에서 빠져도 2500 은 계속 돼야 함 (세 창구 따로).

**2. net.c (W6100 인터럽트 방식)** — ioc : PE1 = GPIO_EXTI1 Falling, 풀업, NVIC 5
- `NET_Init` 끝 : `setSIMR(0x07)`(소켓 0 · 1 · 2) + `setSn_IMR(n, 0x0F)`(CON · DISCON · RECV · TIMEOUT, **SENDOK 는 뺌**) → `net_mode == 0` 이면 `net_open` 3개.
- `net_open(sock, port)` : `switch` → **if 3개 순서대로** (CLOSE_WAIT → disconnect / CLOSED → `setSn_RCR(sock, 2)` → socket → `setSn_KPALVTR(sock, 1)` / INIT → listen). 한 번 부르면 LISTEN 까지. `w610_reset` 바로 아래로 옮김.
  - keep-alive : 5초 조용하면 "살아 있어?" → 재전송 2번(0.2 · 0.4 · 0.8초) 대답 없으면 W6100 이 스스로 닫음(TIMEOUT) → **약 6~7초** (시험 필요). 1바이트라도 보낸 뒤에만 동작. RCR 을 줄이면 데이터 재전송도 2번만 → 네트워크 나쁘면 더 잘 끊김.
  - keep-alive(PC 컴퓨터 살아 있나) ≠ FI 7 20초(PC 프로그램이 명령 보내나) → **둘 다 필요**.
- `NET_Run` (`switch`·`getSn_SR` 폴링 없음) :
  1. `if (INT 핀 == 0)` (**핀은 거꾸로 : 0 = 일 있음**) → `w6100_doing = getSn_IR(TCP_SOCK) & 0x0F` → `setSn_IRCLR(TCP_SOCK, w6100_doing)` (읽고 **바로** 끔). `w6100_doing` = 표시등 복사본 (평소 0, 일 있으면 그 비트 1). 처음 `= 0` 꼭 (핀 안 읽은 바퀴 쓰레기 값 방지).
  2. `& Sn_IR_CON` → `tcp_on = 1`, `last = 지금` / `& Sn_IR_RECV` → 기존 받기 코드 (STX ~ ETX → `service_port("[TX] ")` → `CMD_Run`) / `& (DISCON | TIMEOUT)` → `tcp_on = 0`, `unplug = 0`, `net_open`.
  3. 보드 랜선 뽑힘(`tcp_on == 1 && PHY OFF`) → `tcp_on = 0, unplug = 1` / **우리가 끊기** : 20초 명령 없음 또는 다시 꽂힘 → `disconnect` + **바로 `net_open`** (PC 가 RST 로 대답하면 DISCON 이 안 올 수 있어서).
  4. 서비스 · 로그 : `if (INT 핀 아직 0)` → 각각 읽고 끄고 DISCON · TIMEOUT 이면 `net_open`.
  - **`& 0x0F` 이유** : `send()` 가 SENDOK 를 기다림 (socket.c 307줄). NET_Run 이 SENDOK 까지 지우면 다음 send 가 영영 기다려 Comm_Task 멈춤.
  - SPI (1ms 한 바퀴) : 아무도 연결 안 됨 6~7번 → **0번**, 2500 연결 중 조용 → **1번**(랜선).
- `service_port(char *tr, buf, len)` (static) : 노트북 없거나 보낼 자리(`getSn_TX_FSR < len + 7`) 없으면 안 보냄 → `"[TX] "`/`"[RX] "` + 내용 그대로 + `\r\n` (send 3번). 자리 확인 이유 : 노트북이 연결만 하고 안 읽으면 보내기 칸이 꽉 차 send 가 기다리며 2500 까지 멈춤.
- `NET_Send(buf, len)` (net.h 공개) : 2500 으로 보내고 `service_port("[RX] ")`. cmd.c `send(TCP_SOCK, …)` 7곳 → `NET_Send`. cmd.c `#include "socket.h"` → `net.h`, `#define TCP_SOCK` 삭제.
- **STX · ETX · ACK · NAK** : cmd.c → **cmd.h** 로 옮김 (사용자), cmd.c · net.c 의 `0x02/0x03/0x06/0x15` 를 이름으로. (hmi.c 의 STX · ETX 는 터치패드용이라 따로, net.c MAC `0x02` 는 STX 아님)
- 아직 안 함 : Comm_Task `osDelay(1)` → `osThreadFlagsWait(NET_FLAG, …, 1)` + event.c EXTI 콜백 `W610_INT_Pin` 줄 (지금은 1ms 마다 **핀 레벨을 읽어서** 동작은 함. 초인종은 기다리는 시간을 늘릴 때 필요. CLI 가 UART1 폴링이라 지금은 1ms 유지). 서비스로 명령 받기 · 서비스로 대답, 로그.
- 질문 · 개념 정리 : 핀(0 = 일 있음) ↔ 표시등 비트(1 = 일 있음)는 **다른 것** / IMR(울릴지 설정, 켤 때 한 번) ↔ IR(실제 일, 읽고 끄기) / `if (조건);` 의 `;` 는 빈 문장 / `==` 가 `&` 보다 먼저 (`w6100_doing == 0 & CON` 틀림) / static 함수는 쓰는 곳보다 위에 / 지역 변수 처음 값은 쓰레기, static 은 0.

**3. 만재 (event.c + 타이머)** — 사용자 생각 : 인터럽트로 바로 인식하면 스칠 때마다 부저 · R 깜빡 → **2초 동안 그대로일 때만 인정**.
- `manjae_event` : `if (manjae_change()) osTimerStart(Manjae_TimerHandle, 2000);` (바뀔 때마다 2초 다시 감기)
- app_freertos.c `Callback_Manjae_Timer` : `full_event_on = 1;` + 만재 하나라도 있으면 `Buzzer_On` 아니면 `Buzzer_Off` (확정 순간 한 번).
- `full_event_on` 은 "PC 로 FF 보내 줘" 쪽지 (타이머 태스크는 send 못 함).
- 사용자가 쓴 첫 모양(2초 if / else 매번)은 100ms 마다 FF · 부저를 반복해서 알람 부저 · B 명령 · 음소거와 부딪힘 → 타이머로.
- ⚠️ 남음 : R 램프(`lamp_manjae`)와 PO · HMI 는 `manjae_on` 을 **바로** 읽음 → 스칠 때 R 은 아직 깜빡. FULL_1_1(PE11) 은 EXTI 없음(EXTI11 = 긴급정지) → 100ms 읽기 남음.

**4. PO 틸트 (run.c `PO_tilt`, 사용자 : 변수 줄이는 쪽 · 구조 그대로)**
- 20ms 마다 깨던 for 문 → `touch_time += 지금`(이제 "쏟기 끝 시각") → `osThreadFlagsClear(TOUCH_FLAG)` → 처음 한 번 확인 → `while ((left = touch_time - 지금) > 0) { osThreadFlagsWait(TOUCH_FLAG, …, 렉1 1단이면 20 아니면 left); if (manjae_on) touch = 1; }`.
- `left` 1개는 꼭 필요 : 시계를 두 번 읽으면 그 사이 넘어갈 때 "약 49일 기다리기" 로 멈춤.
- 쏟은 뒤 `if (estop == 1 || status_1 == ALARM) return 0;` 추가 (전에는 쏟는 중 긴급정지면 ALARM 을 PAUSE(T) 로 덮어씀).
- event.c EXTI 콜백 : 만재 핀이면 `osThreadFlagsSet(Motor_TaskHandle, TOUCH_FLAG)` 도.

**5. RFID (타이머, 반만 됨)** — app_freertos.c `Callback_Rfid_Timer` 에 `Rfid_Check();` ✅ / `Rfid_Check` 의 0.5초 확인 if 삭제 ✅
- ❗ **남음 (안 하면 리더에 100ms 마다 물음)** : rfid.c `Rfid_Init` 끝에 `osTimerStart(Rfid_TimerHandle, ASK_MS);` + `#include "cmsis_os2.h"` · `extern osTimerId_t Rfid_TimerHandle;` / `static uint32_t ask_last;` 줄 삭제 / event.c `rfid_event` 함수 · 호출 삭제 / ioc `TIMER_TASK_STACK_DEPTH` 256 → 512 (Rfid_Check 의 snprintf).
- 2초 못 읽음 확인은 **지금(HAL_GetTick 시각 비교) 그대로 두기로**. 사용자 고민 : 타이머 · HAL tick 이 섞여 보임 → 대안 ① `miss` 횟수(`LOST_MS / ASK_MS`) ② 만재처럼 렉마다 2초 타이머(CAN 수신 인터럽트라 `xTimerResetFromISR` 필요, 타이머 2개 추가, `card_lost` 공개).

**6. 그 밖에 이야기한 것**
- 인터럽트로 바꿀 수 있는 건 장치가 먼저 알려 주는 것뿐 (만재 · W6100 INT · CAN 수신 · 긴급정지). RFID · HMI 는 "묻고 대답" 이라 주기는 남음.
- Comm_Task 를 전부 초인종으로 하려면 : W6100(오늘) → CLI UART1 인터럽트 → 이벤트 초인종 → 그때 알람 시간 100ms ~ 1초.
- RAM 을 진짜 줄이는 곳 : 태스크 스택 실측(`uxTaskGetStackHighWaterMark`) 후 줄이기 (힙 20KB 고정).
- 빌드 : 전체 통과, 경고 0. Flash 약 95.2KB / 256KB, RAM 약 28.6KB / 128KB. ⚠️ CubeIDE 코드 생성 · 저장 때 열린 탭이 Claude 수정을 덮어씀 (10/14 event.c `manjae_event` 가 한 번 되돌아갔음) → 탭 F5.

## 10/15 회사에서 바뀐 것 (마무리 구현 + 구조 정리) — 보드 시험 전부 안 함

**사용자 원칙 (10/15)** : "각 파일은 그 파일 관련 행동만". cmd.c = 명령이 맞는지 확인 → NAK / ACK + 그 파일 함수 실행. 동작은 **run.c 의 원래 함수(MI · MO · PO · I)** 를 그대로 씀. `CMD_…` 비교로 흐름 나누는 모양 싫어함 (10/7 · 10/15 두 번 거절). 코드는 `BTN_RESET` 처럼 **기본 함수 나열**, 짧게. 새 감싸기 함수(`Run_Order`, `home_event`, `before` 변수 등) 거절. 시작 · 끝 줄이 여러 곳에 반복되는 것 싫어함.

**1. RFID 타이머 마무리** : rfid.c `Rfid_Init` 끝 `osTimerStart(Rfid_TimerHandle, ASK_MS)`, `ask_last` 삭제, event.c `rfid_event` 삭제, `Event_Run` 맨 앞 `Rfid_Init()`. `configTIMER_TASK_STACK_DEPTH 512` (FreeRTOSConfig.h + ioc). TCP 연결(CON) 때 `rfid_new = 1` → 지금 카드 상태 PC 로.

**2. net.c 구조 정리** (맨 위 주석 = W6100 라이브러리 함수 목록 + 이 파일 함수 목록)
- 공통 `net_open` · `static port_doing(sock)` (`w6100_doing = 0` → INT 핀 1 이면 끝 → `getSn_IR & 0x0F` 읽고 끔). 변수 이름 `w6100_doing` 하나로 통일.
- 2500 : `tcp_recv`(STX~ETX) → `tcp_cmd` / `tcp_check`(랜선 · FI7 20초 · 다시 꽂힘) / `tcp_port`(CON · RECV · DISCON/TIMEOUT). 서비스 · 로그 : `service_log_port`. `NET_Run` = `tcp_port(); service_log_port(); log_send();` (`net_mode != 0` 이면 안 함).
- **일련번호 `Roder_Number()`** (net.c, 하나의 번호표 01~99 → 01) : PC 가 번호 없이 보낸 명령(`MI_1_1_2…`)과 이벤트에 로더가 붙임. PC 가 번호 붙여 보낸 명령 · 승인은 그 번호 그대로 (`number` 도 그 번호로 맞춤). cmd.c `event_send` 의 자기 번호 삭제.
- **PC 완료 승인 `01-AI_…` 의 `-` 는 사실 ACK(0x06)** → cmd.c 승인 확인 `s[2] == ACK`.
- **로그 포트 50001** : `Log_Port(char *text)` (아무 태스크, `osKernelLock` 으로 `log_text[512]` 에 덧붙임 + CRLF) → `log_send`(Comm_Task, 연결 · 자리 있을 때 보냄). 시각 · HELLO 없음 (Tera Term 타임스탬프 사용). 내용 : MI/MO/PO 시작(렉 · 열 · 단) · 끝(done/FAIL + 초), 알람(번호 · 레지스터 · 값 · 이름). 서비스 58080 = 2500 오간 것 `[TX]` / `[RX]` 복사만 (명령 안 받음).

**3. 알람 02 ~ 04 (드라이브 알람)** — 모터 파일 = 읽기 함수, alarm.c = 판단 · 이름, event.c `alarm_event` = 1초마다 (원점 끝난 뒤만, 알람 · 긴급정지 · 초기 · 원점 중엔 안 물음) `if (A_02()) return; if (A_03()) return; A_04();`
- X `IM_Alarm(&code)` : 0x2203 을 **두 모터 다** 읽어 OR (0x01 과전류 0x02 과전압 0x40 전류측정 0x80 축고정 실패 0x100 오토튜닝 0x200 EEPROM).
- Y `AM_Alarm(&code)` : **H0B_33 = 0 일 때 H0B_34 = 0x0B22** (전에 0x0B34 로 틀렸음). ER.950 · 952 · 601 은 알람 아님 (사용자). 값 형식(0x0630?) 보드 확인 필요.
- 틸트 `TM_Alarm(&code)` : PA_005 = 0x0005 (01 과전류 02 과전압 03 저전압).
- 로그 예 : `ALARM 02  X  0x2203 = 0x0001  over current`.
- hmi.c `hmi_alarm` : 긴급정지 '9' / `alarm_n >= 2` 면 `'0' + 번호` (10 = ':' — ESP 가 `data[2] - '0'`, AlarmString 0~10 이 우리 번호와 같음, 범위 검사 없음) / 수동 '1' / 없음 '0'.

**4. cmd.c · run.c · Motor_Task (명령 구조)**
- cmd.c 머리 주석 = 함수 지도. `case CMD_MI: case CMD_MO: case CMD_PO:` 합침 : 바쁨(네 렉 다 WAIT 아님) · 수동 · 승인 전 → NAK / `sscanf` → 범위 → `order_xy(cmd)`(FRAM 표에서 좌표, 풀어 쓴 모양 유지) → ack → `order_no` → `Status_RUN` → 시작 로그 → 초인종(MI/MO/PO_FLAG). C · D · E 들여쓰기 · 주석 정리.
- `CMD_I` : 원점 중 · 운전 · 일시정지면 NAK → ack → `order_no` → `osThreadFlagsSet(MOTOR_FLAG)` 한 줄.
- run.h : `order_rack/col/dan/x/y/xy_speed/tilt_speed/move_delay/return_delay` (run.c 에 정의, cmd.c 가 채움).
- run.c **`Motor_Run(flag)`** : `if (flag & MI_FLAG) return MI(…)` 처럼 run 함수 하나. **원점은 시작 · 끝 전부 여기** : `Status_HOME → Buzzer_On → motor_basic_init()` → 성공 `Status_WAIT(1~4) + Buzzer_Off` / 실패 `if (status_1 != ALARM) { Status_INIT(); Buzzer_Off(); }`. 켤 때 · HMI RUN · PC I 는 **초인종 한 줄만** (`Status_HOME` · `Buzzer_On` · 시작 로그 · `CLI_Start` · HOME 로그 지움).
- cmd.c **`CMD_Done(flag, ok)`** (Motor_Task) : 원점이면 PC I 였을 때만 `homing done` / 아니면 로그 + 성공 시 `Status_WAIT(order_rack)` + `done_text`(AI · AO · EO).
- **`motor_basic_init` (사용자 모양)** : `int x = IM_MapInit(); int y = AM_Init(); int t = TM_Init(); if (x && y && t) return I(); return 0;` — `x_ok` 등 static · 재시도 없음 → **원점마다 드라이브 다시 설정** (긴급정지 뒤 설정 사라짐 문제도 풀림, 대신 원점마다 Y 서보 껐다 켬). 켤 때 드라이브가 늦게 깨면 실패 → HMI RUN 다시. `AXIS_WAIT` · `INIT_RETRY` 는 사용자가 지움.
- **wait 함수 삭제** : `wait_xy` · `wait_tilt` → 모터 파일 `IM_Arrive(x)` · `AM_Arrive(y)` · `TM_Arrive(deg)` (지금 도착했나 한 번 보고 1/0, `GAP 10` · `TILT_GAP 2` 도 모터 파일로) + alarm.c `A_05(x)` · `A_06(y)` · `A_07(deg)` = **도착까지 기다림, 10초 못 가면 알람, 도착 1 / 실패 0** (전에는 "걸면 1"). run.c MI · PO 는 `A_07(0); IM_Move; AM_Move; A_05(x); A_06(y);` 처럼 나열. PO 의 Y 만 움직이는 구간은 Y 만 물음 (버스 절반).

**5. 그 밖에** : event.c `lamp_event` 만재 R 은 `osTimerIsRunning(Manjae_TimerHandle) == 0` 일 때만 (스침이면 안 깜빡). `home_event` · `home_end` 없음. lamp.c `LampY2 → Lamp_Y2`(사용자). 노션 「RTOS os 함수 지도 · 언제 무엇을 쓰나 (10/15)」.

**10/15 이야기만 한 것 (코드 안 바꿈)**
- **버스 줄이기** : 사용자가 원하는 방식 = "걸릴 시간을 계산해서 그동안 자고, 그 뒤 묻기". 모터 파일마다 `*_Time(목표, percent)` (FP 11 `speed_rpm` · FP 12 `accdec_ms` 를 써서 자동 반영, 사다리꼴, 실제보다 길게 안 나오게) → A_05~07 맨 앞 `osDelay`. ❗ 드라이브마다 가감속 ms 뜻(목표 속도까지 / 0→1000rpm) 매뉴얼 확인 필요. **보드 시험 후 결정.**
- 버스가 늘 바쁘면 : 보통은 Event_Task(High) 가 한 번(3~5ms)만 기다림. 문제는 **드라이브 무응답(X·틸트 RX_TIMEOUT 500ms, Y 50ms) + 소프트웨어 알람 정지(E_S)** 가 겹칠 때 최대 500ms 늦음 (긴급정지 버튼은 NC 하드웨어라 상관없음). 시험 때 `uart2_err` · `uart2_us` 보기.
- **수동 모드 구멍** : 작동 중엔 수동 모드가 안 켜지고(네 렉 WAIT 일 때만) 21~26 도 무시 → OK. 하지만 **수동 모드 켠 채 PC I** 는 NAK 안 됨 → 원점 중 수동 버튼이 먹힘. 고치는 안 ① `CMD_I` 입구에 `|| manual == 1` ② 수동 버튼 줄 `manual == 1 && status_1 == WAIT`. **사용자 : 오늘 안 함, 내일 이어서.**

## 10/16 회사에서 바뀐 것 (파일별 정리 수업 : fdcan → rfid → run · alarm · status) — 보드 시험은 사무실 문제로 거의 못 함

**사용자 방식 (10/16)** : 파일마다 "왜 이렇게 짰나 → 개념 → 더 좋은 방법 → 고칠 안" 순서로 천천히. **설명은 우편함 · 편지 같은 비유 말고 프로젝트 실제 것(리더 ID 201, 'C', FIFO0, PO…)으로**, 용어 한꺼번에 많이 쓰지 말 것, 그림 좋아함. 코드는 `I()` · `BTN_RESET` 처럼 **기본 함수 나열**, if · while 은 줄이고, 변수로 on/off 하는 것보다 **기존 함수 이용**을 좋아함. 함수가 너무 늘어나는 것도 싫어함. **cmd.c 는 "TCP 명령이 맞나 확인 → NAK / ACK + 실행" 용도만** (PC 로 먼저 알리는 건 cmd 일이 아님).

**1. fdcan.c** : 이름 사용자 결정 `CAN_On`(CAN 켜기) · `Send_to_Reader`(프레임 1개 보내기). 수신 콜백 `HAL_FDCAN_RxFifo0Callback` 은 **ST 드라이버가 정한 이름이라 바꾸면 안 불림** (그대로, 주석 "리더 대답 받기"). 콜백 `if` → `while` (FIFO0 3칸이 빌 때까지 읽기, `return` → `continue`). HAL 함수 줄마다 주석 + 드라이버 파일 위치.
- 리더 코드(`3DS_RFID_V1.1.0_251128_7a56`, STM32F042) 확인 : 속도 **125kbps**(리더 main.c Prescaler 24, ⚠️ 리더 ioc 는 500k → 리더 프로젝트를 CubeMX 재생성하면 깨짐), ID = 200 + DIP(~4핀, 0 이면 10), `'C'` 받으면 같은 ID 로 UID 7바이트, **카드 바뀌면 묻지 않아도 보냄**, **20번 연속 못 읽으면(약 0.25초) UID 0000000 보냄**, 리더 CAN `AutoBusOff = DISABLE`(Bus-Off 면 전원 꺼야 풀림).
- 우리 쪽 : FDCAN 클럭 170MHz ÷ 80 ÷ (1 + 14 + 2) = 125kbps, 샘플 88%. 트랜시버 MCP2542FD 는 전압 변환만 (VDD 5V · VIO 3.3V · STBY Low 여야 동작).

**2. main.h 에 RTOS extern 모음** (위 "공유 변수 규칙"). rfid · event · cmd · usart 의 `extern … Handle` 줄, cli.c 중복 `extern SAVE_Data save` 삭제.

**3. rfid.c (사용자 구조, 45 → 53줄)** : `Rfid_Save(rack, data)` = **"이럴 때 이렇게" 4줄** (`rack == 1 && data[0] != 0 && card_ok_1 == 0` → 1 + `memcpy(uid_1)` + `card_event_on` / `data[0] == 0 && card_ok_1 == 1` → 0 + `memset` + `card_event_on`, 렉2 같음). `Rfid_Check` = 'C' 묻기, **`Send_to_Reader` 실패(대답 없어 보내기 칸 3개 참, 약 2초) → `Rfid_Save(렉, &none)` = 빠짐** (선 빠짐 · 리더 꺼짐). `Rfid_Init` = CAN_On ×2 → `Rfid_Check()` → 타이머. `card_on(rack)` 추가(렉 3·4 = 1). `uid_1/2` 공개.
- 없어진 것 : `seen_1/2` · `LOST_MS`(STM 2초 기다림 → **리더의 0.25초 그대로**, 사용자 결정 : 진동은 시험 보고), `card_lost`, `rfid_show` + CLI 출력(타이머 태스크가 3.6ms 막히던 것), `Rfid_Text` · `Rfid_Msg`(카드 글자는 cmd.c 가 만재 FF 처럼 그 자리에서 `snprintf`), `HAL_GetTick` → `osKernelGetTickCount`.
- `rfid_new` → **`card_event_on`** (처리 대기 변수 이름 통일 : `무엇_event_on`).
- ⚠️ 카드 있음 판단이 `data[0] != 0` (첫 칸) : 첫 칸이 00 인 4바이트 카드면 못 읽음 → 시험 때 확인, 안 되면 앞 4칸 OR.

**4. 도착 기다림 · 알람 05~07 (사용자 결정 모양)** : 모터 파일 `*_Arrive` = 기다림만 (`MOVE_MS` 넘으면 0, 긴급정지 · 알람이면 0) / alarm.c `A_05(x)` · `A_06(y)` · `A_07(deg)` = 위치 한 번 읽어 아니면 로그 + `alarm_go` / run.c 는 `IM_Arrive(x); AM_Arrive(y); A_05(x); A_06(y);` 처럼 나열. `IM_GAP 10` · `AM_GAP 10` · `TM_GAP 2` 는 모터 헤더, `MOVE_MS 10000` 은 alarm.h. PO 의 "Y 절반" 뒤엔 A_06 없음 (계속 올라가는 중이라 오알람).

**5. run.c** : MI 가 도착 안 기다리던 것(`IM_Arrive` 한 번 보기) · PO 의 `TM_C(tilt_angle)`(기울이자마자 되돌림) 고침. `PO_pause` = `Status_PAUSE(rack, 'F')` / `card_on(rack) == 0` → `'S'` / `while (pause_why) { if (pause_why != 'M' && 만재 풀림 && 카드 있음) Status_RUN(rack); osDelay(20); }` (만재 + 카드 없음 둘 다면 **둘 다 풀려야** 진행, 정지선 STOP 은 HMI RUN 까지). `PO_tilt` = 쏟는 시간을 20ms 씩 줄이며 `manjae_on` → 한 번도 안 닿으면 `'T'` → `while (pause_why) osDelay(20);`. MI 정지선 `while (pause_why) osDelay(20);`. 안 쓰는 include(`cli.h` · `net.h` · `stdio.h`) 삭제.
- ⚠️ **사용자가 오후 시험용으로 PO 안 `// PO_tilt(…)` · `// PO_pause(…)`(쏟기 확인 · 쏟은 뒤 정지선) 주석 처리** → 지금 PO 는 기울기 도착 → 바로 복귀(쏟는 시간 없음), 빌드 경고 `PO_tilt not used` 는 이것 때문.

**6. status.c = 상태판 + 상태 규칙 한 곳** (사용자 : status 를 cmd 로 옮기는 안 → 장치 파일이 cmd 에 기대게 돼서 상태판 유지로 결정) : `Status_PAUSE(rack, why)` = 알람이면 안 바꿈 + 상태 + `pause_why = why` + `pause_event_on`. `Status_RUN` · `Status_Resume` · alarm.c `alarm_go` 끝에 `pause_why = 0` → **`pause_why` 가 "일시정지 중" 표시 겸 이유** (0 = 아님). event.c STOP · cmd.c S · cli.c S 는 `Status_PAUSE(0, 'M');` 한 줄 (이제 PC S · CLI S 도 PPAUSE:M 보냄).

**7. `TOUCH_FLAG` 삭제** (event.c 만재 EXTI 줄 · event.h · cmd.h 주석).

**8. 사무실 시험에서 나온 것**
- 사무실엔 HMI 없음 → 켜고 약 3초 뒤 **알람 01** → `E_S` + ALARM → 원점 중단, MI/MO NAK(`can_not_command`), CLI 이동 막힘. 드라이브는 그 정지 상태가 RAM 에 남아 **10/12 아침 펌웨어로 바꿔도 `MOTOR INIT ERR`** → 드라이브 전원을 꺼야 풀림. → **event.c `A_01(button);` 주석 처리 (사무실 시험용, 현장에선 꼭 풀 것)**.
- 로그에 `ALARM 01` 이 안 보인 이유 : 알람은 켜고 3초에 **한 번만** 로그, 로그 창이 그때 연결 안 돼 있으면 `log_send` 가 **버림** (리셋하면 Tera Term 연결도 끊김). 알람 확인은 PC `C` 대답의 `S_1_A_01`.
- 카드 : CAN1 · CAN2 LED **계속 켜짐** = 'C' 에 ACK 없어서 하드웨어가 계속 다시 보냄 (CAN2 는 리더 없으니 정상). 리더 D3(카드 읽음)는 켜지는데 STM 엔 안 들어옴, **10/12 펌웨어도 같음 → 코드 아님**. 의심 : 리더 CAN Bus-Off(오늘 플래시 · 디버그 반복 중) → **리더 전원 껐다 켜기**, 그래도면 CAN H/L · 120Ω(전원 끄고 H–L 저항 60Ω) · 트랜시버 5V · STBY · 리더 DIP · 리더 펌웨어 125k.
- 10/15 에 `CLI_Start` 를 지워서 이제 켤 때 `MOTOR INIT OK/ERR` 가 CLI 에 안 나옴 (원점 실패를 모를 수 있음).
- ST-LINK `Target no device found` / CubeProgrammer `Voltage 0.00V` = 보드 전원 · SWD 선 문제.
- 펌웨어 직접 올리기 : `C:\ST\STM32CubeIDE_1.19.0\STM32CubeIDE\plugins\com.st.stm32cube.ide.mcu.externaltools.cubeprogrammer.win32_2.2.200.202503041107\tools\bin\STM32_Programmer_CLI.exe -c port=SWD -w 파일.elf -v -rst`.
- 백업 : `workspace_1.19.0\threeD_roder_1016_current`(오늘 코드), `Downloads\threeD_roder (1).zip`(10/8 회사 코드 + 10/11 집 수정, 안의 Debug elf 는 10/8 빌드). 10/12 저녁 · 10/8 따로 백업 없음.

**10/16 이야기만 한 것 (코드 안 바꿈)**
- **PC 알림 구조 (사용자 원하는 방향)** : `CMD_Event` 를 cmd.c 에서 빼고(cmd = 명령 확인만), `_event_on` 변수 대신 **`Log_Port` 처럼 `Event_Port("PPAUSE:F")` 를 일이 생긴 자리에서 부르기** (net.c 가 모아 Comm_Task 가 번호 붙여 보냄). 카드는 CAN 인터럽트에서 못 부르니 판단을 `Rfid_Check`(타이머 태스크)로. → 시험 뒤에.
- 일시정지 기다림을 플래그로? → 풀리는 길이 5가지(HMI RUN · PC D · 만재 풀림 · 카드 들어옴 · 알람)라 하나라도 안 울리면 영원히 잠 → **20ms 확인 유지** (사람 반응이라 20ms 무관, CPU 거의 0).
- 시간 숫자 이름 규칙 : 시간은 전부 ms, `_MS` 이름, 맨숫자 금지 (만재 2000 · 원점 60000 · alarm_event 1000 · 완료응답 1000 · `osDelay(20)` 등) → 파일 정리할 때.
- `volatile` 통일 안 됨 (`status_1` 등) → 나중에.
- 긴급정지를 변수 없이(`estop_on()` + `status_1` 을 "아까"로) → 10군데 바뀌어 alarm 정리 때.
- 로그가 노트북 연결 전엔 버려짐 → 연결될 때까지 모아 두기 (net.c 정리 때).

## 10/19 회사 · 현장에서 바뀐 것 (net.c · cmd.c · run.c 구조 정리 + 현장 시험)

**사용자 결정 (10/19)** : cmd.c = **명령이 맞나 확인 → ACK / NAK** 만. 명령 배열엔 PC 가 보낸 내용만 (STX · ETX · ACK · 번호 X). 번호는 로더가 붙임 (PC 가 번호 붙여 보내면 NAK). 이벤트 번호도 자동. 코드는 "더럽지 않게" — 쓸데없는 함수 · 한 함수 안 변수 · 배열 줄이기. 로그 문장은 나중에 파일 하나(`debug.h` 같은)에 모아 유지보수.

**1. W6100 · 라이브러리** : 받은 `io6Library-master.zip` 과 `Drivers/Ethernet` 비교 → **코드 같음** (socket.c 줄맞춤만 다름, wizchip_conf.h 는 `Application.h` include 하나 빠짐). 소켓 8개 · 보내기 16KB + 받기 16KB (지금 2KB × 8, 3개만 씀). 소켓 하나 = 연결 하나 (같은 포트에 노트북 2대 = 소켓 2개 LISTEN 필요, 지금은 안 함). 같은 망 PC 면 누구나 58080 · 50001 볼 수 있음 (명령은 2500 만).

**2. net.c (포트 하나 = 함수 하나)** : `NET_Run = tcp_port(); service_port(); log_port();`
- 서비스 58080 : `Service_TX`(PC → 로더, PC 보낸 그대로) · `Service_RX`(로더 → PC) 각 send 3번 (사용자가 한 줄 모으기보다 이 모양 원함) / `service_port` 끊기면 LISTEN.
- 로그 50001 : **`Log_Debug(text)`**(옛 `Log_Port`, 아무 태스크, 쌓기만) / `log_port`(Comm_Task : 끊기면 LISTEN + **노트북 연결 전엔 버리지 않고 모아 둠** → 연결되면 보냄).
- 2500 : `Socket0_Line`(옛 `tcp_recv`, 글자를 `rx[index]` 에 바로 받음, 변수 3개) → `send_cmd` / `send_socket`(옛 `NET_Send`) / **`send_event(text)`**(새 번호 + STX · ETX) / `Net_On_Off`(옛 `tcp_check`, 사용자 이름) / `tcp_port`.
- `NET_Init` : FI 복사 `memcpy` 3줄, 실패 0. 주석 비유(편지 · 벨 · 창구) → 실제 이름. static 함수는 쓰는 곳보다 위라 서비스 · 로그 칸이 2500 보다 먼저.
- ⚠️ 사용자가 `Log_Port` 안에 `port_doing` · `net_open` 을 넣었던 것 → 다른 태스크가 SPI 를 만지게 돼서 `log_port`(Comm_Task)로.

**3. cmd.c**
- `cmd_answer(no, A_N, text)` 하나 (옛 `ack` · `nak`) : `A_N` = ACK 받았다 / NAK 못 받았다 / 0 완료응답. C · R 대답은 글자만 만들고 `cmd_answer(no, ACK, …)`.
- `CMD_Run(int no, char *s)` : `s[0]` 부터 명령 (옛 `s + 2` → `s`). 맨 앞 ① 완료 승인 `strcmp(s, done_text) == 0` → `order_no = 0` (대답 없음) ② `s[0]` 숫자 → `NAK wrong_number`. FP · FI 항목 번호 변수 `no` → `fno`.
- MI · MO · PO 입구 : `manual || order_no != 0` (앞 명령 안 끝남) → `can_not_command`. ACK 뒤 `done_text` 를 `AI_` / `AO_` / `EO_` 세 줄로 미리.
- `CMD_I` : `home_no = no` + **초인종 전에 `Status_HOME()`** (안 하면 CMD_Event 가 아직 W 인 걸 보고 끝났다고 착각). MI 도 같은 이유로 초인종 전에 `Status_RUN`.
- `CMD_Event` : 만재 · 일시정지 · 카드 · 알람은 `send_event`. **상태판으로 끝 판단** : `order_no` 있고 `status_1 == ALARM` → 0 (완료응답 없음) / 네 렉 다 W → 1초마다 `cmd_answer(order_no, 0, done_text)` / `home_no` 있고 W → `homing done` 한 번, RESTART · ALARM → 대답 없음.
- **`CMD_Done` · `done_no` · `move_start` · `home_text` 삭제**, 안 쓰는 include 5개 삭제. `order_no` · `done_text` · `home_no` 는 Comm_Task 혼자 씀 (태스크끼리는 상태판만).
- 로그 `MI done 12s` 는 없어짐 (Tera Term 타임스탬프로 start ~ AI 사이).

**4. run.c** : `void Motor_Run(int flag)` 4줄 (`&&` : 초인종 맞으면 실행, 성공하면 대기). `motor_basic_init` 안에 원점 시작 · 끝 (원점 중 · 부저 · `HOME  start` → `HOME  X/Y/Tilt drive no answer (setting)` → 성공 W ×4 · 부저 끔 · `HOME  done` / 실패 초기상태 · `HOME  FAIL`). `I()` · `*_Home` 은 안 건드림. CLI INIT 도 같은 함수.

**5. 정한 규칙 (아직 코드 X)** : HMI 끊김 = 켤 때 · 원점 중(`RESTART` · `HOME`)이면 **A_10** + 로그 `ALARM 10  HMI no answer while homing -> home fail`, 그 외 **A_01** + `ALARM 01  HMI no answer while running`. 02~09 도 `ALARM 번호  무엇이  언제  -> 결과` 모양으로. **`A_01(button);` 은 아직 주석.**

**6. 이야기한 개념** : 태스크에 넣을 함수 고르기 = ① 무엇을 기다리나 ② 어떤 장치를 만지나 ③ 얼마나 급한가, 반복문엔 파일 대표 함수 하나. `NET_Run` · `Event_Run` = 매번 전부(목록), `Motor_Run` = 하나만 고르기(`if`) → 그래서 모양이 다름. `E_S` 는 Motor_Task 에 넣으면 MI 끝나야 멈춤 → 알람 자리에서 바로. Event_Task 함수는 "바뀐 게 있나"만 보고 끝 (µs), 장치가 먼저 알려 주는 것만 플래그로. Flash 70~80% 까지, RAM 은 태스크 스택마다 25% 여유 (`uxTaskGetStackHighWaterMark` 로 재기).

**7. 현장 시험 (10/19 오후)** — 원점 · MI · AI 완료응답 · 카드(현장 리더) **됨**. 문제 :
- 도착 직후 `05S_1_A_02&S_2_A_02` + 로그 `ALARM 02  X no answer` : `alarm_event` 1초마다 X **두 모터(ID 3 · 4)** 0x2203 읽기, `read_reg` 이미 3번 재시도(500ms) → 약 1.5초 대답 없음. **ID 4 는 평소 아무도 안 읽어서** 통신이 불안정해도 몰랐을 수 있음. → 할 것 : 1-a 로그를 모터별로 (`ID3 ok / ID4 FAIL`), 1-b "대답 없음"은 3번 연속일 때만 알람 (원인 본 뒤 결정). `uart2_err` 같이 보기.
- **원점 중 긴급정지 → X 두 축 따로 멈춰 틀어짐** : (가) `IM_Stop` 이 감속시간 ×2 → 멈춤 ID3 → ID4 순서, 실패 재시도면 ID4 가 늦음 → 감속시간을 켤 때 미리 + 멈춤만 / iCL Modbus 브로드캐스트(주소 0, 매뉴얼 확인) 로 동시에. (나) NC 하드웨어가 드라이브 전원을 끊으면 소프트웨어로 못 고침. **사용자 확인 필요 : 긴급정지 때 X 드라이브 전원(enable)이 꺼지나.**
- **사무실에서만 카드 안 됨** = 코드 아님 (같은 펌웨어 현장 됨). 사무실 CAN 종단 120Ω(전원 끄고 H–L ≈ 60Ω) · 사무실 리더(펌웨어 500k?) · 선 H/L · GND → 현장 리더 · 선을 가져와 꽂아 보기.
- **원점 끝났는데 부저 반 번 더** : 부저 HAL 아님. `IM_Home` 마지막 100mm 이동 도착 확인이 `osDelay(IM_ACC_MS)` = **1초 간격** ([i_motor.c:296]) → 최대 1초 늦게 다음 단계. 원점 코드라 **사용자 결정 필요** (20ms 로 줄일지, 주석 "너무 일찍 하면 문제").

- 빌드 : 전체 통과, 경고 0. Flash 약 96.8KB / 256KB, RAM 약 30KB / 128KB.

## 10/20 · 10/21 현장에서 바뀐 것 (로그 파일 · X 두 모터 도착 · 버스 쉬는 시간 · 알람 11 · 12 · HMI · 수동 모드)

**사용자 결정 · 방식 (10/20 ~ 21)**
- 로그 문장은 **debug.h 한 곳** (`LOG_…`), 쓰는 곳은 이름만. "어디서 찍나"는 Ctrl+Shift+G 로 찾음.
- 사용자가 "어디를 어떻게 · 왜" 설명을 듣고 직접 고치는 쪽을 원함 (급할 땐 Claude 가). 새 함수는 꼭 필요할 때만 (`IM_Here` · `Alarm_Reset` · `Lamp_Run` · `Event_PC` 안은 사용자가 "필요 없음" → 있는 함수 이용).
- 함수 짜는 법 (노션 정리) : 층 4개 = 장치(한 번) / 기다리기(끝 조건 · 포기 시간 · 그만둘 이유) / 알람(결과 보고 판단 · 덮어쓰기 방지) / 동작(나열). 코드는 "그걸 아는 곳 · 그때 돌고 있는 곳"에.

**1. 로그**
- **debug.h** (새 헤더, 사용자가 문장 작성) : 원점 · 이동(Move · Tilting · Complete · ACCPT) · 알람 01~12 · 이벤트(MANJAE · RFID · Tilting_error · PAUSE · PAUSE_PC · CHECK_PC · RFID_PC · CLEAR · ALARM_CLEAR).
- **`Log_Debug(const char *fmt, ...)`** (net.c) : printf 모양 (`vsnprintf` → 로그 칸). `__attribute__((format(printf,1,2)))` 로 `%` 개수와 값 개수가 다르면 빌드 경고. 쓰는 곳마다 `char b[]` + `snprintf` 없어짐.
- 넣은 자리 : run.c `motor_basic_init`(HOME) · `PO`(Tilting) · `PO_pause`(MANJAE · RFID · CLEAR) · `PO_tilt`(Tilting_error) · `Motor_Run`(MOVE_DONE : `name = "MI"` + `ok` 로 정리) / cmd.c MOVE · ACCPT(완료 승인) · CHECK_PC(C) · RFID_PC(R) · PAUSE_PC(S) / event.c PAUSE(HMI STOP) / status.c `Status_Resume`(CLEAR) / alarm.c 전부 + `Alarm_Clear`(ALARM_CLEAR).
- ⚠️ `LOG_CHECK_PC` 는 PC 가 1초마다 C 를 보내면 로그 칸(512)을 금방 채움 → 노트북 없을 때 알람 로그가 버려질 수 있음. 많으면 그 줄 지우기.
- 문자열 안 큰따옴표는 `\"` (사용자 debug.h `"…"R""` 가 빌드 에러였음).

**2. X 도착 = 두 모터** : `IM_Pos(int32_t *mm1, int32_t *mm2)` (ID3 · ID4 둘 다, mm). `IM_Arrive` · alarm.c `A_05` 는 **두 모터 다 ±IM_GAP** 이어야 도착. hmi.c 수동 · `IM_Home` 원점 거리는 `mm1` 만 씀 (`now2` · `far2` 안 씀).

**3. RS485 버스 쉬는 시간 (ALARM 02 X no answer 원인 추정)** : 대기 중엔 알람 없고 **이동 중에만** 남. `bus_xfer` 의 `osDelay(BUS_GAP)` 가 **뮤텍스를 돌려준 뒤**라, Motor_Task(위치 읽기) ↔ Event_Task(알람 읽기)가 번갈아 쓸 때 프레임 사이 쉬는 시간 0 → 드라이브가 못 받음. → **usart.c `UART2_Xfer` 안 `osMutexRelease` 앞 `osDelay(2)`**, 세 모터 파일 `BUS_GAP` · `osDelay(BUS_GAP)` 삭제. **현장에서 해결 확인은 아직** (`uart2_err` 로 볼 것).

**4. Y 펄스** : CLI 디버그 명령 **`YR 0509`** (a_motor.c `AM_ReadReg` 공개 + cli.c) 로 H05_09 읽어 봄 → 드라이브 값이 바뀌어 있어서 사용자가 맞춤. 주소 = H05_뒤번호를 16진수로 (H05_11 = 050B, H0B_34 = 0B22). 디버그용 → 원인 끝났으면 지울 것.

**5. 알람 11 · 12 (alarm.c)**
- **A_11 모터 통신 끊김** = 드라이브 대답 없음. `A_02/03/04` 의 대답 없음 → `return A_11(LOG_A11_X/Y/T);` (02~04 는 이제 **드라이브가 알람 코드를 보낸 경우만**). event.c `alarm_event` 는 **원점 중에도** 확인 (조건에서 HOME 뺌, 초기상태만 안 함). ⚠️ 원점 시작 때 드라이브 재설정 순간 오알람 가능 (Y 대기 50ms × 3) → 시험.
- **A_12 랜선 빠짐** : net.c `Net_On_Off` 의 "PC 연결 중 PHY OFF" 자리 → `A_12()`. **대기 포함 모든 상태** (이미 알람 · 긴급정지면 안 함). **PC 로는 안 보냄** (`alarm_event_on = 0`, 같은 Comm_Task 라 사이에 못 나감). 단 PC `C` 대답엔 `S_1_A_12` 가 보임 → PC 확인 필요.
- 램프 · 부저는 `alarm_go` 그대로 (다른 알람과 같음). **드라이브 3종 다 통신 감시 레지스터 없음** (사용자 확인) → 선이 끊기면 E_S 도 못 감, 드라이브는 받은 목표까지 가서 섬. 진짜 정지는 비상정지 버튼.
- HMI : ESP 가 0~10 만 앎 → `hmi_alarm` 이 10 넘으면 `'0'` (작업 칸 6 알람). **사무실에서 ESP 고친 뒤 11 → '5'(주행이탈), 12 → '9'(비상정지)**.
- `Alarm_Clear` (HMI RESET) = 로그 + 드라이브 알람 리셋 ×3 + `AM_EStop(0)` + 번호 지움 + `Status_INIT` + `Buzzer_Off` (event.c RESET 은 `manual = 0; Alarm_Clear();`).

**6. HMI (hmi.c)** : 만재 8칸은 **센서 그대로 바로**. 작업 칸 "3 일시정지" · 이유 "2 만재" 는 **2초 넘게 그대로일 때만** — `hmi_manjae()` = 만재 타이머 안 돌 때 + 지금 만재 (램프 R 과 같은 기준). 대기 중 만재 · 시딩월(카드 없음, 렉2 는 `rack_channel >= 2` 일 때만 = `hmi_card_out()`) → 작업 3. 운전 중 MI · MO 는 2 운전, PO 는 `PO_pause` 가 P 로. event.c **`manjae_event()` 를 `hmi_event()` 앞으로** (안 그러면 바뀐 첫 바퀴에 타이머 시작 전이라 일시정지가 한 번 깜빡).

**7. 수동 모드** : HMI 수동 버튼(33) = 대기 **또는 알람 05 · 06 · 07 · 10** 일 때 켬 (끼임 풀기, 소프트웨어 알람이라 드라이브 멀쩡). 모터 가드 3곳 `estop == 1 || (status_1 == ALARM && manual == 0)` → 수동이면 알람 중에도 움직임, **긴급정지는 계속 막음**. cmd.c `CMD_I` 에 `|| manual` (수동 중 PC 원점 NAK, 10/15 구멍 해결).

**8. 이벤트 정리** : 새 함수 안 만들기로 → `Alarm_Clear` 로 RESET 묶기, event.c `MANJAE_MS 2000` · `ALARM_CHECK_MS 1000`. `lamp_event` 는 10/8 구조대로 event.c 에 둠. PC 이벤트(`CMD_Event` 의 FF · PPAUSE · UT · S)를 cmd.c 에서 뺄지는 보류.

**현장 시험 결과 (10/20 ~ 21)**
- 원점 · MI · AI · 카드(현장 리더) 됨. 로그 `HOME start/done`, `MI … Move` 확인.
- `ALARM 02 X no answer` 가 이동 중에 계속 → 3번(쉬는 시간) 고침, 확인 전.
- 랜선 뽑기 : 대기 중이라 A_12 안 걸렸음 (그때 조건) → 대기 포함으로 바꿈, 확인 전.
- 사무실에서만 카드 안 됨 = 하드웨어 (10/19).

- 빌드 : 전체 통과, 경고 0 (`read_map` 안 씀 경고는 사용자가 `IM_MapRead` 본문을 지워서 — h 선언 남음). Flash 약 98.1KB / 256KB, RAM 약 30KB / 128KB.

## 다음 (10/22 ~)
1. **집 : 복습 + 레고 구조로 직접 수정** — 노션 「왜 이렇게 짰나」 · 「성능 설계 개념」(지금 수준 · 폴링/인터럽트/DMA/뮤텍스/틱 vs 카운트/통신 에러) · 「레고처럼 짜기」(R1~R7, event · alarm · cmd 고치는 방향 예시). 사용자가 event.c `hmi_event` · alarm.c `A_02~04` · cmd.c `CMD_Run` 을 레고 모양으로 고칠 예정 + 추가 기능. **다음 세션은 사용자가 고친 코드를 R1~R7 기준으로 리뷰부터.**
2. 현장 확인 : `ALARM 02/11` 이동 중 사라졌나 (`uart2_err`), A_12 대기 중, 원점 중 A_11 오알람, 수동 모드(알람 05 중), HMI 만재 2초 · 시딩월, PC 가 `S_1_A_11` · `C` 의 `A_12` 받는지, 로그 양(CHECK_PC).
3. ESP : 11 · 12 표시 추가 (사무실).
4. 남은 결정 : A_01 / A_10 규칙 (원점 중 HMI 끊김 = 10, `LOG_A10_REASON_1`), PC 이벤트를 cmd.c 에서 뺄지, `read_reg` 맨 아래 모터별 실패 로그(`reg_name`), `YR` · `IM_MapRead` 선언 정리, CLI `S` 로그.
5. 그 뒤 : 원점 도착 확인 1초 간격(`IM_Home` `osDelay(IM_ACC_MS)`, 부저 늦게 꺼짐), 긴급정지 X 틀어짐(`IM_Stop` 정리 · 두 위치 차이 알람), usart.c 정리, 성능 최적화(버스 `*_Time`, Comm_Task 초인종, 스택 실측), 렉 3·4.

**램프 시험 표** (PC 연결 · 대기 상태 · 카드 있음 · 만재 없음일 때) : `01LL_1_1_10`(렉1 적 켬) / `02LL_2_2_10`(렉2 녹 켬) / `03LL_1_3_20&L_2_1_20`(렉1 황 · 렉2 적 깜빡) / `04LL_1_2_15&L_2_3_15`(5초) / `05LL_1_1_2:`(10초 깜빡) / `06LL_1_1_00&L_1_2_00&L_1_3_00&L_2_1_00&L_2_2_00&L_2_3_00`(전부 끔) / `07LL_1_1_30` · `08LL_5_1_10` → NAK.

## 현재 상태 (2026-10-21 현장 끝)

- 10/20 ~ 21 : debug.h + printf 모양 `Log_Debug`, X 도착 두 모터(`IM_Pos(&mm1, &mm2)`), RS485 쉬는 시간을 뮤텍스 안으로(`UART2_Xfer` `osDelay(2)`), Y 펄스 확인(CLI `YR`), 알람 11(모터 통신) · 12(랜선), HMI 만재 바로 + 일시정지 2초, 수동 모드 알람 05~07 · 10 허용, `Alarm_Clear` = RESET 묶음. 백업 `workspace_1.19.0\threeD_roder_1021`. **`A_01` 은 현장이라 주석 풀려 있음.**

### (10/19 끝 기준)

- 10/19 : net.c 포트별 함수 · `Log_Debug` · 로그 모아 두기 · `send_event`, cmd.c `CMD_Run(no, s)` · `cmd_answer` · 완료 승인 `AI_1_1_2` · `CMD_Done` 삭제(상태판으로 완료 판단), run.c `Motor_Run` 4줄 · 원점 로그. **`A_01` 주석 그대로.** 현장 시험 : 원점 · MI · AI · 카드 됨 / X 알람 02 · 긴급정지 틀어짐 · 부저 늦게 꺼짐 남음.

### (10/16 끝 기준)

- 10/16 : fdcan.c 정리(while, 이름), main.h RTOS extern, rfid.c 사용자 구조(4줄 판단 · 선 빠짐 · `card_on` · `card_event_on`), 카드 글자 cmd.c, `*_Arrive` 기다림 + `A_05~07` 확인, run.c MI · PO 버그 · `PO_pause` · `PO_tilt` 정리, `Status_PAUSE(rack, why)` · `pause_why` = 일시정지 중, `TOUCH_FLAG` 삭제. **`A_01` 주석(사무실용), PO 안 `PO_tilt` · 쏟은 뒤 `PO_pause` 주석(사용자 시험용).** 마지막 명령줄 빌드 통과(경고 `PO_tilt` 하나), **A_01 주석 뒤엔 빌드 안 함** (빌드 목록이 옛 코드 기준 → CubeIDE Clean · Build 필요). **보드 = 10/8 빌드.** 보드 시험 : 사무실 HMI 없음 · 카드 CAN ACK 없음으로 거의 못 함.

### (10/15 끝 기준)

- 10/15 추가 완료 (보드 시험 전) : RFID 타이머 마무리, net.c 구조 정리 + 일련번호 `Roder_Number` + ACK 승인, 로그 포트 `Log_Port`, 알람 02~04 (`IM/AM/TM_Alarm`) · HMI 알람 번호, cmd.c 확인 → 초인종 / run.c `Motor_Run` / `CMD_Done`, 원점 시작 · 끝 `Motor_Run` 한 곳, `motor_basic_init` 사용자 모양, wait → `*_Arrive` + `A_05~07`.
- 전체 빌드 통과 (경고 0). Flash 약 97.4KB / 256KB, RAM 약 30KB / 128KB.

### (10/14 끝 기준)

- 완료 : UART2 DMA, 시간 제한, UART4_Xfer, event.c(긴급정지 엣지, HMI 버튼, 만재, RFID, 램프), 일시정지 B 방식(정지선), HMI 상태 표시, TCP 완료응답 · D, RFID CAN, PO 상황 처리(F/S/T/M, 10/13 부터 run.c `PO_pause` · `PO_tilt`), 큐 제거, 이벤트 일련번호(01~99), 렉 개수 설정, 1단계(Motor_Task · 스레드 플래그), usart 플래그 비교 수정, 드라이브 알람 리셋, X 감속 정지(0x6017), 문서 형식 LL 램프, 랜선 재접속, 알람 01 · 05~07 · 09 · 10 (alarm.c 에 조건 모음), 부저(buzzer.c · B 명령), 만재 함수 3개, FP 11 · 12 반영, Y 원점 오프셋(시험 전), 모터 파일 정리(static · == 0 · 멈추기 따로), **10/14 : 창구 3개(2500 · 서비스 58080 · 로그 50001) + keep-alive, W6100 INT 핀 방식 NET_Run, 서비스 [TX]/[RX] 모니터링(NET_Send), STX 등 cmd.h, 만재 2초 타이머, PO 틸트 초인종 (전부 보드 시험 전), RFID 타이머 반만**.
- 전체 빌드 통과 (경고 0). Flash 약 95.2KB / 256KB, RAM 약 28.6KB / 128KB.
- 9/28 리뷰 남음 : 버퍼 길이 검사.
- 터치패드 : JC3248W535C (ESP32-S3, 3.5" 320x480). Sensor[0] = 화면 왼쪽. ESP 작업 : 0 초기 1 대기 2 운전 3 일시정지 4 정지 5 원점 6 알람 / 일시정지 : 0 없음 1 시딩월 2 만재 3 틸트 4 사용자.
- 노션 정리 : 코텍전자 → [10/02](https://app.notion.com/p/3ed10d3ee54481fb9d0fc4639a4e600b) · [10/07](https://app.notion.com/p/3f310d3ee5448135a75ecbdb6c29e82d) · [10/08](https://app.notion.com/p/3f310d3ee54481ca8f37d67ce7a2a6f8) · [10/12](https://app.notion.com/p/3f710d3ee544810ca566db3c76c11c87) · [10/13](https://app.notion.com/p/3f810d3ee5448173a49de7589f856e21) · [10/14](https://app.notion.com/p/3f910d3ee54481c98f2acc2608b0bae1) · [10/15](https://app.notion.com/p/3fa10d3ee544811aba31c942635229b3) · [10/16](https://app.notion.com/p/3fb10d3ee54481b9b5f1e97224384cc0) · [10/19](https://app.notion.com/p/3fe10d3ee54481298c46c51af866b3e0) · [10/20~21](https://app.notion.com/p/40010d3ee544816cb558fbe63a1883f5). C 기초 다지기 보충 : [레고처럼 짜기 (10/21)](https://app.notion.com/p/40010d3ee54481ce990fe74200b34314) · [성능 설계 개념 (10/21)](https://app.notion.com/p/40010d3ee5448180a3d9c47216878ad3) · [왜 이렇게 짰나 복습 (10/21)](https://app.notion.com/p/40010d3ee54481bbb620d1bee4a8446a) · [함수 나누는 법 (10/20)](https://app.notion.com/p/3ff10d3ee54481c2b9d5f2b256d6fffd) · [(10/19)](https://app.notion.com/p/3fe10d3ee54481bbbbdcd053049dd319) · [(10/16)](https://app.notion.com/p/3fb10d3ee5448119b239cbae35b54c9a) · [RTOS os 함수 지도 (10/15)](https://app.notion.com/p/3fa10d3ee54481ab8595f1158e64364e) · [(10/15)](https://app.notion.com/p/3fa10d3ee54481598e11df8d32c5c673) · [포인터 vs 복사 (10/12)](https://app.notion.com/p/3f710d3ee544819f9c7fff9eea32148f) · [오늘 코드의 C · 펌웨어 기초 (10/13)](https://app.notion.com/p/3f810d3ee5448105a06ae510ec22a0f9) · [(10/14)](https://app.notion.com/p/3f910d3ee54481a4b097cc872f9151f0).

## 일정 (마감 2026-10-14, 10/5·10/6(예비군)·10/9 휴무, 매일 19시까지)

- 9/28 HMI / 9/29 Event + HMI 버튼 / 9/30 일시정지 S / 10/1 이벤트 → TCP 프로토콜 + ACK
- 10/2 RFID (CAN) / 10/7 효율화 / 10/8 센서 EXTI / 10/12 통합 테스트 / 10/13 유지보수 정리 / 10/14 네트워크 추가 (사용자 : 마감은 하루 넘겨도 됨)

## 공부 자료 (10/12 추천, 실제로 있는 것)

- **Digi-Key "Introduction to RTOS"** (YouTube, Shawn Hymel, 12편, 영어) : 태스크 · 우선순위 · 큐 · 뮤텍스 · 세마포어를 FreeRTOS 로. **먼저 1~4편**(태스크 · 스케줄링 · 메모리 · 큐) → "for 문이면 폴링?", "플래그 wait / set" 이해.
- **Mastering the FreeRTOS Real Time Kernel** (freertos.org 무료 PDF) : FreeRTOS 공식 교과서. 블록 · 우선순위 · 태스크 알림의 정확한 뜻 찾아보기용.
- **Quantum Leaps "Modern Embedded Systems Programming"** (YouTube, Miro Samek) : 임베디드 C 를 바닥부터 (포인터, volatile, 인터럽트, RTOS).
- **코딩도장 C언어** (dojang.io, 한국어) : 포인터 · 문자열 · static 복습.
- **혼자 공부하는 C언어** (서현우, 한빛미디어, 지금 교재) : 포인터 · 배열 · 문자열 장.

## 참고

- 데이터시트 · 프로토콜 : https://github.com/ParkSeong0425/3D (`2차소터 프로토콜_V1.3_260916.pdf`, `3DS_motor_DataSheet/` iCL-RS · AIMmotor · TL57-R). iCL-RS 중요 쪽 : 49쪽 0x1003 · 0x1801 · 0x2203 · Pr8.02, 50쪽 Pr8.15~8.29(0x6017 = quick stop 감속 ms), 51쪽 Pr9.00(TYPE 1 위치 2 속도 3 원점, Bit4 INS).
- GitHub: https://github.com/ParkSeong0425/ThreeD_roder
- 노션: 코텍전자 → [09/27](https://app.notion.com/p/3e710d3ee544816aadc3d257fcc232da), [09/27 (2) 개념 정리 · 이해도 테스트](https://app.notion.com/p/3e810d3ee544810186fbec938c853ed1)
- CLI: Tera Term, STLINK-V3 VCP (집 PC COM6), 115200. Windows 11 25H2는 wmic가 없어 CubeIDE 시리얼 콘솔이 안 됨.
- 명령: CLI `X/Y pulse percent`, `C percent`, `R/L deg percent`, `S`, `I`, `INIT`, `IP`, `FRAM`. TCP `STX 01MI_... ETX` 형식.
- 전체 빌드 (명령줄) : CubeIDE 의 make.exe + arm-none-eabi-gcc 폴더를 PATH 에 넣고 `Debug` 폴더에서 `make -j8 all`.
- 문법 검사: `arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfpu=fpv4-sp-d16 -mfloat-abi=hard -std=gnu11 -DUSE_HAL_DRIVER -DSTM32G473xx -fsyntax-only -Wall` + 모든 헤더 폴더 `-I`.
