# threeD_roder (3D 로더) 펌웨어 — Claude 작업 안내서

STM32G473VCT6 (170MHz) + FreeRTOS(CMSIS-RTOS2) + STM32CubeIDE 1.19 프로젝트.
3축 로봇(X / Y / TILT)을 RS485 Modbus RTU 드라이브로 제어하고, PC와 TCP(W6100)로 통신한다.
사용자는 펌웨어를 배우는 중이다. 설명은 **한국어, 쉬운 비유, 그림(다이어그램) 포함**으로 한다.

## 작업 방식 (반드시 지킬 것)

1. **바꾸기 전에 계획부터**: "어느 파일 → 어느 함수 → 무엇을" 표 + 개념 + 왜 그렇게 하는지 + 그림.
2. 사용자가 **"그렇게 하자"** 라고 하면 그 단계 전체를 한 번에 적용한다.
3. 적용 후 **파일별로 바뀐 줄**을 보여준다. 가능하면 ARM GCC로 문법 검사.
4. 하루 작업이 끝나면 **노션 "코텍전자" 페이지 맨 아래**에 날짜 페이지로 정리한다 (질문·해결·개념·변경·다음 할 일).
5. **코드 구조는 사용자가 먼저 짠다.** Claude는 추천과 설명, 그리고 수정.
6. GitHub `main`에는 사용자 허락 없이 올리지 않는다. 리뷰·제안은 별도 브랜치나 REVIEW 문서로.
7. **사용자가 직접 다시 짠 코드를 리뷰하는 방식**(10/2부터): 사용자가 짠 코드를 읽고 → 맞는지 / 왜 안 되는지 설명 → 고칠 때도 **사용자 스타일 그대로**. 문제가 생길 때마다 변수·플래그·함수를 덧붙이지 말고, 사용자가 만든 함수 안에서 해결한다.
8. 판단 기준은 **CPU 효율과 메모리(RAM, 스택, 버스 점유) 효율**. 리뷰할 때 "이 코드가 CPU를 얼마나 쓰는지, 버스를 얼마나 잡는지, 메모리를 얼마나 쓰는지"를 같이 설명한다.
9. **하루 작업이 끝나면 Claude가 이 CLAUDE.md를 업데이트한다**: "현재 상태", "그날 바뀐 것", "남은 일"을 그날 기준으로 고치고, 바뀐 부분을 사용자에게 보여준다. (집 ↔ 회사는 zip으로 옮기므로, 이 파일이 다음 세션의 유일한 기억이다.) 사용자가 "끝", "마무리", "오늘은 여기까지" 같은 말을 하면 반드시 먼저 한다.
10. **코드는 사용자가 "수정하자 / 바꾸자" 라고 할 때만 바꾼다** (10/11). 그 전에는 읽고 설명·리뷰만. 새 상수·함수·변수 제안(예: `X_TWIST`)도 사용자가 원할 때만. 정리를 부탁받으면 **지금 상태만** 적고 "앞으로 할 것"은 적지 않는다.
11. **하루 흐름** (10/11 사용자 결정) : **09:00 전 = 공부** — 노션 「임베디드 데일리 브리핑」·「C 기초 다지기」(클라우드 루틴이 평일 07:30 자동 생성) 링크를 알려 주고, 물으면 자세히 설명 · 문제 채점 (`~/.claude/CLAUDE.md` 규칙). **09:00 부터 = 프로젝트** — 사용자 질문에 맞춰 이 프로젝트를 진행. 그날 코드에 나오는 어려운 용어(예: 버스, 뮤텍스, DMA, 인터럽트, 폴링)는 나올 때 쉬운 비유 + 그림으로 설명하고, 교재 「혼자 공부하는 C언어」(서현우, 한빛미디어)의 해당 장도 같이 짚는다.
    - 사용자가 부탁한 설명 : **fdcan.c, rfid.c 를 어떻게 만들었는지** (10/11 요청).
12. **(10/29) "그래 바꿔줘" 같은 분명한 허락 전에는 코드를 절대 안 바꾼다.** 함수 하나 · 작은 단위 하나씩. 답은 ① 지금 역할 ② 문제 ③ 이유 ④ 바꿀 곳 (전 / 후, 필요한 부분만) ⑤ 직접 확인할 것 ⑥ 다음 하나. 사용자가 CubeIDE 에서 직접 치며 배우는 방식이 기본 (급하거나 "해줘" 하면 Claude 가). 새 함수 · 변수 · 구조체 · 플래그는 "왜 꼭 필요한지, 있는 것으로 안 되는지" 먼저. 안전(긴급정지 · 알람 · 통신 오류)은 단순화한다고 빼지 않음. 사용자가 정리한 설계 문서(10/29, GPT 와 쓴 것)를 무시하지 말 것 — 예 : `Order_Set` 은 없애기로 함, `Save_XY` 는 이미 없음.

## 코드 스타일 (사용자 스타일 유지)

- `run.c`의 `I()` 수준으로 **짧고 쉽게**, 단계마다 한글 한 줄 주석.
- `if (!Func())` 금지 → `if (Func() == 0)` 처럼 쓴다. `== 1` 은 안 씀 → `if (Func())` (10/13).
- 성공 1 / 실패 0 반환, 실패는 `return 0`으로 위로 전달.
- **새 파일 · 새 함수 · 새 상수는 꼭 필요할 때만**, 반드시 계획에서 승인받고. 구조를 크게 바꾸지 않는다 (예전에 bus.c 분리했다가 되돌림).
- **모든 while 기다림에는 시간 제한** (`osKernelGetTickCount()` 시작 시각 비교). 예외 : 일시정지(PAUSE) 대기.
- `save.c`, `cmd.c`의 풀어서 쓴 구조(left_x1 ~ left_x9 등)는 **일부러 그런 것** → 배열로 바꾸자고 하지 않는다.
- CubeMX 생성 파일은 **USER CODE BEGIN ~ END 안에만** 쓴다. 설정은 ioc에서.
- 파일은 CRLF 줄바꿈. sed로 수정하면 LF로 바뀌니 주의.
- 디버그 출력은 원인 찾으면 지운다.

## 구조 (10/8 사용자 그림 기준)

**사용자가 원하는 구조** (10/8 손그림):
- 모터 파일(i/a/t_motor) = **레지스터로 움직이는 기본 함수** → run.c 가 그걸 모아 **로더 동작 함수**(I, MI, MO, PO, E_S)를 만든다.
- rfid · lamp · alarm · 만재(manjae) · status · hmi = **켜기/끄기·읽기만 하는 기본 함수** → event.c 가 그걸 써서 **"이런 상황이 생기면 이렇게"** 함수를 만든다.
- 상황 처리는 **event.c 안에서** (run.c PO 는 순수 동작 그대로 두고, event.c `PO_event` 가 PO 줄을 나눠 단계 사이에 상황 처리).
- RTOS 는 유지 (이유: `I()` 처럼 위에서 아래로 쓰려면 기다리는 동안 다른 태스크가 돌아야 함. 없으면 step 상태기계가 됨).

**사용자가 원하는 모양 = 레고 (10/21 확정, 코드 리뷰 · 수정의 기준)** — 함수 안에 다른 파일의 함수(블록)가 레고처럼 붙어 있는 모양. 좋은 예 : `I()` · `MI` · `Rfid_Init` · `NET_Run`. 노션 「레고처럼 짜기」 참고.
- R1 블록 = 한 가지 일 (한 줄로 말할 수 있음), 성공 1 / 실패 0.
- R2 조립 함수 = 블록 나열 + 최소 if (레지스터 · 긴 계산 없음).
- R3 판단(조건 · 숫자)은 **그 데이터를 가진 파일의 블록 안** (알람 조건 alarm.c, 상태 규칙 status.c). 조립하는 쪽은 부르기만.
- R4 아래 층(장치 · 모터 파일)은 위 층(run · event · alarm)을 모름. 지금 예외 : `IM_Home`/`AM_Home` → `A_10`, 모터 가드의 `estop` · `manual` (알고 남겨 둔 것).
- R5 switch 의 case 는 블록 한 줄.
- R6 장치 지식(레지스터 · 알람 코드 이름표)은 장치 파일 (예 : `A_02` 의 iCL 코드 이름표 → i_motor.c 로 옮길 후보).
- R7 태스크 사이는 상태판 · 표시 변수만 (보내기는 주인 태스크).
- 새 함수보다 **있는 함수(블록) 안으로 옮기기**가 먼저. 함수 개수 늘리는 것 싫어함.
- 지금 상태 : 레고 ✅ run · rfid · lamp · net · manjae · 모터 파일 / 덜 레고 ⚠️ event.c `hmi_event`(case 안 판단), alarm.c `A_02~04`(이름표), cmd.c `CMD_Run`(case 안 읽기 · 범위 · 실행) · `CMD_Event`(이벤트). → **사용자가 집에서 직접 고칠 예정** (10/21).
- 성능 목표(사용자) : 통신 대기 줄이기 · CPU · RAM 아끼기. 순서 = 안전(긴급정지 반응) > 버스(RS485) > CPU > RAM. 폴링은 "장치가 먼저 안 알려 주는 것"만. 노션 「성능 설계 개념」 참고.
- UART2 뮤텍스 `Uart2LockHandle` 은 **ioc(CubeMX) `Uart2Lock`** (10/22 사용자가 옮김). UART2 를 Motor · Event · Comm(CLI) 세 태스크가 써서 필요. 열쇠는 `UART2_Xfer` · `UART2_Send`(브로드캐스트) 안에서만.

```
태스크 층   app_freertos.c : Event_Task(High) / Motor_Task(AboveNormal, 10/15 : 초인종 4개 기다렸다가 CMD_Done(flag, Motor_Run(flag))) / Comm_Task(Normal)
명령 층     cmd.c (TCP 명령 확인 → NAK / ACK + 초인종 · 완료응답 CMD_Done) · cli.c (UART1 CLI) · hmi.c (UART4 터치패드)
이벤트      event.c : 100ms 순회 (긴급정지, HMI 버튼, 만재, 드라이브 알람 02~04, 램프) — PO 상황은 run.c PO_pause · PO_tilt, 카드는 Rfid_Timer
동작 층     run.c : I / MI / MO / PO / E_S / motor_basic_init / motor_basic_run(CLI 시험) / Motor_Run(초인종 → 함수 하나, 원점 시작 · 끝 전부)
장치 층     i_motor.c (X, ID3) · a_motor.c (Y, ID1) · t_motor.c (TILT, ID2) · fram.c · net.c · save.c · rfid.c · lamp.c · manjae.c · status.c · alarm.c(조건 + 걸기) · buzzer.c(10/13)
통신 부품   usart.c USER CODE : UART2_Xfer (모터, DMA + 인터럽트 + 뮤텍스) · UART4_Xfer (HMI, 인터럽트)
```

- 명령 경로 (10/19) : W6100 소켓 0 → `net.c Socket0_Line`(STX~ETX 사이 내용만, ETX 순간 `last`) → `send_cmd`(서비스 `[TX]` + `CMD_Run(Roder_Number(), s)` : **번호는 따로, 명령 배열엔 PC 내용만**) → `cmd.c CMD_Run`(Comm_Task) 확인 → `cmd_answer(no, NAK, …)` / `cmd_answer(no, ACK, s)` + 주문서 `order_*` + `order_no` + 완료응답 글자 `done_text`(AI_렉_열_단) 미리 + `Status_RUN` + 초인종 → 바로 돌아감. **Motor_Task** 는 `Motor_Run(flag)` 한 줄 (run.c : `(flag & MI_FLAG) && MI(…)` 이면 `Status_WAIT(order_rack)`, 원점은 `motor_basic_init`). **`CMD_Done` 없음** → `CMD_Event` 가 **상태판(R → W)** 을 보고 1초마다 `08AI_1_1_2`, PC 가 `AI_1_1_2`(번호 · ACK 없이) 돌려주면 `order_no = 0` (대답 없음).
- RTOS 도구: 시간(`osDelay`, `osKernelGetTickCount`) / 플래그 / 뮤텍스(usart.c 안에만) / **소프트웨어 타이머(10/14, ioc : `Manjae_Timer` Once · `Rfid_Timer` Periodic, 콜백은 app_freertos.c USER CODE)**. **큐는 10/8 ioc 에서 삭제**. `osTimerStart` 는 인터럽트 안에서 못 부름 (태스크에서만).
- **스레드 플래그 번호표 = `Core/Inc/flag.h` 한 곳 (10/29)** : `0x01 XFER_DONE`(usart.c 안, UART2·UART4 응답 → 통신한 태스크) / `0x02 ESTOP_FLAG` · `0x04 FULL_FLAG`(EXTI → Event_Task) / **`0x20 MOVE_FLAG`**(run.c `Motor_Request` 만 울림 → Motor_Task, 무슨 일인지는 주문서 `job.cmd`) / `0x10 NET_FLAG`(W6100 INT EXTI → Comm_Task). 0x08 · 0x40 · 0x80 비어 있음 (옛 MOTOR · MO · PO). 새 초인종은 **0x100 부터** 안 겹치게 (플래그 = 2진수 칸 하나, 31칸까지). 10/12 에 MOTOR_FLAG 를 0x01 로 했다가 XFER_DONE 과 겹쳐 UART2 가 죽었음.
- **공유 변수 규칙 (10/16)** : 변수는 주인 파일의 `.h` 에 `extern` 한 번, 쓰는 파일은 `#include` 만. app_freertos.c 의 RTOS 것들(`Event_TaskHandle`, `Motor_TaskHandle`, `Manjae_TimerHandle`, `Rfid_TimerHandle`, `Uart2LockHandle`)은 짝 헤더가 없어 **main.h USER CODE(ET)** 에 extern (`cmsis_os2.h` include). `.c` 안에 extern 직접 쓰지 않음.
- **변수 두 종류 (10/16 사용자와 정리)** : ① 상태 (`estop`, `card_ok_1`, `tcp_on`, `pause_why`…) = 그 상황인 동안 유지 ② 처리 대기 (`무엇_event_on`) = 생긴 순간 1, cmd.c `CMD_Event` 가 PC 로 보내며 바로 0 (보내기 **전에** 0). 장치에서 바로 읽을 수 있으면 변수 대신 함수(`manjae_on`, `card_on`, `IM_Pos`).
- **W6100(send/recv)은 Comm_Task 에서만** 부른다 (SPI 를 두 태스크가 같이 쓰면 명령이 섞임). 다른 태스크는 표시(`*_event_on`, 상태판)나 `Log_Debug`(쌓기만)만. PC 로 나가는 길은 net.c `send_socket`(2500 + 서비스 `[RX]`) 하나 — cmd.c 대답은 `cmd_answer`, 이벤트는 net.c `send_event`(새 번호 자동).
- 인터럽트 우선순위: FreeRTOS 함수를 부르면 5 이상 ("Uses FreeRTOS functions"). DMA 5, EXTI1 5(W6100 INT, 10/14), EXTI15_10 5, FDCAN 5, USART2 6, USART1 7, UART4 7.
- 시계: FreeRTOS tick(SysTick, 1ms) / HAL tick(**TIM6 — 지우면 안 됨**) / DWT(µs 측정 전용, `dwt.h`, `uart2_us`).
- 대기 규칙: 이동 **5초**(`MOVE_MS`, alarm.h, 10/22), 위치 묻는 사이 20ms 쉼(`ARRIVE_MS`, 10/23), 원점 60초 제한. 10/16 부터 **기다림은 모터 파일 `IM_Arrive(x)` · `AM_Arrive(y)` · `TM_Arrive(deg)`**(최대 10초, 알람 안 검, osDelay 없이 위치 반복 읽기), **알람은 run.c 가 그 뒤 `A_05(x)` · `A_06(y)` · `A_07(deg)`**(한 번 확인 → 없으면 알람). 버스는 이동 중 거의 늘 바쁨 → 보드 시험 후 "걸릴 시간 계산해서 자기" 정할 것.
- 폴링이 맞는 것: FRAM, EEPROM (짧고 드묾).

## 10/2 회사에서 바뀐 것 (Claude 가 수정, 사용자가 집에서 다시 읽고 정리할 예정)

- Y 배율 원인: Y 드라이브 H05_09 = 320 (1회전 320펄스) → `Y_PULSE 320`, `Y_GEAR 5`, `Y_PI 160`. X 는 `X_PI 100`. 원점 후 이동 Y `AM_Move(150, 50)`, X `IM_Move(100, 30)` (사용자 값).
- 상태(status)는 W 대기 / R 운전 / I 원점 / P 일시정지 / A 알람 / N 초기상태(10/7 부터 `RESTART`)만. 만재·카드는 상태가 아니라 `full_1/2`, `card_ok_1/2` 변수로만 본다.
- **렉1 = 오른쪽 렉, 렉2 = 왼쪽 렉** (cmd.c PO 에서 rack 1 → right_x/right_y). 만재 핀 FULL_1_x · 경광등 _1 핀 · FDCAN1 = 렉1 (핀 이름 그대로 맞음). HMI 화면은 왼쪽 칸 = Sensor[0] 이라 `hmi.c` 에서 왼쪽 칸에 렉2, 오른쪽 칸에 렉1 을 넣는다. 같은 렉 안 R/Y 만 배선이 반대라 `lamp_rfid`/`lamp_manjae` 에서 바꿔 씀.
- 긴급정지: 인터럽트는 깨우기만, `estop_event` 가 핀을 직접 읽음. 모든 대기(`wait_xy`, `wait_tilt`, 원점, CLI 이동)에 `if (estop == 1) return 0;`. 흐름: 긴급정지 → 알람 → 리셋(처음 상태 INITIAL) → 시작(원점).
- HMI: ESP32 프로토콜(`STX '1' 'C' 작업 일시정지 알람 센서20 ETX`)에 맞춰 `hmi.c` 가 상태를 채워 보냄. 수동 버튼은 설정→수동(33)으로 수동 모드일 때만.
- PO: 틸트 전·복귀 전에 **그 단** 만재(`floor_full(rack, y_no)`) / **그 렉** 카드 없음이면 `PPAUSE:F` / `PPAUSE:S` 한 번 보내고 대기, 풀리면 자동 진행. 같은 렉이라도 다른 단은 진행. MI/MO 는 그대로 이동. `PO(rack, x, y, y_no, …)` 로 단 번호를 받음.
- TCP: 완료응답 AI/AO/EO 를 PC 승인(`번호-AI_…`)까지 1초마다, 승인 전 MI/MO/PO 는 NAK. 원점 완료 `번호<ACK>homing done` 한 번. 램프 명령 `LL_번호_색_모드_시간`(번호 홀수 렉1 / 짝수 렉2, 색 1 적 2 녹 3 황). PC 연결 중 램프는 PC 가, 안 연결이면 STM 이.
- RFID: 0.5초마다 리더에 'C' 질문, 2초 동안 못 읽으면 카드 없음. 리더 ID = 200 + DIP (두 렉 다 201, CAN 선이 따로라 같아도 됨).
- 램프: 타이머 안 씀. `blink()` 가 시간으로 켬/끔 → 렉1·2 같은 박자. 긴급정지·알람 빠르게, 원점·일시정지 느리게.
- 넷: 마지막 명령 후 20초 조용하면 끊김 (전에는 접속 후 20초에 무조건 끊김).
- 가감속(사용자 값): X `IM_ACC/DEC_MS 900`, Y `AM_ACC_DEC_MS 100`, TILT `TM_ACC/DEC_MS 200`.
- X 토크 원점(사용자 값): `IM_HOME_HI_RPM 180`, `IM_HOME_LO_RPM 80`, `IM_HOME_ACC/DEC_MS 1000`, `IM_HOME_TIME_MS 20`, `IM_HOME_FORCE 35`. 목표 = "쾅 부딪히지 않고 살짝 닿으면 원점". 원칙: **토크(FORCE)만 낮추면 마찰·가속 토크에 오인식**(X 는 모터 2대라 한쪽만 먼저 잡히면 비틀림) → 먼저 **속도를 낮추고**, 판단 시간(TIME)은 너무 짧으면 순간 튀는 토크에 오인식. 지금 TIME 20ms 는 짧은 편이라 테스트로 확인 필요.

## 10/7 회사에서 바뀐 것 (event · hmi · run · status 정리, 일시정지 T/F/S/M)

- **안 쓰는 함수 삭제**: `AM_Speed/AM_Torque/AM_Read`, `IM_AlarmRead/IM_DIPRead/IM_Read`, `TM_Read`, `Home_lamp/Alarm_lamp`, `NET_Link`, run.c `Motor_Check`·`CHECK_COUNT`, event.h `Alarm_Set/Clear` 선언(본문은 event.c 에 주석으로 남김). 헤더도 같이 지움.
- **상태 이름**: 초기상태 = `RESTART`(사용자가 INITIAL → RESTART 로 바꿈, CRC 레지스터 이름과 겹쳐서). 전원 켜지면 `status_1/2 = RESTART`. `Status_INIT()` 이 RESTART 로 만듦.
- **S() 를 status.c 로**: S 는 "멈춰라 표시"만 (`Status_PAUSE` 두 렉 + `pause_why='M'` + PC 알림). 모터를 바로 세우지 않음. MI/MO 는 도착 후, PO 는 쏟기 전·복귀 전에 멈춤.
- **hmi.c**: 보낼 27바이트 틀 `tx` 를 static 으로 미리 채우고 바뀌는 11칸만 씀. 버튼 = `rx[2] - '0'`. `hmi_pause` 가 `pause_why` 대로 1 시딩월 / 2 만재 / 3 틸트 / 4 사용자.
- **event.c hmi_event**: 수동 버튼(21~26)은 `manual == 1` 일 때만. RUN = 초기상태면 `Status_HOME`(→ Motor_Task 가 원점), 일시정지 M·T 면 풀기. STOP → `S()`. RESET → 알람 리셋 + 초기상태. 설정→수동(33) 토글.
- **긴급정지 EXTI 콜백**: 주석 처리돼 있어서 긴급정지가 이동 끝난 뒤에야 먹던 것 → 사용자가 주석 풂 (테스트 필요).
- **manjae.c**: `floor_full(rack, dan)` 공개(manjae.h). `Full_Read` 는 `GPIOE->IDR & 0x7F80` 으로 만재 8칸 한 번에 읽고 바뀔 때만 나눔.
- **PO 일시정지 (T/F/S/M)**: run.c PO = 이동 → `PO_event(rack, y_no, 1)` → Y 올리며 틸트 → `touch = PO_pour(…)` → `PO_event(rack, y_no, touch)` → 복귀. `PO_pour`/`PO_event` 는 event.c 에 있지만 **Motor_Task 가 실행**.

  | 이유 | 언제 | 풀기 | HMI |
  |---|---|---|---|
  | T 틸트 | 쏟는 동안 그 단 센서에 한 번도 안 닿음 | HMI RUN | 3 |
  | F 만재 | 그 단 만재 | 센서 풀리면 자동 / PC `01D` | 2 |
  | S 시딩월 | 그 렉 카드 없음 | 카드 들어오면 자동 | 1 |
  | M 사용자 | STOP 버튼 / S 명령 | HMI RUN | 4 |
- **cmd.c**: `CMD_D ('D' << 8)` 추가 — 만재(F)로 멈춘 것만 억지로 풀기.
- 이름 정리: `full_new/pause_new` → `full_event_on/pause_event_on`.
- 미룸: TM `GO_ABS 0x03 → 0x07`(움직이는 중 새 목표 받기, 틸트 즉시 멈춤·재개용) — 사용자가 직접 고쳐 볼 예정. TCP W6100 인터럽트 · CAN 은 다음 주.

### 10/7 결론 : 구조가 마음에 안 듦 → 집에서 "왜 이렇게 짰나" 공부부터

사용자 생각: **10/2 코드는 Claude 가 거의 다 짠 것**이라 내 코드가 아니다. 앞으로는 **내가 구조를 짜고 싶고, 어떻게 짜야 하는지 알면서** 하고 싶다.
특히 고쳐야 할 것 같은 곳: **status.c, run.c (Motor_Run), cmd.c**.

- Motor_Run 이 지저분한 이유(10/7 에 본 것): 켜질 때 원점 / HMI RUN 원점 / 큐 명령 3가지 일을 한 함수에서 함. 원점 길이 3개(켜질 때·HMI = `motor_basic_init`, PC·CLI 의 I = `I()` 만)로 다름. 시작·끝 상태를 `cmd.command == CMD_…` 로 명령마다 따로 정함 (MI→W, MO→R 유지, PO→W).
- Claude 가 낸 안 2개는 **사용자가 거절**: ① `home_run`/`cmd_run` 새 함수 ("I 함수가 있는데 왜 또 함수를"), ② `cmd.command ==` 줄을 옮기는 안 ("커멘드들이 보기 싫다"). → 다음엔 사용자가 구조를 먼저 짜고 Claude 는 설명·리뷰만.
- 상태(status)를 바꾸는 곳이 흩어져 있음: run.c(Motor_Run), event.c(hmi_event, PO_event, estop_event), status.c(S), cmd.c(D). status.c 를 어떻게 할지 사용자가 정할 것.

**집에서 할 수업 (다음 세션 첫 일)**: 파일마다, **함수마다** 아래를 자세히 설명.
1. 이 함수가 하는 일 (한 줄) + 누가 부르나 / 어느 태스크가 실행하나
2. **왜 이렇게 짰나** (다른 방법과 비교, 장단점)
3. 그림 (호출 흐름, 시간 흐름, 메모리 · 버스)
4. 나오는 **C 개념** (static, volatile, extern, 구조체 값 전달, 포인터, `'0'` 빼기, 비트 마스크 `& 0x7F80`, `<< 8` 등)
5. 나오는 **펌웨어 개념** (태스크 · 우선순위, 큐, 스레드 플래그, 뮤텍스, DMA, IDLE 인터럽트, EXTI, Modbus RTU, 폴링 vs 인터럽트, 시간 제한)
6. CPU / 버스 / RAM 을 얼마나 쓰나

순서 추천: status → run → event → cmd → hmi → net → 모터(i/a/t_motor) → manjae · rfid · lamp → usart.c USER CODE (UART2_Xfer, UART4_Xfer).

## 10/8 회사에서 바뀐 것 (구조 다시 잡기 + 보드 테스트)

**방향** : 사용자 손그림 구조(위 "구조")로. 사용자가 run.c 를 직접 다시 씀 → Claude 는 사용자 함수에 맞춰 나머지 수정.

- **큐 · 구조체 삭제** : ioc 에서 MotorQueue 삭제. `MotorCommand`, `job/job_on`, `Motor_Run` 없음. Motor_Task 는 `osThreadExit();` (ioc 에선 지우지 말 것 — 1단계에서 다시 씀).
- **cmd.c 가 동작을 직접 부름** : MI/MO/PO/I 는 `ack(s)` → `Status_RUN(rack)` → `CMD_Done(s, MI(x, y, …))`. PO 는 `CMD_Done(s, PO_event(…))`. I 는 `Status_HOME(); CMD_Done(s, motor_basic_init());`. 좌표는 지역 변수 `x`, `y`.
- **`CMD_Done(char *s, int ok)`** : 받은 글자 s 에서 번호 · 렉 · 열(yeol) · 단(dan) 꺼내 `AI/AO/EO`, I 는 `homing done` + 대기 / 실패 초기상태. ok 0 이면 완료 아님(상태 그대로).
- **입구 확인** (MI/MO/PO) : `status_1 != WAIT || status_2 != WAIT || manual == 1 || done_text[0] != 0` → NAK `can_not_command`.
- **cli.c** : 모터 함수 직접. `motor_basic_run(command, pulse, deg, rpm)` (사용자 수정, 명령만 보내고 도착 안 기다림, 진짜 결과 반환).
- **Comm_Task** : `Save_Init → NET_Init → Status_HOME` 후 반복에서 `status_1 == HOME` 이면 `motor_basic_init()` (켤 때 · HMI RUN 원점). **원점 끝나야 TCP 시작** (1단계에서 Motor_Task 로 옮김).
- **run.c (사용자)** : MI/MO/PO 오류 `if` 없앰 (오류는 알람으로 할 예정). `I()` = `TM_Home() && IM_Home() && AM_Home()`. **`E_S()`** 긴급정지 = TM_Estop · IM_Stop · AM_EStop(1) 을 **따로 다 보내고** 결과만 합침 (멈추기는 `&&` 금지, 움직이기는 `&&`). `S` 삭제. `wait_xy/wait_tilt` static 해제(event.c 가 씀). run.c PO 는 순수 동작 그대로(지금 안 씀).
- **일시정지 = B 방식(신호등)** : STOP(HMI) · `S_1`(PC) · `S`(CLI) → `Status_PAUSE(1/2)` + `pause_why='M'` 표시만. MI 끝 · PO 쏟은 뒤 "정지선"에서 기다림 → HMI RUN 으로 진행. status.c 의 `S()` 삭제.
- **event.c `PO_event`** (PC PO 명령용) : run.c PO 줄을 가져와 단계 사이에 상황 처리. 이동 → `PO_arrive`(그 단 만재 F / 카드 S / 일시정지 → 풀릴 때까지) → 틸트 → `PO_pour`(쏟는 동안 센서 스쳤나) → `PO_poured`(안 스쳤으면 T, **RUN → 복귀 → EO 완료**) → 복귀. 세 도우미는 static. **MI/MO 는 만재 · 카드 상관없음 (확정)**.
- **긴급정지** : `estop_event` 누름 / 풀림 **엣지만** (폴링 반복 안 함). 누름 = `Status_Alarm(); E_S();`, 풀림 = `AM_EStop(0); Status_Alarm();` (눌린 사이 대기로 바뀌었어도 다시 알람). **NC 배선이 하드웨어로 모터를 끊음** (사용자 확인). RESET 에 `IM_MapInit(); AM_Init(); TM_Init();` 추가 (긴급정지로 드라이브 전원이 끊겼으면 설정 다시) → 시험 필요.
- **net.c** : `net_timeout` 을 켤 때 복사 → FI 1·2·3·5·6·7 · FD 전부 **재부팅 후 적용** (FI 4 목적지 IP 는 클라이언트 모드용, 안 씀. DNS 아님). 랜선 뽑히면 `wizphy_getphylink() == PHY_LINK_OFF` → `close()` (disconnect 는 PC 대답 기다려서 멈춤). `tcp_on` 중복 삭제. 20초 규칙 = 연결 후 / 마지막 명령 후 20초 명령 없으면 끊기 (이미 그렇게 됨).
- **cmd.c 이벤트 번호 삭제** : `event_number` 없음, 이벤트는 `STX + 내용 + ETX` (번호 없음).
- 빌드 : 전체 빌드 통과. Flash 약 90KB / 256KB, RAM 약 28.5KB / 128KB (힙 20KB 고정).

**프로토콜 정리 (사용자 문서가 전부, 예시 로그 사진은 무시)**
- 일련번호 : PC 가 01 → 99 → 01. 로봇은 **받은 번호 그대로** ACK / NAK / 완료응답(AI·AO·EO·homing done) — `s[0] s[1]` 복사로 자동.
- PC 완료 승인 : `번호-AI_…` (코드는 `s[2] == '-'`).
- 이벤트(만재 FF · 일시정지 PPAUSE · 카드 U · 알람 S) : 번호 없음.
- TCP 는 글자 흐름이라 두 메시지가 한 줄에 붙어 보일 수 있음 → STX~ETX 로 나누면 정상.

**10/8 보드 테스트에서 나온 문제**
1. `FF… PPAUSE:F 03EO` 가 **동작 끝난 뒤 한꺼번에** 나옴 → Comm_Task 가 PO 를 실행하느라 CMD_Event 를 못 돎. 원하는 것 = 도착 → 바로 PPAUSE:F/S → 해제 → 진행 → EO / 쏟은 뒤 안 스치면 바로 PPAUSE:T. → **남은 일 1단계**.
2. 틸팅 에러 해제 = 일시정지와 같음 (RUN → 복귀 → 명령 완료). 작업자 확인 후 처리. → 이미 구현, 1단계 후 시험.
3. 긴급정지(도착 후) → 풀기 → RESET → HMI "초기상태/없음" → RUN 해도 원점 안 됨 → 드라이브 전원이 끊겨 설정이 사라졌을 가능성 → RESET 에 드라이브 재설정 넣음, **시험 필요**.
4. 랜선 다시 꽂으면 한참 뒤 연결 → PC 가 옛 연결을 붙잡고 있는 것으로 추정. 커먼체크에서 직접 끊기 → 연결로 확인.
5. HMI ESP 소스 확인 (Downloads\HMI.zip → HMI_Kor_260702.zip → HMI_JC3248W535_v1.2/src) : 버튼 11 Run, 12 Pause, 13 Stop, 21~26 수동, 31 SoundOff, 32 Reset, 33 Manual, 34 Origin. 응답은 `STX '1' (버튼+0x30) ETX`. 60초 동안 못 받으면 ESP 재시작. 알람 글자 : 0 없음 1 수동 2 주행모터 3 리프팅모터 4 틸팅모터 5 주행이탈 6 리프트이탈 7 틸트이탈 8 안전센서 9 비상정지 10 원점설정.

### 남은 일 (다음)
1. **1단계 : 동작은 Motor_Task, TCP 는 Comm_Task** (계획까지 함, 사용자 승인 대기)
   - cmd.c `CMD_Run`(Comm_Task) : MI/MO/PO/I 확인 · 좌표 찾기 → `ack` → `order[160]` 에 받은 글자, `order_x/order_y`, `order_on = 1` → 바로 돌아감. 바쁘면(`order_on == 1`) NAK.
   - cmd.c `CMD_Move`(새 함수, Motor_Task 가 10ms 마다) : `order` 보고 MI / MO / `PO_event` / 원점 → `CMD_Done` → `order_on = 0`. **Motor_Task 는 send 금지** (표시만).
   - app_freertos.c : Motor_Task = 켤 때 원점 + HMI RUN 원점 + `CMD_Move()`. Comm_Task = TCP · CLI · CMD_Event 만 (켜자마자 접속 가능).
2. **알람** : 사용자가 alarm.c/h 기본 함수(`Alarm_Set(code)` = Status_Alarm + alarm_1/2 + alarm_new, `Alarm_Clear()`) → event.c 가 사용.
   - 긴급정지 9 / 이동 끝났는데 목표 ±GAP 밖 → 5 주행이탈 · 6 리프트이탈 · 7 틸트이탈 (`IM_Pos/AM_Pos/TM_Pos` 로 확인) / 위치 못 읽음 → 2·3·4 모터 / 원점 실패 · 60초 초과 → 10 / 원점이 3초 안에 끝남(이물질) → 10 (**원점 근처에서 시작하면 정상인데도 3초 안일 수 있음 → 기준 시험 필요**).
   - hmi.c `hmi_alarm` 이 `'0' + 알람 번호` 보내기. RESET 에 `Alarm_Clear()`.
3. 집 : 지금까지 한 것 정리 + 10/7 "함수마다 왜 이렇게 짰나" 공부 계속.
4. cmd.c 정리 (선택) : MO · PO 좌표 찾기 합치기, `0x02/0x06/0x15` → `STX/ACK/NAK` 이름, 주석. net.c (선택) : 상태 한 번만 읽기, 한 번에 recv.
5. 기존 : GO_ABS 0x07 (틸트 즉시 멈춤·재개), X 원점 살짝 닿기, HMI 센서 칸 순서 / PC 단 1 = FULL_x_1 확인, 수동 버튼이 `*_Pos` 실패를 안 봄, CMD_S `S_1` 만 받음.
6. 다음 주 : TCP W6100 인터럽트, CAN.

## 10/11 (집) 바뀐 것 · 지금 상태 (사실만)

- 집 PC = `threeD_roder (1).zip`(10/11 19:01, 10/8 회사 버전)으로 맞춘 뒤 아래만 바뀜. 전체 문법 검사 통과(에러·경고 0). 보드 시험 안 함.
- **alarm.c / alarm.h** : 알람 **켜기만** (구조상 판단은 event.c). `A_01(rack)` ~ `A_10(rack)` = 공통 `static alarm_on(rack, 번호)` 한 줄씩 (rack 1, 2 / 0 = 두 렉 → 상태 A + `alarm_1/2` 번호 + `alarm_event_on = 1`). `Alarm_Clear()` = 번호만 0. `alarm_1/2` 는 status.c 에서, 알람 번호 상수(`ALARM_*`)는 event.h 에서 지움.
  - 번호 뜻(사용자) : 01 HMI 통신(끊김·꼬임·버튼 안 먹음) / 02~04 X·Y·틸트 모터 / 05~07 X·Y·틸트 위치(시간 초과, 가는 중 엔코더 그대로) / 08 안전센서 / 09 비상정지 / 10 원점(너무 빨리 끝남 = 이물질, 리셋→RUN 했는데 통신 안 됨). ※ 프로토콜 문서 · HMI ESP 는 01 = 수동모드.
  - 지금 거는 곳 : 비상정지 눌림 `A_09(0)` (event.c estop_event). RESET 에 `Alarm_Clear()`. 나머지 번호는 아직 아무도 안 부름.
- **이벤트 일련번호** : cmd.c `event_send` 안 `static int number` → `STX + 01~99(99 다음 01) + 내용 + ETX`. 만재 FF · PPAUSE · 카드 U · 알람 S 모두. 완료응답(AI/AO/EO) · 체크(C) 응답은 PC 가 보낸 번호 그대로.
- **알람 이벤트** : 걸린 렉만 `S_1_A_09` / 둘 다면 `S_1_A_09&S_2_A_09`. 알람 풀릴 때는 안 보냄(원점 완료 메시지로 앎). 체크(C) 응답은 원래대로 `S_1_..&S_2_..&F_1_....&F_2_....`.
- i_motor.c 주석 고침 : `100% = IM_MAX_RPM (1000rpm)`.
- **확인한 사실 (코드 읽기)** :
  - UART2 모터 : 송신 DMA + 수신 DMA(ReceiveToIdle) + IDLE 인터럽트가 플래그로 깨움 + 뮤텍스(Uart2Lock). UART4 HMI = 인터럽트(DMA 아님). UART1 CLI 송신 DMA, **수신은 폴링**(`CLI_Run` 이 RXNE 확인).
  - mm/도 ↔ 펄스 : X 100 펄스/mm, Y 10 펄스/mm(부호 반대, 양쪽 다 뒤집어 맞음), 틸트 20000 펄스/360도. 보내기 · 읽기 왕복 맞음.
  - X 위치는 1번 모터(IM_1_ID)만 읽음. X·Y 도착은 위치(±GAP 10mm)만 봄, 틸트는 위치 + `TM_Done`. MI/MO 는 이동 · 기다림 결과를 안 봄. `wait_xy` 는 쉬지 않고 위치를 물어 이동 중 RS485 버스가 거의 늘 바쁨.
  - **폴링 · 고정 간격으로 도는 곳** : Event_Task 100ms 순회(HMI 묻기, RFID 0.5초 질문, 램프) / Comm_Task `osDelay(1)` 반복(CLI 수신 · W6100 `getSn_SR`·`recv` 확인 · CMD_Event, 그리고 MI/MO/PO/원점을 직접 실행) / `PO_arrive`·`PO_pour`·`PO_poured` 20ms 반복 / `wait_xy`·`wait_tilt`. Motor_Task 는 `osThreadExit()`. W6100 INT 핀(PE1, `W610_INT`)은 입력으로만 있고 안 씀.
  - **인터럽트 · RTOS 로 깨우는 곳** : UART2 응답(플래그), UART4 응답(플래그), 긴급정지 · 만재 EXTI(Event_Task 플래그), FDCAN 수신 콜백.
- **공부 루틴 (프로젝트 밖)** : 클라우드 루틴 2개가 평일 07:30 노션에 자동 생성 — 「임베디드 데일리 브리핑」(RTOS · 동시성 비중 높음), 「C 기초 다지기」(15강 커리큘럼, 교재 연계, 사용자 실제 실수 예시). 09:00 전 공부 / 09:00 부터 프로젝트 (작업 방식 11).

## 10/12 회사에서 바뀐 것 (하루에 아주 많이 바뀜 — 집에서 하나씩 다시 읽을 것)

**1. 렉 개수 설정 (rack_channel)** : FRAM `save.fs.rack_channel`(1~4)만큼 렉이 생김. **홀수 렉 = 오른쪽(렉1 처럼), 짝수 = 왼쪽(렉2 처럼)**, 렉 3·4 는 같은 쪽이 X 로 길어진 것.
- status.c : `status_1 ~ status_4`(처음 RESTART). `Status_WAIT/RUN(rack)` 1~4, `Status_PAUSE(0)` = 모든 렉. HOME · Resume · INIT · Alarm 은 4개 다.
- alarm.c : `alarm_1 ~ alarm_4`. cmd.c MI/MO/PO 렉 확인 `rack < 1 || rack > save.fs.rack_channel` → NAK, MO/PO 좌표는 `rack % 2` 로 오른쪽/왼쪽 표. C 응답 · 알람 이벤트는 rack_channel 만큼만. hmi.c · lamp.c 상태 확인도 3·4 포함.
- 렉 3·4 : 위치 표(FP 10~19)와 센서는 **나중에**. 지금 `PO_event` 는 렉 3·4 면 만재·카드 안 봄.
- ⚠️ CLI `FRAM` 의 CHANNEL 이 0 이면 MI/MO/PO 가 전부 NAK.

**2. 1단계 : 동작은 Motor_Task, TCP 는 Comm_Task** (계획대로 됨, 원점 · MI 도착 보드 확인)
- cmd.c : `static char order[160]`(받은 글자 복사 — `s` 는 net.c 받는 칸이라 다음 명령에 덮어써짐), `static volatile int order_on`(바쁨 표시), `extern osThreadId_t Motor_TaskHandle`.
- `CMD_Run` MI/MO/PO/I : 입구 확인(`order_on == 1` / 렉 상태 WAIT 아님 / manual / 완료응답 승인 전 → NAK) → `ack` → `Status_RUN` → `strcpy(order, s); order_on = 1; osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);`
- `CMD_Move`(Motor_Task) : CMD_Run 과 같은 `switch (cmd)` 모양. 맨 앞 = 원점 요청(`status_1 == HOME && order_on == 0` → `IM_MapInit · AM_Init · TM_Init` 드라이브 설정 다시 → `motor_basic_init` → 성공 대기 / 실패 초기상태). 그다음 `order` 의 MI/MO/PO/I 실행 → `CMD_Done` → `order_on = 0`.
- app_freertos.c : Motor_Task = `for (;;) { osThreadFlagsWait(MOTOR_FLAG, osFlagsWaitAny, osWaitForever); CMD_Move(); }` (폴링 아님 — 초인종 올 때까지 잠). Comm_Task = `Save_Init → NET_Init → Status_HOME → 플래그(켤 때 원점)` 후 `CLI_Run · NET_Run · CMD_Event · osDelay(1)`. **켜자마자 TCP 접속 가능.**
- HMI RUN(초기상태) → `Status_HOME` + 플래그 → Motor_Task 가 원점. CMD_D(만재 F 풀기)·PPAUSE 가 이제 **동작 중에도 바로** 나감.

**3. PO 상황 (event.c, 사용자 방식 — 그대로 둠)** : `PO_event(rack, dan, move_done, sensor_check)` → `PO_manjae`(도착 때 그 단 만재 → F, 센서 풀리거나 D 까지) / `PO_rfid`(도착 때 카드 없음 → S) / `PO_tilt`(쏟는 sensor_check ms 동안 센서 안 스침 → T, RUN 까지). run.c PO : `PO_event(rack, dan, 1, 0)` 도착 / `PO_event(rack, dan, 0, return_delay * 10)` 쏟기.

**4. 긴급정지 · 정지**
- usart.c UART2_Xfer · UART4_Xfer : `!= XFER_DONE` → `(… & XFER_DONE) == 0` (9/28 리뷰 숙제). 다른 플래그(긴급정지 0x02 등)가 같이 오면 HMI 응답을 실패로 버려 **RESET 버튼을 놓치던 문제**.
- RESET 에서 드라이브 재설정 빼고 RUN(원점 요청) 때 함. 긴급정지 → 풀기 → RESET → RUN **보드 확인됨**.
- `E_S()` (사용자 수정) : `TM_Stop()`(감속 정지) · `IM_Stop()` · `AM_Stop()`. 알람이면 무조건 `E_S` (alarm.c `alarm_on` 안).
- **X `IM_Stop`** : 가는 중엔 드라이브가 새 PR 명령을 안 받음(매뉴얼 Pr8.02 "0x001P not yet responding") → quick stop 만 됨. 그래서 `0x6017(Pr8.23 quick stop 감속 시간) ← IM_DEC_MS`(두 모터 먼저) → `0x6002 ← 0x40`(두 모터). 시도했다 버린 것 : PR0 속도 모드 0rpm(도착 후에야 멈춤 + 원점이 이상해짐).
- ⚠️ 0x6017 은 드라이브 RAM 에 남아서 **긴급정지 후 X 원점이 "닿고 더 밀다 늦게 돌아옴"** 이 될 수 있음 (원점 때 닿고 서는 것도 0x6017 을 쓰는 듯). **사용자 결정 : 원점 코드는 원래대로, 손대지 말 것.** 시험 결과 보고 정함. 시험 전 X 드라이브 전원 한 번 끄기.
- Y 원점 오프셋(H05_36, 0x0524 32bit) 시험 → 안 올라와서 **옛날 방식 `AM_Move(150, 50)` 로 되돌림**. `R_HOME_OFFSET` 이름만 남김. 매뉴얼 H05_37~40 (오프셋으로 이동하는 옵션) 확인 필요.

**5. 알람 (alarm.c = 켜기만, 판단은 각 자리)**
- 공통 `alarm_on(rack, code)` : 상태 A + `alarm_n` 번호 + `alarm_event_on` + **`E_S()`**. RESET = `IM_AlarmReset`(0x1801 ← 0x1111) · `AM_AlarmReset` · `TM_AlarmReset`(PA_04F ← 0x0300) · `AM_EStop(0)` · `Alarm_Clear` · `Status_INIT` → RUN 으로 원점. (과전류 · 과전압 등은 전원 껐다 켜야 풀림)
- 01 HMI 통신 : `HMI_Run` 실패 · 꼬임 = `HMI_FAIL`(-1, hmi.h). event.c `hmi_event` `case HMI_FAIL` : 20번 연속(약 3초) → `A_01(0)`.
- 02 · 03 · 04 모터 : event.c `alarm_event`(1초마다 X 0x2203 / Y H0B_34 / 틸트 PA_004 Fault) — **지금 `Event_Run` 에서 주석으로 뺌**. 이유 : 드라이브가 대답 안 하면 재시도(500ms × 3) 동안 Event_Task 가 멈춰 → 카드 리더에 못 물어봄 → 카드 빠짐으로 착각 → UT 이벤트 2.5초마다 반복. 다시 넣을 때 "읽기 실패 = 알람" 으로 한 번만 막히게 + `wait_xy` 에 `status_1 == ALARM` 이면 그만. Y H0B_34 가 "지금 알람"인지 매뉴얼 확인.
- 05 · 06 · 07 위치 : run.c `wait_xy` 30초 → 못 간 축 `A_05`/`A_06`, `wait_tilt` 30초 → `A_07`. `MI` · `PO` 의 wait 줄마다 `== 0 → return 0` (알람이면 PO 가 틸트 안 함, MI 는 AI 안 보냄).
- 08 안전센서 : 없음. 09 비상정지 : `estop_event` → `A_09(0)`. 10 원점 : 기준 정할 것 (주석).
- 아직 : hmi.c `hmi_alarm` 이 어떤 알람이든 `'9'` 를 보냄 (번호 보내기 안 함).

**6. 램프 명령 = 프로토콜 문서 형식** : `01LL_렉_램프_모드시간&L_렉_램프_모드시간…` (램프 1 적 2 녹 3 황 / 모드 '0' 끔 '1' 켬 '2' 깜빡 / 시간 '0'~'l' = 0~60초, '0' 계속, 10초 = ':'). cmd.c `case CMD_LAMP` : `s + 3` 부터 `sscanf(p, "L_%d_%d_%c%c")` 반복 + `strchr(p, '&')`. 홀수 렉 → 램프1, 짝수 → 램프2. 하나라도 틀리면 NAK (앞 묶음은 이미 켜짐). **보드 시험 안 함.**

**7. 랜선 (net.c)** : 뽑히면 `tcp_on = 0; unplug = 1;`(close 안 함), 다시 꽂히면 `disconnect()` 로 PC 에 끊는다고 알림 → PC 가 바로 새로 연결. (전에는 STM 이 조용히 close → PC 가 옛 연결을 붙잡고 한참 뒤 재접속.) **보드 시험 안 함.** 뽑힌 동안 이벤트 `send()` 가 잠깐 막힐 수 있음.

**10/12 보드 확인** : 원점 · MI 도착 · 긴급정지 → RESET → RUN 됨. 로그 해석 : `11UT_1_…` = 카드 이벤트(완료응답 아님), `55S_1_A_05&…&F_1_0000…` = PC `55C` 상태조회 대답.

**사용자 의견 (10/12)** : 하루에 너무 많이 바뀌어 cmd.c · event.c 가 헷갈림 (cmd.c 처음 구조와 쉬운 부분은 사용자가 짠 것). 원점처럼 **요청 안 한 곳은 절대 같이 고치지 말 것.** 설명은 짧고 쉽게.

## 10/13 회사에서 바뀐 것 (모터 파일 · 알람 · event · 만재 · 부저 정리)

**사용자 결정 · 규칙 (10/13)**
- `if (함수() == 1)` 쓰지 않음 → `if (함수())`. "아니면"은 `== 0` (`!` 금지는 그대로).
- 여러 레지스터 쓰기 : **움직이기 · 설정 = `&&`**(앞이 실패하면 뒤 안 함) / **멈추기 = 따로 다 보내고 `a && b`**(하나 실패해도 나머지는 세움). 둘 다 실패면 0.
- 알람 **조건 · 숫자는 alarm.c 한 곳**, 부르는 자리는 한 줄씩. 긴급정지도 `alarm_go`.
- 요청 안 한 곳(특히 **원점**)은 같이 고치지 말 것. 새 함수 · 변수 · 상수는 사용자 승인 후.
- PO 만재 · 카드 · 틸트 판단은 **run.c 안**(`PO_pause` · `PO_tilt`), event.c 는 Event_Task 함수만.

**1. 모터 파일 (a · i · t_motor)**
- Y 원점 오프셋 : **H05_36 은 Enable OFF(서보 꺼진 동안만 씀)** 라 `AM_Home` 에서 쓰면 거절됐던 것 → `AM_Init` 의 서보 켜기 전으로 옮김 (H05_34 · H05_35 도). `AM_HOME_OFFSET (-150 * Y_PULSE * Y_GEAR / Y_PI)`(a_motor.h), `write_regs(R_HOME_OFFSET, 2, AM_HOME_OFFSET, AM_HOME_OFFSET >> 16)`(write_regs 가 안에서 16비트로 자름). 원점 후 `AM_Move(150, 50)` 삭제 → 드라이브가 스스로 150mm. **보드 시험 필요** (ER.668 이면 부호 반대).
- `!` → `== 0` 통일, `AM_Stop` 따로 보내기, `IM_Move` `&&`, 원점 시작 명령 실패면 바로 0.
- 안에서만 쓰는 함수 `static` (`AM_Servo/Done/HomeDone/Zero`, `IM_Zero/State/Done`), `TM_Estop` · 안 쓰는 상수 삭제. `TM_Move` 는 수동 버튼 때문에 공개. t_motor.c `HOME` → `START_HOME` (status.h 의 상태 `HOME` 과 이름 충돌).
- **FP 11 · 12 반영** : `speed_rpm()`(100% = FP 11 rpm, 0 이면 `*_MAX_RPM`) · `accdec_ms()`(FP 12, 0 이면 기본). save.c FP 11 범위 확인 `SPEED_MAX 3000`. X 원점 후 100mm 이동은 `write_move(…, 100, IM_ACC_MS)` 로 **기본값 고정**(사용자가 rpm 100 으로 바꿈, 주석은 아직 150).
- **이동 함수 맨 앞 가드** : `IM_Move` · `AM_Move` · `TM_Move` 에 `if (estop == 1 || status_1 == ALARM) return 0;` → 그래서 run.c MI · PO 는 `if` 없이 함수만 나열, 끝에 `return (estop == 0 && status_1 != ALARM);`. 멈춤 함수(`*_Stop`)엔 가드 없음. ❓ **사용자 고민 중 : 꼭 모터 함수 안에 넣어야 하나** (다음에 다시 보기).
- 매뉴얼 확인 : ALM COIN = **추종 오차 < H05_21** (가는 중에도 켜질 수 있음 → 도착 판단엔 위치 비교 유지), 73쪽 "다단 운전 중 DI4 끄면 즉시 멈춤"(AM_Stop OK). iCL Pr8.02 "가는 중엔 새 PR 안 받음, quick stop 만" → X 감속 정지는 0x6017 + 0x40.
- `wait_xy` 를 Done 방식으로 바꾸는 안은 **안 함**(PO 절반 지점은 위치가 필요, Y COIN 은 도착 신호가 아님).

**2. 알람 (alarm.c)**
- `static alarm_go(rack, code)` = **E_S + 상태 A + 번호 + PC 알림 + Buzzer_On**.
- `A_01(button)` HMI_FAIL 20번 연속 / `A_05 · A_06 · A_07(start, arrived)` 10초 못 감 (걸면 1) / `A_09(rack)` 긴급정지 / `A_10(far, start)` 원점 시작 전 200mm 넘게 떨어져 있었는데 2초 안에 닿음 (걸면 1) / 02~04 · 08 은 `alarm_go` 한 줄 (02~04 는 아직 아무도 안 부름 → 내일).
- 상수 : `HMI_FAIL_MAX 20`, `MOVE_MS 10000`, `HOME_NEAR_MM 200`, `HOME_FAST_MS 2000` (전부 alarm.c).
- 부르는 곳 : event.c `estop_event`(A_09) · `hmi_event`(A_01) / run.c `wait_xy`(A_05 · 06) · `wait_tilt`(A_07) / `IM_Home` · `AM_Home`(A_10 : "닿은 순간"을 아는 곳). cmd.c 원점 실패는 `if (status_1 != ALARM) Status_INIT();` (알람 덮어쓰지 않게).

**3. event.c** : 머리 주석 = 1. Event_Task / 2. 인터럽트. `hmi_event` = A_01 · RUN · STOP · RESET(+Buzzer_Off) · 수동 모드 · 음소거(Buzzer_Off), 수동 버튼 21~26 은 `if (manual == 1) HMI_Manual(button);` (움직임은 **hmi.c `HMI_Manual`**, 틸트 수동은 `TM_Move(now ± MANUAL_TILT)` 로 고침 — 전엔 반대쪽으로 튐). PO 묶음(`PO_event` 등)은 **run.c `PO_pause` · `PO_tilt` 로 옮김**(event.c 에서 삭제).

**4. run.c PO** : `MO → PO_pause(만재 · 카드면 멈춤, 풀리면 이어서) → Y 올리며 틸트 → PO_tilt(touch_time 동안 센서 안 닿으면 T) → PO_pause(사용자가 넣음, 쏟은 뒤 만재면 기울인 채 대기) → 복귀`. `PO_pause` · `PO_tilt` 맨 앞 `if (estop == 1 || status_1 == ALARM) return 0;` (ALARM 을 PAUSE 로 덮어쓰지 않게). 05~07 시간 30초 → **10초**. ❗ 사용자 의견 : **PO 부분과 wait 부분이 지저분 → 다음에 깨끗하게**.

**5. 만재 (manjae.c, 사용자 모양)** : 함수 3개만, 변수 없음. `manjae_off(rack, dan)` = 핀 그대로(3.3V 빈칸 = 1) / `manjae_on(rack, dan)` = `manjae_off(…) == 0` / `manjae_change()` = 8칸(`GPIOE->IDR & 0x7F80`) 바뀌었으면 1. `floor_full` · `Full_Read` · `full_1_1`~`full_2_4` · `full_1/2` 삭제 → run · event · cmd · hmi · lamp 가 `manjae_on(…)` 으로. hmi.c 화면 칸은 `manjae_on(2, 1) ? '1' : '0'` (원래 모양).

**6. 부저 (buzzer.c 새 파일)** : `Buzzer_On` · `Buzzer_Off` (PD0 = DO9). **능동 · 단속음 부저**라 핀을 켜 두면 스스로 삐 · 삐 (깜빡이게 하면 이상하게 들림). 켜기 = 원점 시작(cmd.c) · `alarm_go` · 만재 생김(event.c `manjae_event`) · PC `01B_렉_1` / 끄기 = 원점 성공(cmd.c) · RESET · 음소거 · 만재 다 풀림 · PC `01B_렉_0`. **"순간"에만 켜고 끔**(0.1초마다 끄던 줄 삭제) → PC 와 STM 이 안 부딪힘, 음소거에 변수 필요 없음. 알람 중 만재가 풀리면 부저도 꺼짐(사용자 결정 : 안전 코드 안 넣음). TIM8 PWM 으로 해 봤다가 안 울려서 GPIO 로 되돌림(ioc 도 되돌림).
- cmd.c **B 명령** : `CMD_BUZZER (('B' << 8) | '_')`, `01B_렉_1/0`, 렉은 범위 확인만.

**7. 기타** : 켤 때 Y 서보가 두 번 켜지는 원인 = CMD_Move 원점 요청에서 `AM_Init` 등을 부르고 `motor_basic_init` 이 또 부름 (`AM_Init` 은 DI 기능을 0 으로 지워 서보를 껐다 켬). 고치는 안(CMD_Move 세 줄 삭제 + `motor_basic_init` 맨 앞 `x_ok = y_ok = t_ok = 0`) **보류**.
- 빌드 : 새 파일(buzzer.c)은 명령줄 makefile(`Debug/Core/Src/subdir.mk`, `Debug/objects.list`)에 손으로 넣음 → **CubeIDE 에서 한 번 빌드하면 다시 만들어짐**. ⚠️ CubeIDE 에 예전 내용으로 열린 탭이 저장되면 Claude 수정이 덮어써짐(10/13 run.c) → 탭 Revert / Refresh(F5).
- Flash 약 93.7KB / 256KB, RAM 약 28.6KB / 128KB. 경고 1개(안 쓰는 `alarm_event`).

## 10/14 회사에서 바뀐 것 (네트워크 추가 · W6100 인터럽트 · 타이머) — 보드 시험 전부 안 함

**작업 방식 (10/14 사용자)** : "Claude 가 하는 걸 내가 따라 치는" 방식. 한 단계씩 작게, 개념 먼저, 사용자가 치고 Claude 가 빌드 · 리뷰. 모르는 상수 · 새 구조보다 **있는 것을 이용**하는 쪽을 좋아함. 사용자가 이해 못 한 채 넘어간 곳이 많음 → **집에서 만재 → RFID → net.c `NET_Run` 순으로 질문하면서 다시 볼 예정**.

**1. 네트워크 요구 (사용자 문서)** : 기본 IP 172.20.0.1 / 255.255.255.0 / 포트 2500 / 서버 (save.c `Network_Default` 에 이미 있음). 창구 3개 :
| 소켓 | 포트 | 용도 |
|---|---|---|
| 0 `TCP_SOCK` | `net_port`(2500) | PC 명령. **20초 명령 없으면 끊기(FI 7)는 여기만** |
| 1 `Service_SOCK` | 58080 | 모니터링 : 2500 에서 오간 것을 `[TX] 내용` (PC 가 보냄) / `[RX] 내용` (PC 가 받음) 으로. 지금은 **STX · ACK · ETX 를 그대로** 보냄 (안 보이는 글자로 나올 수 있음 → 시험 보고 결정) |
| 2 `LOG_SOCK` | 50001 | 로그 : 중요한 것만 영어로 (알람, 상태 바뀜, 모터 통신 에러, 원점 · 이동 시간). **`[숫자]` 앞머리 없음. 구조는 사용자와 같이 짤 것 → 아직 아무것도 안 보냄** |
- 노트북 선만 스위치에서 빠져도 2500 은 계속 돼야 함 (세 창구 따로).

**2. net.c (W6100 인터럽트 방식)** — ioc : PE1 = GPIO_EXTI1 Falling, 풀업, NVIC 5
- `NET_Init` 끝 : `setSIMR(0x07)`(소켓 0 · 1 · 2) + `setSn_IMR(n, 0x0F)`(CON · DISCON · RECV · TIMEOUT, **SENDOK 는 뺌**) → `net_mode == 0` 이면 `net_open` 3개.
- `net_open(sock, port)` : `switch` → **if 3개 순서대로** (CLOSE_WAIT → disconnect / CLOSED → `setSn_RCR(sock, 2)` → socket → `setSn_KPALVTR(sock, 1)` / INIT → listen). 한 번 부르면 LISTEN 까지. `w610_reset` 바로 아래로 옮김.
  - keep-alive : 5초 조용하면 "살아 있어?" → 재전송 2번(0.2 · 0.4 · 0.8초) 대답 없으면 W6100 이 스스로 닫음(TIMEOUT) → **약 6~7초** (시험 필요). 1바이트라도 보낸 뒤에만 동작. RCR 을 줄이면 데이터 재전송도 2번만 → 네트워크 나쁘면 더 잘 끊김.
  - keep-alive(PC 컴퓨터 살아 있나) ≠ FI 7 20초(PC 프로그램이 명령 보내나) → **둘 다 필요**.
- `NET_Run` (`switch`·`getSn_SR` 폴링 없음) :
  1. `if (INT 핀 == 0)` (**핀은 거꾸로 : 0 = 일 있음**) → `w6100_doing = getSn_IR(TCP_SOCK) & 0x0F` → `setSn_IRCLR(TCP_SOCK, w6100_doing)` (읽고 **바로** 끔). `w6100_doing` = 표시등 복사본 (평소 0, 일 있으면 그 비트 1). 처음 `= 0` 꼭 (핀 안 읽은 바퀴 쓰레기 값 방지).
  2. `& Sn_IR_CON` → `tcp_on = 1`, `last = 지금` / `& Sn_IR_RECV` → 기존 받기 코드 (STX ~ ETX → `service_port("[TX] ")` → `CMD_Run`) / `& (DISCON | TIMEOUT)` → `tcp_on = 0`, `unplug = 0`, `net_open`.
  3. 보드 랜선 뽑힘(`tcp_on == 1 && PHY OFF`) → `tcp_on = 0, unplug = 1` / **우리가 끊기** : 20초 명령 없음 또는 다시 꽂힘 → `disconnect` + **바로 `net_open`** (PC 가 RST 로 대답하면 DISCON 이 안 올 수 있어서).
  4. 서비스 · 로그 : `if (INT 핀 아직 0)` → 각각 읽고 끄고 DISCON · TIMEOUT 이면 `net_open`.
  - **`& 0x0F` 이유** : `send()` 가 SENDOK 를 기다림 (socket.c 307줄). NET_Run 이 SENDOK 까지 지우면 다음 send 가 영영 기다려 Comm_Task 멈춤.
  - SPI (1ms 한 바퀴) : 아무도 연결 안 됨 6~7번 → **0번**, 2500 연결 중 조용 → **1번**(랜선).
- `service_port(char *tr, buf, len)` (static) : 노트북 없거나 보낼 자리(`getSn_TX_FSR < len + 7`) 없으면 안 보냄 → `"[TX] "`/`"[RX] "` + 내용 그대로 + `\r\n` (send 3번). 자리 확인 이유 : 노트북이 연결만 하고 안 읽으면 보내기 칸이 꽉 차 send 가 기다리며 2500 까지 멈춤.
- `NET_Send(buf, len)` (net.h 공개) : 2500 으로 보내고 `service_port("[RX] ")`. cmd.c `send(TCP_SOCK, …)` 7곳 → `NET_Send`. cmd.c `#include "socket.h"` → `net.h`, `#define TCP_SOCK` 삭제.
- **STX · ETX · ACK · NAK** : cmd.c → **cmd.h** 로 옮김 (사용자), cmd.c · net.c 의 `0x02/0x03/0x06/0x15` 를 이름으로. (hmi.c 의 STX · ETX 는 터치패드용이라 따로, net.c MAC `0x02` 는 STX 아님)
- 아직 안 함 : Comm_Task `osDelay(1)` → `osThreadFlagsWait(NET_FLAG, …, 1)` + event.c EXTI 콜백 `W610_INT_Pin` 줄 (지금은 1ms 마다 **핀 레벨을 읽어서** 동작은 함. 초인종은 기다리는 시간을 늘릴 때 필요. CLI 가 UART1 폴링이라 지금은 1ms 유지). 서비스로 명령 받기 · 서비스로 대답, 로그.
- 질문 · 개념 정리 : 핀(0 = 일 있음) ↔ 표시등 비트(1 = 일 있음)는 **다른 것** / IMR(울릴지 설정, 켤 때 한 번) ↔ IR(실제 일, 읽고 끄기) / `if (조건);` 의 `;` 는 빈 문장 / `==` 가 `&` 보다 먼저 (`w6100_doing == 0 & CON` 틀림) / static 함수는 쓰는 곳보다 위에 / 지역 변수 처음 값은 쓰레기, static 은 0.

**3. 만재 (event.c + 타이머)** — 사용자 생각 : 인터럽트로 바로 인식하면 스칠 때마다 부저 · R 깜빡 → **2초 동안 그대로일 때만 인정**.
- `manjae_event` : `if (manjae_change()) osTimerStart(Manjae_TimerHandle, 2000);` (바뀔 때마다 2초 다시 감기)
- app_freertos.c `Callback_Manjae_Timer` : `full_event_on = 1;` + 만재 하나라도 있으면 `Buzzer_On` 아니면 `Buzzer_Off` (확정 순간 한 번).
- `full_event_on` 은 "PC 로 FF 보내 줘" 쪽지 (타이머 태스크는 send 못 함).
- 사용자가 쓴 첫 모양(2초 if / else 매번)은 100ms 마다 FF · 부저를 반복해서 알람 부저 · B 명령 · 음소거와 부딪힘 → 타이머로.
- ⚠️ 남음 : R 램프(`lamp_manjae`)와 PO · HMI 는 `manjae_on` 을 **바로** 읽음 → 스칠 때 R 은 아직 깜빡. FULL_1_1(PE11) 은 EXTI 없음(EXTI11 = 긴급정지) → 100ms 읽기 남음.

**4. PO 틸트 (run.c `PO_tilt`, 사용자 : 변수 줄이는 쪽 · 구조 그대로)**
- 20ms 마다 깨던 for 문 → `touch_time += 지금`(이제 "쏟기 끝 시각") → `osThreadFlagsClear(TOUCH_FLAG)` → 처음 한 번 확인 → `while ((left = touch_time - 지금) > 0) { osThreadFlagsWait(TOUCH_FLAG, …, 렉1 1단이면 20 아니면 left); if (manjae_on) touch = 1; }`.
- `left` 1개는 꼭 필요 : 시계를 두 번 읽으면 그 사이 넘어갈 때 "약 49일 기다리기" 로 멈춤.
- 쏟은 뒤 `if (estop == 1 || status_1 == ALARM) return 0;` 추가 (전에는 쏟는 중 긴급정지면 ALARM 을 PAUSE(T) 로 덮어씀).
- event.c EXTI 콜백 : 만재 핀이면 `osThreadFlagsSet(Motor_TaskHandle, TOUCH_FLAG)` 도.

**5. RFID (타이머, 반만 됨)** — app_freertos.c `Callback_Rfid_Timer` 에 `Rfid_Check();` ✅ / `Rfid_Check` 의 0.5초 확인 if 삭제 ✅
- ❗ **남음 (안 하면 리더에 100ms 마다 물음)** : rfid.c `Rfid_Init` 끝에 `osTimerStart(Rfid_TimerHandle, ASK_MS);` + `#include "cmsis_os2.h"` · `extern osTimerId_t Rfid_TimerHandle;` / `static uint32_t ask_last;` 줄 삭제 / event.c `rfid_event` 함수 · 호출 삭제 / ioc `TIMER_TASK_STACK_DEPTH` 256 → 512 (Rfid_Check 의 snprintf).
- 2초 못 읽음 확인은 **지금(HAL_GetTick 시각 비교) 그대로 두기로**. 사용자 고민 : 타이머 · HAL tick 이 섞여 보임 → 대안 ① `miss` 횟수(`LOST_MS / ASK_MS`) ② 만재처럼 렉마다 2초 타이머(CAN 수신 인터럽트라 `xTimerResetFromISR` 필요, 타이머 2개 추가, `card_lost` 공개).

**6. 그 밖에 이야기한 것**
- 인터럽트로 바꿀 수 있는 건 장치가 먼저 알려 주는 것뿐 (만재 · W6100 INT · CAN 수신 · 긴급정지). RFID · HMI 는 "묻고 대답" 이라 주기는 남음.
- Comm_Task 를 전부 초인종으로 하려면 : W6100(오늘) → CLI UART1 인터럽트 → 이벤트 초인종 → 그때 알람 시간 100ms ~ 1초.
- RAM 을 진짜 줄이는 곳 : 태스크 스택 실측(`uxTaskGetStackHighWaterMark`) 후 줄이기 (힙 20KB 고정).
- 빌드 : 전체 통과, 경고 0. Flash 약 95.2KB / 256KB, RAM 약 28.6KB / 128KB. ⚠️ CubeIDE 코드 생성 · 저장 때 열린 탭이 Claude 수정을 덮어씀 (10/14 event.c `manjae_event` 가 한 번 되돌아갔음) → 탭 F5.

## 10/15 회사에서 바뀐 것 (마무리 구현 + 구조 정리) — 보드 시험 전부 안 함

**사용자 원칙 (10/15)** : "각 파일은 그 파일 관련 행동만". cmd.c = 명령이 맞는지 확인 → NAK / ACK + 그 파일 함수 실행. 동작은 **run.c 의 원래 함수(MI · MO · PO · I)** 를 그대로 씀. `CMD_…` 비교로 흐름 나누는 모양 싫어함 (10/7 · 10/15 두 번 거절). 코드는 `BTN_RESET` 처럼 **기본 함수 나열**, 짧게. 새 감싸기 함수(`Run_Order`, `home_event`, `before` 변수 등) 거절. 시작 · 끝 줄이 여러 곳에 반복되는 것 싫어함.

**1. RFID 타이머 마무리** : rfid.c `Rfid_Init` 끝 `osTimerStart(Rfid_TimerHandle, ASK_MS)`, `ask_last` 삭제, event.c `rfid_event` 삭제, `Event_Run` 맨 앞 `Rfid_Init()`. `configTIMER_TASK_STACK_DEPTH 512` (FreeRTOSConfig.h + ioc). TCP 연결(CON) 때 `rfid_new = 1` → 지금 카드 상태 PC 로.

**2. net.c 구조 정리** (맨 위 주석 = W6100 라이브러리 함수 목록 + 이 파일 함수 목록)
- 공통 `net_open` · `static port_doing(sock)` (`w6100_doing = 0` → INT 핀 1 이면 끝 → `getSn_IR & 0x0F` 읽고 끔). 변수 이름 `w6100_doing` 하나로 통일.
- 2500 : `tcp_recv`(STX~ETX) → `tcp_cmd` / `tcp_check`(랜선 · FI7 20초 · 다시 꽂힘) / `tcp_port`(CON · RECV · DISCON/TIMEOUT). 서비스 · 로그 : `service_log_port`. `NET_Run` = `tcp_port(); service_log_port(); log_send();` (`net_mode != 0` 이면 안 함).
- **일련번호 `Roder_Number()`** (net.c, 하나의 번호표 01~99 → 01) : PC 가 번호 없이 보낸 명령(`MI_1_1_2…`)과 이벤트에 로더가 붙임. PC 가 번호 붙여 보낸 명령 · 승인은 그 번호 그대로 (`number` 도 그 번호로 맞춤). cmd.c `event_send` 의 자기 번호 삭제.
- **PC 완료 승인 `01-AI_…` 의 `-` 는 사실 ACK(0x06)** → cmd.c 승인 확인 `s[2] == ACK`.
- **로그 포트 50001** : `Log_Port(char *text)` (아무 태스크, `osKernelLock` 으로 `log_text[512]` 에 덧붙임 + CRLF) → `log_send`(Comm_Task, 연결 · 자리 있을 때 보냄). 시각 · HELLO 없음 (Tera Term 타임스탬프 사용). 내용 : MI/MO/PO 시작(렉 · 열 · 단) · 끝(done/FAIL + 초), 알람(번호 · 레지스터 · 값 · 이름). 서비스 58080 = 2500 오간 것 `[TX]` / `[RX]` 복사만 (명령 안 받음).

**3. 알람 02 ~ 04 (드라이브 알람)** — 모터 파일 = 읽기 함수, alarm.c = 판단 · 이름, event.c `alarm_event` = 1초마다 (원점 끝난 뒤만, 알람 · 긴급정지 · 초기 · 원점 중엔 안 물음) `if (A_02()) return; if (A_03()) return; A_04();`
- X `IM_Alarm(&code)` : 0x2203 을 **두 모터 다** 읽어 OR (0x01 과전류 0x02 과전압 0x40 전류측정 0x80 축고정 실패 0x100 오토튜닝 0x200 EEPROM).
- Y `AM_Alarm(&code)` : **H0B_33 = 0 일 때 H0B_34 = 0x0B22** (전에 0x0B34 로 틀렸음). ER.950 · 952 · 601 은 알람 아님 (사용자). 값 형식(0x0630?) 보드 확인 필요.
- 틸트 `TM_Alarm(&code)` : PA_005 = 0x0005 (01 과전류 02 과전압 03 저전압).
- 로그 예 : `ALARM 02  X  0x2203 = 0x0001  over current`.
- hmi.c `hmi_alarm` : 긴급정지 '9' / `alarm_n >= 2` 면 `'0' + 번호` (10 = ':' — ESP 가 `data[2] - '0'`, AlarmString 0~10 이 우리 번호와 같음, 범위 검사 없음) / 수동 '1' / 없음 '0'.

**4. cmd.c · run.c · Motor_Task (명령 구조)**
- cmd.c 머리 주석 = 함수 지도. `case CMD_MI: case CMD_MO: case CMD_PO:` 합침 : 바쁨(네 렉 다 WAIT 아님) · 수동 · 승인 전 → NAK / `sscanf` → 범위 → `order_xy(cmd)`(FRAM 표에서 좌표, 풀어 쓴 모양 유지) → ack → `order_no` → `Status_RUN` → 시작 로그 → 초인종(MI/MO/PO_FLAG). C · D · E 들여쓰기 · 주석 정리.
- `CMD_I` : 원점 중 · 운전 · 일시정지면 NAK → ack → `order_no` → `osThreadFlagsSet(MOTOR_FLAG)` 한 줄.
- run.h : `order_rack/col/dan/x/y/xy_speed/tilt_speed/move_delay/return_delay` (run.c 에 정의, cmd.c 가 채움).
- run.c **`Motor_Run(flag)`** : `if (flag & MI_FLAG) return MI(…)` 처럼 run 함수 하나. **원점은 시작 · 끝 전부 여기** : `Status_HOME → Buzzer_On → motor_basic_init()` → 성공 `Status_WAIT(1~4) + Buzzer_Off` / 실패 `if (status_1 != ALARM) { Status_INIT(); Buzzer_Off(); }`. 켤 때 · HMI RUN · PC I 는 **초인종 한 줄만** (`Status_HOME` · `Buzzer_On` · 시작 로그 · `CLI_Start` · HOME 로그 지움).
- cmd.c **`CMD_Done(flag, ok)`** (Motor_Task) : 원점이면 PC I 였을 때만 `homing done` / 아니면 로그 + 성공 시 `Status_WAIT(order_rack)` + `done_text`(AI · AO · EO).
- **`motor_basic_init` (사용자 모양)** : `int x = IM_MapInit(); int y = AM_Init(); int t = TM_Init(); if (x && y && t) return I(); return 0;` — `x_ok` 등 static · 재시도 없음 → **원점마다 드라이브 다시 설정** (긴급정지 뒤 설정 사라짐 문제도 풀림, 대신 원점마다 Y 서보 껐다 켬). 켤 때 드라이브가 늦게 깨면 실패 → HMI RUN 다시. `AXIS_WAIT` · `INIT_RETRY` 는 사용자가 지움.
- **wait 함수 삭제** : `wait_xy` · `wait_tilt` → 모터 파일 `IM_Arrive(x)` · `AM_Arrive(y)` · `TM_Arrive(deg)` (지금 도착했나 한 번 보고 1/0, `GAP 10` · `TILT_GAP 2` 도 모터 파일로) + alarm.c `A_05(x)` · `A_06(y)` · `A_07(deg)` = **도착까지 기다림, 10초 못 가면 알람, 도착 1 / 실패 0** (전에는 "걸면 1"). run.c MI · PO 는 `A_07(0); IM_Move; AM_Move; A_05(x); A_06(y);` 처럼 나열. PO 의 Y 만 움직이는 구간은 Y 만 물음 (버스 절반).

**5. 그 밖에** : event.c `lamp_event` 만재 R 은 `osTimerIsRunning(Manjae_TimerHandle) == 0` 일 때만 (스침이면 안 깜빡). `home_event` · `home_end` 없음. lamp.c `LampY2 → Lamp_Y2`(사용자). 노션 「RTOS os 함수 지도 · 언제 무엇을 쓰나 (10/15)」.

**10/15 이야기만 한 것 (코드 안 바꿈)**
- **버스 줄이기** : 사용자가 원하는 방식 = "걸릴 시간을 계산해서 그동안 자고, 그 뒤 묻기". 모터 파일마다 `*_Time(목표, percent)` (FP 11 `speed_rpm` · FP 12 `accdec_ms` 를 써서 자동 반영, 사다리꼴, 실제보다 길게 안 나오게) → A_05~07 맨 앞 `osDelay`. ❗ 드라이브마다 가감속 ms 뜻(목표 속도까지 / 0→1000rpm) 매뉴얼 확인 필요. **보드 시험 후 결정.**
- 버스가 늘 바쁘면 : 보통은 Event_Task(High) 가 한 번(3~5ms)만 기다림. 문제는 **드라이브 무응답(X·틸트 RX_TIMEOUT 500ms, Y 50ms) + 소프트웨어 알람 정지(E_S)** 가 겹칠 때 최대 500ms 늦음 (긴급정지 버튼은 NC 하드웨어라 상관없음). 시험 때 `uart2_err` · `uart2_us` 보기.
- **수동 모드 구멍** : 작동 중엔 수동 모드가 안 켜지고(네 렉 WAIT 일 때만) 21~26 도 무시 → OK. 하지만 **수동 모드 켠 채 PC I** 는 NAK 안 됨 → 원점 중 수동 버튼이 먹힘. 고치는 안 ① `CMD_I` 입구에 `|| manual == 1` ② 수동 버튼 줄 `manual == 1 && status_1 == WAIT`. **사용자 : 오늘 안 함, 내일 이어서.**

## 10/16 회사에서 바뀐 것 (파일별 정리 수업 : fdcan → rfid → run · alarm · status) — 보드 시험은 사무실 문제로 거의 못 함

**사용자 방식 (10/16)** : 파일마다 "왜 이렇게 짰나 → 개념 → 더 좋은 방법 → 고칠 안" 순서로 천천히. **설명은 우편함 · 편지 같은 비유 말고 프로젝트 실제 것(리더 ID 201, 'C', FIFO0, PO…)으로**, 용어 한꺼번에 많이 쓰지 말 것, 그림 좋아함. 코드는 `I()` · `BTN_RESET` 처럼 **기본 함수 나열**, if · while 은 줄이고, 변수로 on/off 하는 것보다 **기존 함수 이용**을 좋아함. 함수가 너무 늘어나는 것도 싫어함. **cmd.c 는 "TCP 명령이 맞나 확인 → NAK / ACK + 실행" 용도만** (PC 로 먼저 알리는 건 cmd 일이 아님).

**1. fdcan.c** : 이름 사용자 결정 `CAN_On`(CAN 켜기) · `Send_to_Reader`(프레임 1개 보내기). 수신 콜백 `HAL_FDCAN_RxFifo0Callback` 은 **ST 드라이버가 정한 이름이라 바꾸면 안 불림** (그대로, 주석 "리더 대답 받기"). 콜백 `if` → `while` (FIFO0 3칸이 빌 때까지 읽기, `return` → `continue`). HAL 함수 줄마다 주석 + 드라이버 파일 위치.
- 리더 코드(`3DS_RFID_V1.1.0_251128_7a56`, STM32F042) 확인 : 속도 **125kbps**(리더 main.c Prescaler 24, ⚠️ 리더 ioc 는 500k → 리더 프로젝트를 CubeMX 재생성하면 깨짐), ID = 200 + DIP(~4핀, 0 이면 10), `'C'` 받으면 같은 ID 로 UID 7바이트, **카드 바뀌면 묻지 않아도 보냄**, **20번 연속 못 읽으면(약 0.25초) UID 0000000 보냄**, 리더 CAN `AutoBusOff = DISABLE`(Bus-Off 면 전원 꺼야 풀림).
- 우리 쪽 : FDCAN 클럭 170MHz ÷ 80 ÷ (1 + 14 + 2) = 125kbps, 샘플 88%. 트랜시버 MCP2542FD 는 전압 변환만 (VDD 5V · VIO 3.3V · STBY Low 여야 동작).

**2. main.h 에 RTOS extern 모음** (위 "공유 변수 규칙"). rfid · event · cmd · usart 의 `extern … Handle` 줄, cli.c 중복 `extern SAVE_Data save` 삭제.

**3. rfid.c (사용자 구조, 45 → 53줄)** : `Rfid_Save(rack, data)` = **"이럴 때 이렇게" 4줄** (`rack == 1 && data[0] != 0 && card_ok_1 == 0` → 1 + `memcpy(uid_1)` + `card_event_on` / `data[0] == 0 && card_ok_1 == 1` → 0 + `memset` + `card_event_on`, 렉2 같음). `Rfid_Check` = 'C' 묻기, **`Send_to_Reader` 실패(대답 없어 보내기 칸 3개 참, 약 2초) → `Rfid_Save(렉, &none)` = 빠짐** (선 빠짐 · 리더 꺼짐). `Rfid_Init` = CAN_On ×2 → `Rfid_Check()` → 타이머. `card_on(rack)` 추가(렉 3·4 = 1). `uid_1/2` 공개.
- 없어진 것 : `seen_1/2` · `LOST_MS`(STM 2초 기다림 → **리더의 0.25초 그대로**, 사용자 결정 : 진동은 시험 보고), `card_lost`, `rfid_show` + CLI 출력(타이머 태스크가 3.6ms 막히던 것), `Rfid_Text` · `Rfid_Msg`(카드 글자는 cmd.c 가 만재 FF 처럼 그 자리에서 `snprintf`), `HAL_GetTick` → `osKernelGetTickCount`.
- `rfid_new` → **`card_event_on`** (처리 대기 변수 이름 통일 : `무엇_event_on`).
- ⚠️ 카드 있음 판단이 `data[0] != 0` (첫 칸) : 첫 칸이 00 인 4바이트 카드면 못 읽음 → 시험 때 확인, 안 되면 앞 4칸 OR.

**4. 도착 기다림 · 알람 05~07 (사용자 결정 모양)** : 모터 파일 `*_Arrive` = 기다림만 (`MOVE_MS` 넘으면 0, 긴급정지 · 알람이면 0) / alarm.c `A_05(x)` · `A_06(y)` · `A_07(deg)` = 위치 한 번 읽어 아니면 로그 + `alarm_go` / run.c 는 `IM_Arrive(x); AM_Arrive(y); A_05(x); A_06(y);` 처럼 나열. `IM_GAP 10` · `AM_GAP 10` · `TM_GAP 2` 는 모터 헤더, `MOVE_MS 10000` 은 alarm.h. PO 의 "Y 절반" 뒤엔 A_06 없음 (계속 올라가는 중이라 오알람).

**5. run.c** : MI 가 도착 안 기다리던 것(`IM_Arrive` 한 번 보기) · PO 의 `TM_C(tilt_angle)`(기울이자마자 되돌림) 고침. `PO_pause` = `Status_PAUSE(rack, 'F')` / `card_on(rack) == 0` → `'S'` / `while (pause_why) { if (pause_why != 'M' && 만재 풀림 && 카드 있음) Status_RUN(rack); osDelay(20); }` (만재 + 카드 없음 둘 다면 **둘 다 풀려야** 진행, 정지선 STOP 은 HMI RUN 까지). `PO_tilt` = 쏟는 시간을 20ms 씩 줄이며 `manjae_on` → 한 번도 안 닿으면 `'T'` → `while (pause_why) osDelay(20);`. MI 정지선 `while (pause_why) osDelay(20);`. 안 쓰는 include(`cli.h` · `net.h` · `stdio.h`) 삭제.
- ⚠️ **사용자가 오후 시험용으로 PO 안 `// PO_tilt(…)` · `// PO_pause(…)`(쏟기 확인 · 쏟은 뒤 정지선) 주석 처리** → 지금 PO 는 기울기 도착 → 바로 복귀(쏟는 시간 없음), 빌드 경고 `PO_tilt not used` 는 이것 때문.

**6. status.c = 상태판 + 상태 규칙 한 곳** (사용자 : status 를 cmd 로 옮기는 안 → 장치 파일이 cmd 에 기대게 돼서 상태판 유지로 결정) : `Status_PAUSE(rack, why)` = 알람이면 안 바꿈 + 상태 + `pause_why = why` + `pause_event_on`. `Status_RUN` · `Status_Resume` · alarm.c `alarm_go` 끝에 `pause_why = 0` → **`pause_why` 가 "일시정지 중" 표시 겸 이유** (0 = 아님). event.c STOP · cmd.c S · cli.c S 는 `Status_PAUSE(0, 'M');` 한 줄 (이제 PC S · CLI S 도 PPAUSE:M 보냄).

**7. `TOUCH_FLAG` 삭제** (event.c 만재 EXTI 줄 · event.h · cmd.h 주석).

**8. 사무실 시험에서 나온 것**
- 사무실엔 HMI 없음 → 켜고 약 3초 뒤 **알람 01** → `E_S` + ALARM → 원점 중단, MI/MO NAK(`can_not_command`), CLI 이동 막힘. 드라이브는 그 정지 상태가 RAM 에 남아 **10/12 아침 펌웨어로 바꿔도 `MOTOR INIT ERR`** → 드라이브 전원을 꺼야 풀림. → **event.c `A_01(button);` 주석 처리 (사무실 시험용, 현장에선 꼭 풀 것)**.
- 로그에 `ALARM 01` 이 안 보인 이유 : 알람은 켜고 3초에 **한 번만** 로그, 로그 창이 그때 연결 안 돼 있으면 `log_send` 가 **버림** (리셋하면 Tera Term 연결도 끊김). 알람 확인은 PC `C` 대답의 `S_1_A_01`.
- 카드 : CAN1 · CAN2 LED **계속 켜짐** = 'C' 에 ACK 없어서 하드웨어가 계속 다시 보냄 (CAN2 는 리더 없으니 정상). 리더 D3(카드 읽음)는 켜지는데 STM 엔 안 들어옴, **10/12 펌웨어도 같음 → 코드 아님**. 의심 : 리더 CAN Bus-Off(오늘 플래시 · 디버그 반복 중) → **리더 전원 껐다 켜기**, 그래도면 CAN H/L · 120Ω(전원 끄고 H–L 저항 60Ω) · 트랜시버 5V · STBY · 리더 DIP · 리더 펌웨어 125k.
- 10/15 에 `CLI_Start` 를 지워서 이제 켤 때 `MOTOR INIT OK/ERR` 가 CLI 에 안 나옴 (원점 실패를 모를 수 있음).
- ST-LINK `Target no device found` / CubeProgrammer `Voltage 0.00V` = 보드 전원 · SWD 선 문제.
- 펌웨어 직접 올리기 : `C:\ST\STM32CubeIDE_1.19.0\STM32CubeIDE\plugins\com.st.stm32cube.ide.mcu.externaltools.cubeprogrammer.win32_2.2.200.202503041107\tools\bin\STM32_Programmer_CLI.exe -c port=SWD -w 파일.elf -v -rst`.
- 백업 : `workspace_1.19.0\threeD_roder_1016_current`(오늘 코드), `Downloads\threeD_roder (1).zip`(10/8 회사 코드 + 10/11 집 수정, 안의 Debug elf 는 10/8 빌드). 10/12 저녁 · 10/8 따로 백업 없음.

**10/16 이야기만 한 것 (코드 안 바꿈)**
- **PC 알림 구조 (사용자 원하는 방향)** : `CMD_Event` 를 cmd.c 에서 빼고(cmd = 명령 확인만), `_event_on` 변수 대신 **`Log_Port` 처럼 `Event_Port("PPAUSE:F")` 를 일이 생긴 자리에서 부르기** (net.c 가 모아 Comm_Task 가 번호 붙여 보냄). 카드는 CAN 인터럽트에서 못 부르니 판단을 `Rfid_Check`(타이머 태스크)로. → 시험 뒤에.
- 일시정지 기다림을 플래그로? → 풀리는 길이 5가지(HMI RUN · PC D · 만재 풀림 · 카드 들어옴 · 알람)라 하나라도 안 울리면 영원히 잠 → **20ms 확인 유지** (사람 반응이라 20ms 무관, CPU 거의 0).
- 시간 숫자 이름 규칙 : 시간은 전부 ms, `_MS` 이름, 맨숫자 금지 (만재 2000 · 원점 60000 · alarm_event 1000 · 완료응답 1000 · `osDelay(20)` 등) → 파일 정리할 때.
- `volatile` 통일 안 됨 (`status_1` 등) → 나중에.
- 긴급정지를 변수 없이(`estop_on()` + `status_1` 을 "아까"로) → 10군데 바뀌어 alarm 정리 때.
- 로그가 노트북 연결 전엔 버려짐 → 연결될 때까지 모아 두기 (net.c 정리 때).

## 10/19 회사 · 현장에서 바뀐 것 (net.c · cmd.c · run.c 구조 정리 + 현장 시험)

**사용자 결정 (10/19)** : cmd.c = **명령이 맞나 확인 → ACK / NAK** 만. 명령 배열엔 PC 가 보낸 내용만 (STX · ETX · ACK · 번호 X). 번호는 로더가 붙임 (PC 가 번호 붙여 보내면 NAK). 이벤트 번호도 자동. 코드는 "더럽지 않게" — 쓸데없는 함수 · 한 함수 안 변수 · 배열 줄이기. 로그 문장은 나중에 파일 하나(`debug.h` 같은)에 모아 유지보수.

**1. W6100 · 라이브러리** : 받은 `io6Library-master.zip` 과 `Drivers/Ethernet` 비교 → **코드 같음** (socket.c 줄맞춤만 다름, wizchip_conf.h 는 `Application.h` include 하나 빠짐). 소켓 8개 · 보내기 16KB + 받기 16KB (지금 2KB × 8, 3개만 씀). 소켓 하나 = 연결 하나 (같은 포트에 노트북 2대 = 소켓 2개 LISTEN 필요, 지금은 안 함). 같은 망 PC 면 누구나 58080 · 50001 볼 수 있음 (명령은 2500 만).

**2. net.c (포트 하나 = 함수 하나)** : `NET_Run = tcp_port(); service_port(); log_port();`
- 서비스 58080 : `Service_TX`(PC → 로더, PC 보낸 그대로) · `Service_RX`(로더 → PC) 각 send 3번 (사용자가 한 줄 모으기보다 이 모양 원함) / `service_port` 끊기면 LISTEN.
- 로그 50001 : **`Log_Debug(text)`**(옛 `Log_Port`, 아무 태스크, 쌓기만) / `log_port`(Comm_Task : 끊기면 LISTEN + **노트북 연결 전엔 버리지 않고 모아 둠** → 연결되면 보냄).
- 2500 : `Socket0_Line`(옛 `tcp_recv`, 글자를 `rx[index]` 에 바로 받음, 변수 3개) → `send_cmd` / `send_socket`(옛 `NET_Send`) / **`send_event(text)`**(새 번호 + STX · ETX) / `Net_On_Off`(옛 `tcp_check`, 사용자 이름) / `tcp_port`.
- `NET_Init` : FI 복사 `memcpy` 3줄, 실패 0. 주석 비유(편지 · 벨 · 창구) → 실제 이름. static 함수는 쓰는 곳보다 위라 서비스 · 로그 칸이 2500 보다 먼저.
- ⚠️ 사용자가 `Log_Port` 안에 `port_doing` · `net_open` 을 넣었던 것 → 다른 태스크가 SPI 를 만지게 돼서 `log_port`(Comm_Task)로.

**3. cmd.c**
- `cmd_answer(no, A_N, text)` 하나 (옛 `ack` · `nak`) : `A_N` = ACK 받았다 / NAK 못 받았다 / 0 완료응답. C · R 대답은 글자만 만들고 `cmd_answer(no, ACK, …)`.
- `CMD_Run(int no, char *s)` : `s[0]` 부터 명령 (옛 `s + 2` → `s`). 맨 앞 ① 완료 승인 `strcmp(s, done_text) == 0` → `order_no = 0` (대답 없음) ② `s[0]` 숫자 → `NAK wrong_number`. FP · FI 항목 번호 변수 `no` → `fno`.
- MI · MO · PO 입구 : `manual || order_no != 0` (앞 명령 안 끝남) → `can_not_command`. ACK 뒤 `done_text` 를 `AI_` / `AO_` / `EO_` 세 줄로 미리.
- `CMD_I` : `home_no = no` + **초인종 전에 `Status_HOME()`** (안 하면 CMD_Event 가 아직 W 인 걸 보고 끝났다고 착각). MI 도 같은 이유로 초인종 전에 `Status_RUN`.
- `CMD_Event` : 만재 · 일시정지 · 카드 · 알람은 `send_event`. **상태판으로 끝 판단** : `order_no` 있고 `status_1 == ALARM` → 0 (완료응답 없음) / 네 렉 다 W → 1초마다 `cmd_answer(order_no, 0, done_text)` / `home_no` 있고 W → `homing done` 한 번, RESTART · ALARM → 대답 없음.
- **`CMD_Done` · `done_no` · `move_start` · `home_text` 삭제**, 안 쓰는 include 5개 삭제. `order_no` · `done_text` · `home_no` 는 Comm_Task 혼자 씀 (태스크끼리는 상태판만).
- 로그 `MI done 12s` 는 없어짐 (Tera Term 타임스탬프로 start ~ AI 사이).

**4. run.c** : `void Motor_Run(int flag)` 4줄 (`&&` : 초인종 맞으면 실행, 성공하면 대기). `motor_basic_init` 안에 원점 시작 · 끝 (원점 중 · 부저 · `HOME  start` → `HOME  X/Y/Tilt drive no answer (setting)` → 성공 W ×4 · 부저 끔 · `HOME  done` / 실패 초기상태 · `HOME  FAIL`). `I()` · `*_Home` 은 안 건드림. CLI INIT 도 같은 함수.

**5. 정한 규칙 (아직 코드 X)** : HMI 끊김 = 켤 때 · 원점 중(`RESTART` · `HOME`)이면 **A_10** + 로그 `ALARM 10  HMI no answer while homing -> home fail`, 그 외 **A_01** + `ALARM 01  HMI no answer while running`. 02~09 도 `ALARM 번호  무엇이  언제  -> 결과` 모양으로. **`A_01(button);` 은 아직 주석.**

**6. 이야기한 개념** : 태스크에 넣을 함수 고르기 = ① 무엇을 기다리나 ② 어떤 장치를 만지나 ③ 얼마나 급한가, 반복문엔 파일 대표 함수 하나. `NET_Run` · `Event_Run` = 매번 전부(목록), `Motor_Run` = 하나만 고르기(`if`) → 그래서 모양이 다름. `E_S` 는 Motor_Task 에 넣으면 MI 끝나야 멈춤 → 알람 자리에서 바로. Event_Task 함수는 "바뀐 게 있나"만 보고 끝 (µs), 장치가 먼저 알려 주는 것만 플래그로. Flash 70~80% 까지, RAM 은 태스크 스택마다 25% 여유 (`uxTaskGetStackHighWaterMark` 로 재기).

**7. 현장 시험 (10/19 오후)** — 원점 · MI · AI 완료응답 · 카드(현장 리더) **됨**. 문제 :
- 도착 직후 `05S_1_A_02&S_2_A_02` + 로그 `ALARM 02  X no answer` : `alarm_event` 1초마다 X **두 모터(ID 3 · 4)** 0x2203 읽기, `read_reg` 이미 3번 재시도(500ms) → 약 1.5초 대답 없음. **ID 4 는 평소 아무도 안 읽어서** 통신이 불안정해도 몰랐을 수 있음. → 할 것 : 1-a 로그를 모터별로 (`ID3 ok / ID4 FAIL`), 1-b "대답 없음"은 3번 연속일 때만 알람 (원인 본 뒤 결정). `uart2_err` 같이 보기.
- **원점 중 긴급정지 → X 두 축 따로 멈춰 틀어짐** : (가) `IM_Stop` 이 감속시간 ×2 → 멈춤 ID3 → ID4 순서, 실패 재시도면 ID4 가 늦음 → 감속시간을 켤 때 미리 + 멈춤만 / iCL Modbus 브로드캐스트(주소 0, 매뉴얼 확인) 로 동시에. (나) NC 하드웨어가 드라이브 전원을 끊으면 소프트웨어로 못 고침. **사용자 확인 필요 : 긴급정지 때 X 드라이브 전원(enable)이 꺼지나.**
- **사무실에서만 카드 안 됨** = 코드 아님 (같은 펌웨어 현장 됨). 사무실 CAN 종단 120Ω(전원 끄고 H–L ≈ 60Ω) · 사무실 리더(펌웨어 500k?) · 선 H/L · GND → 현장 리더 · 선을 가져와 꽂아 보기.
- **원점 끝났는데 부저 반 번 더** : 부저 HAL 아님. `IM_Home` 마지막 100mm 이동 도착 확인이 `osDelay(IM_ACC_MS)` = **1초 간격** ([i_motor.c:296]) → 최대 1초 늦게 다음 단계. 원점 코드라 **사용자 결정 필요** (20ms 로 줄일지, 주석 "너무 일찍 하면 문제").

- 빌드 : 전체 통과, 경고 0. Flash 약 96.8KB / 256KB, RAM 약 30KB / 128KB.

## 10/20 · 10/21 현장에서 바뀐 것 (로그 파일 · X 두 모터 도착 · 버스 쉬는 시간 · 알람 11 · 12 · HMI · 수동 모드)

**사용자 결정 · 방식 (10/20 ~ 21)**
- 로그 문장은 **debug.h 한 곳** (`LOG_…`), 쓰는 곳은 이름만. "어디서 찍나"는 Ctrl+Shift+G 로 찾음.
- 사용자가 "어디를 어떻게 · 왜" 설명을 듣고 직접 고치는 쪽을 원함 (급할 땐 Claude 가). 새 함수는 꼭 필요할 때만 (`IM_Here` · `Alarm_Reset` · `Lamp_Run` · `Event_PC` 안은 사용자가 "필요 없음" → 있는 함수 이용).
- 함수 짜는 법 (노션 정리) : 층 4개 = 장치(한 번) / 기다리기(끝 조건 · 포기 시간 · 그만둘 이유) / 알람(결과 보고 판단 · 덮어쓰기 방지) / 동작(나열). 코드는 "그걸 아는 곳 · 그때 돌고 있는 곳"에.

**1. 로그**
- **debug.h** (새 헤더, 사용자가 문장 작성) : 원점 · 이동(Move · Tilting · Complete · ACCPT) · 알람 01~12 · 이벤트(MANJAE · RFID · Tilting_error · PAUSE · PAUSE_PC · CHECK_PC · RFID_PC · CLEAR · ALARM_CLEAR).
- **`Log_Debug(const char *fmt, ...)`** (net.c) : printf 모양 (`vsnprintf` → 로그 칸). `__attribute__((format(printf,1,2)))` 로 `%` 개수와 값 개수가 다르면 빌드 경고. 쓰는 곳마다 `char b[]` + `snprintf` 없어짐.
- 넣은 자리 : run.c `motor_basic_init`(HOME) · `PO`(Tilting) · `PO_pause`(MANJAE · RFID · CLEAR) · `PO_tilt`(Tilting_error) · `Motor_Run`(MOVE_DONE : `name = "MI"` + `ok` 로 정리) / cmd.c MOVE · ACCPT(완료 승인) · CHECK_PC(C) · RFID_PC(R) · PAUSE_PC(S) / event.c PAUSE(HMI STOP) / status.c `Status_Resume`(CLEAR) / alarm.c 전부 + `Alarm_Clear`(ALARM_CLEAR).
- ⚠️ `LOG_CHECK_PC` 는 PC 가 1초마다 C 를 보내면 로그 칸(512)을 금방 채움 → 노트북 없을 때 알람 로그가 버려질 수 있음. 많으면 그 줄 지우기.
- 문자열 안 큰따옴표는 `\"` (사용자 debug.h `"…"R""` 가 빌드 에러였음).

**2. X 도착 = 두 모터** : `IM_Pos(int32_t *mm1, int32_t *mm2)` (ID3 · ID4 둘 다, mm). `IM_Arrive` · alarm.c `A_05` 는 **두 모터 다 ±IM_GAP** 이어야 도착. hmi.c 수동 · `IM_Home` 원점 거리는 `mm1` 만 씀 (`now2` · `far2` 안 씀).

**3. RS485 버스 쉬는 시간 (ALARM 02 X no answer 원인 추정)** : 대기 중엔 알람 없고 **이동 중에만** 남. `bus_xfer` 의 `osDelay(BUS_GAP)` 가 **뮤텍스를 돌려준 뒤**라, Motor_Task(위치 읽기) ↔ Event_Task(알람 읽기)가 번갈아 쓸 때 프레임 사이 쉬는 시간 0 → 드라이브가 못 받음. → **usart.c `UART2_Xfer` 안 `osMutexRelease` 앞 `osDelay(2)`**, 세 모터 파일 `BUS_GAP` · `osDelay(BUS_GAP)` 삭제. **현장에서 해결 확인은 아직** (`uart2_err` 로 볼 것).

**4. Y 펄스** : CLI 디버그 명령 **`YR 0509`** (a_motor.c `AM_ReadReg` 공개 + cli.c) 로 H05_09 읽어 봄 → 드라이브 값이 바뀌어 있어서 사용자가 맞춤. 주소 = H05_뒤번호를 16진수로 (H05_11 = 050B, H0B_34 = 0B22). 디버그용 → 원인 끝났으면 지울 것.

**5. 알람 11 · 12 (alarm.c)**
- **A_11 모터 통신 끊김** = 드라이브 대답 없음. `A_02/03/04` 의 대답 없음 → `return A_11(LOG_A11_X/Y/T);` (02~04 는 이제 **드라이브가 알람 코드를 보낸 경우만**). event.c `alarm_event` 는 **원점 중에도** 확인 (조건에서 HOME 뺌, 초기상태만 안 함). ⚠️ 원점 시작 때 드라이브 재설정 순간 오알람 가능 (Y 대기 50ms × 3) → 시험.
- **A_12 랜선 빠짐** : net.c `Net_On_Off` 의 "PC 연결 중 PHY OFF" 자리 → `A_12()`. **대기 포함 모든 상태** (이미 알람 · 긴급정지면 안 함). **PC 로는 안 보냄** (`alarm_event_on = 0`, 같은 Comm_Task 라 사이에 못 나감). 단 PC `C` 대답엔 `S_1_A_12` 가 보임 → PC 확인 필요.
- 램프 · 부저는 `alarm_go` 그대로 (다른 알람과 같음). **드라이브 3종 다 통신 감시 레지스터 없음** (사용자 확인) → 선이 끊기면 E_S 도 못 감, 드라이브는 받은 목표까지 가서 섬. 진짜 정지는 비상정지 버튼.
- HMI : ESP 가 0~10 만 앎 → `hmi_alarm` 이 10 넘으면 `'0'` (작업 칸 6 알람). **사무실에서 ESP 고친 뒤 11 → '5'(주행이탈), 12 → '9'(비상정지)**.
- `Alarm_Clear` (HMI RESET) = 로그 + 드라이브 알람 리셋 ×3 + `AM_EStop(0)` + 번호 지움 + `Status_INIT` + `Buzzer_Off` (event.c RESET 은 `manual = 0; Alarm_Clear();`).

**6. HMI (hmi.c)** : 만재 8칸은 **센서 그대로 바로**. 작업 칸 "3 일시정지" · 이유 "2 만재" 는 **2초 넘게 그대로일 때만** — `hmi_manjae()` = 만재 타이머 안 돌 때 + 지금 만재 (램프 R 과 같은 기준). 대기 중 만재 · 시딩월(카드 없음, 렉2 는 `rack_channel >= 2` 일 때만 = `hmi_card_out()`) → 작업 3. 운전 중 MI · MO 는 2 운전, PO 는 `PO_pause` 가 P 로. event.c **`manjae_event()` 를 `hmi_event()` 앞으로** (안 그러면 바뀐 첫 바퀴에 타이머 시작 전이라 일시정지가 한 번 깜빡).

**7. 수동 모드** : HMI 수동 버튼(33) = 대기 **또는 알람 05 · 06 · 07 · 10** 일 때 켬 (끼임 풀기, 소프트웨어 알람이라 드라이브 멀쩡). 모터 가드 3곳 `estop == 1 || (status_1 == ALARM && manual == 0)` → 수동이면 알람 중에도 움직임, **긴급정지는 계속 막음**. cmd.c `CMD_I` 에 `|| manual` (수동 중 PC 원점 NAK, 10/15 구멍 해결).

**8. 이벤트 정리** : 새 함수 안 만들기로 → `Alarm_Clear` 로 RESET 묶기, event.c `MANJAE_MS 2000` · `ALARM_CHECK_MS 1000`. `lamp_event` 는 10/8 구조대로 event.c 에 둠. PC 이벤트(`CMD_Event` 의 FF · PPAUSE · UT · S)를 cmd.c 에서 뺄지는 보류.

**현장 시험 결과 (10/20 ~ 21)**
- 원점 · MI · AI · 카드(현장 리더) 됨. 로그 `HOME start/done`, `MI … Move` 확인.
- `ALARM 02 X no answer` 가 이동 중에 계속 → 3번(쉬는 시간) 고침, 확인 전.
- 랜선 뽑기 : 대기 중이라 A_12 안 걸렸음 (그때 조건) → 대기 포함으로 바꿈, 확인 전.
- 사무실에서만 카드 안 됨 = 하드웨어 (10/19).

- 빌드 : 전체 통과, 경고 0 (`read_map` 안 씀 경고는 사용자가 `IM_MapRead` 본문을 지워서 — h 선언 남음). Flash 약 98.1KB / 256KB, RAM 약 30KB / 128KB.

## 10/22 회사 · 사무실에서 바뀐 것 (오늘은 노션 정리 안 함 — 이 파일로 집에서 복습)

**사용자 결정 · 방식 (10/22)**
- 원하는 함수 모양 = **오늘 만든 `lamp_event`** : `if` 없이 다른 파일 블록만 나열, **순서 = 우선순위**(뒤 블록이 앞을 덮어씀). 앞으로 **파일 하나씩** 이 모양으로 바꿀 예정 → 집에서 "이 파일을 개념이랑 같이 알려 줘" 하면 그 파일만 설명 + 고칠 안.
- 프로토콜 글자는 **그 기능 파일에**, cmd.c 는 "확인 → ACK / NAK" 만.
- 사무실 시험 버전은 따로 파일 만들지 않고 **세 줄만 바꿈** (아래 "사무실 ↔ 현장").
- 백업 : `workspace_1.19.0\threeD_roder_1022`(오전, 현장 설정) · `threeD_roder_1022_pm`(cmd.c 정리 직전).

**1. 뮤텍스 ioc 로** : 사용자가 CubeMX 에서 `Uart2Lock` 만듦 → app_freertos.c 가 생성 (`osMutexNew(&Uart2Lock_attributes)`), USER CODE 의 옛 두 줄 삭제. main.h extern 그대로.

**2. 완료응답 나눔 (cmd.c)** : `done_event()` = 끝나면 완료응답 **한 번** + `done_no = order_no; order_no = 0`(다음 명령 받음) / 승인 기다림 함수(사용자가 `ACCPT_COMMAND` 로 이름 바꿈) = `if (done_no != 0) order_no = done_no;` → 1초마다 다시 + 승인 전 NAK. PC 승인 받으면 `done_no = 0`. **지금 `CMD_Event` 안 `//ACCPT_COMMAND;` 주석 = 한 번만 보내고 승인 없이 다음 명령 받음.** ⚠️ 풀 때 `ACCPT_COMMAND();` (괄호 필수 — `ACCPT_COMMAND;` 는 부르지 않고 경고만).

**3. 이동 시간 초과 = 그 자리에서 멈춤 (A_05 ~ 07)** : `MOVE_MS 5000`(사용자, 10초 → 5초). run.c 는 `A_05(IM_Arrive(x)); A_06(AM_Arrive(y)); A_07(TM_Arrive(deg));` (축마다 기다림 바로 뒤 알람 → 최대 5초, 전에는 두 축 다 기다려 최대 20초). alarm.c `A_05/06/07(int arrived)` = `if (arrived || estop == 1 || status_1 == ALARM) return 0;` → 로그 + `alarm_go`(E_S). 위치 다시 읽기 없음 (버스 한 번 절약). ⚠️ 5초 > 가장 먼 거리 · 가장 느린 % 인지 확인 (X 30% ≈ 250mm/s → 5초에 약 1000mm).

**4. 만재 FF 바로, 확정은 2초** : event.c `manjae_event` = 바뀌면 `full_event_on = 1`(FF 바로) + 타이머 2초. 타이머 콜백은 부저만. `MANJAE_MS 2000` → manjae.h. 스침 = FF 2번(켜짐 · 꺼짐) 나와도 됨 (사용자). PO_pause 의 "2초 확정 기다림" 줄은 **사용자가 지움** (쏟은 뒤 매번 2초 늦어져서) → PPAUSE:F 는 센서 그대로 (10/13 모양).

**5. 프로토콜 글자를 각 파일로 (cmd.c 483 → 316줄)** — PC 로 먼저 알림은 `*_PC()` (Comm_Task 반복문에서만 → W6100 은 여전히 Comm_Task 하나)
| 파일 | 함수 | 하는 일 |
|---|---|---|
| manjae.c | `Manjae_Text` · `Manjae_PC` | `F_1_0000&F_2_0000` (FF · C 대답 같이) / FF 보내기 |
| rfid.c | `Rfid_Text` · `Rfid_PC` | `UT_1_…&UU_2_…` (이벤트 · R 대답 같이) / 보내기 |
| status.c | `Status_Text` · `Status_PC` | C 대답 `S_1_W&S_2_A_03` (옛 cmd.c `rack_text`) / `PPAUSE:이유` |
| alarm.c | `Alarm_PC` | `S_1_A_09&…` |
| lamp.c | `Lamp_Cmd(s)` | LL 풀기 · 범위 · 켜기 → 1/0 |
| buzzer.c | `Buzzer_Cmd(s)` | `B_렉_1/0` → 1/0 |
| run.c | `Order_Set(cmd, s)` + `order_xy` | MI/MO/PO 숫자 7개 · 범위 · 좌표 (cmd.c 에서 옮김). ❓ 사용자 : run.c 가 길어짐 → `order_xy` 를 **save.c `Save_XY`** 로 옮길 안 (아직 안 함) |
- Comm_Task 반복 : `CLI_Run; NET_Run; Manjae_PC; Rfid_PC; Status_PC; Alarm_PC; CMD_Event; osDelay(1);` (CMD_Event = 완료응답 · homing done 만).

**6. X 브로드캐스트 (i_motor.c, 사용자가 "다른 모터와 레지스터 안 겹침" 확인)** : `IM_ALL_ID 0`. usart.c `UART2_Send(tx, tn)` (열쇠 → `uart2_clear` → `HAL_UART_Transmit` 막고 보냄 → 2ms → 열쇠, 대답 없음). `write16` · `write_multi` 맨 아래 `if (id == IM_ALL_ID) return UART2_Send(...) == HAL_OK;`. **쓰기는 전부 ID 0** : `IM_Move` · `IM_Stop`(감속 시간 + 멈춤 2프레임, 두 모터 같은 순간 → 긴급정지 틀어짐 대책) · `IM_AlarmReset` · `IM_Zero` · `IM_Home`(모드 · 속도 · 시작 · 100mm) · `IM_MapInit`. **읽기는 3 · 4 그대로** (`IM_Pos` · `IM_State` · `IM_Alarm`). ⚠️ 보드 시험 전 : Y(AIM) 매뉴얼에 **H18_01(0x1801 알람 리셋)** · **H0F_16~(0x0F10 매핑)** 이 있으면 그 함수만 3 · 4 로 되돌릴 것. 브로드캐스트는 "보냈다" 만 알고 "받았다" 는 모름 → `IM_Arrive` 가 두 모터 위치로 확인.

**7. 램프 = 레고 모양 (사용자가 원하는 모양의 예)**
```c
static void lamp_event(void)        /* event.c : 아래로 갈수록 우선 */
{
    lamp_tcp();         /* 평소 : PC 연결 = LL / 안 연결 = R · G 끔, 2초 뒤 Y = 카드 */
    lamp_manjae();      /* 만재(2초) · 카드 없음 : R 느리게 (타이머 도는 중이면 안 건드림) */
    lamp_alarm();       /* 긴급정지 · 알람 · 일시정지 T · F · S · M : R 만 빠르게 */
    lamp_home();        /* 원점 : 6개 느리게 */
}
```
- 사용자가 처음 쓴 `lamp_alarm` 은 `else if (…) on = …; return 0;` → 중괄호 없어 `return 0` 이 늘 실행 → 빨간불 안 깜빡이던 버그. **if · else 는 중괄호 없으면 바로 다음 한 줄만.**

**8. RESET 버튼 · 부저**
- RESET = `if (긴급정지 · RUN · HOME) break;` → `manual = 0` → `Alarm_Clear()`(드라이브 알람 리셋 · 번호 · 초기상태 · 부저 끔) → **원점 초인종** `MOTOR_FLAG` → Motor_Task 원점 → 대기. RUN 다시 안 눌러도 됨. (사용자가 넣었던 `motor_basic_init()` 직접 호출은 Event_Task 를 원점 동안 60초 멈추게 하고, 뒤의 `Alarm_Clear` 가 W 를 N 으로 덮어써서 뺌.)
- 일시정지 부저 한 곳 : status.c `Status_PAUSE` 끝 `Buzzer_On()`(M · F · S · T 전부) / `Status_Resume` 끝 `Buzzer_Off()` / run.c `PO_pause` 자동 풀림(만재 풀림 · 카드 들어옴)에 `Buzzer_Off()`. BTN_STOP · PO_tilt 의 Buzzer_On 삭제. BTN_RUN 맨 앞 `Buzzer_Off()`(사용자) 그대로.

**9. 오늘 알게 된 것 (사무실 시험)**
- `05S_1_N&…` 의 **N = 초기상태(RESTART)** (원점 안 끝남).
- X · Y 원점 안 감 → 로그 `ALARM 09` = **긴급정지 눌림으로 읽힘**(사무실엔 버튼 없음, NC 라 비면 눌림) → GND 연결.
- 틸트가 CLI `OK` 인데 안 움직임 → 이후 드라이브 전원 끄면 A_11 → 세 축 `ERR`(알람 가드). **드라이브 전원 껐다 켜면 보드도 리셋.** 원인 후보 : 원점 실패로 `TM_Home` 이 PA_04E 를 0x10 으로 남김 (값이 안 바뀌면 드라이브가 새 명령으로 안 봄) → 고칠 안 `TM_Init` 에 `write16(R_CTRL, 0)` · `ALARM_CLEAR` (사용자 결정 전).
- 현장은 긴급정지 하드웨어가 드라이브 전원을 끊어 드라이브 상태가 "청소" 되지만 사무실은 안 됨 → 사무실 · 현장 차이.
- Y 높이 틀어짐 = 동기 에이징 때 드라이브 값 바뀜 → CLI `YR 0509`(H05_09, 320 이어야). `YR 5090` 은 없는 주소라 FAIL. 주소 = H그룹_번호(16진수).
- `FP_1_2_0_690` bad_data = 입고 Y 값 개수 ≠ FS 입고 단 수.
- FP 13 을 `safe_y1 · safe_y2` 로 바꾸면 FRAM 의 FI(IP) 가 4바이트 밀림 (구조체 통째 저장, CRC 없음) → 사용자가 두 칸으로 되돌림. **FP 에 칸 추가 = IP 다시 넣거나 SAVE_VERSION 올리기.**
- 2500 의 "20초 끊고 접속대기" 는 이미 있음 : net.c `Net_On_Off`(FI 7 `net_timeout`, 명령 한 줄(ETX) 받을 때 `last` 다시) → `disconnect` + `net_open`(LISTEN). keep-alive(약 6~7초)는 PC 가 죽은 경우.

**사무실 ↔ 현장 (세 줄 + 주석)** : i_motor.c `IM_2_ID` 사무실 3 / 현장 4 · i_motor.h `IM_HOME_FORCE` 10 / 35 · a_motor.h `AM_HOME_TORQUE` 50(주석 100) / 600. 사무실은 event.c `hmi_event` · `Rfid_Init` 주석, 긴급정지 입력 GND. **지금 파일 = 현장 값, HMI · 카드 켜짐, `A_01` 켜짐.**

### 이 프로그램이 도는 흐름 (복습용)
```
전원 → main : HAL · 클럭 · 주변장치 init → MX_FREERTOS_Init (뮤텍스 · 타이머 2 · 태스크 3) → 스케줄러 시작
 Comm_Task (Normal)   : Save_Init(FRAM) → NET_Init(W6100 · 소켓 3개 LISTEN) → Motor_Task 초인종(MOTOR_FLAG)
                        → 1ms 반복 : CLI_Run → NET_Run(INT 핀 0 이면 SPI) → *_PC(쪽지 → PC) → CMD_Event(완료응답)
 Motor_Task (AboveN)  : 초인종 올 때까지 잠 → Motor_Run(flag) : 원점 = motor_basic_init(설정 → I() → W) / MI · MO · PO
 Event_Task (High)    : Rfid_Init(CAN · 리더 타이머) → 100ms 반복 (긴급정지 · 만재 EXTI 면 바로 깸)
                        estop_event → manjae_event → hmi_event → alarm_event(1초마다) → lamp_event
 타이머 태스크         : Manjae_Timer(2초 확정 → 부저) · Rfid_Timer(ASK_MS 2000 → 리더 'C')
 인터럽트              : UART2 IDLE(모터 대답 → XFER_DONE) · UART4(HMI) · EXTI(긴급정지 · 만재) · FDCAN(카드 대답 → Rfid_Save)
```
**PC 명령 하나 (MI)** : PC → W6100 INT 핀 0 → Comm_Task `Socket0_Line`(STX~ETX) → `send_cmd` → cmd.c `CMD_Run` : 바쁨 · 수동 · 앞 명령 → NAK / `Order_Set` 틀림 → NAK / ACK → `order_no` → `Status_RUN` → 완료 글자 → 초인종 MI_FLAG → Motor_Task `MI` (틸트 가운데 → X · Y 같이 → 기다림 + 알람 → 정지선) → `Status_WAIT` → 잠 → Comm_Task `done_event` 가 1ms 안에 W 보고 `08AI_1_1_2`.
**PO** : MO 와 같은 이동 → `PO_pause`(만재 F · 카드 S 면 멈춤, 풀리면 이어서) → Y 올리며 절반에서 틸트 → `PO_tilt`(쏟는 동안 센서 한 번도 안 닿으면 T) → `PO_pause` → 복귀 → W → EO.
**상황** : 만재 = EXTI → manjae_event(FF 바로, 2초 타이머) → 콜백 부저 / 램프 R · HMI 는 타이머 끝난 뒤. 일시정지 = `Status_PAUSE`(상태 P · 이유 · PPAUSE 쪽지 · 부저). 알람 = `alarm_go`(E_S · 상태 A · 번호 · S 쪽지 · 부저 · 일시정지 끝). 긴급정지 = EXTI → estop_event(핀 엣지) → A_09.

### 이 프로젝트의 성능 (10/22 기준, 계산 + 빌드 값 — 실측은 `uart2_us` · `uart2_err` · 스택 high-water 로 할 것)
| 항목 | 값 | 설명 |
|---|---|---|
| RS485 (UART2 115200) 1바이트 | 0.087ms | 10비트 |
| 모터 한 번 묻고 대답 | **약 4~5ms** | 보내기 8B 0.7 + 드라이브 생각 ~1 + 대답 9B 0.8 + 쉬는 시간 2 (`UART2_Xfer` 열쇠 안) |
| X 위치 (`IM_Pos`, 두 모터) | 약 9ms | 이동 중 1초에 약 100번 → **이동 중 버스는 거의 100% 바쁨** |
| X 이동 · 멈춤 명령 | 브로드캐스트 1프레임 | `HAL_UART_Transmit` 31B 약 2.7ms 동안 CPU 가 기다림(DMA 아님) + 2ms. 두 모터 동시 출발 · 정지 (전 : 4~5ms 차이) |
| 대답 없을 때 최악 | X · 틸트 500ms × 3 = 1.5초, Y 50ms × 3 | 그동안 그 태스크 + 열쇠 기다리는 태스크 멈춤 → A_11 |
| alarm_event (1초마다) | 4번 묻기 ≈ 18ms 버스 | X 두 모터 + Y + 틸트 |
| 모터 통신 CPU | 한 번에 수십 µs | DMA 가 글자 옮김 + IDLE 인터럽트 초인종 → 기다리는 동안 태스크 잠 (**버스는 바쁘고 CPU 는 놂**) |
| PC 명령 → ACK | 약 1~2ms | Comm_Task 1ms 마다 INT 핀 확인 → SPI 로 읽음 → 확인 → ACK |
| 도착 → 완료응답 | 1ms 안 | 상태판 W → `done_event` |
| Comm_Task 1ms 한 바퀴 | 몇 µs (CPU 약 1%) | 핀 1개 · RXNE · 쪽지 변수 확인. SPI 는 일 있을 때만 |
| Event_Task 100ms 한 바퀴 | HMI 대답 기다림이 대부분 (최대 50ms) | 긴급정지 · 만재는 EXTI 로 바로 깸 |
| 긴급정지 반응 | 하드웨어 NC = 바로 / 소프트웨어 E_S = EXTI → Event_Task 즉시, 단 버스 열쇠 기다림 최대 수 ms (드라이브 무응답이면 최대 500ms) | 진짜 안전은 하드웨어 |
| 이동 시간 초과 | `MOVE_MS` 5초 → 그 자리 E_S | |
| 만재 확정 · 카드 묻기 | 2초 타이머 / `ASK_MS` 2000 (주석은 0.5초 — 확인할 것) | 리더는 카드 바뀌면 먼저 보냄 |
| Flash / RAM | 약 98.2KB / 256KB (38%) · 약 30KB / 128KB | 힙 20KB 고정, 스택 Event 2KB · Motor 2KB · Comm 4KB · 타이머 512워드 (실측 안 함) |
- 성능 순서(사용자) : 안전 > 버스 > CPU > RAM. 다음 단계 후보 : 버스 = "걸릴 시간 계산해서 자고 묻기"(`*_Time`) / CPU = Comm_Task 초인종(W6100 EXTI + CLI 인터럽트) / RAM = 스택 실측 후 줄이기.

## 10/23 회사 · 현장에서 바뀐 것 (테스트하며 많이 바뀜 — 보드에서 확인한 것 표시)

**사용자 결정 · 방식 (10/23)**
- 함수는 **블록 이름만 보이게** (`Pause_Set` · `btn_run` · `lamp_event` 처럼). 이벤트 함수 = "조건 → 할 일 나열". 바뀐 뒤 사용자 : "지금 구조 그대로에서 더 유지보수 쉽게" (구조는 그대로, 다듬기만).
- **변수 이름 · 블록 안에 숨긴 처리 싫어함 → 하지만 같은 줄이 여러 곳 반복되면 블록으로** (일시정지 = `Pause_Set` / `Pause_Clear`).
- cmd.c 에 `{ }` 블록 · 지역 변수 만들지 말 것 (FP 에서 했다가 지적받음 → 맨 위 변수로).
- 백업 : `workspace_1.19.0\threeD_roder_1023` (오전 정리 전).

**1. 원점 · RESET**
- 켤 때 : Comm_Task → `MOTOR_FLAG` → Motor_Task `motor_basic_init` (설정 → `I()` → W / 실패 N). 실패 끝 `return I();` 버그 → `return 0;`.
- **RESET = 알람 · 수동 풀고 초기상태(N)까지만**, 원점은 **HMI RUN** (사용자). RUN · PC I · CLI INIT 도 같은 `motor_basic_init`.

**2. event.c 버튼 = 블록** : `hmi_event` 의 switch 는 한 줄씩 → `btn_run`(부저 끔 · 만재 알림 끔 · N 이면 원점 · 일시정지면 `Pause_Clear`) / `btn_stop`(`Pause_Set(0,'M')`) / `btn_reset` / `btn_manual`(대기 또는 알람 02~07 · 10, 긴급정지 중 X) / 음소거.
- 수동 모드가 알람 중 안 먹던 것 : hmi.c `hmi_alarm` 이 알람 번호를 먼저 보내서 HMI 가 수동인 줄 몰랐음 → **수동 `'1'` 을 알람 번호보다 먼저**.

**3. 일시정지 (status.c 블록 3개 + run.c 정지선)**
- `Status_PAUSE` / `Status_Resume` = 상태판만 (멈추기 전 상태 `before_1~4` 기억 → 풀면 R/W 그대로). `Status_PAUSE` 는 알람 · 원점 · 초기상태면 0, **STOP(M) 은 움직일 때(RUN)만** (대기 중 STOP · PC S · CLI S 무시).
- **`Pause_Set(rack, why)`** = 상태 P + PPAUSE 쪽지 + 부저 + 로그(`LOG_PAUSE_SET`) / **`Pause_Clear()`** = 되돌림 + 부저 끔 + 로그 / run.c **`pause_wait()`** = 정지선.
- 일시정지는 **모터를 안 세움(표시만)** → 정지선 : MI 도착 뒤 · PO 기울이기 전 · (PO_tilt 쓸 때) 쏟은 뒤. 진짜 세우는 건 알람 `E_S` 와 긴급정지 하드웨어.
- **풀기는 전부 HMI RUN** (`btn_run` : `if (pause_why) Pause_Clear();`) · PC D(F · T). 센서가 풀려도 자동 해제 없음 (사용자).

**4. 만재 · 카드 (보드 확인됨 — 19:28 빌드)**
| | 스침 (2초 안) | 2초 넘게 만재 |
|---|---|---|
| PC | FF | FF |
| HMI 만재 칸 · 작업 · 이유 | 안 바뀜 | 칸 켜짐 · 3 일시정지 · 2 만재 |
| 부저 · 그 렉 R 느리게 | ✕ | ✅ HMI RUN 까지 유지 |
| MI · MO | 계속 | 계속 (명령도 받음, PPAUSE 없음) |
| PO 가 **그 렉 · 그 단** | 틸트 | **PPAUSE:F** + 그 렉 R 빠르게 → RUN 까지 |
- 2초 판단 = manjae.c **`manjae_stable()`** (센서 바뀐 시각 `changed_at` 으로 직접). ⚠️ `osTimerIsRunning` 은 `osTimerStart` 직후 아직 "안 돎"(타이머 태스크 우선순위 낮음) → 스치자마자 2초 지난 걸로 착각하던 버그. **만재 타이머(`Manjae_Timer`)는 이제 안 씀** (콜백 비어 있음, ioc 에 남음).
- event.c `manjae_1` · `manjae_2`(그 렉 만재 알림 중, event.h extern) : `manjae_event` 가 2초 확정 때 켬 (+ 로그 · 부저), `btn_run` 이 끔. lamp.c `lamp_manjae(rack1, rack2)`, hmi.c 가 읽음.
- 카드 : `rfid_event` = 로그만 (PC UT · UU 는 rfid.c). **PO 가 그 렉 카드 없음 → PPAUSE:S** → RUN 까지. MI · MO 상관없음.
- run.c `PO_pause` 함수 삭제 → PO 안 3줄 : `if (manjae_on(rack,dan) && manjae_stable()) Pause_Set(rack,'F'); if (card_on(rack)==0) Pause_Set(rack,'S'); pause_wait();`
- manjae.c : `manjae_full()` · `manjae_rack(rack)` · `manjae_stable()`. rfid.c : `card_out()`.

**5. 램프 (event.c `lamp_event` 4줄, 아래로 갈수록 우선)** : `lamp_tcp`(평소 : PC LL / 안 연결 R · G 끔 · 2초 뒤 Y 카드) → `lamp_manjae(manjae_1, manjae_2)` → `lamp_alarm`(긴급정지 · 알람 = 두 렉, **일시정지 = P 인 렉만**, R 빠르게) → `lamp_home`(원점 6개 느리게). 사용자가 쓴 `else if … ; return 0;` 중괄호 버그 고침.

**6. 명령 형식 (프로토콜)**
- MI · MO · PO **숫자 8개** : `렉_열_단_리프트속도_틸트속도_시작지연ms_틸트복귀대기x10ms_틸팅각도` (예 `01PO_1_2_3_080_080_500_050_045`). run.c `Order_Set` → `order_tilt_angle` 추가. PO 복귀대기 20~300 · 각도 20~90 **밖이면 끝값으로 맞추고 받음** (NAK 아님).
- PO 각도 = 명령 값 (`Motor_Run` → `order_tilt_angle`). **틸트 복귀 대기** = 기울기 도착 뒤 `osDelay(return_delay * 10)` (PO_tilt 주석이어도 기다림. `PO_tilt` 풀면 osDelay 줄 지울 것).
- **FP 항목 = 한 글자** : `'1'~'9'`, 10 `':'` 11 `';'` 12 `'<'` 13 `'='` (cmd.c `char item` → save.c `FP(rack, char no, …)` 의 `case ':'` 등). 램프 시간은 원래 아스키 `'0'`(무한) ~ `'l'`(60초).
- 좌표 표 → save.c **`Save_XY(in, rack, col, dan, &x, &y)`** (run.c `Order_Set` 이 부름).

**7. 모터 · 버스**
- X **쓰기 전부 브로드캐스트 ID 0** (`IM_Move` · `IM_Stop` · `IM_AlarmReset` · `IM_Zero` · `IM_Home` 설정 · 시작 · 100mm · `IM_MapInit`), usart.c `UART2_Send`(대답 없음, `HAL_UART_Transmit`). 읽기는 ID 3 · 4. ⚠️ Y AIM 에 H18_01(0x1801) · H0F_16(0x0F10) 있으면 그 함수만 되돌릴 것 (확인 전).
- `*_Arrive` 반복마다 `osDelay(ARRIVE_MS 20)` → 이동 중 버스 약 30% (도착 아는 건 최대 ~30ms 늦음, 체감 없음).
- A_05~07 = `A_05(IM_Arrive(x))` 모양 (위치 다시 안 읽음). `MOVE_MS 5000`.

**8. 현장 · 사무실에서 알게 된 것**
- **FRAM FP 12(가감속, ms) 가 1500 으로 바뀌어 있었음** → 틸트 · Y 가 느림 / 에이징 중 **A06**(Y 5초 못 감) 원인 추정. FP 11 = 속도 rpm(클수록 빠름), FP 12 = 가감속 ms(**클수록 느림**). 권장 `FP_1_<_1500_300_100` (X, 틸트, Y). 지금 PO 틸트 % 는 명령 값이 아니라 FRAM `TILTING SPEED`(FP 7).
- 사용자 에이징 프로그램 `Downloads\RobotAging_Windows_manual\RobotAging_Windows\RobotAging.cs` : 정상 8숫자 명령, 완료 승인 뒤 다음 명령, 2초마다 C → 프로그램 문제 아님.
- PPAUSE · FF · UT 는 서비스 58080 에도 `[RX]` 로 복사됨 (send_socket).
- `YR` 주소 = H그룹_번호 16진수 (`YR 0509`).

## 10/25 · 10/26 집에서 바뀐 것 (시연 준비 + 정리) — 보드 시험 안 함

**사용자 결정 · 방식 (10/25 ~ 26)**
- "해도 되나" 확인을 위해 새 함수(`Can_Move` 등 5개, `Status_Can(job)`)를 만들었다가 **사용자가 거절** ("보기 어렵다", "Status_PAUSE 가 있는데 왜") → 지움. 규칙 : **확인은 그 일을 하는 블록 맨 앞에** (`Status_PAUSE` 모양 : 안 되면 return), 새 함수 X.
- 바꾼 건 백업 폴더를 따로 만들어 회사로 가져감 (아래 4).

**1. ALL 명령 (거래처 기본 설정)** : PC `ALL_PIMZ` → save.c `Setting_Default_PIMZ()`(FS + FP 를 정해 둔 값으로 → `FRAM_Save`) → ACK / 모르는 거래처 · 저장 실패 NAK `bad_data`. cmd.c `CMD_ALL (('A' << 8) | 'L')`. 거래처 추가 = 함수 통째 복사 → 이름 · 값 바꿈 → save.h 선언 + cmd.c `CMD_ALL` 에 `strcmp` 한 줄. FS · FP 따로 저장도 그대로. FI(네트워크)는 안 바꿈.

**2. event.c = 블록 나열 (lamp_event 모양, 동작 같음)** — "확인은 그 블록 맨 앞" 으로 옮기고 한 줄짜리 함수 지움
```c
static void hmi_event(void)
{
    int button = HMI_Run();     /* 상태 보내고 버튼 받기 */
    A_01(button);               /* 통신 안 되면 알람 01 */
    switch (button) {
    case BTN_RUN:       btn_run();          break;   /* 원점 / 일시정지 풀기 */
    case BTN_STOP:      Pause_Set(0, 'M');  break;   /* 일시정지 M (status.c) */
    case BTN_RESET:     Alarm_Clear();      break;   /* 수동 · 알람 풀고 초기상태 (alarm.c) */
    case BTN_MANUAL:    btn_manual();       break;
    case BTN_SOUND_OFF: Buzzer_Off();       break;
    case BTN_TILT_Lift: … case BTN_TRAVEL_Back: HMI_Manual(button); break;   /* 21 ~ 26 */
    }
}
```
- `btn_stop` 삭제 (한 줄), `btn_reset` 삭제 → alarm.c `Alarm_Clear` 맨 앞 `if (estop == 1 || RUN 4개 || status_1 == HOME) return;` + `manual = 0;`.
- 수동 버튼 if 블록 삭제 → hmi.c `HMI_Manual` 맨 앞 `if (manual == 0) return;`. `if (button == 0) return;` 삭제 (0 · `HMI_FAIL` -1 은 어느 case 에도 안 맞음).
- 안 쓰는 include 삭제 : cli.h · i_motor.h · t_motor.h · run.h · stdio.h. 남은 함수 : `estop_event` · `btn_run` · `btn_manual` · `hmi_event` · `manjae_event` · `rfid_event` · `alarm_event` · `lamp_event` · `Event_Run` · EXTI 콜백.

**3. "지금 해도 되나" 목록 = status.c 맨 위 주석** (코드는 원래 자리) :
| 일 | 파일 · 함수 | 안 되는 때 |
|---|---|---|
| 일시정지 | status.c `Status_PAUSE` | 알람 · 원점 · 초기상태 / STOP 은 움직일 때만 |
| RESET | alarm.c `Alarm_Clear` | 긴급정지 · 동작 중 · 원점 중 |
| HMI RUN 원점 | event.c `btn_run` | 긴급정지 · 초기상태 아님 |
| HMI 수동 | event.c `btn_manual` | 대기 · 알람 02~07 · 10 아니면 |
| PC MI · MO · PO | cmd.c `CMD_Run` | 네 렉 다 W 아님 · 수동 · 앞 명령 승인 전(`order_no`) |
| PC I | cmd.c `CMD_Run` | 원점 · 동작 · 일시정지 · 수동 |
- 원점 · MI 확인을 `Status_HOME` · `Status_RUN` 안에 못 넣는 이유 : `Status_HOME` 은 run.c `motor_basic_init` 도 원점마다 부름(스스로 막힘) / MI 는 확인 → `Order_Set` 순서가 바뀌면 동작 중 주문서가 덮어써짐.
- "Motor_Task 가 동작 중이면 다음 동작 못 함" 은 규칙이 아니라 구조 (Motor_Run 이 끝나야 다음 초인종을 봄).

**4. 만재 2초 = 칸마다 따로 (manjae.c)** — 백업 `threeD_roder\backup_1026\` (오늘 바뀐 파일 10개 before · after + 읽어보기.txt, zip 도 같은 이름)
- 전 문제 : `changed_at` 시계가 8칸에 하나 → PO 가 렉1 3단(오래 만재)에 도착 직전 2초 안에 **다른 칸**(렉2 1단)이 스치면 `manjae_stable()` = 0 → PPAUSE:F 안 걸고 쏟음. (센서 값 · FF · HMI · `manjae_1/2` 는 그대로, "2초 확정"만 2초 동안 0)
- 지금 : `last_on[2][4]`(-1 로 시작 → 켤 때 첫 번째는 바뀜 = 전처럼 FF 한 번) + `changed_at[2][4]`. `manjae_change()` = 8칸을 `manjae_on` 으로 하나씩 비교, 바뀐 칸만 시각 기록. **`manjae_stable(rack, dan)`** = 그 칸만 / **`(0, 0)` = 8칸 다**(전과 같은 뜻).
- 부르는 곳 : run.c PO `manjae_stable(rack, dan)` (구멍 막힘) / event.c `manjae_event` · hmi.c `HMI_Run` = `(0, 0)` (동작 그대로, 나중에 칸별로 바꿀 수 있음).
- 비용 : RAM +64B, 100ms 마다 핀 16번 읽기 (수 µs), 버스 없음.
- 시험 : 10/23 만재 표 + **렉1 3단 만재인 채 PO 렉1 3단 → 도착 직전 렉2 1단 스침 → PPAUSE:F 가 걸려야 맞음**.

**5. 그 밖에 (주석 · 정리, 동작 같음)** : status.h 한 줄에 붙어 있던 `Pause_Clear` · `Status_Alarm` 선언 나눔 / event.c 머리 주석 실제 순서 · 없어진 `PO_pause` 이름 지움 · 탭 하나 / rfid.c "2초마다" → "0.5초마다" (`ASK_MS 500` 이 맞음, 위 10/22 표의 2000 은 틀림).
- 이야기한 개념 (노션 [10/25 페이지](https://app.notion.com/p/40410d3ee5448132bb38d28d30d8edb2)) : 일시정지 = 상태판 P("문 닫힘" 간판 → HMI · PC NAK · 램프) + `pause_why`(정지선 신호등 → `pause_wait` 의 `while (pause_why) osDelay(20)`) / 모터가 서는 방법 3가지 (목표 도착 = 일시정지 · `E_S` = 알람만 `alarm_go` 에서 · 긴급정지 NC 하드웨어) / `osDelay` 는 태스크만 자고 SysTick 1ms 가 깨움 / 우선순위 Motor(32) > Comm(24) 라 로그 순서가 안 꼬임.
- 빌드 : 명령줄 전체 컴파일 + 링크 통과 (경고 = 원래 있던 `ACCPT_COMMAND` · `PO_tilt`). **CubeIDE 는 열린 탭 저장하지 말고 F5 → Clean → Build.**

## 10/26 회사 · 현장에서 바뀐 것 (시딩월 = 만재와 같은 틀) — 빌드 · 플래시 됨

- **프로젝트 = `Downloads\threeD_roder (3).zip`** (10/25 ~ 26 집 코드) 로 통째 바꿈. 바꾸기 전 백업 `workspace_1.19.0\threeD_roder_1026_before`.
- **시딩월(카드) 2초 확정 (rfid.c)** : `CARD_MS 2000`, `changed_at_1/2`(`Rfid_Save` 4줄마다 바뀐 시각 기록), **`card_stable(rack)`** = 그 렉 카드 상태가 2초 그대로면 1 (만재 `manjae_stable` 과 같은 모양). 이유 : 켤 때 리더가 대답하기 전 `card_ok = 0` 순간 · 진동으로 잠깐 못 읽음을 시딩월 이탈로 잡던 것.
- **event.c `card_1` · `card_2`** (event.h extern, `manjae_1/2` 와 같은 뜻 = 그 렉 알림 중) : `rfid_event` = `done_1/2`(static, 카드 있으면 0) + `card_on(1) == 0 && card_stable(1)` 이면 한 번만 `card_1 = 1` + `LOG_CARD_OUT` (렉2 는 `save.fs.rack_channel >= 2` 일 때만, `#include "save.h"`). `btn_run` 이 `card_1 = card_2 = 0` (HMI RUN 까지 유지). `lamp_event` = `lamp_manjae(manjae_1 || card_1, manjae_2 || card_2)`.
- **hmi.c** : `hmi_task` RESTART 뒤 `if (manjae_1 || manjae_2 || card_1 || card_2) return '3';` / `hmi_pause` 일시정지 블록 뒤 `card_1 || card_2` → `'1'` 시딩월, `manjae_1 || manjae_2` → `'2'`.
- **run.c PO 정지선** :
  ```c
  while (manjae_on(rack, dan) && manjae_stable(rack, dan) == 0) osDelay(20);   /* 스침인지 2초 확인 */
  if (manjae_on(rack, dan) && manjae_stable(rack, dan)) Pause_Set(rack, 'F');
  if (card_on(rack) == 0) Pause_Set(rack, 'S');                               /* 카드는 바로 (2초 기다림 X) */
  pause_wait();
  ```
  카드가 다시 들어와도 자동으로 안 감 → **HMI RUN 만** (사용자). MI · MO 는 만재 · 카드 상관없음.
- **틸팅 검사(명령 9번째 숫자)는 아직 안 만듦** (사용자 결정).
- 이야기만 한 것 : 시작 지연(`order_move_delay`)이 PO 도착 뒤에만 쓰이고 MI · MO 앞엔 안 씀 → 500 · 800 차이 없던 이유. 고칠 안 = `Motor_Run` 에서 동작 전 `osDelay(order_move_delay)` + PO 안 줄 삭제 (**사용자 결정 전, 안 바꿈**).
- 노션 정리 : [10/26 파일별 "왜 이렇게 짰나" (그림 + 예시 코드)](https://app.notion.com/p/40410d3ee54481ffbfe8e2569cf23f41).

## 10/27 회사에서 바뀐 것 (서비스 포트 명령 · 인터럽트 · CLI · usart/fdcan 정리 · FRAM 덩어리 주소) — 전체 빌드 통과, 보드 시험 안 함

**사용자 결정 · 방식 (10/27)**
- "천천히, 순서대로, 이 파일 이 함수는 이런 기능 → 이렇게 짜면 간단" 으로 설명 후 바꿈. **이해 안 됐는데 바꿔 버리면 안 됨** (오늘 1단계 때 지적). 바꾼 뒤엔 "전 → 후 + 왜" 로 보여 줄 것.
- 어렵게 짠 코드 싫어함 → 변수 · 줄 하나하나 "왜 필요한지" 설명할 수 있어야 함. 불필요하면 뺌 (`reply_sock` 뺌).
- Comm_Task 주기는 **1ms 유지** (10ms 로 늘리지 않음). 이유 : 초인종 있는 일은 주기와 상관없이 바로, 초인종 없는 일(쪽지 · 완료응답 · 20초 · 랜선)은 1ms 가 빠름, 부하는 약 1%.
- 폴링 원칙 정리 : 장치가 먼저 알려 주는 것 = 인터럽트 / 못 알려 주는 것(Modbus 모터, HMI, 랜선, 시계) = 폴링이 맞음, **간격만 그 일에 맞게**.

**1. 서비스 포트 58080 = 명령도 받음 (net.c)** : 2500 과 같은 길, 차이는 20초 끊기 없음 + `[TX]` / `[RX]` 표시.
- `Socket0_Line()` → `Socket_Line(sock)` : 줄 칸 `rx[2][160]` · `index[2]` (소켓마다 따로, 섞임 방지), `last`(FI 7 20초)는 2500 만. `service_port` 에 `RECV → Socket_Line(Service_SOCK)`.
- `Service_TX(no, cmd)` : `[TX] 08MI_1_1_2` (번호 붙임).
- **명령 하나 = 번호 하나** : `send_cmd` = `no = done_no; if (strcmp(cmd, done_text) != 0) no = Roder_Number();` → PC 승인 `AI_1_1_2` 도 그 명령 번호(08), 다음 명령 09. cmd.c `done_text` · `done_no` static 뺌 + cmd.h extern.
- 58080 명령의 ACK · 완료응답도 **2500 PC 에 같이 감** (`reply_sock` 넣었다가 사용자 결정으로 뺌, 정비용으로만 씀).

**2. W6100 INT 인터럽트 (2단계)** : ioc 는 이미 켜져 있었음 (PE1 EXTI1 Falling 풀업, NVIC 5). event.c EXTI 콜백 `W610_INT_Pin → osThreadFlagsSet(Comm_TaskHandle, NET_FLAG)` / main.h `Comm_TaskHandle` extern / app_freertos.c `osDelay(1)` → `osThreadFlagsWait(NET_FLAG, osFlagsWaitAny, 1)`. PC 명령은 바로 깸, 나머지는 1ms 그대로.

**3. CLI = UART1 인터럽트 받기 (cli.c · usart.c)** : ioc USART1 인터럽트 이미 켜짐(7). `USART1_Init 2` 에서 `HAL_UART_Receive_IT(&huart1, &cli_ch, 1)` → `HAL_UART_RxCpltCallback` 이 `cli_buf[64]` 보관함에 넣기만 → `CLI_Run` 이 전부 꺼냄 : 글자 echo / **Backspace · Delete 로 지우기** (`"\b \b"`) / 엔터 실행. 붙여넣기도 안 빠짐. ErrorCallback 에 USART1 = 받기 다시 시작. **`REG` 만 치면 H05_09** (`reg = 0x0509` 처음 값 + `strncmp(text, "REG", 3)`). ⚠️ **Tera Term 로컬 에코 끄기** (안 끄면 글자 두 번).

**4. usart.c · fdcan.c USER CODE 읽기 쉽게 (동작 같음, ST 생성 부분 안 건드림)**
- usart.c 맨 위 지도 + "묻고 대답 받기 1~6단계" 주석 (1 찌꺼기 지우기 → 2 보내기 → 3 잠 → 4 [보내기 끝 콜백] 받기 시작 → 5 [대답 끝(IDLE) 콜백] 깨움 → 6 길이 확인). 변수 이름 `motor_tx/rx/want/got/task` · `hmi_got`. `uart2_clear` + UART4 같은 8줄 → `uart_clear(h)` 하나. `UART2_Xfer` · `UART4_Xfer` 결과 = `보내기 && 잠 && 길이` 한 덩어리 (HAL_TIMEOUT 구분 없앰 — 부르는 곳이 전부 `== HAL_OK` 만 봄).
- fdcan.c : 지도 주석, `Send_to_Reader` 헤더 8줄 → 2줄 (나머지 칸은 `{0}` = 기본값, ST 헤더에서 0 확인), 콜백 = `rack` 먼저 정하고 `while` 한 줄.
- IDLE = UART 하드웨어 기능 ("선이 글자 1개 시간 조용 = 말 끝남"), 함수 이름 아님. `HAL_UARTEx_ReceiveToIdle_DMA` · `HAL_UARTEx_RxEventCallback` 은 ST 가 이름을 정함.

**5. FRAM = 덩어리마다 주소 (B 방식, 동기들과 비슷)** — **SAVE_VERSION 6 → 7 : 이 펌웨어로 처음 켜면 FS · FP 0, FI 기본값(172.20.0.1:2500) → PC 에서 `ALL_PIMZ` · FI 다시 넣기**
- 전 : `SAVE_Data` 268B 를 통째로 0번지 (패딩 포함, 중간에 칸 넣으면 뒤가 밀림 = 10/22 IP 사고).
- 후 : save.h **FRAM 지도** `HEAD_ADDR 0x0000`(magic · version 4B) · `FS_ADDR 0x0010`(9B) · `FP_ADDR 0x0100`(228B, 0x03FF 까지 여유) · `FI_ADDR 0x0400`(24B). fram.c = `FRAM_Write(addr, data, size)` · `FRAM_Read(addr, data, size)` 두 개만 (save 를 모름). save.c 는 **바꾼 덩어리만** 저장 : FS() = FS + FP(안 쓰는 칸 0) / FP() = FP / FI() · FD() = FI / ALL_PIMZ = FS + FP / Save_Init = 덩어리마다 읽기 → magic · version 확인 → 아니면 전부 0 + 네트워크 기본 + 전부 저장.
- 칸 추가 규칙 : 그 덩어리 안 맨 끝에 + 다음 덩어리 주소를 안 넘는지만 확인. 새 덩어리(알람 기록 등)는 FI 뒤 새 주소(예 0x0500). 칩 모델은 코드에 없음 (주소 2바이트 = 최대 64KB).

**6. run.c 정리** : `PO` 인자 `move_delay` 삭제 (시작 지연은 `Motor_Run` 의 `osDelay(order_move_delay)` 가 MI · MO · PO 공통으로 함), 주석 위치. `MOVE_MS` 는 지금 alarm.h **8000** (10/22 표의 5000 아님).

**7. 이야기만 한 것 (복습용)**
- 모터 이동 중 묻는 주기 : X 약 29ms (위치 2번 ≈ 9ms + 20ms 쉼) · Y 약 25ms (1번 ≈ 5ms + 20) · 틸트 약 29ms (위치 + 상태). 9ms 동안도 태스크는 대부분 잠 (보냄 → 잠 → IDLE 이 깨움). 20ms 잠을 깨우는 건 SysTick. 버스 약 30%, CPU 1% 미만. 대기 중엔 alarm_event 1초마다 4번(18ms).
- 1ms 마다 SPI 로 묻는 것 : PC 연결 중 `Net_On_Off` 의 `wizphy_getphylink` (랜선) → 100ms ~ 1초면 충분 (**안 고침, 후보**).
- 플래그는 2진수 칸 : 1 · 2 · 4 · 8 · 0x10 …(1 이 하나), `|` 로 합쳐 기다리고 `&` 로 고름. 태스크마다 따로지만 공용 함수(UART2_Xfer 의 XFER_DONE 0x01) 때문에 전체에서 안 겹치게.
- 백업 : `backup_1027\before_step2_cli\` (net · cmd · usart · fdcan · cli · event · app_freertos · cmd.h · main.h · net.h) · `backup_1027\before_fram_B\` (fram · save · run).

- 빌드 : 전체 통과, 경고 2 (원래 있던 `ACCPT_COMMAND` · `PO_tilt`). Flash 약 99.9KB / 256KB, RAM 약 30.3KB / 128KB.

## 10/29 회사에서 바뀐 것 (주문서 없애기 · 모터 문 · 안전위치 경로 · 상태 I · 완료 로그) — 전체 빌드 에러 0 · 경고 0, 보드 시험 안 함

**사용자 결정 · 방식 (10/29)**
- GPT 와 정리한 설계 문서를 가져옴 (파일 역할 : net = TCP · 번호 · 완료응답 · 재전송 / cmd = 확인 · ACK/NAK · 요청 / run = 실행 · 안전위치 · 완료 판단 / save = FRAM / event = HMI · 센서 판단 / manjae · rfid = 상태 · 변화 / app_freertos = 태스크). 위 작업 방식 12번 규칙도 이날 정함.
- cmd.c 는 **확인용만** (읽기 · 검사 · ACK / NAK · 문 고르기). 태스크 · 상태를 cmd 가 직접 만지지 않음.
- 상태판은 **보여 주기용** (HMI · 램프 · PC C). "바쁜가 · 끝났나"를 상태판으로 짐작하지 않음 → run.c `busy`.
- 프로토콜 상태 글자 = **W · R · I · P · A** (N 없음). 켤 때 · RESET 뒤 · 원점 중 = **I**, 원점 끝 = W.
- 렉 방향은 지금 코드가 맞음 (홀수 렉 = `right_*` 표). 프로토콜 표의 "3DS 홀수=좌측 (로봇 기준)" 과 같은 실물.
- 안전위치 경로 = 시뮬레이션 **A "출구만 지키기"** (입고대 안에서는 X 만, 통로에서는 X · Y 같이).

**1. 빌드 맞추기 (GPT 와 하다 멈춘 것)** : run.c `PO_tilt` = `(rack, dan, ms)` 로 `ms` 를 남은 시간으로 써서 닿으면 `return`, 끝까지 안 닿으면 `Pause_Set(rack,'T')` (변수 없음). cli.c FRAM 출력을 배열(`save.fp.in_y` …)로, `SAFE_Y` 목록 추가. save.c `FP()` 의 `count` 삭제(개수 검사는 cmd.c `need`). cmd.c `no`→`PC_num`, `fno`→`fi_no`, `fp_no`, `FI(fi_no, value)`, `int option;`.

**2. 지운 것** : run.c `Order_Set` · `order_*` 10개 (사용자) · cmd.c `CMD_Event`(homing done) · 승인 처리(`done_text` · `done_no` · `order_no` · `home_no`) · cmd.h extern · app_freertos.c `CMD_Event();` · net.c `send_cmd` 는 늘 새 번호 (`Roder_Number()`). **→ 완료응답(AI · AO · EO · homing done) · PC 승인은 지금 없음 (net.c 에서 새로 만들 것).** `Save_XY` 도 없음 (FRAM 표가 배열이라 `save.fp.right_x[col-1]` 로 바로).

**3. flag.h (새 헤더, 정의만)** : 초인종 번호를 cmd.h · event.c 에서 모음. 그 뒤 모터 초인종 4개 → `MOVE_FLAG` 하나.

**4. 모터 문 (run.h · run.c)** — 구조체 `MOVE` = `cmd`(CMD_MI · MO · PO · I) + 명령 숫자 프로토콜 순서 (`rack col dan lift_speed tilt_speed delay return_delay tilt_angle tilt_check`)
- `int Motor_Request(MOVE m)` : `busy` 거나 알람이면 0 / I 중엔 원점(`CMD_I`)만 / 받으면 `job = m` + `MOVE_FLAG` → 1. **`Motor_TaskHandle` 을 부르는 곳은 여기 하나.**
- `void Motor_Run(void)` (Motor_Task) : 원점이면 `motor_basic_init` / 아니면 표시 R → 렉 좌표 고르기 → MI · MO · PO → 성공이면 표시 W → **완료 로그** → `busy = 0`.
- `static MOVE job` · `static volatile int busy` (run.c 안에서만, 1 = Request, 0 = Run 끝).
- 부르는 곳 : cmd.c MI · MO · PO · I / event.c `btn_run` (I 이면 원점) / app_freertos.c 켤 때 → 전부 `Motor_Request(…)`. 원점 주문은 `MOVE home = { CMD_I };`.
- cmd.c MI · MO · PO : `sscanf(s + 3, …)` **MI · MO 8개, PO 9개** → 범위 (렉 · 열 · 단 · 속도 10~100 · 동작 대기 ≥ 0, **PO 만** 복귀 대기 20~300 · 각도 20~90 · 틸팅 검사 0/1) → NAK `bad_data` / 수동 · `Motor_Request` 0 → NAK `can_not_command` / ACK + 로그. cmd.c 에서 `Status_*` · `osThreadFlagsSet` · `cmsis_os2.h` 없어짐.

**5. MI · MO · PO (run.c, 매개변수 = 프로토콜 순서, 안 쓰는 칸도 받음)**
- `safe_out(lift, tilt)` (static) : 틸트 가운데 확인 → **X 만 `safe_x`** (Y 그대로 = 판이 입고대에 안 걸림). MI · MO 맨 앞.
- `MI(dan, lift, tilt, delay, return_delay, tilt_angle)` : `osDelay(delay)` → `safe_out` → `safe_y[dan-1]` → X 만 `in_x` 진입 → Y 만 `in_y[dan-1]` 들어 올림 → 정지선.
- `MO(x, y, lift, tilt, delay, return_delay, tilt_angle)` : `osDelay(delay)` → `safe_out` → X · Y 같이 렉 좌표 → 정지선. (이동만)
- `PO(rack, x, y, dan, lift, tilt, delay, return_delay, tilt_angle, tilt_check)` : `MO(…)` (대기는 MO 가 한 번) → 만재 · 카드 정지선 → Y 올리며 틸트 (`tilting_y` · `tilting_y_speed` 는 FP 7 에서 직접) → **`option[4] == 1 && tilt_check == 1 && rack <= 2` 면 `PO_tilt`, 아니면 `osDelay(return_delay*10)`** (FS 옵션 0 이면 명령 1 이어도 검사 안 함) → **틸트 가운데 확인 뒤** X · Y 같이 **안전위치** (`safe_x`, `y >= safe_y[1]` 이면 `safe_y[1]` 아니면 `safe_y[0]`) → 끝. Y 를 렉 높이로 돌리는 줄은 없어짐 (다음 MI 빨리).
- `safe_x` = **빠지는 점 X 좌표** 그대로 (1618, 빠지는 거리 in_x − safe_x = 92mm). save.c FP `':'` X 옵셋 때 `safe_x` 도 같이 옮김.

**6. 상태 N 없애기** : status.h `RESTART` · `Status_INIT` 삭제. 켤 때 값 `HOME`, `Alarm_Clear` · 원점 실패 → `Status_HOME()`, `Status_PAUSE` · `btn_run` · `alarm_event`(I 면 안 물음) · hmi.c(N 줄 삭제, I 는 '5' 원점).

**7. 완료 로그 (debug.h `LOG_MOVE_DONE` · `LOG_MOVE_POS` · `LOG_MOVE_ERR`, run.c Motor_Run 끝)** : `PO rack 1 Block 2 floor 3 Complete 7840 ms` / `now X1 X2 (X1-X2) Y T` / `goal X Y -> error X Y` (MI = 입고대 그 단, MO = 렉, PO = 끝난 안전위치). 명령마다 위치 한 번 읽음 (버스 약 20ms). `LOG_Tilting` 은 지운 채 (PO 가 열 번호를 모름).

**8. 이야기만 한 것 (복습용)**
- 6단계 시뮬레이션 : A(출구만 지키기) 가 가장 빠름 · 안전. 통로에서 서야 하는 기계면 C(가까운 안전 높이). 판 폭 **380mm** (반폭 190) → `safe_x` 거리가 판이 입고대 밑에 들어간 깊이 + 여유보다 커야 함 (지금 92mm, 현장 확인).
- PO 복귀 중 틸트하면서 Y 를 내리면 렉에 걸릴까 → 지금은 **틸트 가운데 도착 확인 후** 이동이라 안 걸림. 겹치게 하려면 `Y ≥ 렉 턱 + 여유 + 190 × sin(각도)` (턱 높이 재야 함, 아끼는 시간 약 1초).
- keep-alive 는 살아 있는 PC 를 끊지 않음. 없애면 58080 · 50001 에서 노트북이 사라졌을 때 자리가 막힘 → **그대로 둠**.
- 서비스 58080 확인 : 2500 과 같은 명령 처리 · 20초 끊기 없음 · `[TX] 번호+명령` · `[RX]` 복사 ✅.
- 상태 감시 아이디어 : 지금 로그로 오차 · X1−X2 · 걸린 시간 추세 / 다음 = HEALTH 로그(켜진 시간 · `uart2_err` · 힙 · 스택) / 드라이브 토크 · 온도 레지스터 / 진동 · 기울기는 IMU 센서(I2C3) 필요.
- 이벤트를 초인종으로 (쪽지 변수 4개 → flag.h `FF · CARD · PAUSE · ALARM_FLAG`), pause.c (걸기 · 풀기 · 정지선 · PPAUSE 한 파일) 계획만.
- 프로토콜 표에 상태 **F(만재일시정지) · S(정지)** 글자, 알람 **01 = 수동모드 · 10 = 원점귀실패** 가 있음 → 지금 코드(P + PPAUSE:이유, 01 = HMI 통신 · 11 · 12)와 다름. 7단계에서 맞출지 정할 것.
- 백업 : `backup_1029\` (before_order_delete · before_build_fix · before_MI_safe · before_flag_h · before_motor_request · before_PO_safe_return · before_done_log).

- 빌드 : 전체 에러 0 · 경고 0. Flash 약 97.2KB / 256KB, RAM 약 30.3KB / 128KB.

## 10/30 회사에서 바뀐 것 (프로토콜 V1.3 맞추기 · 만재 · 카드 정리 · 완료응답) — 전체 빌드 에러 0 · 경고 0, 보드 시험 안 함

**사용자 결정 · 방식 (10/30)**
- 동기들과 상의 + 프로토콜 V1.3 PDF (GitHub `ParkSeong0425/3D`) 기준. **TCP(2500) 연결 중 = 램프 · 부저는 PC (LL · B), 안 연결 = 보드가 판단.** HMI 는 늘 보드.
- 만재 · 카드는 "RUN 까지 알림"(`manjae_1/2` · `card_1/2`) **유지**. 알람 번호는 **지금 그대로** (01 = HMI 통신, 08 없음, 11 · 12 우리 것). MI → MI 는 **허용** (현장에서 많음). FF · UT/UU 는 PC ACK 를 받기만 (다시 보내기 X).
- 사용자 걱정 : **하루에 너무 많이 바뀌어 유지보수가 걱정** → 오늘 저녁 집에서 복습 (파일 순서 manjae → rfid → status → run → net). 다음부터 다시 작업 방식 12번 (함수 하나씩, 전 → 후, 허락 뒤).
- 규칙 정리 : **"그 일의 변수 · 판단은 그 이름의 파일 안, 다른 파일은 함수만 부름"**. 태스크 사이는 ① 자고 있는 태스크에 일 = 문 함수 + 초인종 (`Motor_Request`) ② 돌고 있는 태스크에 알림 = 표시 · 쪽지 (상태판, `ff_on`, `pause_why`). 새 초인종 안 만듦.
- 백업 : `backup_1030\` 안에 단계마다 (before_lamp_buzzer · before_buzzer_ch · before_manjae · before_B_card · before_status_ff · before_rfid · before_cleanup · before_safe_speed · before_done).

**고칠 일 생기면 볼 파일 (지도)**
| 무엇 | 파일 |
|---|---|
| 만재 (FF · 2초 · 알림) | manjae.c (변수 맨 위) |
| 카드 (UT · UU · 2초 · 알림) | rfid.c (변수 맨 위) |
| 일시정지 · C 대답 상태 글자 (P · F · S) | status.c ("해도 되나" 표) |
| MI · MO · PO · 입고대 속도 · 완료응답 글자 · RUN 규칙 B | run.c (`SAFE_SPEED`, `PO_manjae`) |
| PC 주고받기 · 완료응답 다시 보내기 · 승인 · 램프 기억 지우기 | net.c (`done_port` · `send_cmd` · `tcp_port`) |
| 램프 / 부저 | lamp.c (+ event.c `lamp_event` 순서) / buzzer.c (켜는 곳 · 끄는 곳 목록) |
| NAK 이유 | cmd.c |

**1. 램프 · 부저 주인** : event.c `lamp_event` = `lamp_tcp(); if (tcp_on) return;` / buzzer.c `Buzzer_On` 맨 앞 `if (tcp_on) return;` (끄기는 늘 됨) / net.c PC 접속(CON) = `Buzzer_Off(); Lamp_Clear();` (예전 LL 기억 지움) / 끊김 3곳 → **`tcp_off()`** 한 곳 (`tcp_on = 0` + 완료응답 기다림 끝 + 알람 · 일시정지 · 만재 알림 중이면 부저 다시).
**2. 부저 명령** : `B_1_1@B_2_1…` 채널 1~8 (`@` · `&` 둘 다), 이 로더 = `BUZZER_CH 1`. 틀린 묶음 있으면 아무것도 안 바꾸고 NAK. PC 명령은 핀 직접 (Buzzer_On 은 PC 연결 중 막혀서).
**3. 만재 (manjae.c 한 곳)** : 변수 `manjae_1/2`(RUN 까지 알림, btn_run 이 지움) · `static ff_on`(FF 쪽지) · `static full_2s`(2초 그대로였던 8칸). `manjae_pin`(칸 → 핀 표 한 곳) · `manjae_on`(지금) · `manjae_2s`(2초 확정) · `manjae_change`(Event_Task : `GPIOE->IDR & 핀8개` 레지스터 1번, 바뀌면 `ff_on` + `osTimerStart(Manjae_Timer, 2초)`) · **`Manjae_Timer_2s`**(타이머 콜백 : `full_2s` 찍기 + 알림 · 로그 · 부저) · **`Manjae_check_text`**(C 대답 · FF 글자) · **`Manjae_event_text`**(Comm : FF). 지움 : `manjae_off` · `manjae_stable` · `manjae_full` · `last_on` · `changed_at` 배열 · `full_event_on` · event.c `manjae_event`(Event_Run 에 `manjae_change();` 한 줄). hmi.c 만재 칸 = `manjae_2s`. ⚠️ 2초 타이머는 8칸 공통 → 다른 칸이 계속 바뀌면 확정이 늦어짐 (사용자 : 그럴 일 없음, 6초 제한 뺌).
**4. PO 정지선 (run.c)** : `while (manjae_on && manjae_2s == 0) osDelay(20);` → `if (manjae_on) Pause_Set('F');` → `pause_wait();` (RUN · D) → `if (card_on == 0) Pause_Set('S');` → `while (pause_why == 'S' && card_on == 0) osDelay(20);` → `if (pause_why == 'S') Pause_Clear();` (**카드 들어오면 저절로 틸트**, RUN 으로도 풀림). **B 규칙** : run.c `PO_manjae()` (`busy && job.cmd == CMD_PO && manjae_on(job.rack, job.dan)`) → event.c `btn_run` 이 그 칸 아직 만재면 안 풀음 (부저 · 알림만 끔), 억지로는 PC `D`.
**5. 프로토콜** : status.c `Status_PC` = 만재(F)면 `FF…` 먼저 + `PPAUSE:F` / `rack_text` C 대답 상태 : 만재 일시정지 **F**, 카드 일시정지 **S** (보드 상태판 값은 PAUSE 그대로). 만재 글자는 4칸 그대로 (사용자).
**6. 카드 (rfid.c 한 곳)** : 변수 `card_ok_1/2`(밖은 `card_on`) · `card_event_on` · `card_1/2`(RUN 까지 알림) · `static uid_1/2` · `static out_1/2`(없음 연속 횟수). `Rfid_Save` 2줄 (`on != card_ok` 이면 바꿈 + memcpy + 쪽지, `none[UID_LEN]` 7칸 0) · `Rfid_Check`(0.5초 : 묻기 + `out == CARD_MS/ASK_MS`(4번 = 2초)면 알림 한 번) · **`Rfid_check_text`** · **`Rfid_event_text`**. 지움 : `card_stable` · `card_out` · `changed_at_1/2` · event.c `rfid_event` · `done_1/2`. lamp.c Y = `card_on()`.
**7. 청소** : 지움 `CLI_Start` · `A_08` 선언 · `IM_Info`/`IM_MapRead` · LOG 7개 · `LAMP_BLINK` · `TM_BAUD` · `TM_DEC_MS` · `BTN_ESTOP` · `BTN_Home`. static 으로 : `Status_PAUSE` · `Status_Resume` · `pause_event_on` · `CLI_Print` · `CLI_Result` · `Lamp_R1~G2` · `lamp_rfid` · `Lamp_Tcp` · `Roder_Number` · `TM_State` · `TM_Done` · `alarm_event_on` (`A_11` 은 정의보다 먼저 불려서 공개 유지). **남김 (사용자)** : `AM_BaudInit`(새 Y 드라이브 57600 → 115200), eeprom.c `EEPROM_MAC`, CLI `REG`. cmd.c · status.c · app_freertos.c 틀린 주석 고침.
**8. PO 끝 = MO 위치 (사용자가 직접 바꿈)** : PO 복귀 = 렉 좌표 (x, y). `Motor_Run` 완료 로그 목표도 x, y. FP 7 은 지역 변수 없이 `save.fp.tilting_y` · `tilting_y_speed` 바로.
**9. 입고대 천천히 (run.c)** : `SAFE_SPEED 20`. `safe_out(tilt_speed)` = 틸트 가운데 → **입고대 안(`x1 > safe_x`)일 때만** X 20% 로 safe_x (통로면 그대로, 위치 못 읽으면 빠지는 쪽). MI = safe_out → **통로에서 X(safe_x) · Y(safe_y[단]) 같이** → X 20% 진입 → 들어 올림. PO → PO 의 1618 왕복 없어짐. (X 드라이브는 가는 중 새 명령을 안 받아서 엔코더 보며 감속 X → 토막 나누기)
**10. 완료응답 + PC 승인 (net.c)** : `static done_text[24] · done_no · done_at`, `DONE_MS 1000`. run.c `Motor_Run` 성공 → `Done_Send("AI_렉_열_단" / "AO_…" / "EO_…")` (Motor_Task, osKernelLock) → Comm `done_port`(tcp_port 끝) = 새 번호로 보냄, 승인 없으면 1초마다 같은 번호. `send_cmd` : **`번호 + ACK + 글자` 는 PC 대답** → 완료응답과 번호 · 글자가 같으면 지움, 아니면(FF · UT 대답) 받기만 (대답엔 대답 안 함, 전엔 NAK wrong_number 가 나갔음). cmd.c MI · MO · PO = `manual || Done_Wait() || Motor_Request(m) == 0` → NAK. 2500 끊기면(`tcp_off`) 승인 기다림 끝. **MO 끝 = 상태 R 그대로** (프로토콜 AO) → 그동안 HMI 운전 · 수동 X · STOP 먹음 (현장 흐름 확인). `homing done` 은 V1.3 에 없어서 안 넣음 (원점 끝 = C 로 `S_1_W`).
**11. 그 밖에** : 램프 LL 렉 · 램프를 `%c` 한 글자 (렉 `':'` = 10, `rack - '0'`). CLI `INIT` · `I` = `Motor_Request(home)` (Comm 안 멈춤, OK = 받음 / ERR = 하는 중 · 알람, 끝은 로그 `HOME done`). net.c `Net_On_Off` = `PHY_MS 100` 마다만 (SPI 1초 2000번 → 20번).

**58080 서비스 포트로 시험** : 2500 과 같은 명령 처리, 20초 끊기 없음, `[TX]` 보낸 것 · `[RX]` 대답 · 이벤트 · 완료응답. 58080 만 연결이면 `tcp_on = 0` → 램프 · 부저는 보드 (LL 은 ACK 만, 안 보임). 번호 없이 `STX + 명령 + ETX` (Tera Term Ctrl+B · Ctrl+C, ACK = Ctrl+F). PO 숫자 9개.

- 빌드 : 에러 0 · 경고 0. Flash 약 97.1KB, RAM 약 30.3KB.

## 11/1 집에서 바뀐 것 (X 모터 하나 · Y · 틸트 시험용 + 승인 · 원점 대기 · CLI) — 전체 빌드 에러 0 (경고 = `hmi_event`), 보드 시험 아직

**사용자 결정 (11/1)** : **"어렵게 짠 코드는 유지보수를 못 한다"** — 변수 하나에 뜻 하나, 켜고 끄는 건 이름이 보이는 한 줄, 줄이 조금 늘어도 읽기 쉬운 쪽. 완료 승인은 원래 받는 게 맞고, 시험 때만 한 줄 주석. **승인은 글자만** (`번호 + ACK` 승인은 없앰). 현장 값은 define 옆 주석 `[현장]`.

- 프로젝트 = `Downloads\threeD_roder (2).zip` (10/30 회사 코드) 로 맞춤. 전 백업 `C:\user\stm32\threeD_roder_before_1101`. 이번 묶음 = `backup_1101.zip`.
- **승인 (net.c)** : `send_cmd` = `AI_1_1_2` 처럼 보낸 완료응답과 같은 글자면 `done_text` 지움(다른 글자는 `bad_command`). `번호 + ACK + 글자` 는 이벤트(FF · UT) 대답으로 **받기만**. `Done_Send` 의 **`done_wait = 1;`** (지금 주석) = 승인 받기 / 주석 = 한 번만 보내고 다음 명령 받음. `Done_Wait` = `done_wait && done_text[0] != 0`.
- **원점 대기 규칙 = 한 번 묻고 `ARRIVE_MS` 쉼** : `AM_Home` 의 `while` 2곳에 쉼 추가 (Y 약 220번/초 → 약 40번/초), `IM_Home` 100mm 뒤 `osDelay(IM_ACC_MS)` 는 `while` 앞 **한 번만** + 20ms 마다 묻기, `TM_Home` `osDelay(20)` → 이름.
- **CLI 는 모터 · REG · 원점 · 통신 실패만** : cli.c `CLI_Note`(아무 태스크, 쌓기) · `note_print`(Comm_Task, 출력) / run.c `home_say` = 로그 + CLI / `I()` 축별 실패 문장 / `A_11` CLI 표시. 문장에 ID 적음 (`HOME  Tilt ID 2 no answer -> check DIP / RS485 / power`) → 코드 ID 바꾸면 debug.h 도. **Tera Term 로컬 에코 끄기** (CLI 글자 두 번).
- 틸트가 안 되던 원인 = **틸트 드라이브 DIP 틀림** (사용자 확인). 드라이브가 보드보다 늦게 켜지면 원점 한 번 실패 → 상태 I → PC `I` 로 다시.
- 명령 : **번호 없이** `<STX>MI_1_1_2_050_050_100_000_000<ETX>` (8개) / `PO_1_1_2_010_010_500_050_045_0` (9개, 각도 · 틸팅검사) / `C` / `I` 한 글자 / `ALL_PIMZ` / 승인 `AI_1_1_2`.
- 이야기한 것 : 대기 중 1초 통신 = `alarm_event`(X 2번 · Y · 틸트 알람 레지스터), 이동 중 = 위치 · 상태 (Modbus 는 물어봐야 대답). 한 바퀴 = 묻는 횟수 × 약 4.5ms + 쉬는 시간. 보드에 무리 없음 (DMA · 잠, CPU 약 1% 이하, 계산값).
- ❓ 사용자 확인 : app_freertos.c `Manjae_event_text` · `Rfid_event_text` 주석은 사용자가 끈 것 (FF · UT/UU 안 나감).

## 11/2 · 11/3 회사에서 바뀐 것 (틸트 끼임 풀기 · 수동 모드 리셋) — 보드 확인됨

- **틸트 끼임 알람** : t_motor.c `TM_Init` 끝 `write16(R_POS_ERROR, 3000)` (PA_10A 위치 편차 기준, 약 54°) → 끼면 드라이브 알람 → `A_04` (PA_005) → `alarm_go`. 60000 은 범위 밖이라 거절 → TM_Init 실패 → 원점 안 됨. 기본값은 매뉴얼에 없음 (CLI `T 010A` 로 읽을 것).
- **`TM_AlarmReset`** = `TM_Stop`(PA_04E ← 0x0020) → 알람 풀기(PA_04F ← 0x0300) → **현재 위치 지우기(PA_04F ← 0x0400)** → 제어 칸 0. 0x0400 을 안 하면 드라이브가 "가야 할 위치"(끼기 전 목표)를 기억해서 풀리자마자 옛 목표로 감. Bit5 정지 · Bit6 비상정지 · GO_ABS Bit2 로는 안 지워짐 (시험). 0x0400 뒤엔 각도 기준이 사라지니 **판 뺀 뒤 꼭 원점(RESET → RUN)**.
- event.c **`btn_manual`** (공개) : 알람 02~07 · 10 중 수동 켤 때 `IM_AlarmReset · AM_AlarmReset · TM_AlarmReset` 한 번. cli.c **`MANUAL`** 명령 (HMI 33 과 같은 규칙). 알람 중 CLI 이동은 `MANUAL` 먼저 (안 하면 ERR).
- 알람 없이 운전 중 끼면 : 가는 중 새 명령이 계획 위치부터 다시 짜여 "못 받는 것처럼" 보임 → 0x0400 외엔 방법 없음 (기준 사라짐). 끼면 알람이 나게 기준을 낮추는 쪽 (시험 필요).
- 문서 : 프로젝트 폴더 `틸트_끼임_풀기.pdf` · `TL57-R 모터 해결 제안_박성원_261103_간단.pdf` (데이터시트 TL57-R 쪽 번호 포함).
- 11/2 : net.c `DONE_WAIT` 정의(완료응답 승인 받기 1 / 시험 0) 등 — 자세한 건 `backup_1102\` (before_done_define · before_done_simple · before_tilt_stop).

## 11/6 회사에서 바뀐 것 (입고대 부드럽게 · TCP · 번호 · 램프 주인 · 사수 hex 분석) — ⚠️ 하루에 아주 많이 바뀜

**사용자 의견 (11/6)** : 한 번에 너무 많이 바뀌어서 **어디가 문제인지 혼자 못 찾겠다** → 다음부터 다시 작업 방식 12 (함수 하나씩, 전 → 후, 허락, 직접 치기). 함수가 늘어난 것도 싫어함. 집에서 파일별로 함수 하나씩 다시 공부할 예정 (아래 "다음").

**1. 입고대 드나들기 = 부드럽게 (run.c · i_motor.c, 보드 확인 : MO · PO 자연스러움)**
- 시험으로 확인한 것 : **iCL(X) 은 가는 중 통신 명령을 안 받음** (Pr8.02 "0x01P 반응 안 함"). INS 비트(Pr9.00 Bit4)를 켜도 안 됨 (`X 0 10` → `X 0 80` 안 빨라짐). PR 두 개 이어 달리기(Bit5 겹침 + Bit14 점프)는 알람 05 → 버림.
- 그래서 **명령 한 번 + 가감속 기울기 계산** : i_motor.c **`IM_MoveSoft(목표, %, start_mm, end_mm, slow%)`** — 출발 start_mm 갔을 때 / 도착 end_mm 앞에서 딱 slow% 가 되게 Pr9.04 · 9.05 (ms/1000rpm) 를 `120,000,000 × 거리 ÷ (X_PI × rpm²)` 로 계산 (`soft_ms`). `write_move` 는 가속 · 감속 따로 받게 바뀜.
- run.c 블록 : `in_stand`(입고대 안?) · `x_pass(mm, out)`(지날 때까지 20ms 묻기, 8초 → A_05) · `stand_leave(y, speed)`(MI → MI : 20% 로 밖 → Y 새 높이 기다림, **사용자가 직접 고침**) · `x_start`(MO 나오기 : 천천히 → safe_x 지나며 빨라짐 → 지나면 Y) · `x_enter`(MI 들어가기 : 빠르게 → 입구에서 20%, 입구 `Y_CHECK_MM 200` 앞에서 Y 안 왔으면 `IM_Stop`) · `po_stop` · `tilt_pour` · `pour_wait`. `safe_out` · `PO_tilt` 없어짐.
- MI 순서 = `stand_leave → AM_Move(Y 먼저) → x_enter` (**사용자가 직접 고침** : 전엔 x_enter 가 먼저라 Y 출발 전에 X 가 입구에서 급정지 → 알람 06). MI 끝 높이 = `safe_y` (들어 올림 삭제).
- PO : Y 를 FP 7 tilting_y 만큼 올리며 **절반에서 틸트** (그대로) → 기울인 채 → **틸트 C + Y 원래 자리 같이** (명령 속도, 11/6 바꿈). Y · 틸트 **동시 출발**(사인 계산, `same_time`)은 시험에서 틸트가 껴서 되돌림.
- ⚠️ **급정지(`IM_Stop`) 뒤 원점에서 X1 · X2 가 따로 움직임** (시험) : 브로드캐스트 원점 명령을 급정지 상태가 덜 풀린 모터가 무시한 것으로 추정 (Pr8.02 `0x040` = 반응 안 함). 그럴 땐 X 드라이브 전원 껐다 켜고 RESET → RUN. 고칠 안 "나" = `IM_Home` 전에 두 모터 Pr8.02 가 `0x000` 인지 확인 (**원점 코드라 사용자 허락 필요, 안 함**).
- `home_say` (원점 문장을 로그 + CLI 에) 는 사용자가 "필요 없음" → 없애고 `I()` 를 `return TM_Home() && IM_Home() && AM_Home();` 로 되돌리는 안 (**아직 안 함**).

**2. TCP (net.c · cmd.c)**
- **일련번호** : PC 가 `23MI…` 로 보내면 대답 `23<ACK>MI…` (그 번호 그대로), 그 뒤 이벤트(FF · UT · AI)는 **마지막 번호 + 1**. 번호 없이 오면 보드가 붙임(Tera Term 시험). `번호 + ACK + 글자` = PC 대답 → 받기만 (완료응답과 같은 글자면 승인). cmd.c `wrong_number` NAK 삭제. (커먼체크로 확인됨)
- **58080 · 50001 안 끊기게** : `net_open` 에서 2500 만 RCR 2 · keep-alive 5초, 나머지는 RCR 8 · 60초 (노트북이 1분 넘게 사라졌을 때만 닫힘 — 완전히 없애면 노트북 선이 빠졌을 때 포트가 영원히 막힘).
- **CLI 에 끊긴 이유** : `2500 connected` / `2500 closed by PC` / `2500 timeout (PC no answer)` / `2500 closed : no command (FI 7 time)` / `58080 · 50001 closed by laptop · timeout`. **CLI 에 `2500 connected` 가 나오면 새 펌웨어가 도는 것.**
- **램프 · 부저 주인** : `PC_On()` = 2500 · 58080 · 50001 중 **하나라도** 연결. 처음 연결 순간 `pc_join` = 램프 전부 끔 + 부저 끔(알람이면 유지), 다 끊기면 `pc_leave` = 알람 · 일시정지 · 만재 중이면 부저 다시. 연결 중엔 **알람(R 빠르게 + 부저) · 원점(6개 깜빡)만 보드**, 만재 · 일시정지 · 카드 램프 · 부저는 PC (LL · B). `log_port` 는 SPI 대신 `log_on` 표시로 (1ms SPI 줄임).

**3. ⚠️ 2500 안 붙음 = FRAM 네트워크 값 깨짐** : CLI `IP` → `PORT = 0 · TIMEOUT = 0` · SUBNET 70.80.1.11 등. TIMEOUT 0 이면 연결되자마자 "20초 명령 없음" 이 0초로 걸려 끊김. 원인 추정 : 10/29 에 FRAM 지도의 FI 자리를 0x0400 → **0x1000** (HEAD 0x0000 → 0x0001) 로 옮긴 날 그 자리에 기본값이 안 써졌고, `FI_1` 이 쓰레기째 저장. **고치기 = 58080 에서 `FD_1` → 재부팅 → `IP` 확인** (재부팅 2~3번 뒤에도 그대로인지 = 칩이 4KB 보다 작아 겹치는지 확인). 예방 안 (**안 함**) : `NET_Init` 맨 앞 `if (port == 0 || timeout < 10000 || timeout > 60000) FD();`.

**4. 빌드** : 사용자가 CubeIDE 최적화를 **-Os** 로 바꿈 → 플래시 약 100KB → **약 62.8KB**. -Os 는 디버거로 변수가 잘 안 보이고 숨은 `volatile` 문제가 드러날 수 있음 → 원점 · MI · MO · PO · 긴급정지 · 알람 · TCP 전부 다시 시험. 이상하면 -O0 으로 같은지 비교.

**5. 사수 펌웨어 hex 분석** → **`docs/senior_fw/읽어보기.md`** (hex 원본 · 분석 결과 · 다시 분석하는 PowerShell 도구). 핵심 : 출력 = **채널 번호 표 + 공통 함수(`DO_On/Off/Blink/Tick`)**, 램프는 상태 **바뀔 때 한 번**, Y = 카드(2500 연결 중엔 안 함), 부저 = 알람만, LL = ACK 먼저 보내고 틀리면 조용히 멈춤 (램프 1~4), PC 승인은 번호로.

**6. 정한 방향 (코드 아직 안 바꿈)** : 램프 · 부저를 **출력 표 + 공통 함수(`Out_On/Off/Blink/Tick`)** 로 (lamp.c 안 추천, 새 파일 X). 결정(무엇을 켤지)은 `lamp_event` 100ms 다시 그리기 그대로 (틀려도 저절로 고쳐짐). 성능 같음 (CPU µs · RAM +약 90B), LL 반응은 빨라짐(바로 핀). 두 태스크가 표를 만지면 `osKernelLock`. **사용자가 정할 것** : ① 이 방향으로 할지 ② 표 위치 lamp.c / 새 파일 ③ PC 연결 순간 램프 · 부저를 끌지(지금) / 그대로(사수).

- 백업 : `backup_1106\` (before_safe_pass · before_ins · move2_fail · before_blocks · before_mi_sync).

## 사무실 ↔ 현장 (11/6 기준, 지금 파일 = 현장 값, 단 `DONE_WAIT 0`)

**"사무실 값으로 바꿔 줘" / "현장 값으로 바꿔 줘" 하면** 코드에서 `[현장]` 을 찾아(Ctrl+Shift+F) 옆 주석대로 바꾼다. 사무실 시험 = X 모터 하나(ID 3) · Y · 틸트 있음 · HMI · RFID 없음.

| 파일 | 현장 (지금) | 사무실 |
|---|---|---|
| i_motor.c | `IM_2_ID 4` · `IM_ALL_ID 0` | 3 · 3 |
| i_motor.h | `IM_HOME_HI_RPM 180` · `IM_HOME_LO_RPM 80` · `IM_HOME_FORCE 35` | 50 · 30 · 10 |
| a_motor.h | `AM_HOME_TORQUE 600` | 100 |
| event.c `Event_Run` | `Rfid_Init();` · `hmi_event();` 켬 | 주석 |
| app_freertos.c Comm_Task | `Manjae_event_text();` · `Rfid_event_text();` 켬 | 주석 |
| run.c `po_stop` | `if (card_on(rack) == 0) Pause_Set(rack, 'S');` 켬 | 주석 |
| net.c | `#define DONE_WAIT 1` (PC 승인 받기) | **지금 0** (시험 : 승인 없이 한 번만) |

## 다음 (11/7 ~) : 집에서 파일별 다시 공부 → 정한 것 하나씩 (노션 정리 안 함 — 사용자 요청)

**사용자가 "공부하자 / ○○.c 알려줘" 하면** : 그 파일을 **함수 하나씩** 설명. 함수마다 ① 하는 일 한 줄 · 누가 부르나 · 어느 태스크 ② 왜 이렇게 짰나 ③ **그림(이미지 · 다이어그램, show_widget 등)** — 호출 흐름 · 시간 흐름 · 모터 움직임 ④ 그 함수에서 고장 나면 어떤 증상 · 로그 줄 → 어디 고침 ⑤ CPU · 버스 · RAM. 한 함수 끝나면 사용자가 이해했는지 확인하고 다음.
- 순서 추천 : **run.c** (오늘 많이 바뀜 : 블록 → MI · MO · PO → Motor_Run) → i_motor.c (`IM_MoveSoft` · `soft_ms` · `write_move`) → net.c (`send_cmd` 번호 · `pc_join/leave` · `net_open` · CLI 끊김 이유) → lamp.c · buzzer.c (지금 구조 + 사수 방식 비교, `docs/senior_fw/읽어보기.md`) → t_motor.c (`TM_AlarmReset`) · event.c (`btn_manual`).
- 공부 중 "여기 고치자" 가 나오면 작업 방식 12 (전 → 후, 허락, 직접 치기).

**공부 뒤 / 회사에서 할 것 (정할 것 포함)**
1. FRAM : 58080 `FD_1` → 재부팅 → CLI `IP` (PORT 2500 · TIMEOUT 20000) → 재부팅 2~3번 더 확인. `NET_Init` 예방 한 줄 넣을지.
2. 새 펌웨어 확인 (CLI `2500 connected`) 뒤 시험 : MI(통로 → 입고대, MI → MI) · MO · PO(절반 틸트 · 같이 복귀) · 램프 주인(58080 만 연결해도 꺼지나 · 알람 R + 부저) · 번호.
3. run.c 정리 (사용자 결정 대기) : `home_say` 없애기 · X 블록 5개 → `stand_out` · `stand_in` 2개로 · `tilt_pour` 를 PO 안으로 · run.c 맨 위 "증상 → 고칠 곳" 지도 주석 · 증명 로그 (`x_pass` 가 safe_x 지날 때 위치 · 속도 mm/s, `x_enter` Y 확인 결과).
4. 원점 X1 · X2 따로 움직임 → 안 "나" (`IM_Home` 전 Pr8.02 확인) 허락 받기.
5. 램프 · 부저 출력 표 (위 11/6-6) : 사용자가 ① ② ③ 정하면 1단계부터.
6. 전부터 남은 것 : 프로토콜 V1.3 대조 (아래 11/2 ~ 표), HEALTH 로그, ESP 11 · 12, 렉 3 · 4, Y AIM 레지스터.

## 다음 (11/2 ~) : 오전 수정 → 오후 시험 — 11/6 기준 위 목록이 먼저, 프로토콜 대조 기록용

**프로토콜 V1.3 PDF 와 코드 대조 결과 (11/1)** — 문서 : https://github.com/ParkSeong0425/3D (`2차소터 프로토콜_V1.3_260916.pdf`). pdftotext 로 읽어 표 칸이 일부 섞임 → 표시한 곳은 문서를 눈으로 확인. **MI · MO · PO 함수의 숫자 순서 · 범위는 맞음.**

**먼저 사용자가 정할 것**
| 항목 | 프로토콜 | 지금 코드 | 추천 |
|---|---|---|---|
| 일련번호 | PC 가 붙임 `01MI_…`, 응답도 그 번호 | 붙이면 `NAK wrong_number` (10/19 사용자 결정) | PC 번호도 받기, 없으면 보드가 붙이기 → 둘 다 됨 |
| 완료 승인 | AI · AO · EO `ACK 요구 Y`, 응답 = `번호 + ACK + 글자` | `AI_1_1_2` 글자만 (11/1 사용자 지시, `번호 + ACK` 는 받기만) | 두 형식 다 받기 (조건 한 줄) |

**형식 고치기 후보**
| 명령 | 프로토콜 | 지금 코드 |
|---|---|---|
| D | `D_1` | `D` 만 (`D_1` = `bad_command`) |
| S | `S_렉` (1~4) | `S_1` 만, 전체 렉 정지 |
| FS | `FS_1_D112545401100` (붙여 씀) | `FS_1_S_2_1_2_…` (`_` 로 나눔), 장비 `D` 거절 |
| FP 13 | `FP_1_=_1618_0` (2개) | `in_y + 1` 개 (PIMZ 3개) |
| 카드 2개째 | `UT_1_…&U_2_000…` | `UT_1_…&UU_2_000…` (글자 해석 확인) |

**담당자 · 문서 확인 필요**
- MI 5번째 칸 `틸트 속도 / 리프트 하강거리(mm)` : 문서 예 `01MI_1_1_2_080_200_100_000_000` 이 코드에선 `bad_data` (10~100 밖).
- 없는 기능 : K 리프트 파킹, MD 리프트 하강, L · R · M (로딩 대기 · 출발 · 이동중 — 표가 섞여 확실치 않음).
- C 일시정지 글자 : 문서 = `P` + 구분번호(01 버튼, 02 시딩월), `S` = 정지 / 코드 = 만재 `F`, 카드 `S`, 나머지 `P` (번호 없음).
- 램프 : 문서 1~16 (예시에 4번) / 코드 1~3, 4번이면 전체 NAK. `PPAUSE: F` 공백 (코드 `PPAUSE:F`).
- 10/30 사용자 결정으로 문서와 다른 것 (그대로) : 만재 FF 8칸 · C 5칸 → 코드 4칸, 렉 4개 → 2개, 알람 01 = HMI 통신 · 11 · 12 추가.
- 일치 ✅ : MO · PO 숫자 개수, `PI` NAK, C · R · I · FD_1, FI 1~6 (+ 7 우리 것), FP 1~12, AI · AO · EO 글자와 뒤 상태 (AO R, AI · EO W).

**시험 (오후, 11/1 코드도 보드 시험 전)** : 원점 → `S_1_W` · Y 원점 불빛 · 원점 뒤 위치가 전과 같은지 → MI → 승인 → MO → PO → CLI 통신 실패 문장 (드라이브 선 하나 빼고 `I`) → 만재 · 카드 (현장 값일 때). 앱 주석 `Manjae_event_text` · `Rfid_event_text` 는 사용자가 끈 것 → 의도 확인.

**이어서** : 파일별 공부 (manjae → rfid → status → run → net).

## 다음 (10/31 ~) — 11/1 기준 위 목록이 먼저, 기록용
1. **오늘 저녁 집 복습** : manjae.c → rfid.c → status.c → run.c (PO 정지선 · safe_out · MI · Motor_Run 완료응답) → net.c (done_port · send_cmd · tcp_off). 파일마다 그림 + 기초 예시 코드 + 왜. **노션 10/30 은 사용자가 "넣어" 할 때만** (예시를 먼저 보여 줌).
2. **보드 시험 (10/29 + 10/30 전부)** — 집 또는 다음 주 조립된 기계 :
   - 켜기 → 원점 → `C` = `S_1_W`. CLI `FRAM` 으로 SAFE X · SAFE_Y · IN_X.
   - MI : 입고대 20% 진입 · 들어 올림 → `AI_1_1_1` 1초마다 → `<STX>번호<ACK>AI_1_1_1<ETX>` 로 승인 → 멈춤. 승인 전 MI NAK.
   - MI → PO : 20% 로 92mm 빠질 때 판(380mm)이 안 걸리나, PO → EO, 렉 자리로 복귀. PO → PO 다른 열 : 1618 안 거침. MO → AO · `S_1_R`.
   - 만재 : 스침 = FF 2번만 / 2초 = HMI · 부저 · 빨간불 (PC 미연결) / PO 칸 만재 = `FF…` + `PPAUSE:F` + `S_1_F`, 막은 채 RUN = 안 풀림, 치우고 RUN · PC `D` = 이어서.
   - 카드 : PO 렉 카드 빼기 = `PPAUSE:S` · `S_1_S` → 꽂으면 저절로.
   - 램프 · 부저 주인 : PC(2500) 연결 중 알람 = 보드 램프 · 부저 안 켬 / 끊으면 빨간불 + 부저 / 다시 연결 = 부저 끔 · 램프 꺼진 상태. `B_1_1@B_2_1` · `LL_1_1_10`.
   - CLI `INIT` → OK → 로그 `HOME done`.
3. 정리 · 성능 (전부터) : HEALTH 로그 (켜진 시간 · `uart2_err` · 스택), 이동 시간 자동 계산(`*_Time`) → 시간 초과 알람 자동, USART1_TX DMA, `TM_Init` 청소, Y AIM 레지스터 확인, ESP 11 · 12, 렉 3 · 4, `SAFE_SPEED` FRAM 으로 옮길지, `A_11` static.

## 다음 (10/30 ~) — 10/30 기준 위 목록으로 대체, 기록용
1. **보드 시험 (10/29 것)** — 완료응답이 없으니 PC 는 `C` 로 W 를 보며 하나씩
   - CLI `FRAM` : `SAFE X = 1618` · `SAFE_Y = 0 650` · 옵션. 틸팅 검사 시험은 `FS_…_00001`.
   - 켜기 → 자동 원점 → `S_1_W`
   - `MI_1_1_1_080_080_100_000_000` : **입고대에서 92mm 빠질 때 판(380mm)이 기둥에서 다 빠지나** (모자라면 FP 13 `safe_x` 줄이기)
   - `PO_1_2_3_080_080_500_050_045_1` : 틸트 가운데 도착 **뒤에** X 이동, 안전 2(650) 로 가나 / PO 1 · 2단은 안전 1(0)
   - 움직이는 중 MI → NAK `can_not_command` / 알람 → RESET → I → HMI RUN → 원점 → W
   - 로그 50001 의 완료 3줄(시간 · 위치 · 오차 · X1−X2) 확인
2. **완료응답 + PC 승인 (net.c 에서 새로)** : `Motor_Run` 의 `ok` 를 결과로 → AI · AO · EO · homing done, 1초 재전송, 승인 받으면 다음 명령. 승인 번호 = 그 명령 번호 (10/27 규칙).
3. CLI `INIT` · `I` 도 `Motor_Request` 로 (지금은 Comm_Task 에서 직접 원점 → `busy` 를 모름).
4. **7단계 (event · 만재 · rfid)** : 7-1 만재 `manjae_1/2` · `check` → manjae.c `Manjae_Check()` / 7-2 카드 같은 모양 `Card_Check()` / 7-3 알림 초인종 / 7-4 pause.c + 프로토콜 F · S · 알람 번호 / 7-5 PO 만재 2초 `while` 을 manjae.c 블록으로.
5. HEALTH 로그 · 드라이브 토크 · 온도 (시험 결과 보고).
6. 전부터 남은 것 : 자동 계산(`*_Time` · 시간 초과 알람 자동), 랜선 확인 간격, USART1_TX DMA, ESP 11 · 12, 렉 3 · 4, `TM_Init` 청소, Y AIM 레지스터, `ACCPT_COMMAND` 없어짐(완료응답 새로 만들 때 함께).

## 다음 (10/28 ~) — 10/29 기준 위 목록으로 대체, 기록용
1. **보드 시험 (10/27 것 전부)** : 처음 켤 때 FRAM 기본값 → `ALL_PIMZ` · FI 다시 / CLI 지우기 · 붙여넣기 · `REG` (Tera Term 로컬 에코 끔) / 58080 에서 MI → `[TX] 08…` · 승인 번호 08 · 다음 09 / 58080 20초 안 끊김 / 카드 · HMI · 모터 전과 같음.
2. **만재 · RFID 구조 정리 (사용자가 먼저 모양 정하기)** — 지금 흩어진 것 :
   | | 센서 값 | 바뀐 시각 · 2초 | 알림 중 (RUN 까지) | 한 번만 알리기 |
   |---|---|---|---|---|
   | 만재 | manjae.c `manjae_on` | `changed_at[2][4]` · `manjae_stable(r,d)`, `(0,0)` = 8칸 다 | event.c `manjae_1/2` | event.c `static check` (8칸 공통) |
   | 카드 | rfid.c `card_ok_1/2` | `changed_at_1/2` · `card_stable(r)` | event.c `card_1/2` | event.c `static done_1/2` (렉마다) |
   - 문제 : 같은 생각("2초 그대로면 알림, RUN 까지 유지, 한 번만")이 두 모양 / 판단이 장치 파일 · event.c 에 나뉨 / `Rfid_Save` 긴 4줄 반복 / run.c PO 153~154 가 만재 2초를 직접 다시 판단.
   - 방향 : 가 = 만재 것은 manjae.c, 카드 것은 rfid.c 가 다 가짐 (레고 R3) / 나 = 자리 그대로 모양만 통일. **기능은 그대로**.
3. **틸팅 에러를 프로토콜에 맞게** : 명령 9번째 숫자(틸팅 검사 옵션) 아직 없음. 정할 것 = 프로토콜 V1.3 의 형식 · 옵션 저장(RAM / FRAM) · 8숫자 PO 계속 받을지. 지금 `PO_tilt` 는 주석 (복귀 대기 `osDelay(return_delay * 10)` 만).
4. **자동 계산 아이디어 (run · 모터)** :
   - `*_Time(거리, %)` : FP 11 rpm · FP 12 가감속으로 이동 시간 계산 → 그만큼 자고 그 뒤 20ms 묻기 (이동 중 버스 30% → 거의 0).
   - 시간 초과 알람 `MOVE_MS 8000` 고정 → **계산한 이동 시간 × 1.5 + 여유** (먼 거리 · 느린 % 에서 오알람 없고, 가까운 이동은 빨리 잡음).
   - 원점 · 틸트 각도 · Y 절반 지점 등 숫자도 FP 값에서 계산되는지 확인.
   - ❗ 드라이브마다 가감속 ms 뜻(목표 속도까지 / 0→1000rpm) 매뉴얼 확인 필요.
5. 작은 것 : 랜선 확인 1ms → 100ms (`Net_On_Off`), USART1_TX DMA 설정만 있고 안 씀(ioc 정리 또는 CLI_Print 를 DMA 로 — `FRAM` 출력 때 Comm_Task 60~80ms 멈춤), save.c 풀어 쓴 부분(`left_x1~9`)은 사용자가 정할 때까지 그대로.
6. 기존 결정 대기 : PO 틸트 % 를 명령 값으로, `ACCPT_COMMAND();`(괄호!) 켤지, PC D 가 S 도 풀지, A_11 동작, `TM_Init` 청소, Y AIM 레지스터 확인, 안전 위치(FP 13), ESP 11 · 12, 원점 도착 1초 간격, 렉 3 · 4.

## 다음 (10/24 ~) — 10/27 기준 위 목록으로 대체, 기록용
1. **집 : 지금 구조 그대로 유지보수 쉽게** — 사용자가 파일 하나씩 "알려 줘" → 함수마다 하는 일 · 개념 · 다듬을 곳 (이름 · 주석 · 안 쓰는 것 정리). 안 쓰는 것 후보 : `Manjae_Timer` 콜백(빈 함수, ioc), debug.h `LOG_PAUSE` · `LOG_MANJAE` · `LOG_RFID` · `LOG_Tilting_error` · `LOG_CARD_OUT` 일부, `YR` 디버그, `IM_MapRead` 선언, `card_event_on` 주석들.
2. FRAM FP 12 다시 넣고 에이징 → A06 사라지나.
3. 결정 : PO 틸트 % 를 명령 값으로 할지, `PO_tilt`(센서 확인 T) 켤지, 승인 반복 `ACCPT_COMMAND();`(괄호!) 켤지, PC D 가 S 도 풀지, A_11 동작, `TM_Init` 청소, Y AIM 레지스터 확인.
4. 그 뒤 : 안전 위치(FP 13), ESP 11 · 12 · JOG, 원점 도착 1초 간격, 렉 3 · 4.

**램프 시험 표** (PC 연결 · 대기 상태 · 카드 있음 · 만재 없음일 때) : `01LL_1_1_10`(렉1 적 켬) / `02LL_2_2_10`(렉2 녹 켬) / `03LL_1_3_20&L_2_1_20`(렉1 황 · 렉2 적 깜빡) / `04LL_1_2_15&L_2_3_15`(5초) / `05LL_1_1_2:`(10초 깜빡) / `06LL_1_1_00&L_1_2_00&L_1_3_00&L_2_1_00&L_2_2_00&L_2_3_00`(전부 끔) / `07LL_1_1_30` · `08LL_5_1_10` → NAK.

## 현재 상태 (2026-11-06 회사 끝)

- 11/6 : MI · MO 입고대 부드럽게 (`IM_MoveSoft` + run.c 블록, MI 순서 · `stand_leave` 는 사용자가 고침), PO 복귀 = 틸트 C + Y 같이, TCP 번호 = PC 번호 그대로 · 이벤트 +1, 58080 · 50001 안 끊기게, 램프 · 부저 주인 = 세 포트 중 하나라도 연결 (`PC_On`), CLI 끊김 이유, 사수 hex 분석(`docs/senior_fw/`). **-Os 빌드** 에러 0 · 경고 0, 플래시 약 62.8KB. 현장 값 (`DONE_WAIT 0` 만 시험값). **FRAM 네트워크 값 깨짐 → `FD_1` 필요.** MI · 램프 주인 · PO 같이 복귀는 마지막 펌웨어로 아직 보드 시험 전. 노션 정리 안 함 (사용자 요청).

### (11/1 집 끝 기준)

- 11/1 : 사무실 시험 값 (`[현장]` 12곳), 승인 글자만 + `done_wait` 한 줄 (지금 주석 = 승인 없이), 원점 대기 통일, CLI 원점 · 통신 실패 표시. 전체 빌드 에러 0 · 경고 `hmi_event`. **보드 시험 전.** 묶음 `backup_1101.zip`. 프로토콜 대조 결과는 "다음 (11/2 ~)" 에 저장만 함 — **그 내용은 코드에 아직 안 고침.**

### (10/30 회사 끝 기준)

- 10/30 : 프로토콜 V1.3 맞추기 (램프 · 부저 주인 = TCP 연결 중 PC, 부저 채널, FF + PPAUSE:F, C 상태 F · S, 완료응답 AI · AO · EO + PC 승인 + 승인 전 NAK, LL 렉 ':') / 만재 · 카드 변수 · 판단을 각자 파일로 (`Manjae_Timer_2s` · `out_1/2`) / PO 카드 들어오면 저절로 · RUN 규칙 B / 입고대 20% (`SAFE_SPEED`) · 통로 X · Y 같이 / 청소 (static · 안 쓰는 것). 전체 빌드 에러 0 · 경고 0. **보드 시험 안 함.** 노션 10/30 은 예시만 보여 주고 사용자 허락 대기. 사용자는 오늘 저녁 집에서 복습.

### (10/29 회사 끝 기준)

- 10/29 : `Order_Set` · 주문서 전역 · 완료응답 · 승인 처리 지움 → **모터 문** (`MOVE` · `Motor_Request` · `busy` · `Motor_Run`, 초인종 `MOVE_FLAG` 하나, flag.h) / MI · MO · PO 매개변수 프로토콜 순서 + 동작 대기 / **안전위치 경로** (`safe_out` · PO 끝 안전 1 · 2) / 틸팅 검사 = FS 옵션 && 명령 / 상태 N → I / 완료 로그 (시간 · 위치 · 오차 · X1−X2) / cmd.c 확인용만. 전체 빌드 에러 0 · 경고 0. **보드 시험 안 함. 완료응답 없음 (PC 는 `C` 로 확인).** 만재 · 카드 · 알람 · HMI · 램프 코드는 안 바뀜. 노션 정리 안 함.

### (10/27 회사 끝 기준)

- 10/27 : 58080 명령 받기 + 번호 규칙(명령 하나 = 번호 하나), W6100 INT → `NET_FLAG` 초인종(1ms 유지), CLI UART1 인터럽트 · 지우기 · echo · `REG`, usart.c · fdcan.c USER CODE 정리(동작 같음), **FRAM 덩어리마다 주소 + SAVE_VERSION 7 (처음 켜면 설정 다시 넣기)**, run.c PO `move_delay` 인자 삭제. 전체 빌드 통과(경고 2 = 원래 것). **보드 시험 안 함.** 다른 것은 10/26 현장 값 그대로 (`IM_2_ID 4`, HMI · 카드 · `A_01` 켜짐, `PO_tilt` · `ACCPT_COMMAND` 주석). 노션 정리 안 함.

### (10/26 회사 끝 기준)

- 10/26 회사 : zip(3) 코드로 바꾼 뒤 시딩월 2초 확정(`card_stable`) · `card_1/2` 알림(HMI RUN 까지) · PO 카드 없음 바로 PPAUSE:S · PO 만재는 그 칸 2초 확인 뒤 F. **빌드 에러 0 · 보드에 플래시 됨** (시딩월 오인식 사라졌는지 현장 확인 계속). 시작 지연 MI · MO 미적용은 그대로.

### (10/26 집 끝 기준)

- 10/25 ~ 26 : ALL_PIMZ 명령(`Setting_Default_PIMZ`), event.c 블록 나열(`hmi_event` switch 한 줄씩, `btn_stop` · `btn_reset` 삭제, 확인은 `Alarm_Clear` · `HMI_Manual` 맨 앞), status.c 맨 위 "해도 되나" 목록 주석, 만재 2초 칸마다(`manjae_stable(rack, dan)` / `(0, 0)`). **보드 시험 전부 안 함.** 백업 = `backup_1026\` · `backup_1026.zip`. 다른 것은 10/23 현장 값 그대로 (`IM_2_ID 4`, HMI · 카드 · `A_01` 켜짐, `PO_tilt` · `ACCPT_COMMAND` 주석).

### (10/23 끝 기준)

- 10/23 : RESET → N · RUN → 원점, `btn_*` 버튼 블록, `Pause_Set` / `Pause_Clear` / `pause_wait`, 만재 2초 = `manjae_stable()` (보드 확인 : 스침 FF 만, 2초 HMI 만재 · 부저 · 램프 · PO 그 단 F), 카드 = PO 그 렉 S, 해제는 전부 HMI RUN, 명령 숫자 8개 · 각도 · 복귀대기, FP 아스키 항목, X 쓰기 전부 브로드캐스트, `ARRIVE_MS 20`, `Save_XY`. 전체 빌드 통과 (에러 0, 경고 = 주석 처리된 `ACCPT_COMMAND` · `PO_tilt`). Flash 약 98KB, RAM 약 30KB. **지금 파일 = 현장 값** (`IM_2_ID 4`, HMI · 카드 켜짐, `PO_tilt` · `ACCPT_COMMAND` 주석). 노션 정리 안 함.

### (10/22 끝 기준)

- 10/22 : 완료응답 한 번 / 승인 반복 나눔(지금 주석), A_05~07 = `A_05(IM_Arrive(x))` · `MOVE_MS 5000`, FF 즉시, 프로토콜 글자 각 파일(`*_Text` · `*_PC` · `*_Cmd` · `Order_Set`), X 쓰기 전부 브로드캐스트(`UART2_Send`), `lamp_event` 레고 4줄 + `lamp_alarm` 버그 고침, RESET → 바로 원점, 일시정지 부저 `Status_PAUSE/Resume`. 전체 빌드 통과(에러 0, 경고 = 안 쓰는 `ACCPT_COMMAND` · `read_map`). Flash 약 98.2KB, RAM 약 30KB. **마지막 수정분(브로드캐스트 전부 · 램프 레고 · RESET → 원점 · 일시정지 부저)은 보드 시험 안 함.** 노션 정리 안 함(사용자 요청).

### (10/21 끝 기준)

- 10/20 ~ 21 : debug.h + printf 모양 `Log_Debug`, X 도착 두 모터(`IM_Pos(&mm1, &mm2)`), RS485 쉬는 시간을 뮤텍스 안으로(`UART2_Xfer` `osDelay(2)`), Y 펄스 확인(CLI `YR`), 알람 11(모터 통신) · 12(랜선), HMI 만재 바로 + 일시정지 2초, 수동 모드 알람 05~07 · 10 허용, `Alarm_Clear` = RESET 묶음. 백업 `workspace_1.19.0\threeD_roder_1021`. **`A_01` 은 현장이라 주석 풀려 있음.**

### (10/19 끝 기준)

- 10/19 : net.c 포트별 함수 · `Log_Debug` · 로그 모아 두기 · `send_event`, cmd.c `CMD_Run(no, s)` · `cmd_answer` · 완료 승인 `AI_1_1_2` · `CMD_Done` 삭제(상태판으로 완료 판단), run.c `Motor_Run` 4줄 · 원점 로그. **`A_01` 주석 그대로.** 현장 시험 : 원점 · MI · AI · 카드 됨 / X 알람 02 · 긴급정지 틀어짐 · 부저 늦게 꺼짐 남음.

### (10/16 끝 기준)

- 10/16 : fdcan.c 정리(while, 이름), main.h RTOS extern, rfid.c 사용자 구조(4줄 판단 · 선 빠짐 · `card_on` · `card_event_on`), 카드 글자 cmd.c, `*_Arrive` 기다림 + `A_05~07` 확인, run.c MI · PO 버그 · `PO_pause` · `PO_tilt` 정리, `Status_PAUSE(rack, why)` · `pause_why` = 일시정지 중, `TOUCH_FLAG` 삭제. **`A_01` 주석(사무실용), PO 안 `PO_tilt` · 쏟은 뒤 `PO_pause` 주석(사용자 시험용).** 마지막 명령줄 빌드 통과(경고 `PO_tilt` 하나), **A_01 주석 뒤엔 빌드 안 함** (빌드 목록이 옛 코드 기준 → CubeIDE Clean · Build 필요). **보드 = 10/8 빌드.** 보드 시험 : 사무실 HMI 없음 · 카드 CAN ACK 없음으로 거의 못 함.

### (10/15 끝 기준)

- 10/15 추가 완료 (보드 시험 전) : RFID 타이머 마무리, net.c 구조 정리 + 일련번호 `Roder_Number` + ACK 승인, 로그 포트 `Log_Port`, 알람 02~04 (`IM/AM/TM_Alarm`) · HMI 알람 번호, cmd.c 확인 → 초인종 / run.c `Motor_Run` / `CMD_Done`, 원점 시작 · 끝 `Motor_Run` 한 곳, `motor_basic_init` 사용자 모양, wait → `*_Arrive` + `A_05~07`.
- 전체 빌드 통과 (경고 0). Flash 약 97.4KB / 256KB, RAM 약 30KB / 128KB.

### (10/14 끝 기준)

- 완료 : UART2 DMA, 시간 제한, UART4_Xfer, event.c(긴급정지 엣지, HMI 버튼, 만재, RFID, 램프), 일시정지 B 방식(정지선), HMI 상태 표시, TCP 완료응답 · D, RFID CAN, PO 상황 처리(F/S/T/M, 10/13 부터 run.c `PO_pause` · `PO_tilt`), 큐 제거, 이벤트 일련번호(01~99), 렉 개수 설정, 1단계(Motor_Task · 스레드 플래그), usart 플래그 비교 수정, 드라이브 알람 리셋, X 감속 정지(0x6017), 문서 형식 LL 램프, 랜선 재접속, 알람 01 · 05~07 · 09 · 10 (alarm.c 에 조건 모음), 부저(buzzer.c · B 명령), 만재 함수 3개, FP 11 · 12 반영, Y 원점 오프셋(시험 전), 모터 파일 정리(static · == 0 · 멈추기 따로), **10/14 : 창구 3개(2500 · 서비스 58080 · 로그 50001) + keep-alive, W6100 INT 핀 방식 NET_Run, 서비스 [TX]/[RX] 모니터링(NET_Send), STX 등 cmd.h, 만재 2초 타이머, PO 틸트 초인종 (전부 보드 시험 전), RFID 타이머 반만**.
- 전체 빌드 통과 (경고 0). Flash 약 95.2KB / 256KB, RAM 약 28.6KB / 128KB.
- 9/28 리뷰 남음 : 버퍼 길이 검사.
- 터치패드 : JC3248W535C (ESP32-S3, 3.5" 320x480). Sensor[0] = 화면 왼쪽. ESP 작업 : 0 초기 1 대기 2 운전 3 일시정지 4 정지 5 원점 6 알람 / 일시정지 : 0 없음 1 시딩월 2 만재 3 틸트 4 사용자.
- 노션 정리 : 코텍전자 → [10/02](https://app.notion.com/p/3ed10d3ee54481fb9d0fc4639a4e600b) · [10/07](https://app.notion.com/p/3f310d3ee5448135a75ecbdb6c29e82d) · [10/08](https://app.notion.com/p/3f310d3ee54481ca8f37d67ce7a2a6f8) · [10/12](https://app.notion.com/p/3f710d3ee544810ca566db3c76c11c87) · [10/13](https://app.notion.com/p/3f810d3ee5448173a49de7589f856e21) · [10/14](https://app.notion.com/p/3f910d3ee54481c98f2acc2608b0bae1) · [10/15](https://app.notion.com/p/3fa10d3ee544811aba31c942635229b3) · [10/16](https://app.notion.com/p/3fb10d3ee54481b9b5f1e97224384cc0) · [10/19](https://app.notion.com/p/3fe10d3ee54481298c46c51af866b3e0) · [10/20~21](https://app.notion.com/p/40010d3ee544816cb558fbe63a1883f5). C 기초 다지기 보충 : [레고처럼 짜기 (10/21)](https://app.notion.com/p/40010d3ee54481ce990fe74200b34314) · [성능 설계 개념 (10/21)](https://app.notion.com/p/40010d3ee5448180a3d9c47216878ad3) · [왜 이렇게 짰나 복습 (10/21)](https://app.notion.com/p/40010d3ee54481bbb620d1bee4a8446a) · [함수 나누는 법 (10/20)](https://app.notion.com/p/3ff10d3ee54481c2b9d5f2b256d6fffd) · [(10/19)](https://app.notion.com/p/3fe10d3ee54481bbbbdcd053049dd319) · [(10/16)](https://app.notion.com/p/3fb10d3ee5448119b239cbae35b54c9a) · [RTOS os 함수 지도 (10/15)](https://app.notion.com/p/3fa10d3ee54481ab8595f1158e64364e) · [(10/15)](https://app.notion.com/p/3fa10d3ee54481598e11df8d32c5c673) · [포인터 vs 복사 (10/12)](https://app.notion.com/p/3f710d3ee544819f9c7fff9eea32148f) · [오늘 코드의 C · 펌웨어 기초 (10/13)](https://app.notion.com/p/3f810d3ee5448105a06ae510ec22a0f9) · [(10/14)](https://app.notion.com/p/3f910d3ee54481a4b097cc872f9151f0).

## 일정 (마감 2026-10-14, 10/5·10/6(예비군)·10/9 휴무, 매일 19시까지)

- 9/28 HMI / 9/29 Event + HMI 버튼 / 9/30 일시정지 S / 10/1 이벤트 → TCP 프로토콜 + ACK
- 10/2 RFID (CAN) / 10/7 효율화 / 10/8 센서 EXTI / 10/12 통합 테스트 / 10/13 유지보수 정리 / 10/14 네트워크 추가 (사용자 : 마감은 하루 넘겨도 됨)

## 공부 자료 (10/12 추천, 실제로 있는 것)

- **Digi-Key "Introduction to RTOS"** (YouTube, Shawn Hymel, 12편, 영어) : 태스크 · 우선순위 · 큐 · 뮤텍스 · 세마포어를 FreeRTOS 로. **먼저 1~4편**(태스크 · 스케줄링 · 메모리 · 큐) → "for 문이면 폴링?", "플래그 wait / set" 이해.
- **Mastering the FreeRTOS Real Time Kernel** (freertos.org 무료 PDF) : FreeRTOS 공식 교과서. 블록 · 우선순위 · 태스크 알림의 정확한 뜻 찾아보기용.
- **Quantum Leaps "Modern Embedded Systems Programming"** (YouTube, Miro Samek) : 임베디드 C 를 바닥부터 (포인터, volatile, 인터럽트, RTOS).
- **코딩도장 C언어** (dojang.io, 한국어) : 포인터 · 문자열 · static 복습.
- **혼자 공부하는 C언어** (서현우, 한빛미디어, 지금 교재) : 포인터 · 배열 · 문자열 장.

## 참고

- 데이터시트 · 프로토콜 : https://github.com/ParkSeong0425/3D (`2차소터 프로토콜_V1.3_260916.pdf`, `3DS_motor_DataSheet/` iCL-RS · AIMmotor · TL57-R). iCL-RS 중요 쪽 : 49쪽 0x1003 · 0x1801 · 0x2203 · Pr8.02, 50쪽 Pr8.15~8.29(0x6017 = quick stop 감속 ms), 51쪽 Pr9.00(TYPE 1 위치 2 속도 3 원점, Bit4 INS).
- GitHub: https://github.com/ParkSeong0425/ThreeD_roder
- 노션: 코텍전자 → [09/27](https://app.notion.com/p/3e710d3ee544816aadc3d257fcc232da), [09/27 (2) 개념 정리 · 이해도 테스트](https://app.notion.com/p/3e810d3ee544810186fbec938c853ed1)
- CLI: Tera Term, STLINK-V3 VCP (집 PC COM6), 115200. Windows 11 25H2는 wmic가 없어 CubeIDE 시리얼 콘솔이 안 됨.
- 명령: CLI `X/Y pulse percent`, `C percent`, `R/L deg percent`, `S`, `I`, `INIT`, `IP`, `FRAM`. TCP `STX 01MI_... ETX` 형식.
- 전체 빌드 (명령줄) : CubeIDE 의 make.exe + arm-none-eabi-gcc 폴더를 PATH 에 넣고 `Debug` 폴더에서 `make -j8 all`.
- 문법 검사: `arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfpu=fpv4-sp-d16 -mfloat-abi=hard -std=gnu11 -DUSE_HAL_DRIVER -DSTM32G473xx -fsyntax-only -Wall` + 모든 헤더 폴더 `-I`.
