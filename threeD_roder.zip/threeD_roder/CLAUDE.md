# threeD_roder (3D 로더, 회사 기본 코드) — Claude 작업 안내서 (마지막 갱신 2026-11-16)

STM32G473VCT6 (170MHz) + FreeRTOS(CMSIS-RTOS2) + STM32CubeIDE 1.19.
3축 로봇(X 두 모터 / Y / 틸트)을 RS485 Modbus RTU 드라이브로 움직이고, PC 와 TCP(W6100), 터치화면(ESP32)과 RS485, 카드 리더와 CAN 으로 통신한다.
사용자는 펌웨어를 배우는 중이다. 설명은 **한국어 · 이론 + 움직이는 그림(애니메이션) · 우리 기계 실제 부품 예시**로 한다.

## ▶ 이 코드의 목적 (11/13 사용자 결정)

- **threeD_roder = 회사 기본 코드.** 현장마다 로봇 규격에 맞춰 고치고 오래 유지보수한다.
- **현장 사람이 고칠 수 있게** : run · 만재 · 모터 숫자처럼 현장마다 바뀌는 값은 **찾기 쉽고 뜻이 적힌 한 곳**에 둔다 (주석 · `[현장]` 표시 · "증상 → 볼 곳" 지도).
- **통신 · RTOS 같은 바탕 지식은 사용자가 알고 있어야 한다** → 바꿀 때마다 이론 + 그림으로 설명.
- **새 프로젝트 `dual_roder`** 를 이 코드를 토대로 새로 만든다. 이것도 회사 코드가 되니 처음부터 깔끔한 구조로.

## ▶ 새 세션 시작 (zip 을 받거나 "이어서 하자" 하면)

**zip 만들기 (회사 → 집)** : `threeD_roder` (단 `Debug/` 빼고) + `HMI\HMI_Kor_260702\HMI_JC3248W535_v1.2` (단 `.pio/` · `build/` 빼고). 글꼴을 다시 만들 일이 있으면 `workspace_1.19.0\tools\` (Node 포터블 · lv_font_conv, 약 80MB) 도 따로. 집에서 같은 이름 폴더로 풀고, Claude Code 를 `threeD_roder` 폴더에서 열어 "이어서 하자". (Claude 의 메모리는 PC 마다 따로 → **이 파일이 유일하게 따라가는 기억**)

1. 이 파일 "작업 방식" · "코드 스타일" → "지금 구조" → "11/16 한 것" → "앞으로 할 것" 순서로 읽는다.
2. zip 을 받으면 : 지금 폴더를 `workspace_1.19.0\threeD_roder_before_날짜` 로 백업 → 사용자가 고친 곳을 먼저 찾아 보여 줌 (**사용자 수정 덮어쓰기 금지**) → 전체 빌드 (아래 "참고") 에러 · 경고 수 보고 → `[현장]` 검색해 사무실 / 현장 값 보고 → CubeIDE 열린 탭은 F5.
3. 그다음 "앞으로 할 것" 1번부터. 사용자가 다른 걸 말하면 그걸 먼저.
   - **할 일마다 공부를 같이 한다** (사용자 요청 11/13, 중요) : 그 단계에 나오는 개념을 먼저 **이론 (정의 → 왜 → 동작 순서 → 우리 코드 → 흔한 실수)** + **움직이는 그림 (canvas 애니메이션, 실제 부품 · 공이 선 위를 오가는 모양, 버튼으로 상황 바꾸기)** 으로 설명하고 나서 코드로 간다. 표 · 네모 상자 · 시간 막대(레인) 그림은 쓰지 않는다 (11/16 : 레인 그림 "더 이해가 안 감"). **통신은 특히** 이 방식으로.
4. 하루 끝 ("끝 · 마무리 · 여기까지") : 이 파일의 "한 것" · "지금 상태" · "앞으로 할 것" 을 그날 기준으로 고치고 바뀐 곳을 보여 준다.

## 작업 방식 (반드시 지킬 것)

1. **"그래 바꿔줘" 같은 분명한 허락 전에는 코드를 안 바꾼다.** 함수 하나 · 작은 단위 하나씩. 답은 ① 지금 역할 ② 문제 ③ 이유 ④ 바꿀 곳 (전 / 후) ⑤ 직접 확인할 것 ⑥ 다음 하나.
2. 바꾸기 전에 계획 : 어느 파일 → 어느 함수 → 무엇을 + 개념 + 왜 + 그림. 적용 후 파일별로 바뀐 줄 + 빌드 결과.
3. **코드 구조는 사용자가 먼저 정한다.** Claude 는 추천 · 설명 · 수정. 사용자가 짠 코드는 **사용자 스타일 그대로** 고친다 (변수 · 플래그 · 함수 덧붙이지 말고 있는 함수 안에서).
4. 새 함수 · 변수 · 구조체 · 플래그 · 처음 보는 문법은 **고치기 전에** "새로 생김 : 이름 · 뜻 · 왜 꼭 필요한지, 있는 것으로 안 되는지" 먼저 말한다 (11/16 : `Motor_Busy` · `on == &tcp_on` 을 말 없이 넣어서 혼남). 요청 안 한 곳(특히 **원점**)은 같이 고치지 않는다.
5. 판단 기준 = **안전(긴급정지 · 알람 · 통신 오류) > 버스(RS485) > CPU > RAM**. 리뷰할 때 CPU · 버스 · RAM 을 같이 말한다. 안전은 단순화한다고 빼지 않는다.
6. **설명 그림** : 네모 상자 · 화살표 · 시간 막대 그림 금지. **실제 부품을 그린 움직이는 그림 + 버튼으로 상황 바꾸기** (show_widget canvas). 그림 옆에 **이론** 을 꼭 같이. 답은 짧고 쉽게 (긴 글은 줄여 달라고 함).
7. 낯선 문법(삼항 `? :` 등) 쓰지 않음. 새 문법을 꼭 쓰면 먼저 "새 문법" 이라고 말한다.
8. GitHub `main` 에는 허락 없이 올리지 않는다.
9. 하루 끝에 이 파일 갱신 (위 새 세션 4). 노션 정리는 사용자가 원할 때만.
10. 줄 끝 맞추기(CRLF)는 **고친 파일만** (11/16 : 폴더 전체에 돌려서 CubeMX 생성 파일 syscalls.c · sysmem.c · system_stm32g4xx.c 를 CRLF 로 바꿨다가 LF 로 되돌림 — 이 셋은 원래 LF).

## 코드 스타일 (사용자가 원하는 것 — 계속 유지)

- **레고 모양** : 함수 = 다른 파일의 블록 함수를 한 줄씩 나열 (좋은 예 : `I()` · `MI` · `lamp_event` · `NET_Run`). 순서 = 우선순위.
  - R1 블록 = 한 가지 일, 성공 1 / 실패 0. R2 조립 함수 = 블록 나열 + 최소 if. R3 판단(조건 · 숫자)은 그 데이터를 가진 파일 안 (알람 alarm.c, 상태 status.c). R4 아래 층(모터 · 장치 파일)은 위 층을 모름. R5 switch 의 case 는 블록 한 줄. R6 장치 지식(레지스터 · 코드 이름표)은 장치 파일. R7 태스크 사이는 큐 · 상태판 · 플래그로.
  - 새 함수보다 **있는 함수 안으로 옮기기**가 먼저. 함수 · 변수 늘어나는 것 싫어함. "부르기만 하는 포장 함수" 는 없앤다 (이름이 단계를 설명하면 남김 : `TM_C/R/L` 등). **대입을 감싸는 함수도 싫어함** (11/16 `State_Go` 지움 → `state.now = 'W';` 바로).
  - "해도 되나" 확인은 그 일을 하는 블록 맨 앞.
- `if (!Func())` 금지 → `if (Func() == 0)`. `== 1` 안 씀 → `if (Func())`. **`!=` 도 쓰지 않음** (11/16) → `==` 와 `if { }` 블록으로. (옛 코드의 `!=` 는 아직 남아 있음 : 통신 글자 확인 · strcmp 등)
- 성공 1 / 실패 0 반환, 실패는 `return 0` 으로 위로.
- 여러 레지스터 쓰기 : 움직이기 · 설정 = `&&` (앞이 실패하면 뒤 안 함) / 멈추기 = 따로 다 보내고 결과만 합침.
- **모든 while 기다림에는 시간 제한** (`osKernelGetTickCount()` 시작 시각 비교). 예외 : 일시정지 대기.
- 시간 숫자는 ms, 이름은 `_MS`. 맨숫자 피함 (거리 숫자 · `osDelay(2)` 같은 짧은 쉬기는 예외로 그 자리에 숫자 + 주석).
- 단계마다 한글 한 줄 주석. 짧고 쉽게. 디버그 출력은 원인 찾으면 지운다.
- `save.c` · `cmd.c` 의 풀어 쓴 모양은 일부러 → 배열로 바꾸자고 하지 않는다.
- 일부러 남긴 안 쓰는 함수 : `AM_BaudInit` · `uart_speed` · `EEPROM_MAC`, CLI `REG` → 지우자고 하지 않는다. 그 밖에 **확실히 안 쓰는 변수 · 레지스터 이름은 지운다** (11/16 사용자).
- 변수는 주인 파일 `.h` 에 `extern` 한 번. RTOS 핸들은 `main.h` USER CODE 에.
- CubeMX 생성 파일은 **USER CODE BEGIN ~ END 안에만**. 설정은 ioc 에서 (사용자가 함).
- 파일은 **CRLF** (CubeMX 생성 syscalls.c · sysmem.c · system_stm32g4xx.c 는 LF 그대로). 고친 뒤 bareLF 0 확인.
- 렉1 = 오른쪽 렉 (홀수 렉 = `right_*` 표), 렉2 = 왼쪽. HMI 화면 왼쪽 칸 = 렉2.

## 지금 구조 (11/16 기준)

**상태 = FSM 하나 (status.h `state`, 11/16)** — 전엔 `status · pause_why · pause_rack · run_rack · estop · manual · alarm_no` 7개 변수
```
state.now  'I' 초기상태 (켠 직후 · RESET 뒤)  → 시작 → 'H'
           'H' 원점중                         → 끝 'W' / 실패 'A'(10)
           'W' 대기                           → PC MI·MO·PO → 'R' / 일시정지 → 'S' / 수동 → 'M'
           'R' 운전                           → 끝 'W' (AI·EO 는 PC 승인 때, AO 는 R 그대로) / 멈춤 → 'S'
           'S' 멈춤 (시작 기다림)              → 시작 → state.prev (why : 'M' 일시정지 · 'F' 만재 · 'T' 틸트 · 'S' 시딩월)
           'M' 수동 (W · I 에서만)             → 수동 버튼 → state.prev / 시작(전 I) → 원점
           'E' 긴급정지                        → 풀면 'A'
           'A' 알람                            → RESET → 'I'
state.prev (멈춤 · 수동 전) · state.why · state.rack (운전 렉) · state.alarm (번호)
Motor_Stop() = 'E' 또는 'A' (모터 문 2). 어디서 바뀌는지 표 = status.c 맨 위
버튼 하나 = 일 하나 : RESET = 리셋만(→ I) / 시작 = 원점(I) · 이어서(S) / 수동 = 켜기 · 끄기
모터 문 1 run.c Motor_Request : W = 원점·MI·MO·PO / I = 원점만 / R = MI·MO·PO 만 / 그 밖 NAK
```

**태스크 · 큐 (app_freertos.c, ioc)**
```
Event_Task (High)        EventQueue 기다림 (최대 20ms) ← HMI 버튼 (UART4 인터럽트, 바뀐 순간만) · 'E' 긴급정지 · 'M' 만재 (EXTI)
                         estop_event → manjae_change → hmi_event → (X JOG 다시 쓰기) → A_01 → HMI_Send(20ms 물음) → lamp_event
Motor_Task (AboveNormal) MoveQueue(1칸) Peek → Motor_Run → Get
Bus_Task (AboveNormal)   11/16 새로 (ioc). 지금은 20ms 바퀴 + alarm.c Alarm_Drive (드라이브 알람 02~04 · 11, 1초마다) 만
                         BusQueue(4칸, uint8_t) 는 아직 안 씀. 스택 512워드
Comm_Task (Normal)       CommQueue 기다림 (최대 1ms, 사용자 결정 : 즉각) → CMD_Event · CLI_Run · NET_Run · CMD_Done
타이머 태스크            Manjae_Timer (만재 2초) · Rfid_Timer (0.5초)
뮤텍스                    Uart2Lock (UART2 를 Motor · Event · Comm · Bus 가 씀) → Bus_Task 로 다 옮기면 삭제 예정
```

**알람 (alarm.c 맨 위 표) · ESP 화면 글자** : 01 HMI 통신 = **터치에러** (ESP 가 STM 물음 100ms 못 받으면 직접 띄움, STM 은 대답 3번 없음 = 60ms) · 02 주행모터 · 03 리프팅모터 · 04 틸팅모터 (드라이브 알람) · 05~07 이탈 (8초 못 감) · 09 비상정지 · 10 원점 · 11 **모터에러** (드라이브 대답 없음 : X1 3번 묻고 → 약 2.5초) · 12 **랜선뽑힘**. 풀기 = RESET → 'I' → 시작 → 원점.

**완료응답** : cmd.c `ANS_1`(기본, PC 승인까지 1초마다) / `ANS_0`(한 번). 번호 = 마지막 PC 번호 그대로.

**통신 (11/16 정리)**
| 통신 | 선 · 속도 | 누가 먼저 | 받는 법 | 박자 · 선 사용 |
|---|---|---|---|---|
| 모터 4대 | RS485 UART2 115200 | STM 만 (ID 로 한 대) | DMA + IDLE → XFER_DONE | 대기 약 2% · 주행 약 30% · X JOG 20~40%. 묻고 받기 약 4ms (X 두 대 8ms) |
| ESP 화면 | RS485 UART4 115200 | **STM 만 (20ms 마다 물음, ESP 는 대답만)** | IT + IDLE → 바뀐 버튼만 EventQueue | 물음 27글자 2.3ms + 대답 4글자 0.4ms = 약 15% |
| PC | 이더넷 W6100 (SPI4) | PC | INT 핀 EXTI → CommQueue 'N' (즉시) | 1% 아래 |
| 카드 리더 | CAN 125k (FDCAN1 · 2) | STM 0.5초 'C' | 인터럽트 → rfid.c | 약 0.5% |
| CLI | UART1 115200 | 사람 | 글자마다 IT → 보관함 64칸 | Comm_Task 1ms 마다 꺼냄 |
- 충돌 안 나는 이유 : 모터 선 = STM 안 열쇠(Uart2Lock) 로 한 태스크만 + 드라이브는 자기 ID 만 대답 + CRC / ESP 선 = STM 이 묻고 ESP 는 대답만 (ESP `sendPacket` 은 받기 콜백에서만) / CAN = 하드웨어 중재 / TCP · CLI = 전이중.
- TX · RX LED 가 계속 켜져 보이는 건 1초 50번 깜빡 (눈이 못 따라감). 쉬는 시간 85%, 부품 무리 없음.

**모터 통신 숫자 (usart.h, 일부러 이 값)** : `MOTOR_RETRY 3` · `X_RX_MS 500` · `Y_RX_MS 50` · `T_RX_MS 500` · `BUS_GAP_MS 2`. 100ms · 1.75ms 로 줄였을 때 명령을 못 먹어서 되돌림. 어떤 명령이 느린지는 `uart2_us` 로 재 볼 것 (`dwt.h` 는 재고 나면 삭제).

**FRAM (save.h 지도)** : HEAD 0x0001 · FS 0x0010 · FI 0x0030 · FP 0x0200. `SAVE_VERSION 10`. 버전이 바뀌면 처음 켤 때 기본값 → PC `01ALL_PIMZ` · FI 다시.

**ESP (HMI) 프로젝트** : `workspace_1.19.0\HMI\HMI_Kor_260702\HMI_JC3248W535_v1.2` (VS Code PlatformIO, LVGL 8.3.11 = `lib/lvgl` 한 벌, `platformio.ini` lib_deps 는 GFX 만).
- 파일 : `main.cpp`(켜기 · 1ms 타이머 · 버튼 누르는 범위 12px) · `main.h`(보드 핀 · 화면 · 터치 보정 전부, 11/16 pincfg · dispcfg 합침) · `hmi.cpp/.h`(버튼 `Btn_Event` → `btn_put` / `Btn_Take`, 화면 글자 `SysInfoRefresh`, 표 `TaskString` · `PauseString` · `AlarmString`) · `serial1.cpp/.h`(STM 선 : `SerialReceive` → `HMI_Parser` → 받자마자 `TxEvent_BtnClick` 대답) · `AXS15231B_touch`.
- **STM 과 이야기하는 건 `Serial0`(UART0, P4 단자)** — `serial1.h` `#define RS485 Serial0`, 받기 = `Serial0.onReceive(SerialReceive)` 콜백. `Serial1`(IO17/18) 은 예비. RE/DE = GPIO15.
- STM ↔ ESP 글 (11/16) : STM → ESP 27글자 (`STX '1' 'C' 작업 일시정지 알람 센서20 ETX`) **20ms 마다 늘** / ESP → STM 4글자 (`STX '1' 버튼+'0' ETX`) **물음 받자마자**, 같은 버튼을 대답 3번에 실음 (`BTN_REPEAT 3`), 없으면 '0'. STM 은 바뀐 순간만 처리, JOG 가 안 실려 오면 = 뗌. ESP 화면은 STM 글이 바뀔 때만 다시 그림 (`HMI.Changed`).
- 숫자 : 터치 읽기 `lv_conf.h` `LV_INDEV_DEF_READ_PERIOD 10` (30 → 10) · `JOG_HOLD_MS 100` · `BTN_GAP_MS 300` · `TOUCH_ERR_MS 100` · 화면 넘김 페이드 150ms (`ui_*Screen.c`, SquareLine 재생성하면 500 으로 돌아감). 버튼 최대 늦음 약 33ms (터치 10 + 물음 20 + 3).
- **글꼴** : 화면 글꼴은 쓰는 글자만 그림으로 넣은 것. 새 글자는 `font_src\make_fonts.js` 글자 목록에 더하고 `make_fonts.bat` 더블클릭 (`font_src\읽어보기.txt`). 원본 NotoSansKR-Medium · SemiBold (Google Fonts OFL), 도구 `workspace_1.19.0\tools\` (Node v20.20.2 포터블 · lv_font_conv 1.5.3). 사수 명령 그대로라 기존 글자는 똑같이 나옴 (11/16 확인).
- 자동 생성 (손 안 댐) : `ui_*.c`, `fonts/`, `lib/`. ⚠️ `ui_*Screen.c` 의 `Btn_Event(e, 버튼, 0/1)` 줄 · 페이드 150 은 손으로 고친 것 → SquareLine 재생성하면 사라짐.
- `serial1.h` 는 옛 한글 인코딩(EUC-KR) → Claude 편집 도구로 못 고침.
- 빌드 `%USERPROFILE%\.platformio\penv\Scripts\pio.exe run`, 올리기 = 아래 막대 →. 올리기 전 COM6 시리얼 모니터 닫기, 안 되면 BOOT 버튼.
- 화면 보드 전원 : 외부 24V → (앞단에서 5V) → LM1117-3.3 (미지근 = 정상, 5V 입력이면 약 0.3~0.5W).

## 11/16 한 것

- **ESP 통신을 "묻고 대답하기"로** : STM 20ms 마다 묻고 ESP 는 콜백에서 바로 대답 (충돌 0, 가짜 ACK · 다시 보내기 · 1초 생존 없앰). STM `HMI_Send` 20ms · `HMI_Receive` 바뀐 순간만 + JOG 끊김 = 뗌 · `A_01` 대답 3번 없음 (부팅 3초는 안 봄). 터치 읽기 10ms. 버튼 누르는 범위 12px · 페이드 150ms. ESP 파일 줄임 (pincfg · dispcfg → main.h, 안 쓰는 파일 · lib 중복 삭제).
- **RESET · 시작 · 수동 역할 나눔** + 램프 · 부저는 **PC 2500 연결만** 봄 (`tcp_on`, 58080 · 50001 은 상관없음).
- **Bus_Task 시작** (ioc 사용자 추가) : 드라이브 알람 확인을 Event_Task → Bus_Task (`alarm.c Alarm_Drive`). 알람 11 은 X1 3번 실패로 바로 (`IM_Alarm`).
- **화면 알람 3개** : 모터에러(11) · 랜선뽑힘(12) · 터치에러(13, ESP 직접). 글꼴 다시 만듦 (`font_src`).
- **상태 FSM** : 변수 7개 → `state` 구조체 하나, 글자 I H W R S M E A, `!=` 없앰. 대기 중 일시정지도 됨. 알람이 나면 JOG 먼저 세움 (수동 Y JOG 가 계속 가던 위험).
- 지움 : `Motor_Busy` · `HMI_Quiet` · `alarm_event`(옮김) · `uart2_err` · 레지스터 이름 9개 · `t_motor.c id` · `lamp tcp_mode` 1바이트 등. text 62,556 → **62,412B**.
- 보드 확인됨 : ESP 새 통신 · 버튼 · JOG · 터치에러 · RESET 초기상태 · FSM 동작 (사용자 "테스트 잘 됨").

## 지금 상태 (2026-11-16 끝)

- STM 빌드 에러 0 · 경고 0, text 62,412B. ESP 빌드 성공 Flash 583,089B. 둘 다 보드에 올라감.
- **내일 바로 할 것 (허락 받음, 아직 안 고침)** :
  - MI → MI : `run.c MI` 의 MI→MI 칸에 `AM_Move(y) + A_06(AM_Arrive(y))` 2줄 → X 밖 → Y 끝 → X 안.
  - MI → MO · PO : 새 블록 `i_motor.c IM_Pass(x)` (X 두 모터가 x 를 지나 바깥쪽에 올 때까지, 최대 MOVE_MS, 멈춤 안 봄) + `run.c MO` 에서 `IM_MoveSoft(x)` 다음 `A_05(IM_Pass(save.fp.safe_x))` 다음 `AM_Move(y)`. X 안 섬 (사용자가 ⓐ 선택). PO 는 MO 를 불러서 같이 바뀜. MO · PO → MI 는 지금처럼 같이 출발.
- 원점 기다림 (`IM_Home` · `AM_Home`) 은 알람이 나도 최대 60초 계속 기다림 → 그동안 RESET → 시작 해도 원점 주문이 안 들어감. "알람이면 그만" 한 줄씩 제안함 (원점 코드라 허락 필요, 아직 안 함).

## 앞으로 할 것

1. **MI → MI · MI → MO/PO 순서** (위 "내일 바로 할 것") → 보드 확인 (높이 차이 큰 MI→MI, 입고대 → 렉).
2. **Bus_Task 다음 단계** : CLI 로 X 매핑 0x0F00 한 번에 읽기 · `uart2_us` (읽기 · 쓰기 대답 시간) 재기 → 칠판(위치 · 상태 · 알람) → `*_Arrive` · `IM_Pass` 가 칠판 보기 ("명령 뒤 새로 읽은 값만" 장치 필요) → 이동 · JOG 쓰기도 BusQueue → 열쇠 · `UART2_Send` · `motor_task` 삭제 + ioc `Uart2Lock` 삭제. 한 번에 4대 다 읽으면 115200 에서 100% → 20ms 에 2대씩 (각 모터 40ms 마다, 선 50%).
3. 원점 기다림에 "알람이면 그만" (허락 받으면).
4. 화면 보드 LM1117 3번 핀(IN) 전압 재기 (5V 면 정상). ESP `gfx->flush()` 5ms 마다 화면 전체 → 바뀔 때만 (열 · 화면 늦음 같이).
5. 옛 코드의 `!=` 정리 (통신 글자 확인 · strcmp 등) — 할지 사용자에게.
6. 현장 유지보수용 : run · 만재 · 모터 숫자 한 곳 · `[현장]` · "증상 → 볼 곳" 지도. 파일 합칠 후보 (lamp+buzzer, fram+eeprom, dwt.h, flag.h) 는 사용자가 정함.
7. **`dual_roder` 새 프로젝트** + 그 모터 데이터시트 분석 (오늘 못 함). 처음부터 통신 하나 = 담당 하나 · FSM 상태 · 레고 모양 · 현장 값 한 곳.
8. 와치독 (IWDG, 알람 10 에 이유로) — 보류.

## 사무실 ↔ 현장 (지금 파일 = 현장 값)

"사무실 값으로 / 현장 값으로 바꿔 줘" → `[현장]` 검색 (Ctrl+Shift+F) 해서 옆 주석대로. 사무실 = X 모터 하나(ID 3) · Y · 틸트 · HMI · RFID 없음.

| 파일 | 현장 (지금) | 사무실 |
|---|---|---|
| i_motor.c | `IM_2_ID 4` · `IM_ALL_ID 0` | 3 · 3 |
| i_motor.h | `IM_HOME_HI_RPM 180` · `IM_HOME_LO_RPM 80` · `IM_HOME_FORCE 35` | 50 · 30 · 10 |
| a_motor.h | `AM_HOME_TORQUE 600` | 100 |
| event.c `Event_Run` | `Rfid_Init();` · `A_01();` 켬 | 주석 |
| cmd.c `CMD_Event` | `PC_FF` · `PC_CARD` 두 줄 켬 | 주석 |
| run.c `po_stop` | `if (card_on(rack) == 0) Pause_Set(rack, 'S');` 켬 | 주석 |
| (코드 아님) 완료응답 승인 | 기본 `ANS_1` | 시험 때 PC `01ANS_0` (재부팅하면 ANS_1) |

## 참고

- 전체 빌드 (명령줄) : CubeIDE plugins 의 `gnu-tools-for-stm32 … tools\bin` 과 `make … tools\bin` 을 PATH 에 넣고 `Debug` 폴더에서 `make -j8 all` → `arm-none-eabi-size threeD_roder.elf`.
- 펌웨어 직접 올리기 : `STM32_Programmer_CLI.exe -c port=SWD -w 파일.elf -v -rst` (CubeIDE plugins 의 cubeprogrammer `tools\bin`).
- CLI : Tera Term, STLINK-V3 VCP 115200, **로컬 에코 끄기**. 명령 `X/Y pulse percent` · `C percent` · `R/L deg percent` · `S` · `I` · `INIT` · `IP` · `FRAM` · `DATA` · `REG` · `MANUAL`.
- TCP 시험 : `<STX>01MI_1_1_2_050_050_100_000_000<ETX>` (번호 필수, MI · MO 8개 / PO 9개), 승인 `01AI_1_1_2`. 서비스 포트 58080 (같은 명령 · 20초 끊기 없음 · `[TX]`/`[RX]`), 로그 50001.
- 데이터시트 · 프로토콜 : https://github.com/ParkSeong0425/3D (`2차소터 프로토콜_V1.3_260916.pdf`, `3DS_motor_DataSheet/` iCL-RS · AIMmotor · TL57-R). GitHub : https://github.com/ParkSeong0425/ThreeD_roder
- 사수 펌웨어 분석 : `docs/senior_fw/읽어보기.md`. 파일별 리뷰 : `docs/review_1109.md`.
- 공부 자료 : Digi-Key "Introduction to RTOS" 1~4편, Mastering the FreeRTOS Real Time Kernel (freertos.org PDF), 혼자 공부하는 C언어 (교재).
