# threeD_roder (3D 로더, 회사 기본 코드) — Claude 작업 안내서 (마지막 갱신 2026-11-19)

STM32G473VCT6 (170MHz) + FreeRTOS(CMSIS-RTOS2) + STM32CubeIDE 1.19.
3축 로봇(X 두 모터 / Y / 틸트)을 RS485 Modbus RTU 드라이브로 움직이고, PC 와 TCP(W6100), 터치화면(ESP32)과 RS485, 카드 리더와 CAN 으로 통신한다.
사용자는 펌웨어를 배우는 중이다. 설명은 **한국어 · 이론 + 움직이는 그림(애니메이션) · 우리 기계 실제 부품 예시**로 한다.

## ▶ 이 코드의 목적 (11/13 사용자 결정)

- **threeD_roder = 회사 기본 코드.** 현장마다 로봇 규격에 맞춰 고치고 오래 유지보수한다.
- **현장 사람이 고칠 수 있게** : run · 만재 · 모터 숫자처럼 현장마다 바뀌는 값은 **찾기 쉽고 뜻이 적힌 한 곳**에 둔다 (주석 · `[현장]` 표시 · "증상 → 볼 곳" 지도).
- **현장에서 고치는 곳은 `run.c` · 모터 파일(i · a · t_motor) · 태스크 스위치판(app_freertos.c)만** (11/17). 나머지는 기본 세팅. 기능 끄기 = 스위치판의 `[기능]` 줄 주석.
- **통신 · RTOS 같은 바탕 지식은 사용자가 알고 있어야 한다** → 바꿀 때마다 이론 + 그림으로 설명.
- **새 프로젝트 `dual_roder`** 를 이 코드를 토대로 새로 만든다. 이것도 회사 코드가 되니 처음부터 깔끔한 구조로.

## ▶ 새 세션 시작 (zip 을 받거나 "이어서 하자" 하면)

**zip 만들기 (회사 → 집)** : `threeD_roder` (단 `Debug/` 빼고) + `HMI\HMI_Kor_260702\HMI_JC3248W535_v1.2` (단 `.pio/` · `build/` 빼고). 글꼴을 다시 만들 일이 있으면 `workspace_1.19.0\tools\` (Node 포터블 · lv_font_conv, 약 80MB) 도 따로. 집에서 같은 이름 폴더로 풀고, Claude Code 를 `threeD_roder` 폴더에서 열어 "이어서 하자". (Claude 의 메모리는 PC 마다 따로 → **이 파일이 유일하게 따라가는 기억**)

1. 이 파일 "작업 방식" · "코드 스타일" → "지금 구조" → "시딩월 · 틸트 값 계산" → "한 것" → "앞으로 할 것" 순서로 읽는다.
2. zip 을 받으면 : 지금 폴더를 `workspace_1.19.0\threeD_roder_before_날짜` 로 백업 → 사용자가 고친 곳을 먼저 찾아 보여 줌 (**사용자 수정 덮어쓰기 금지**) → 전체 빌드 (아래 "참고") 에러 · 경고 수 보고 → `[현장]` 검색해 사무실 / 현장 값 보고 → CubeIDE 열린 탭은 F5.
3. 그다음 "앞으로 할 것" 1번부터. 사용자가 다른 걸 말하면 그걸 먼저.
   - **할 일마다 공부를 같이 한다** (사용자 요청 11/13, 중요) : 그 단계에 나오는 개념을 먼저 **이론 (정의 → 왜 → 동작 순서 → 우리 코드 → 흔한 실수)** + **움직이는 그림 (canvas 애니메이션, 실제 부품 · 공이 선 위를 오가는 모양, 버튼으로 상황 바꾸기)** 으로 설명하고 나서 코드로 간다. 표 · 네모 상자 · 시간 막대(레인) 그림은 쓰지 않는다 (11/16 : 레인 그림 "더 이해가 안 감"). **통신은 특히** 이 방식으로.
4. 하루 끝 ("끝 · 마무리 · 여기까지") : 이 파일의 "한 것" · "지금 상태" · "앞으로 할 것" 을 그날 기준으로 고치고 바뀐 곳을 보여 준다.

## 작업 방식 (반드시 지킬 것)

1. **"그래 바꿔줘" 같은 분명한 허락 전에는 코드를 안 바꾼다.** 함수 하나 · 작은 단위 하나씩. 답은 ① 지금 역할 ② 문제 ③ 이유 ④ 바꿀 곳 (전 / 후) ⑤ 직접 확인할 것 ⑥ 다음 하나.
2. 바꾸기 전에 계획 : 어느 파일 → 어느 함수 → 무엇을 + 개념 + 왜 + 그림. 적용 후 파일별로 바뀐 줄 + 빌드 결과.
3. **코드 구조는 사용자가 먼저 정한다.** Claude 는 추천 · 설명 · 수정. 사용자가 짠 코드는 **사용자 스타일 그대로** 고친다 (변수 · 플래그 · 함수 덧붙이지 말고 있는 함수 안에서).
4. 새 함수 · 변수 · 구조체 · 플래그 · 처음 보는 문법은 **고치기 전에** "새로 생김 : 이름 · 뜻 · 왜 꼭 필요한지, 있는 것으로 안 되는지" 먼저 말한다 (11/16 : `Motor_Busy` · `on == &tcp_on` 을 말 없이 넣어서 혼남). 요청 안 한 곳(특히 **원점**)은 같이 고치지 않는다.
5. 판단 기준 = **안전(긴급정지 · 알람 · 통신 오류) > 버스(RS485) > CPU > RAM**. 리뷰할 때 CPU · 버스 · RAM 을 같이 말한다. 안전은 단순화한다고 빼지 않는다.
6. **설명 그림** : 네모 상자 · 화살표 · 시간 막대 그림 금지. **실제 부품을 그린 움직이는 그림 + 버튼으로 상황 바꾸기** (show_widget canvas). 그림 옆에 **이론** 을 꼭 같이. 답은 짧고 쉽게 (긴 글은 줄여 달라고 함).
7. 낯선 문법(삼항 `? :` 등) 쓰지 않음. 새 문법을 꼭 쓰면 먼저 "새 문법" 이라고 말한다.
8. GitHub `main` 에는 허락 없이 올리지 않는다.
9. 하루 끝에 이 파일 갱신 (위 새 세션 4). 노션 정리는 사용자가 원할 때만.
10. 줄 끝 맞추기(CRLF)는 **고친 파일만** (11/16 : 폴더 전체에 돌려서 CubeMX 생성 파일 syscalls.c · sysmem.c · system_stm32g4xx.c 를 CRLF 로 바꿨다가 LF 로 되돌림 — 이 셋은 원래 LF).

## 코드 스타일 (사용자가 원하는 것 — 계속 유지)

- **레고 모양** : 함수 = 다른 파일의 블록 함수를 한 줄씩 나열 (좋은 예 : `I()` · `MI` · `lamp_event` · `NET_Run`). 순서 = 우선순위.
  - R1 블록 = 한 가지 일, 성공 1 / 실패 0. R2 조립 함수 = 블록 나열 + 최소 if. R3 판단(조건 · 숫자)은 그 데이터를 가진 파일 안 (알람 alarm.c, 상태 status.c). R4 아래 층(모터 · 장치 파일)은 위 층을 모름. R5 switch 의 case 는 블록 한 줄. R6 장치 지식(레지스터 · 코드 이름표)은 장치 파일. R7 태스크 사이는 큐 · 상태판 · 플래그로.
  - 새 함수보다 **있는 함수 안으로 옮기기**가 먼저. 함수 · 변수 늘어나는 것 싫어함. "부르기만 하는 포장 함수" 는 없앤다 (이름이 단계를 설명하면 남김 : `TM_C/R/L` 등). **대입을 감싸는 함수도 싫어함** (11/16 `State_Go` 지움 → `state.now = 'W';` 바로).
  - "해도 되나" 확인은 그 일을 하는 블록 맨 앞.
- `if (!Func())` 금지 → `if (Func() == 0)`. `== 1` 안 씀 → `if (Func())`. **`!=` 도 쓰지 않음** (11/16) → `==` 와 `if { }` 블록으로. (옛 코드의 `!=` 는 아직 남아 있음 : 통신 글자 확인 · strcmp 등)
- 성공 1 / 실패 0 반환, 실패는 `return 0` 으로 위로.
- 여러 레지스터 쓰기 : 움직이기 · 설정 = `&&` (앞이 실패하면 뒤 안 함) / 멈추기 = 따로 다 보내고 결과만 합침.
- **모든 while 기다림에는 시간 제한** (`osKernelGetTickCount()` 시작 시각 비교). 예외 : 일시정지 대기.
- 시간 숫자는 ms, 이름은 `_MS`. 맨숫자 피함 (거리 숫자 · `osDelay(2)` 같은 짧은 쉬기는 예외로 그 자리에 숫자 + 주석).
- 단계마다 한글 한 줄 주석. 짧고 쉽게. 디버그 출력은 원인 찾으면 지운다.
- `save.c` · `cmd.c` 의 풀어 쓴 모양은 일부러 → 배열로 바꾸자고 하지 않는다.
- 일부러 남긴 안 쓰는 함수 : `AM_BaudInit` · `uart_speed` · `EEPROM_MAC`, CLI `REG` → 지우자고 하지 않는다. 그 밖에 **확실히 안 쓰는 변수 · 레지스터 이름은 지운다** (11/16 사용자).
- 변수는 주인 파일 `.h` 에 `extern` 한 번. RTOS 핸들은 `main.h` USER CODE 에.
- CubeMX 생성 파일은 **USER CODE BEGIN ~ END 안에만**. 설정은 ioc 에서 (사용자가 함).
- 파일은 **CRLF** (CubeMX 생성 syscalls.c · sysmem.c · system_stm32g4xx.c 는 LF 그대로). 고친 뒤 bareLF 0 확인.
- 렉1 = 오른쪽 렉 (홀수 렉 = `right_*` 표), 렉2 = 왼쪽. HMI 화면 왼쪽 칸 = 렉2.

## 지금 구조 (11/17 기준)

**상태 = FSM 하나 (status.h `state`, 11/16)** — 전엔 `status · pause_why · pause_rack · run_rack · estop · manual · alarm_no` 7개 변수
```
state.now  'I' 초기상태 (켠 직후 · RESET 뒤)  → 시작 → 'H'
           'H' 원점중                         → 끝 'W' / 실패 'A'(10)
           'W' 대기                           → PC MI·MO·PO → 'R' / 일시정지 → 'S' / 수동 → 'M'
           'R' 운전                           → 끝 'W' (AI·EO 는 PC 승인 때, AO 는 R 그대로) / 멈춤 → 'S'
           'S' 멈춤 (시작 기다림)              → 시작 → state.prev (why : 'M' 일시정지 · 'F' 만재 · 'T' 틸트 · 'S' 시딩월)
           'M' 수동 (W · I 에서만)             → 수동 버튼 → state.prev / 시작(전 I) → 원점
           'E' 긴급정지                        → 풀면 'A'
           'A' 알람                            → RESET → 'I'
state.prev (멈춤 · 수동 전) · state.why · state.rack (운전 렉) · state.alarm (번호)
Motor_Stop() = 'E' 또는 'A' (모터 문 2). 어디서 바뀌는지 표 = status.c 맨 위
버튼 하나 = 일 하나 : RESET = 리셋만(→ I) / 시작 = 원점(I) · 이어서(S) / 수동 = 켜기 · 끄기
모터 문 1 run.c Motor_Request : W = 원점·MI·MO·PO / I = 원점만 / R = MI·MO·PO 만 / 그 밖 NAK
```

**태스크 = 스위치판 (app_freertos.c 태스크 함수, 11/17)** : 태스크 함수 = 블록 한 줄씩. `[기능]` 줄을 주석 처리하면 그 기능이 통째로 꺼짐 (event.c `Event_Run` 은 없앰)
```
Event_Task (High)        Rfid_Init[기능] · UART4_Start → Event_Wait (EventQueue 최대 20ms) → estop_event[기능] → manjae_change[기능]
                         → hmi_event → A_01 → HMI_Send[기능] (20ms 물음) → lamp_event[기능]
Motor_Task (AboveNormal) Motor_Run (MoveQueue 1칸 Peek → 원점 / MI · MO · PO → Get)
Bus_Task (AboveNormal)   모터 선 담당. osDelayUntil 40ms → IM_Read · AM_Read · TM_Read (칠판) → Alarm_Drive (칠판 보고 알람). 스택 512워드
                         BusQueue(4칸) 는 아직 안 씀 (C 단계). 칠판 지도 = Start_Bus_Task 위 주석
Comm_Task (Normal)       Save_Init → NET_Init[기능] → btn_run (켤 때 원점) → CMD_Event (1ms) · CLI_Run[기능] · NET_Run[기능] · CMD_Done
타이머 태스크            Manjae_Timer (만재 2초) · Rfid_Timer (0.5초)
뮤텍스                    Uart2Lock (UART2 를 Motor · Event · Comm · Bus 가 씀) → C 단계 끝나면 삭제
```

**칠판 (11/17)** : `usart.h MOTOR {pos · state · alarm · miss}` 한 칸 = 모터 한 대. `im1` · `im2` (i_motor) · `am` (a_motor) · `tm` (t_motor). Bus_Task 만 적고 나머지는 보기만.
- 적기 : X = `0F00` 부터 5칸 (`IM_MapInit` 이 원점 시작 때 0x1003 상태 · **0x602C/D 위치** (11/18 : 0x1014 Feedback 은 X2 가 방향 반대라 − 로 나와 A05 → Actual position 으로) · 0x2203 알람 · 0x601D 경고를 모아 둠) / Y = `0B07` 2칸 위치 + `0B22` 고장 코드 (11/18 : 0B05 부터 4칸 묶어 읽기는 −6553 처럼 엉뚱한 값 → 되돌림) / 틸트 = `0004` 부터 6칸 (상태 · 알람 · 위치 0008/9).
- 한 번씩만 묻고 (`BUS_RX_MS 50`, 11/18 : 5 였을 때 Y 의 늦은 대답이 다음 명령과 부딪혀 PO 때 Y 가 안 올라감) 못 받으면 칠판 그대로 + `miss` +1 → 다음 바퀴에 다시. 받으면 `miss` 0.
- 보기 : `IM_Arrive` · `IM_Pass` · `AM_Arrive` · `TM_Arrive` · `IM_MoveSoft` (출발 위치) · `IM_Home` / `AM_Home` (원점 전 거리 `far`, X 는 매핑 뒤 80ms 기다림) · run.c MI (MI→MI) · `move_done` 로그 · `Alarm_Drive`.
- 지움 : `IM_Pos` · `AM_Pos` · `TM_Pos` · `TM_Done` · `IM_Alarm` · `AM_Alarm` · `TM_Alarm` · `read_pos` · `read32` · `A_11(log)`. 원점 안의 상태 읽기 (`IM_State` · `AM_Done` · `AM_HomeDone`) 는 아직 옛 읽기 (원점은 허락 받고).

**알람 (alarm.c 맨 위 표) · ESP 화면 글자** : 01 HMI 통신 = **터치에러** (ESP 가 STM 물음 100ms 못 받으면 직접 띄움, STM 은 대답 3번 없음 = 60ms) · 02 주행모터 · 03 리프팅모터 · 04 틸팅모터 (드라이브 알람, 칠판 alarm 칸) · 05~07 이탈 (8초 못 감 / **그 축 한 대만 대답 3번 없음** 로그 X1 · X2 · Y · Tilt / **X1 · X2 차이 50mm 넘음** 05) · 09 비상정지 · 10 원점 · 11 **모터에러 = 4대 다 대답 없음 (모터 선 UART2 · 전원)** · 12 **랜선뽑힘**. 대답 없음 · 차이 · 드라이브 알람은 Bus_Task `Alarm_Drive` 40ms (I · H · E · A 때는 안 봄). 숫자 `alarm.h BUS_MISS 3` · X 차이 `50` 은 alarm.c `bus_alarm` 안에 숫자로 [현장] (사용자 11/18 : 이름 대신 숫자). 풀기 = RESET → 'I' → 시작 → 원점 (원점이 X 두 대를 다시 맞춤).

**완료응답** : cmd.c `ANS_1`(기본, PC 승인까지 1초마다) / `ANS_0`(한 번). 번호 = 마지막 PC 번호 그대로.

**통신 (11/17 정리)** — 한 번 묻고 받기 = 보내기 0.7 + 대답 약 2 (최대 `BUS_RX_MS 50`) + 쉬기 2 (`BUS_GAP_MS`, Modbus 3.5글자 1.75ms + 여유) ≈ 4.5ms
| 통신 | 선 · 속도 | 누가 먼저 | 받는 법 | 박자 · 선 사용 |
|---|---|---|---|---|
| 모터 4대 | RS485 UART2 115200 | STM 만 (ID 로 한 대, 쓰기는 X 주소 0 = 둘 같이 · 대답 없음) | DMA + IDLE → XFER_DONE | Bus_Task **40ms 마다 4대 한 번씩** ≈ 19ms → 평소 선 약 47% (Y 고장 코드는 1초에 한 번, 11/18 A2). X JOG 중 +13% (다시 쓰기는 동작 글자만, A1) ≈ 62%. 명령 (이동 · JOG · 멈춤) 은 아직 Motor · Event 가 열쇠 잡고 직접 |
| ESP 화면 | RS485 UART4 115200 | **STM 만 (20ms 마다 물음, ESP 는 대답만)** | IT + IDLE → 바뀐 버튼만 EventQueue | 물음 27글자 2.3ms + 대답 4글자 0.4ms = 약 15% |
| PC | 이더넷 W6100 (SPI4) | PC | INT 핀 EXTI → CommQueue 'N' (즉시) | 1% 아래 |
| 카드 리더 | CAN 125k (FDCAN1 · 2) | STM 0.5초 'C' | 인터럽트 → rfid.c | 약 0.5% |
| CLI | UART1 115200 | 사람 | 글자마다 IT → 보관함 64칸 | Comm_Task 1ms 마다 꺼냄 |
- 충돌 안 나는 이유 : 모터 선 = STM 안 열쇠(Uart2Lock) 로 한 태스크만 + 드라이브는 자기 ID 만 대답 + CRC / ESP 선 = STM 이 묻고 ESP 는 대답만 (ESP `sendPacket` 은 받기 콜백에서만) / CAN = 하드웨어 중재 / TCP · CLI = 전이중.
- TX · RX LED 가 계속 켜져 보이는 건 1초 50번 깜빡 (눈이 못 따라감). 쉬는 시간 85%, 부품 무리 없음.

**통신 손잡이 = `Core/Inc/comm.h` 한 곳 (11/23, 이름은 사용자가 정함)** : 모든 선 = 박자 `_MS` · 기다림 `_WAIT_MS` · 놓침 `_MISS` (알람 시간 = 박자 × 놓침). `MOTOR_MS 40` · `MOTOR_WAIT_MS 50` (Bus_Task 읽기, 1번) · `MOTOR_MISS 3` · `X/Y/T_RX_MS` (명령 · 원점 읽기, 3번 — 11/10 에 100 으로 줄였다 명령 못 먹어 되돌림 → 쓰기 대답 시간 재기 전엔 안 줄임) · `HMI_MS 20` · `HMI_MISS 3` · `HMI_BOOT_MS 3000` · `NET_MS 100` · `MOVE_DONE_MS 1000` · `CARD_MS 500` · `SENSOR_MS 2000`. **규칙 : 통신 시간은 comm.h 이름으로만 씀** (맨숫자로 쓰면 comm.h 를 고쳐도 안 따라옴 — 새 modbus.c 도). 예) MOTOR_MS 1000 으로 하면 빌드는 되지만 도착 확인 · Pass 가 최대 1초씩 늦고 대답 없음 알람 3초 → 요청한 사람에게 먼저 말함.
- **칠판 초인종 `BOARD_NEW 0x100` (flag.h, 11/23)** : Bus_Task 가 칠판 다 적으면 `osThreadFlagsSet(Motor_TaskHandle, BOARD_NEW)` → `IM_Arrive` · `IM_Pass` · `AM_Arrive` · `AM_Pass` · `TM_Arrive` 가 `osDelay(20)` 대신 이걸 기다림 (최대 2 × MOTOR_MS). 새 값만 딱 한 번씩 봄. 원점 안 직접 묻기 4줄은 `ARRIVE_MS` 그대로. usart.h 는 `#include "comm.h"` + Modbus 고정값 `MOTOR_RETRY 3` · `BUS_GAP_MS 2` 만. `MOVE_MS` · `ARRIVE_MS` (alarm.h) · `HOME_FAST_MS` (alarm.c) 는 알람 쪽 그대로. lamp.c `2000` (PC 끊긴 뒤 램프) 은 뜻이 달라 그대로. ESP 짝 = ESP hmi.h `TOUCH_ERR_MS` (HMI_PERIOD_MS × 5).
- 옛 이름 → 새 이름 (아래 글의 옛 이름은 이걸로 읽기) : `BUS_MS` → `MOTOR_MS` · `BUS_RX_MS` → `MOTOR_WAIT_MS` · `BUS_MISS` → `MOTOR_MISS` · `EVENT_MS` · `HMI_POLL_MS` → `HMI_MS` · `ASK_MS` → `CARD_MS` (500, 묻기) · `MANJAE_MS` · 옛 `CARD_MS`(2000) → `SENSOR_MS` · `PHY_MS` → `NET_MS` · cmd.c `1000` → `MOVE_DONE_MS`.

**모터 통신 숫자 (옛 설명, 이름은 위 표로)** : Bus_Task = `BUS_MS 40` · `BUS_RX_MS 50` (1번만, 보통 2ms 에 옴. 한 바퀴 보통 23ms / 한 대 늦음 약 71ms / 4대 다 죽음 약 211ms). 옛 쓰기 · 원점 읽기 = `MOTOR_RETRY 3` · `X_RX_MS 500` · `Y_RX_MS 50` · `T_RX_MS 500` (C 단계에서 정리). `BUS_GAP_MS 2`.
- 11/17 잰 것 (`uart2_us` · `uart2_max_us`, Live Expressions) : 평소 대답 약 1.9ms. **X1 은 원점 닿는 순간 0.5초 넘게 대답 안 함** (그래서 H 때는 놓침을 안 셈) · **Y 는 MO · PO 중 가끔 50ms 넘게 대답 안 함** (1~2 바퀴라 3번에 안 걸림). 측정용 `uart2_us` · `uart2_max_us` · `dwt.h` 는 11/19 삭제 (C3). 다시 재려면 DWT 스톱워치를 잠깐 다시 넣음.
- X 급정지 감속 `i_motor.h IM_DEC_MS 500` (Pr8.23, ms, 직선). **가는 중엔 Pr8.23 을 안 받아서 `IM_MapInit` (서 있을 때) 이 미리 넣고, `IM_Stop` 은 0x040 만** (11/17, 사용자 "아주 맘에 듦"). 거리 = 속도 × 시간 ÷ 2 (100% 1667mm/s → 약 420mm).
- X 드라이브 DI 에 `0x22 Quick stop` 기능이 있음 → 비상정지를 드라이브 단자에 직접 거는 것도 가능 (배선, 나중에).

**FRAM (save.h 지도)** : HEAD 0x0001 · FS 0x0010 · FI 0x0030 · FP 0x0200. `SAVE_VERSION 10`. 버전이 바뀌면 처음 켤 때 기본값 → PC `01ALL_PIMZ` · FI 다시.

**ESP (HMI) 프로젝트** : `workspace_1.19.0\HMI\HMI_Kor_260702\HMI_JC3248W535_v1.2` (VS Code PlatformIO, LVGL 8.3.11 = `lib/lvgl` 한 벌, `platformio.ini` lib_deps 는 GFX 만).
- 파일 : `main.cpp`(켜기 · 1ms 타이머 · 버튼 누르는 범위 12px) · `main.h`(보드 핀 · 화면 · 터치 보정 전부, 11/16 pincfg · dispcfg 합침) · `hmi.cpp/.h`(버튼 `Btn_Event` → `btn_put` / `Btn_Take`, 화면 글자 `SysInfoRefresh`, 표 `TaskString` · `PauseString` · `AlarmString`) · `serial1.cpp/.h`(STM 선 : `SerialReceive` → `HMI_Parser` → 받자마자 `TxEvent_BtnClick` 대답) · `AXS15231B_touch`.
- **STM 과 이야기하는 건 `Serial0`(UART0, P4 단자)** — `serial1.h` `#define RS485 Serial0`, 받기 = `Serial0.onReceive(SerialReceive)` 콜백. `Serial1`(IO17/18) 은 예비. RE/DE = GPIO15.
- STM ↔ ESP 글 (11/16) : STM → ESP 27글자 (`STX '1' 'C' 작업 일시정지 알람 센서20 ETX`) **20ms 마다 늘** / ESP → STM 4글자 (`STX '1' 버튼+'0' ETX`) **물음 받자마자**, 같은 버튼을 대답 3번에 실음 (`BTN_REPEAT 3`), 없으면 '0'. STM 은 바뀐 순간만 처리, JOG 가 안 실려 오면 = 뗌. ESP 화면은 STM 글이 바뀔 때만 다시 그림 (`HMI.Changed`).
- 숫자 : 터치 읽기 `lv_conf.h` `LV_INDEV_DEF_READ_PERIOD 10` (30 → 10) · `JOG_HOLD_MS 100` · `BTN_GAP_MS 300` · `TOUCH_ERR_MS 100` · 화면 넘김 페이드 150ms (`ui_*Screen.c`, SquareLine 재생성하면 500 으로 돌아감). 버튼 최대 늦음 약 33ms (터치 10 + 물음 20 + 3).
- **글꼴** : 화면 글꼴은 쓰는 글자만 그림으로 넣은 것. 새 글자는 `font_src\make_fonts.js` 글자 목록에 더하고 `make_fonts.bat` 더블클릭 (`font_src\읽어보기.txt`). 원본 NotoSansKR-Medium · SemiBold (Google Fonts OFL), 도구 `workspace_1.19.0\tools\` (Node v20.20.2 포터블 · lv_font_conv 1.5.3). 사수 명령 그대로라 기존 글자는 똑같이 나옴 (11/16 확인).
- 자동 생성 (손 안 댐) : `ui_*.c`, `fonts/`, `lib/`. ⚠️ `ui_*Screen.c` 의 `Btn_Event(e, 버튼, 0/1)` 줄 · 페이드 150 은 손으로 고친 것 → SquareLine 재생성하면 사라짐.
- `serial1.h` 는 옛 한글 인코딩(EUC-KR) → Claude 편집 도구로 못 고침.
- 빌드 `%USERPROFILE%\.platformio\penv\Scripts\pio.exe run`, 올리기 = 아래 막대 →. 올리기 전 COM6 시리얼 모니터 닫기, 안 되면 BOOT 버튼.
- 화면 보드 전원 : 외부 24V → (앞단에서 5V) → LM1117-3.3 (미지근 = 정상, 5V 입력이면 약 0.3~0.5W).

## 시딩월 · 틸트 값 계산 (11/19, 현장에서 자로 재고 계산 → FP 에 넣음)

현장마다 시딩월 크기가 달라서 **코드는 안 바꾸고 FP 값만** 계산해서 넣는다. 사용자가 CLI `X mm %` · `Y mm %` 로 맞는지 확인 → FP.
- 단위 : X 펄스 = mm × 100 (10000펄스 = 100mm) / Y 펄스 = −(mm × 10) (320 × 5 ÷ 160) / 틸트 펄스 = 도 × 55.6 (1000 × 20 = 360°).
- 판(틸트) : 쏟는 방향 폭 460 (축에서 끝까지 230) · X 방향 폭 380 (절반 190). 실험실 바구니 5개 2070 → 한 칸 W = 414.
- **열 X (FP 3 · 5)** : X=0 에서 자로 A = 판 원점 쪽 끝 → 바구니5 원점 쪽 끝. `x5 = A + W/2 − 190`, `x[열] = x5 + (5 − 열) × W` (기둥이 있으면 W = (바구니1 가운데 − 바구니5 가운데) ÷ 4).
- **단 Y (FP 4 · 6)** : Y=0 에서 B = 1단 선반 윗면 − 판 윗면, H = 단 간격. `y[단] = B + (단 − 1) × H`.
- **SAFE X (FP 13)** : 아무 열보다 입구 쪽이면 됨. 1열이 safe_x 보다 안쪽이어도 MO 가 알아서 (아래 11/19). 입구 천천히 구간 = IN_X − SAFE_X.
- **틸트 높이 (FP 7 tilting_y)** : 기울이면 판 끝이 `230 × sin θ` 내려감 → 판 끝 높이 = tilting_y − 230 × sin θ. 시험으로 확인한 기준 (240, 50° → 판 끝 64mm, 렉에 안 닿음) 을 다른 각도로 옮기면 `tilting_y = 240 + 230 × (sin θ − sin 50)` (60° 263 · 65° 272 · 70° 280).
- **큰 상품 걸림** (위층 시딩월 기둥과 렉 선반 사이 틈 G 로 들어갈 때 상자 위 모서리가 기둥에 걸림, 4단은 기둥 없어 안 걸림) : 상자 꼭대기 = `e + a × sin θ + b × cos θ < G − 10` (e = 기울였을 때 판 끝 ~ 렉 윗면, a = 눕는 길이, b = 높이. 13×16 상자는 51° 에서 제일 넓음 → 각도를 키울수록 유리). **e · G 를 자로 재서 각도 정하기 = 아직 안 함.** 각도기 없으면 스마트폰 수평계 또는 `θ = asin(판 두 끝 높이 차 ÷ 460)`.
- PO 각도 = **PC 명령 각도**. FP 7 `tilt_angle` 은 저장만 되고 안 씀. 각도에서 tilting_y 자동 계산은 안 하기로 (사람이 계산해서 FP 7, 11/19).
- 실험실 FP (11/19) : IN_X 1705 · LEFT/RIGHT_X 1625 1225 825 415 0 · Y 0 510 1020 1530 · SAFE_Y 0 510 · TILTING Y 240 · SAFE X 1600.

## 11/18 ~ 19 한 것

- **PO 틸트 안 됨** : `AM_Arrive`(±10 창) 가 40ms 사이에 절반 지점을 건너뜀 → `AM_Pass` (넘었나) 새로. `tilt_pour` 에 `A_06(AM_Move(...))`.
- **Y −6553 · PO 때 Y 안 올라감** : 0B05 4칸 묶어 읽기 → 0B07 2칸으로 되돌림 / Bus 기다림 5ms 가 짧아 Y 늦은 대답이 다음 명령과 부딪힘 → `BUS_RX_MS 50`.
- **원점 직후 A05 (X1 70 · X2 −71)** : 0x1014 Feedback 은 X2 가 방향 반대 → 매핑을 **0x602C/D Actual position** 으로.
- **CLI X2 · `IM_Move2` 지움** (X 가 대차로 묶여 한쪽만 못 감). X 차이 숫자 `X_SKEW_MM` → alarm.c `bus_alarm` 안 숫자 `50` [현장].
- **A1** X JOG 다시 쓰기는 동작 글자만 (속도는 누를 때만) / **A2** Y 고장 코드는 1초에 한 번 → 평소 선 약 47%.
- **RFID 번호 0000000** (`card_ok` 기본 1 이라 번호를 바뀔 때만 적어서) → 번호는 늘 적고 PC 알림만 바뀔 때.
- **24/7 점검** : tick 49.7일 넘어감 = 기다림이 전부 `지금 − 시작` 이라 안전 · 도는 중 새 메모리 없음 · CPU 거의 0. 남은 것 = 스택 여유 (Bus 포함) · 와치독 · 드라이브 통신 끊김 감시 · 에이징.
- **MO 1열 A05 (11/19 에이징)** : 1열 X 1625 > SAFE X 1600 → `IM_Pass(safe_x)` 가 8초 기다림. run.c `MO` : `if (x < safe_x) IM_Pass(safe_x) / else IM_Arrive(x)` → 보드 확인 "이제 됨".
- MI 를 MI→MI 처럼 (Y 먼저 → X) 바꾸는 건 사용자가 패스.
- 시딩월 · 틸트 계산식 (위 칸) 정리, X · Y 는 계산값으로 맞춤 확인.
- **C3** 측정용 `uart2_us` · `uart2_max_us` · `dwt.h` · `DWT_Init` 삭제 (usart.c · app_freertos.c).
- **Bus_Task C 단계 결정** : 전체 C (쓰기도 Bus_Task 가, 열쇠 삭제) 는 안 함 → 지금 "읽기 = Bus · 쓰기 = 열쇠" 유지. 전체 C 는 dual_roder 에서 처음부터. C2 (원점 읽기 칠판) 는 뺌.
- text **62,948B** (에러 0 · 경고 0).

## 11/23 한 것

- 통신 공부 (코드 수정 없이 시작) : STM 박자 · 태스크 시계 / 모터 읽기 · 쓰기 바이트 (write16 · write_multi · write32 · write_regs, 32비트 쪼개기 : X · 틸트 = 위 칸 먼저, **Y(AIM) = 아래 칸 먼저**) / 화면 27 · 4바이트 / 만재 GPIOE IDR 비트 (7~14, 0x7F80) / ESP 함수 (1ms 타이머 · 5ms loop · 받기 콜백 · 60초 무응답이면 esp_restart).
- 사용자 결정 : 통신 숫자 종류를 줄여 **한 곳 comm.h** (박자 · 기다림 · 놓침 세 단어) · 모터 글 코드는 **modbus.c 로 모음** (다음 단계) · usart.c 는 선 담당 그대로 (콜백 · DMA 칸 · 열쇠가 같은 파일에 있어야 해서). `_Static_assert` 는 안 씀.
- **comm.h 만듦 + 이름 옮김** (동작 그대로) : 17 파일 이름 바꿈 + 옛 #define 지움 + include. 사용자가 comm.h 이름을 짧게 고침 (MOTOR_MS · HMI_MS · NET_MS · MOVE_DONE_MS · CARD_MS · SENSOR_MS) → 쓰는 곳 맞춤.
- **칠판 초인종 BOARD_NEW** : Arrive · Pass 5개가 20ms 마다 그냥 보던 것 → Bus_Task 가 다 적었을 때 깨워 줌.
- `MOTOR_WAIT_MS` vs `X/Y/T_RX_MS` 정리 : 읽기(1번, 50) / 명령(3번, 500). 명령 기다림을 50 으로 줄이는 C1 은 **보류** (11/10 실패 기록, 쓰기 대답 시간 측정 먼저).
- **modbus.c / modbus.h 새로 (2단계 : 읽기)** : `MB_Crc` (세 파일 crc16 3개 → 1개, 삼항 없이) · `MB_Read(id, reg, qty, out, tries, wait_ms)` (i · t_motor read_reg 지움, `!=` 없이). a_motor `read_regs` 는 MB_Read 부르고 **Y 32비트 아래 칸 먼저 합치기만** 남김 (장치 지식). 쓰기 (write16 · write_multi · write32 · write_regs) 는 아직 모터 파일 (MB_Crc 만 씀) → 3단계 MB_Write.
- 명령줄 빌드 : 새 .c 는 `Debug/Core/Src/subdir.mk` · `Debug/objects.list` 에도 한 줄씩 넣어야 함 (CubeIDE 빌드는 저절로 다시 만듦).
- 빌드 에러 0 · 경고 0, text **62,596B** (−400B). 보드 확인 전.

## 지금 상태 (2026-11-23 오전)

- STM 빌드 에러 0 · 경고 0, text **62,596B**. 11/19 C3 · 11/23 comm.h · BOARD_NEW · modbus 읽기 = **보드에 아직 안 올림** → 시험 · 에이징 다음.
- 11/19 18:29 사용자 수정 확인 (Claude file-history v76 ↔ v77 비교) : `IM_Home` 원점 뒤 이동 속도 100 → **50rpm** (사용자 : 50 이 맞음). 거리는 `move_pos(25)` = **25mm** → 주석 "100mm" 3곳을 25mm 로 맞춤 (11/23). "원점 뒤 X 30mm" 할 일은 이걸로 끝 (25mm 유지).
- 아직 안 한 테스트 : X 차이 A05 (`bus_alarm` 50 → 잠깐 3 → `X 1000 100` → 되돌림) · X2 선 빼기 → A05 "X2 no answer" · 모터 선 전체 → A11 · RFID UT / UU.
- CLI `REG` 의 X 위치는 아직 0x1014 (엔코더, mm 식과 안 맞음) → 0x602C 로 바꿀지 (cli.c 한 줄, 사용자 대답 전).
- REG 에서 X `6017 = 50 · 600F = 200 · 6014 = 50` (코드 500 · 180 · 35) → **원점 뒤 다시 REG** 해서 같은지 확인 필요.
- ~~원점 뒤 X 30mm 앞으로~~ → 이미 `IM_Home` 이 원점 뒤 25mm · 50rpm 이동 (11/23 확인, 그대로 씀).

## 앞으로 할 것

0. **(11/23 오전 마무리 → 이어서)** : ① 보드 시험 (원점 · MI · MO · PO · JOG · 화면 버튼 · 만재 2초 · 카드 2초 · REG 4대 값 (Y 위치 전과 같은지) · X2 선 빼기 A05) → ② **에이징** → 문제없으면 확정 → ③ **dual_roder 새 프로젝트** (사용자 : 에이징 확정 뒤 바로). `MB_Write` (아래 ③) 는 MB_Read 구조를 사용자가 이해한 뒤에 (11/23 : "함수 구조를 먼저 알아야 함"). 사용자가 헷갈린 것 = "칸 안 바이트 순서 (공통, modbus.c)" 와 "32비트 두 칸 순서 (Y 만 아래 칸 먼저, 모터 파일)" 를 나누는 것 → 설명할 때 X1 · Y 바이트를 나란히.
   (원래 순서) ② ~~modbus 읽기~~ 11/23 함 → ③ `MB_Write` (write16 · write_multi · write32 · write_regs 대신, 원점 · MI · MO · PO · JOG · 비상정지 · 선 빼기 전부 시험). 이때 `X/Y/T_RX_MS` → `MOTOR_WAIT_MS` 하나 (= C1, 원점 X1 0.5초 무응답 따로) · `MOTOR_RETRY` · `BUS_GAP_MS` → modbus.h. 모터 파일엔 레지스터 · 단위 · 32비트 순서만 남김.
1. **틸트 각도 정하기** : e · G 자로 재기 → 식으로 각도 · tilting_y → FP 7 · PC PO 각도.
2. REG 0x602C · REG 값 확인. (원점 뒤 X 이동은 25mm · 50rpm 으로 확정, 11/23)
3. **최적화 (토요일)** — 시작 전 통신 공부 페이지로 복습 : `docs/comm_study.html` (Artifact https://claude.ai/artifact/AhsgCHNcbVezsmbvv1BQFB, 통신 5가지 움직이는 그림 · 바꿀 때 지도 · 계산기) : **C1** 쓰기 기다림 `X_RX_MS 500` · `T_RX_MS 500` → 50 (원점 때 X1 0.5초 무응답은 따로 생각) — 할 때 **각 통신이 몇 ms 마다 어디서 어떻게 오가는지 움직이는 그림으로 먼저 설명** (사용자 요청) / **C4** 주석 · 통신 표를 "읽기 = Bus · 쓰기 = 열쇠" 로 맞춤 / D #define 정리 (한 곳만 쓰면 숫자 + 주석) / E 스택 · 힙 (CLI RAM 에 Bus_Task 추가) / F 옛 주석 (10초 → 8초 등) / 옛 `!=` 정리 (사용자에게). 파일 · 함수 다시 훑기.
4. **문서 (주말)** : 통신 프로토콜 (사용자가 만든 모양처럼) · 고장 → 파일 · 함수 지도 엑셀 (모터 레지스터 장 · 시딩월 계산표 포함).
5. Bus_Task C 단계 (명령도 Bus_Task 가, `Uart2Lock` 삭제) · 원점 기다림 "알람이면 그만" (허락).
6. 24/7 : 와치독 (IWDG) · 드라이브 통신 끊김 감시 파라미터 (매뉴얼) · 비상정지 드라이브 단자 직접 (배선).
7. 화면 보드 LM1117 3번 핀 전압 · ESP `gfx->flush()` 바뀔 때만.
8. **`dual_roder` 새 프로젝트** + 모터 데이터시트 분석. 처음부터 통신 하나 = 담당 하나 · FSM · 레고 · 현장 값 한 곳.

## 사무실 ↔ 현장 (지금 파일 = 현장 값)

"사무실 값으로 / 현장 값으로 바꿔 줘" → `[현장]` 검색 (Ctrl+Shift+F) 해서 옆 주석대로. 사무실 = X 모터 하나(ID 3) · Y · 틸트 · HMI · RFID 없음.

| 파일 | 현장 (지금) | 사무실 |
|---|---|---|
| i_motor.c | `IM_2_ID 4` · `IM_ALL_ID 0` | 3 · 3 |
| i_motor.h | `IM_HOME_HI_RPM 180` · `IM_HOME_LO_RPM 80` · `IM_HOME_FORCE 35` | 50 · 30 · 10 |
| a_motor.h | `AM_HOME_TORQUE 600` | 100 |
| app_freertos.c 스위치판 | `Rfid_Init();` · `manjae_change();` · `HMI_Send();` 켬 (`[기능]` 줄) | 주석 |
| alarm.c `bus_alarm` | X 차이 `50` (mm) | (X 하나면 차이 0 이라 그대로) |
| cmd.c `CMD_Event` | `PC_FF` · `PC_CARD` 두 줄 켬 | 주석 |
| run.c `po_stop` | `if (card_on(rack) == 0) Pause_Set(rack, 'S');` 켬 | 주석 |
| (코드 아님) 완료응답 승인 | 기본 `ANS_1` | 시험 때 PC `01ANS_0` (재부팅하면 ANS_1) |

## 참고

- 전체 빌드 (명령줄) : CubeIDE plugins 의 `gnu-tools-for-stm32 … tools\bin` 과 `make … tools\bin` 을 PATH 에 넣고 `Debug` 폴더에서 `make -j8 all` → `arm-none-eabi-size threeD_roder.elf`.
- 펌웨어 직접 올리기 : `STM32_Programmer_CLI.exe -c port=SWD -w 파일.elf -v -rst` (CubeIDE plugins 의 cubeprogrammer `tools\bin`).
- CLI : Tera Term, STLINK-V3 VCP 115200, **로컬 에코 끄기**. 명령 `X/Y mm percent` · `X2 mm percent` (시험 : X2 하나만) · `C percent` · `R/L deg percent` · `S` · `I` · `INIT` · `IP` · `FRAM` · `DATA` · `REG` · `MANUAL`.
- TCP 시험 : `<STX>01MI_1_1_2_050_050_100_000_000<ETX>` (번호 필수, MI · MO 8개 / PO 9개), 승인 `01AI_1_1_2`. 서비스 포트 58080 (같은 명령 · 20초 끊기 없음 · `[TX]`/`[RX]`), 로그 50001.
- 데이터시트 · 프로토콜 : https://github.com/ParkSeong0425/3D (`2차소터 프로토콜_V1.3_260916.pdf`, `3DS_motor_DataSheet/` iCL-RS · AIMmotor · TL57-R). GitHub : https://github.com/ParkSeong0425/ThreeD_roder
- 사수 펌웨어 분석 : `docs/senior_fw/읽어보기.md`. 파일별 리뷰 : `docs/review_1109.md`.
- 공부 자료 : Digi-Key "Introduction to RTOS" 1~4편, Mastering the FreeRTOS Real Time Kernel (freertos.org PDF), 혼자 공부하는 C언어 (교재).
