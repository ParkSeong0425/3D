# threeD_roder (3D 로더, 회사 기본 코드) — Claude 작업 안내서 (마지막 갱신 2026-11-17)

STM32G473VCT6 (170MHz) + FreeRTOS(CMSIS-RTOS2) + STM32CubeIDE 1.19.
3축 로봇(X 두 모터 / Y / 틸트)을 RS485 Modbus RTU 드라이브로 움직이고, PC 와 TCP(W6100), 터치화면(ESP32)과 RS485, 카드 리더와 CAN 으로 통신한다.
사용자는 펌웨어를 배우는 중이다. 설명은 **한국어 · 이론 + 움직이는 그림(애니메이션) · 우리 기계 실제 부품 예시**로 한다.

## ▶ 이 코드의 목적 (11/13 사용자 결정)

- **threeD_roder = 회사 기본 코드.** 현장마다 로봇 규격에 맞춰 고치고 오래 유지보수한다.
- **현장 사람이 고칠 수 있게** : run · 만재 · 모터 숫자처럼 현장마다 바뀌는 값은 **찾기 쉽고 뜻이 적힌 한 곳**에 둔다 (주석 · `[현장]` 표시 · "증상 → 볼 곳" 지도).
- **현장에서 고치는 곳은 `run.c` · 모터 파일(i · a · t_motor) · 태스크 스위치판(app_freertos.c)만** (11/17). 나머지는 기본 세팅. 기능 끄기 = 스위치판의 `[기능]` 줄 주석.
- **통신 · RTOS 같은 바탕 지식은 사용자가 알고 있어야 한다** → 바꿀 때마다 이론 + 그림으로 설명.
- **새 프로젝트 `dual_roder`** 를 이 코드를 토대로 새로 만든다. 이것도 회사 코드가 되니 처음부터 깔끔한 구조로.

## ▶ 새 세션 시작 (zip 을 받거나 "이어서 하자" 하면)

**zip 만들기 (회사 → 집)** : `threeD_roder` (단 `Debug/` 빼고) + `HMI\HMI_Kor_260702\HMI_JC3248W535_v1.2` (단 `.pio/` · `build/` 빼고). 글꼴을 다시 만들 일이 있으면 `workspace_1.19.0\tools\` (Node 포터블 · lv_font_conv, 약 80MB) 도 따로. 집에서 같은 이름 폴더로 풀고, Claude Code 를 `threeD_roder` 폴더에서 열어 "이어서 하자". (Claude 의 메모리는 PC 마다 따로 → **이 파일이 유일하게 따라가는 기억**)

1. 이 파일 "작업 방식" · "코드 스타일" → "지금 구조" → "11/16 한 것" → "앞으로 할 것" 순서로 읽는다.
2. zip 을 받으면 : 지금 폴더를 `workspace_1.19.0\threeD_roder_before_날짜` 로 백업 → 사용자가 고친 곳을 먼저 찾아 보여 줌 (**사용자 수정 덮어쓰기 금지**) → 전체 빌드 (아래 "참고") 에러 · 경고 수 보고 → `[현장]` 검색해 사무실 / 현장 값 보고 → CubeIDE 열린 탭은 F5.
3. 그다음 "앞으로 할 것" 1번부터. 사용자가 다른 걸 말하면 그걸 먼저.
   - **할 일마다 공부를 같이 한다** (사용자 요청 11/13, 중요) : 그 단계에 나오는 개념을 먼저 **이론 (정의 → 왜 → 동작 순서 → 우리 코드 → 흔한 실수)** + **움직이는 그림 (canvas 애니메이션, 실제 부품 · 공이 선 위를 오가는 모양, 버튼으로 상황 바꾸기)** 으로 설명하고 나서 코드로 간다. 표 · 네모 상자 · 시간 막대(레인) 그림은 쓰지 않는다 (11/16 : 레인 그림 "더 이해가 안 감"). **통신은 특히** 이 방식으로.
4. 하루 끝 ("끝 · 마무리 · 여기까지") : 이 파일의 "한 것" · "지금 상태" · "앞으로 할 것" 을 그날 기준으로 고치고 바뀐 곳을 보여 준다.

## 작업 방식 (반드시 지킬 것)

1. **"그래 바꿔줘" 같은 분명한 허락 전에는 코드를 안 바꾼다.** 함수 하나 · 작은 단위 하나씩. 답은 ① 지금 역할 ② 문제 ③ 이유 ④ 바꿀 곳 (전 / 후) ⑤ 직접 확인할 것 ⑥ 다음 하나.
2. 바꾸기 전에 계획 : 어느 파일 → 어느 함수 → 무엇을 + 개념 + 왜 + 그림. 적용 후 파일별로 바뀐 줄 + 빌드 결과.
3. **코드 구조는 사용자가 먼저 정한다.** Claude 는 추천 · 설명 · 수정. 사용자가 짠 코드는 **사용자 스타일 그대로** 고친다 (변수 · 플래그 · 함수 덧붙이지 말고 있는 함수 안에서).
4. 새 함수 · 변수 · 구조체 · 플래그 · 처음 보는 문법은 **고치기 전에** "새로 생김 : 이름 · 뜻 · 왜 꼭 필요한지, 있는 것으로 안 되는지" 먼저 말한다 (11/16 : `Motor_Busy` · `on == &tcp_on` 을 말 없이 넣어서 혼남). 요청 안 한 곳(특히 **원점**)은 같이 고치지 않는다.
5. 판단 기준 = **안전(긴급정지 · 알람 · 통신 오류) > 버스(RS485) > CPU > RAM**. 리뷰할 때 CPU · 버스 · RAM 을 같이 말한다. 안전은 단순화한다고 빼지 않는다.
6. **설명 그림** : 네모 상자 · 화살표 · 시간 막대 그림 금지. **실제 부품을 그린 움직이는 그림 + 버튼으로 상황 바꾸기** (show_widget canvas). 그림 옆에 **이론** 을 꼭 같이. 답은 짧고 쉽게 (긴 글은 줄여 달라고 함).
7. 낯선 문법(삼항 `? :` 등) 쓰지 않음. 새 문법을 꼭 쓰면 먼저 "새 문법" 이라고 말한다.
8. GitHub `main` 에는 허락 없이 올리지 않는다.
9. 하루 끝에 이 파일 갱신 (위 새 세션 4). 노션 정리는 사용자가 원할 때만.
10. 줄 끝 맞추기(CRLF)는 **고친 파일만** (11/16 : 폴더 전체에 돌려서 CubeMX 생성 파일 syscalls.c · sysmem.c · system_stm32g4xx.c 를 CRLF 로 바꿨다가 LF 로 되돌림 — 이 셋은 원래 LF).

## 코드 스타일 (사용자가 원하는 것 — 계속 유지)

- **레고 모양** : 함수 = 다른 파일의 블록 함수를 한 줄씩 나열 (좋은 예 : `I()` · `MI` · `lamp_event` · `NET_Run`). 순서 = 우선순위.
  - R1 블록 = 한 가지 일, 성공 1 / 실패 0. R2 조립 함수 = 블록 나열 + 최소 if. R3 판단(조건 · 숫자)은 그 데이터를 가진 파일 안 (알람 alarm.c, 상태 status.c). R4 아래 층(모터 · 장치 파일)은 위 층을 모름. R5 switch 의 case 는 블록 한 줄. R6 장치 지식(레지스터 · 코드 이름표)은 장치 파일. R7 태스크 사이는 큐 · 상태판 · 플래그로.
  - 새 함수보다 **있는 함수 안으로 옮기기**가 먼저. 함수 · 변수 늘어나는 것 싫어함. "부르기만 하는 포장 함수" 는 없앤다 (이름이 단계를 설명하면 남김 : `TM_C/R/L` 등). **대입을 감싸는 함수도 싫어함** (11/16 `State_Go` 지움 → `state.now = 'W';` 바로).
  - "해도 되나" 확인은 그 일을 하는 블록 맨 앞.
- `if (!Func())` 금지 → `if (Func() == 0)`. `== 1` 안 씀 → `if (Func())`. **`!=` 도 쓰지 않음** (11/16) → `==` 와 `if { }` 블록으로. (옛 코드의 `!=` 는 아직 남아 있음 : 통신 글자 확인 · strcmp 등)
- 성공 1 / 실패 0 반환, 실패는 `return 0` 으로 위로.
- 여러 레지스터 쓰기 : 움직이기 · 설정 = `&&` (앞이 실패하면 뒤 안 함) / 멈추기 = 따로 다 보내고 결과만 합침.
- **모든 while 기다림에는 시간 제한** (`osKernelGetTickCount()` 시작 시각 비교). 예외 : 일시정지 대기.
- 시간 숫자는 ms, 이름은 `_MS`. 맨숫자 피함 (거리 숫자 · `osDelay(2)` 같은 짧은 쉬기는 예외로 그 자리에 숫자 + 주석).
- 단계마다 한글 한 줄 주석. 짧고 쉽게. 디버그 출력은 원인 찾으면 지운다.
- `save.c` · `cmd.c` 의 풀어 쓴 모양은 일부러 → 배열로 바꾸자고 하지 않는다.
- 일부러 남긴 안 쓰는 함수 : `AM_BaudInit` · `uart_speed` · `EEPROM_MAC`, CLI `REG` → 지우자고 하지 않는다. 그 밖에 **확실히 안 쓰는 변수 · 레지스터 이름은 지운다** (11/16 사용자).
- 변수는 주인 파일 `.h` 에 `extern` 한 번. RTOS 핸들은 `main.h` USER CODE 에.
- CubeMX 생성 파일은 **USER CODE BEGIN ~ END 안에만**. 설정은 ioc 에서 (사용자가 함).
- 파일은 **CRLF** (CubeMX 생성 syscalls.c · sysmem.c · system_stm32g4xx.c 는 LF 그대로). 고친 뒤 bareLF 0 확인.
- 렉1 = 오른쪽 렉 (홀수 렉 = `right_*` 표), 렉2 = 왼쪽. HMI 화면 왼쪽 칸 = 렉2.

## 지금 구조 (11/17 기준)

**상태 = FSM 하나 (status.h `state`, 11/16)** — 전엔 `status · pause_why · pause_rack · run_rack · estop · manual · alarm_no` 7개 변수
```
state.now  'I' 초기상태 (켠 직후 · RESET 뒤)  → 시작 → 'H'
           'H' 원점중                         → 끝 'W' / 실패 'A'(10)
           'W' 대기                           → PC MI·MO·PO → 'R' / 일시정지 → 'S' / 수동 → 'M'
           'R' 운전                           → 끝 'W' (AI·EO 는 PC 승인 때, AO 는 R 그대로) / 멈춤 → 'S'
           'S' 멈춤 (시작 기다림)              → 시작 → state.prev (why : 'M' 일시정지 · 'F' 만재 · 'T' 틸트 · 'S' 시딩월)
           'M' 수동 (W · I 에서만)             → 수동 버튼 → state.prev / 시작(전 I) → 원점
           'E' 긴급정지                        → 풀면 'A'
           'A' 알람                            → RESET → 'I'
state.prev (멈춤 · 수동 전) · state.why · state.rack (운전 렉) · state.alarm (번호)
Motor_Stop() = 'E' 또는 'A' (모터 문 2). 어디서 바뀌는지 표 = status.c 맨 위
버튼 하나 = 일 하나 : RESET = 리셋만(→ I) / 시작 = 원점(I) · 이어서(S) / 수동 = 켜기 · 끄기
모터 문 1 run.c Motor_Request : W = 원점·MI·MO·PO / I = 원점만 / R = MI·MO·PO 만 / 그 밖 NAK
```

**태스크 = 스위치판 (app_freertos.c 태스크 함수, 11/17)** : 태스크 함수 = 블록 한 줄씩. `[기능]` 줄을 주석 처리하면 그 기능이 통째로 꺼짐 (event.c `Event_Run` 은 없앰)
```
Event_Task (High)        Rfid_Init[기능] · UART4_Start → Event_Wait (EventQueue 최대 20ms) → estop_event[기능] → manjae_change[기능]
                         → hmi_event → A_01 → HMI_Send[기능] (20ms 물음) → lamp_event[기능]
Motor_Task (AboveNormal) Motor_Run (MoveQueue 1칸 Peek → 원점 / MI · MO · PO → Get)
Bus_Task (AboveNormal)   모터 선 담당. osDelayUntil 40ms → IM_Read · AM_Read · TM_Read (칠판) → Alarm_Drive (칠판 보고 알람). 스택 512워드
                         BusQueue(4칸) 는 아직 안 씀 (C 단계). 칠판 지도 = Start_Bus_Task 위 주석
Comm_Task (Normal)       Save_Init → NET_Init[기능] → btn_run (켤 때 원점) → CMD_Event (1ms) · CLI_Run[기능] · NET_Run[기능] · CMD_Done
타이머 태스크            Manjae_Timer (만재 2초) · Rfid_Timer (0.5초)
뮤텍스                    Uart2Lock (UART2 를 Motor · Event · Comm · Bus 가 씀) → C 단계 끝나면 삭제
```

**칠판 (11/17)** : `usart.h MOTOR {pos · state · alarm · miss}` 한 칸 = 모터 한 대. `im1` · `im2` (i_motor) · `am` (a_motor) · `tm` (t_motor). Bus_Task 만 적고 나머지는 보기만.
- 적기 : X = `0F00` 부터 5칸 (`IM_MapInit` 이 원점 시작 때 0x1003 상태 · 0x1014/15 위치 · 0x2203 알람 · 0x601D 경고를 모아 둠) / Y = `0B05` 부터 4칸 (DO · 0B06 · 위치) + `0B22` 고장 코드 / 틸트 = `0004` 부터 6칸 (상태 · 알람 · 위치 0008/9).
- 한 번씩만 묻고 (`BUS_RX_MS 5`) 못 받으면 칠판 그대로 + `miss` +1 → 다음 바퀴에 다시. 받으면 `miss` 0.
- 보기 : `IM_Arrive` · `IM_Pass` · `AM_Arrive` · `TM_Arrive` · `IM_MoveSoft` (출발 위치) · `IM_Home` / `AM_Home` (원점 전 거리 `far`, X 는 매핑 뒤 80ms 기다림) · run.c MI (MI→MI) · `move_done` 로그 · `Alarm_Drive`.
- 지움 : `IM_Pos` · `AM_Pos` · `TM_Pos` · `TM_Done` · `IM_Alarm` · `AM_Alarm` · `TM_Alarm` · `read_pos` · `read32` · `A_11(log)`. 원점 안의 상태 읽기 (`IM_State` · `AM_Done` · `AM_HomeDone`) 는 아직 옛 읽기 (원점은 허락 받고).

**알람 (alarm.c 맨 위 표) · ESP 화면 글자** : 01 HMI 통신 = **터치에러** (ESP 가 STM 물음 100ms 못 받으면 직접 띄움, STM 은 대답 3번 없음 = 60ms) · 02 주행모터 · 03 리프팅모터 · 04 틸팅모터 (드라이브 알람, 칠판 alarm 칸) · 05~07 이탈 (8초 못 감 / **그 축 한 대만 대답 3번 없음** 로그 X1 · X2 · Y · Tilt / **X1 · X2 차이 `X_SKEW_MM 50` 넘음** 05) · 09 비상정지 · 10 원점 · 11 **모터에러 = 4대 다 대답 없음 (모터 선 UART2 · 전원)** · 12 **랜선뽑힘**. 대답 없음 · 차이 · 드라이브 알람은 Bus_Task `Alarm_Drive` 40ms (I · H · E · A 때는 안 봄). 숫자 `alarm.h BUS_MISS 3` · `X_SKEW_MM 50 [현장]`. 풀기 = RESET → 'I' → 시작 → 원점 (원점이 X 두 대를 다시 맞춤).

**완료응답** : cmd.c `ANS_1`(기본, PC 승인까지 1초마다) / `ANS_0`(한 번). 번호 = 마지막 PC 번호 그대로.

**통신 (11/17 정리)** — 한 번 묻고 받기 = 보내기 0.7 + 대답 약 2 (최대 `BUS_RX_MS 5`) + 쉬기 2 (`BUS_GAP_MS`, Modbus 3.5글자 1.75ms + 여유) ≈ 4.5ms
| 통신 | 선 · 속도 | 누가 먼저 | 받는 법 | 박자 · 선 사용 |
|---|---|---|---|---|
| 모터 4대 | RS485 UART2 115200 | STM 만 (ID 로 한 대, 쓰기는 X 주소 0 = 둘 같이 · 대답 없음) | DMA + IDLE → XFER_DONE | Bus_Task **40ms 마다 4대 한 번씩** (Y 는 질문 2개) ≈ 23ms → 선 약 55%. 명령 (이동 · JOG · 멈춤) 은 아직 Motor · Event 가 열쇠 잡고 직접 |
| ESP 화면 | RS485 UART4 115200 | **STM 만 (20ms 마다 물음, ESP 는 대답만)** | IT + IDLE → 바뀐 버튼만 EventQueue | 물음 27글자 2.3ms + 대답 4글자 0.4ms = 약 15% |
| PC | 이더넷 W6100 (SPI4) | PC | INT 핀 EXTI → CommQueue 'N' (즉시) | 1% 아래 |
| 카드 리더 | CAN 125k (FDCAN1 · 2) | STM 0.5초 'C' | 인터럽트 → rfid.c | 약 0.5% |
| CLI | UART1 115200 | 사람 | 글자마다 IT → 보관함 64칸 | Comm_Task 1ms 마다 꺼냄 |
- 충돌 안 나는 이유 : 모터 선 = STM 안 열쇠(Uart2Lock) 로 한 태스크만 + 드라이브는 자기 ID 만 대답 + CRC / ESP 선 = STM 이 묻고 ESP 는 대답만 (ESP `sendPacket` 은 받기 콜백에서만) / CAN = 하드웨어 중재 / TCP · CLI = 전이중.
- TX · RX LED 가 계속 켜져 보이는 건 1초 50번 깜빡 (눈이 못 따라감). 쉬는 시간 85%, 부품 무리 없음.

**모터 통신 숫자 (usart.h)** : Bus_Task = `BUS_MS 40` · `BUS_RX_MS 5` (1번만). 옛 쓰기 · 원점 읽기 = `MOTOR_RETRY 3` · `X_RX_MS 500` · `Y_RX_MS 50` · `T_RX_MS 500` (C 단계에서 정리). `BUS_GAP_MS 2`.
- 11/17 잰 것 (`uart2_us` · `uart2_max_us`, Live Expressions) : 평소 대답 약 1.9ms. **X1 은 원점 닿는 순간 0.5초 넘게 대답 안 함** (그래서 H 때는 놓침을 안 셈) · **Y 는 MO · PO 중 가끔 50ms 넘게 대답 안 함** (1~2 바퀴라 3번에 안 걸림). 측정용 `uart2_us` · `uart2_max_us` · `dwt.h` 는 C 단계 끝나고 삭제.
- X 급정지 감속 `i_motor.h IM_DEC_MS 500` (Pr8.23, ms, 직선). **가는 중엔 Pr8.23 을 안 받아서 `IM_MapInit` (서 있을 때) 이 미리 넣고, `IM_Stop` 은 0x040 만** (11/17, 사용자 "아주 맘에 듦"). 거리 = 속도 × 시간 ÷ 2 (100% 1667mm/s → 약 420mm).
- X 드라이브 DI 에 `0x22 Quick stop` 기능이 있음 → 비상정지를 드라이브 단자에 직접 거는 것도 가능 (배선, 나중에).

**FRAM (save.h 지도)** : HEAD 0x0001 · FS 0x0010 · FI 0x0030 · FP 0x0200. `SAVE_VERSION 10`. 버전이 바뀌면 처음 켤 때 기본값 → PC `01ALL_PIMZ` · FI 다시.

**ESP (HMI) 프로젝트** : `workspace_1.19.0\HMI\HMI_Kor_260702\HMI_JC3248W535_v1.2` (VS Code PlatformIO, LVGL 8.3.11 = `lib/lvgl` 한 벌, `platformio.ini` lib_deps 는 GFX 만).
- 파일 : `main.cpp`(켜기 · 1ms 타이머 · 버튼 누르는 범위 12px) · `main.h`(보드 핀 · 화면 · 터치 보정 전부, 11/16 pincfg · dispcfg 합침) · `hmi.cpp/.h`(버튼 `Btn_Event` → `btn_put` / `Btn_Take`, 화면 글자 `SysInfoRefresh`, 표 `TaskString` · `PauseString` · `AlarmString`) · `serial1.cpp/.h`(STM 선 : `SerialReceive` → `HMI_Parser` → 받자마자 `TxEvent_BtnClick` 대답) · `AXS15231B_touch`.
- **STM 과 이야기하는 건 `Serial0`(UART0, P4 단자)** — `serial1.h` `#define RS485 Serial0`, 받기 = `Serial0.onReceive(SerialReceive)` 콜백. `Serial1`(IO17/18) 은 예비. RE/DE = GPIO15.
- STM ↔ ESP 글 (11/16) : STM → ESP 27글자 (`STX '1' 'C' 작업 일시정지 알람 센서20 ETX`) **20ms 마다 늘** / ESP → STM 4글자 (`STX '1' 버튼+'0' ETX`) **물음 받자마자**, 같은 버튼을 대답 3번에 실음 (`BTN_REPEAT 3`), 없으면 '0'. STM 은 바뀐 순간만 처리, JOG 가 안 실려 오면 = 뗌. ESP 화면은 STM 글이 바뀔 때만 다시 그림 (`HMI.Changed`).
- 숫자 : 터치 읽기 `lv_conf.h` `LV_INDEV_DEF_READ_PERIOD 10` (30 → 10) · `JOG_HOLD_MS 100` · `BTN_GAP_MS 300` · `TOUCH_ERR_MS 100` · 화면 넘김 페이드 150ms (`ui_*Screen.c`, SquareLine 재생성하면 500 으로 돌아감). 버튼 최대 늦음 약 33ms (터치 10 + 물음 20 + 3).
- **글꼴** : 화면 글꼴은 쓰는 글자만 그림으로 넣은 것. 새 글자는 `font_src\make_fonts.js` 글자 목록에 더하고 `make_fonts.bat` 더블클릭 (`font_src\읽어보기.txt`). 원본 NotoSansKR-Medium · SemiBold (Google Fonts OFL), 도구 `workspace_1.19.0\tools\` (Node v20.20.2 포터블 · lv_font_conv 1.5.3). 사수 명령 그대로라 기존 글자는 똑같이 나옴 (11/16 확인).
- 자동 생성 (손 안 댐) : `ui_*.c`, `fonts/`, `lib/`. ⚠️ `ui_*Screen.c` 의 `Btn_Event(e, 버튼, 0/1)` 줄 · 페이드 150 은 손으로 고친 것 → SquareLine 재생성하면 사라짐.
- `serial1.h` 는 옛 한글 인코딩(EUC-KR) → Claude 편집 도구로 못 고침.
- 빌드 `%USERPROFILE%\.platformio\penv\Scripts\pio.exe run`, 올리기 = 아래 막대 →. 올리기 전 COM6 시리얼 모니터 닫기, 안 되면 BOOT 버튼.
- 화면 보드 전원 : 외부 24V → (앞단에서 5V) → LM1117-3.3 (미지근 = 정상, 5V 입력이면 약 0.3~0.5W).

## 11/17 한 것

- **MI → MI · MO/PO 순서** : MI→MI 는 X 밖(`safe_x - 10`, `IM_Arrive` ±10 때문) → Y → X 안. MO 는 `IM_MoveSoft(x)` → `A_05(IM_Pass(safe_x))` → Y. 보드 확인됨.
- **`IM_MoveSoft` 하나로** (물리식 v² = 2ad : 기울기 = 1,200,000 × 거리 ÷ rpm², `OUT_SPEED 27` · `SAFE_SPEED 20`, 평소보다 가파르면 평소). `IM_Move` 지움 (CLI X 도 MoveSoft). PO `pour_wait` : 틸트 체크 시간(FP) 안에 만재 센서 스치면 `return_delay`, 아니면 틸팅 멈춤 'T'.
- **스위치판** : 태스크 함수에 블록 한 줄씩 + `[기능]` 주석. `Event_Run` 없앰, 켤 때 원점 = Comm_Task `btn_run`. `card_ok` 기본 1.
- **통신 공부 1 · 2회차** (Modbus RTU 글 모양 · 기다림 · 다시 묻기 · 주기) + 측정 (`uart2_max_us`, 조건 중단점 `uart2_us > 40000` + `motor_tx[0]` 으로 누가 늦는지).
- **Bus_Task A · B 단계** : 40ms 칠판 (매핑 읽기) → 도착 · 원점 전 거리 · 로그가 칠판을 봄 → 알람도 칠판 (05~07 한 대 대답 없음 · 11 4대 다 · X 차이 50mm 05). Pos · Alarm 읽기 함수 7개 지움.
- **X 급정지** : Pr8.23 을 `IM_MapInit` 에서 미리 → 500ms 가 진짜 먹음 (전엔 가는 중에 보내서 버려짐). 보드 확인 "아주 맘에 듦".
- **시험 명령** CLI `X2 mm %` (`IM_Move2`, X2 하나만) → X 차이 알람 시험용. 운전엔 안 씀.
- text 62,412 → **63,380B** (로그 글 · 칠판 · Read 함수).

## 지금 상태 (2026-11-17 끝)

- STM 빌드 에러 0 · 경고 0, text 63,380B. **B2 (알람 칠판) · CLI X2 는 아직 보드에 안 올림 / 테스트 전.** B1 (도착이 칠판) 도 테스트 결과 아직 못 들음.
- 내일 처음 할 테스트 :
  1. 원점 → MI · MO · PO · MI→MI · 분배가 전처럼 되는지 (B1).
  2. 원점 끝난 뒤 바로 A06 · A07 "no answer" 가 뜨면 → Y `0B06` · 틸트 `0006/7` 칸을 드라이브가 거부하는 것 → 읽는 칸 줄이기.
  3. CLI `X2 30 10` (X1 이 다른 자리일 때) → X 차이 50mm 에서 **A05 + 로그 X1 · X2 위치** → RESET → 시작 (원점이 둘 다 맞춤) → TCP MI 받는지. ⚠ 멈추기까지 약 50mm + 감속 거리 → 짧게 · 느리게, 처음엔 `X_SKEW_MM` 을 작게.
  4. X2 RS485 선만 빼기 → A05 "X2 no answer" / 모터 선 전체 빼기 → A11.
- 원점 기다림 (`IM_Home` · `AM_Home`) 은 알람이 나도 최대 60초 계속 기다림 → "알람이면 그만" 제안 (원점 코드라 허락 필요, 아직 안 함).

## 앞으로 할 것

1. **위 테스트 (B1 · B2 · X2)** → 문제 고치기.
2. **Bus_Task C 단계** : 이동 · JOG(X 다시 쓰기 = 바퀴 맨 앞) · 멈춤 명령도 Bus_Task 가 보냄 (BusQueue) → `Uart2Lock` · `UART2_Send` · `motor_task` 삭제 (ioc 는 사용자) · 쓰기 실패도 miss 로 → A05~07. 원점 안 읽기 (`IM_State` 등) 도 칠판으로 (허락 받고). 끝나면 `uart2_us` · `uart2_max_us` · `dwt.h` 삭제, 통신 표 다시 쓰기.
3. 원점 기다림에 "알람이면 그만" (허락 받으면).
4. 화면 보드 LM1117 3번 핀(IN) 전압 재기 (5V 면 정상). ESP `gfx->flush()` 5ms 마다 화면 전체 → 바뀔 때만 (열 · 화면 늦음 같이).
5. 옛 코드의 `!=` 정리 (통신 글자 확인 · strcmp 등) — 할지 사용자에게.
6. 현장 유지보수용 : run · 만재 · 모터 숫자 한 곳 · `[현장]` · "증상 → 볼 곳" 지도. 파일 합칠 후보 (lamp+buzzer, fram+eeprom, dwt.h, flag.h) 는 사용자가 정함.
7. **`dual_roder` 새 프로젝트** + 그 모터 데이터시트 분석 (오늘 못 함). 처음부터 통신 하나 = 담당 하나 · FSM 상태 · 레고 모양 · 현장 값 한 곳.
8. 와치독 (IWDG, 알람 10 에 이유로) — 보류.

## 사무실 ↔ 현장 (지금 파일 = 현장 값)

"사무실 값으로 / 현장 값으로 바꿔 줘" → `[현장]` 검색 (Ctrl+Shift+F) 해서 옆 주석대로. 사무실 = X 모터 하나(ID 3) · Y · 틸트 · HMI · RFID 없음.

| 파일 | 현장 (지금) | 사무실 |
|---|---|---|
| i_motor.c | `IM_2_ID 4` · `IM_ALL_ID 0` | 3 · 3 |
| i_motor.h | `IM_HOME_HI_RPM 180` · `IM_HOME_LO_RPM 80` · `IM_HOME_FORCE 35` | 50 · 30 · 10 |
| a_motor.h | `AM_HOME_TORQUE 600` | 100 |
| app_freertos.c 스위치판 | `Rfid_Init();` · `manjae_change();` · `HMI_Send();` 켬 (`[기능]` 줄) | 주석 |
| alarm.h | `X_SKEW_MM 50` | (X 하나면 차이 0 이라 그대로) |
| cmd.c `CMD_Event` | `PC_FF` · `PC_CARD` 두 줄 켬 | 주석 |
| run.c `po_stop` | `if (card_on(rack) == 0) Pause_Set(rack, 'S');` 켬 | 주석 |
| (코드 아님) 완료응답 승인 | 기본 `ANS_1` | 시험 때 PC `01ANS_0` (재부팅하면 ANS_1) |

## 참고

- 전체 빌드 (명령줄) : CubeIDE plugins 의 `gnu-tools-for-stm32 … tools\bin` 과 `make … tools\bin` 을 PATH 에 넣고 `Debug` 폴더에서 `make -j8 all` → `arm-none-eabi-size threeD_roder.elf`.
- 펌웨어 직접 올리기 : `STM32_Programmer_CLI.exe -c port=SWD -w 파일.elf -v -rst` (CubeIDE plugins 의 cubeprogrammer `tools\bin`).
- CLI : Tera Term, STLINK-V3 VCP 115200, **로컬 에코 끄기**. 명령 `X/Y mm percent` · `X2 mm percent` (시험 : X2 하나만) · `C percent` · `R/L deg percent` · `S` · `I` · `INIT` · `IP` · `FRAM` · `DATA` · `REG` · `MANUAL`.
- TCP 시험 : `<STX>01MI_1_1_2_050_050_100_000_000<ETX>` (번호 필수, MI · MO 8개 / PO 9개), 승인 `01AI_1_1_2`. 서비스 포트 58080 (같은 명령 · 20초 끊기 없음 · `[TX]`/`[RX]`), 로그 50001.
- 데이터시트 · 프로토콜 : https://github.com/ParkSeong0425/3D (`2차소터 프로토콜_V1.3_260916.pdf`, `3DS_motor_DataSheet/` iCL-RS · AIMmotor · TL57-R). GitHub : https://github.com/ParkSeong0425/ThreeD_roder
- 사수 펌웨어 분석 : `docs/senior_fw/읽어보기.md`. 파일별 리뷰 : `docs/review_1109.md`.
- 공부 자료 : Digi-Key "Introduction to RTOS" 1~4편, Mastering the FreeRTOS Real Time Kernel (freertos.org PDF), 혼자 공부하는 C언어 (교재).
