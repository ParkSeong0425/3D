#ifndef INC_RUN_H_
#define INC_RUN_H_

#include <stdint.h>
#define CMD_I   ('I' << 8)
#define CMD_MI  (('M' << 8) | 'I')
#define CMD_MO  (('M' << 8) | 'O')
#define CMD_PO  (('P' << 8) | 'O')
#define CMD_S   (('S' << 8) | '_')
#define CMD_INIT (('I' << 8) | 'N')   /* CLI INIT : 초기화 재시도 */

int motor_basic_init(void);
int motor_basic_run(int command, int32_t pulse, int deg , int rpm);
int MI(int dan, int xy_speed, int tilt_speed);     /* 입고 dan 단 (좌표는 FRAM 입고 표 · 안전 위치에서) */
int MO(int x, int y, int xy_speed, int tilt_speed);
int PO(int rack, int x, int y, int dan,
       int xy_speed, int tilt_speed, int return_delay,
       int tilt_angle, int tilting_y, int tilting_y_speed, int tilting_check);
int I (void);
int E_S (void);     /* 긴급정지 */

void Motor_Run(int flag);           /* Motor_Task : 울린 초인종에 맞는 run 함수 하나 → 성공하면 그 렉 대기 */

#endif
