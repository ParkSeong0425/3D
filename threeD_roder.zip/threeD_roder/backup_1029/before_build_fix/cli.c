#include "cli.h"
#include "run.h"
#include "status.h"
#include "net.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "save.h"
#include "lamp.h"
#include "buzzer.h"
#include "usart.h"
#include "cmsis_os2.h"
#include <stdio.h>
#include <string.h>

#define CLI_SIZE 32



/* UART1 출력 */
void CLI_Print(const char *text)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)text, strlen(text), 100);
}


/* 시작 메시지 */
void CLI_Start(int ok)
{
    if (ok)
    {
        CLI_Print(
            "\r\nMOTOR INIT OK\r\n"
            "X ID=3,4\r\n"
            "Y ID=1\r\n"
            "TILT ID=2\r\n"
        );
    }
    else
    {
        CLI_Print(
            "\r\nMOTOR INIT ERR\r\n"
            "Type INIT to retry\r\n"
        );
    }

    CLI_Print(
        "\r\nX pulse percent\r\n"
        "Y pulse percent\r\n"
        "C percent\r\n"
        "R deg percent\r\n"
        "L deg percent\r\n"
        "S / H / INIT / IP / FRAM\r\n> "
    );
}


/* 모터 실행 결과 출력 */
void CLI_Result(int command, int ok)
{
    char text[160];

    if (command == 'X')
        snprintf(text, sizeof(text),
                 "X_MOVE %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == 'Y')
        snprintf(text, sizeof(text),
                 "Y_MOVE %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == 'C')
        snprintf(text, sizeof(text),
                 "CENTER %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == 'R')
        snprintf(text, sizeof(text),
                 "RIGHT %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == 'L')
        snprintf(text, sizeof(text),
                 "LEFT %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == CMD_S)
        snprintf(text, sizeof(text),
                 "STOP %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == CMD_I)
        snprintf(text, sizeof(text),
                 "HOME %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == CMD_INIT)
        snprintf(text, sizeof(text),
                 "INIT %s\r\n> ", ok ? "OK" : "ERR");
    else
        return;

    CLI_Print(text);
}


/* FRAM 배열 출력 */
static void CLI_List(const char *name, int32_t *data, int count, int max)
{
    char buf[32];

    CLI_Print(name);

    if (count > max)
        count = max;

    for (int i = 0; i < count; i++)
    {
        snprintf(buf, sizeof(buf), "%ld ", (long)data[i]);
        CLI_Print(buf);
    }

    CLI_Print("\r\n");
}


/* FRAM 저장값 출력 */
static void CLI_FRAM(void)
{
    char buf[500];

    int32_t in_y[5] = {
        save.fp.in_y1, save.fp.in_y2, save.fp.in_y3,
        save.fp.in_y4, save.fp.in_y5
    };

    int32_t left_x[9] = {
        save.fp.left_x1, save.fp.left_x2, save.fp.left_x3,
        save.fp.left_x4, save.fp.left_x5, save.fp.left_x6,
        save.fp.left_x7, save.fp.left_x8, save.fp.left_x9
    };

    int32_t left_y[9] = {
        save.fp.left_y1, save.fp.left_y2, save.fp.left_y3,
        save.fp.left_y4, save.fp.left_y5, save.fp.left_y6,
        save.fp.left_y7, save.fp.left_y8, save.fp.left_y9
    };

    int32_t right_x[9] = {
        save.fp.right_x1, save.fp.right_x2, save.fp.right_x3,
        save.fp.right_x4, save.fp.right_x5, save.fp.right_x6,
        save.fp.right_x7, save.fp.right_x8, save.fp.right_x9
    };

    int32_t right_y[9] = {
        save.fp.right_y1, save.fp.right_y2, save.fp.right_y3,
        save.fp.right_y4, save.fp.right_y5, save.fp.right_y6,
        save.fp.right_y7, save.fp.right_y8, save.fp.right_y9
    };

    snprintf(buf, sizeof(buf),
             "\r\n[FS]\r\n"
             "RACK         = %d\r\n"
             "TYPE         = %c\r\n"
             "CHANNEL      = %d\r\n"
             "IN_X         = %d\r\n"
             "IN_Y         = %d\r\n"
             "LEFT_X       = %d\r\n"
             "LEFT_Y       = %d\r\n"
             "RIGHT_X      = %d\r\n"
             "RIGHT_Y      = %d\r\n"
             "\r\n[FP]\r\n"
             "IN_X = %ld\r\n",
             save.fs.rack,
             save.fs.type,
             save.fs.rack_channel,
             save.fs.in_x,
             save.fs.in_y,
             save.fs.left_x,
             save.fs.left_y,
             save.fs.right_x,
             save.fs.right_y,
             (long)save.fp.in_x);

    CLI_Print(buf);

    CLI_List("IN_Y = ", in_y, save.fs.in_y, 5);
    CLI_List("LEFT_X = ", left_x, save.fs.left_x, 9);
    CLI_List("LEFT_Y = ", left_y, save.fs.left_y, 9);
    CLI_List("RIGHT_X = ", right_x, save.fs.right_x, 9);
    CLI_List("RIGHT_Y = ", right_y, save.fs.right_y, 9);

    snprintf(buf, sizeof(buf),
             "\r\n"
             "LIFT Y OFFSET = %ld\r\n"
             "TILT ANGLE    = %ld\r\n"
             "TILTING Y     = %ld\r\n"
             "TILTING SPEED = %ld\r\n"
             "Y OFFSET      = %ld\r\n"
             "TILT OFFSET   = %ld\r\n"
             "X OFFSET      = %ld\r\n"
             "SPEED X       = %ld\r\n"
             "SPEED TILT    = %ld\r\n"
             "SPEED Y       = %ld\r\n"
             "ACCDEC X      = %ld\r\n"
             "ACCDEC TILT   = %ld\r\n"
             "ACCDEC Y      = %ld\r\n"
             "SAFE X        = %ld\r\n"
             "SAFE Y        = %ld\r\n> ",
             (long)save.fp.lift_y_offset,
             (long)save.fp.tilt_angle,
             (long)save.fp.tilting_y,
             (long)save.fp.tilting_y_speed,
             (long)save.fp.y_offset,
             (long)save.fp.tilt_offset,
             (long)save.fp.x_offset,
             (long)save.fp.speed_x,
             (long)save.fp.speed_tilt,
             (long)save.fp.speed_y,
             (long)save.fp.accdec_x,
             (long)save.fp.accdec_tilt,
             (long)save.fp.accdec_y,
             (long)save.fp.safe_x,
             (long)save.fp.safe_y);

    CLI_Print(buf);
}


/* 문자열 명령 처리 */
static void CLI_Command(char *text)
{
    long pulse;
    int persent;
    unsigned int reg = 0x0509;  /* (디버그) REG 주소 : 그냥 REG 면 H05_09 (Y 1회전 펄스, 320 이어야) */
    char buf[300];

    /* 네트워크 값 */
    if (!strcmp(text, "IP"))
    {
        snprintf(buf, sizeof(buf),
                 "\r\n[IP]\r\n"
                 "IP      = %d.%d.%d.%d\r\n"
                 "SUBNET  = %d.%d.%d.%d\r\n"
                 "GATEWAY = %d.%d.%d.%d\r\n"
                 "DEST IP = %d.%d.%d.%d\r\n"
                 "PORT    = %d\r\n"
                 "MODE    = %d\r\n"
                 "TIMEOUT = %lu\r\n> ",
                 save.fi.ip[0], save.fi.ip[1],
                 save.fi.ip[2], save.fi.ip[3],
                 save.fi.sn[0], save.fi.sn[1],
                 save.fi.sn[2], save.fi.sn[3],
                 save.fi.gw[0], save.fi.gw[1],
                 save.fi.gw[2], save.fi.gw[3],
                 save.fi.dip[0], save.fi.dip[1],
                 save.fi.dip[2], save.fi.dip[3],
                 save.fi.port, save.fi.mode,
                 (unsigned long)save.fi.timeout);

        CLI_Print(buf);
        return;
    }

    /* FRAM 값 */
    if (!strcmp(text, "FRAM"))
    {
        CLI_FRAM();
        return;
    }

    /* 일시정지 : 빨간불 (MI / PO 가 정지선에서 섬) */
    if (!strcmp(text, "S"))
    {
        Pause_Set(0, 'M');          /* 일시정지 : 모든 렉, 이유 사용자 (+ 부저 · 로그) */
        CLI_Result(CMD_S, 1);
        return;
    }

    /* 모터 초기화 재확인 */
    if (!strcmp(text, "INIT"))
        CLI_Result(CMD_INIT, motor_basic_init());

    /* X 모터 : X 펄스 속도% */
    else if (sscanf(text, "X %ld %d", &pulse, &persent) == 2)
        CLI_Result('X', motor_basic_run('X', (int32_t)pulse, 0, persent));

    /* Y 모터 : Y 펄스 속도% */
    else if (sscanf(text, "Y %ld %d", &pulse, &persent) == 2)
        CLI_Result('Y', motor_basic_run('Y', (int32_t)pulse, 0, persent));

    /* Tilt 중앙 : C 속도% */
    else if (sscanf(text, "C %d", &persent) == 1)
        CLI_Result('C', motor_basic_run('C', 0, 0, persent));

    /* Tilt 오른쪽 : R 각도 속도% (읽은 숫자는 각도) */
    else if (sscanf(text, "R %ld %d", &pulse, &persent) == 2)
        CLI_Result('R', motor_basic_run('R', 0, (int)pulse, persent));

    /* Tilt 왼쪽 : L 각도 속도% */
    else if (sscanf(text, "L %ld %d", &pulse, &persent) == 2)
        CLI_Result('L', motor_basic_run('L', 0, (int)pulse, persent));

    /* 원점복귀 */
    else if (!strcmp(text, "I"))
        CLI_Result(CMD_I, I());

    /* (디버그) Y 레지스터 읽기 : REG = H05_09 / REG 0B22 = 그 주소 (16진수 4자리, 뒤 두 자리는 번호를 16진수로 : H0B_34 = 0B22) */
    else if (strncmp(text, "REG", 3) == 0) {
        sscanf(text + 3, "%x", &reg);       /* 뒤에 주소 있으면 그 주소, 없으면 0509 그대로 */
        int32_t v16 = 0, v32 = 0;
        int ok16 = AM_ReadReg((uint16_t)reg, &v16, 1);
        int ok32 = AM_ReadReg((uint16_t)reg, &v32, 2);
        snprintf(buf, sizeof(buf), "\r\nY reg 0x%04X : 16bit %s %ld / 32bit %s %ld\r\n> ",
                 reg, ok16 ? "=" : "FAIL", (long)v16, ok32 ? "=" : "FAIL", (long)v32);
        CLI_Print(buf);
    }

    else
        CLI_Print("BAD COMMAND\r\n> ");
}


/* UART1 CLI (Comm_Task 1ms 마다) : 보관함(cli_buf, usart.c 인터럽트가 넣음)에 온 글자를 전부 꺼내 한 줄 만들기
   글자 → 줄에 붙이고 화면에 다시 보여 줌 / 지우기 → 하나 빼고 화면에서도 지움 / 엔터 → 명령 실행 */
void CLI_Run(void)
{
    static char line[CLI_SIZE];             /* 지금 치는 한 줄 */
    static uint8_t index = 0;               /* 줄에서 다음 글자 넣을 칸 */
    static uint8_t tail = 0;                /* 보관함에서 다음에 꺼낼 칸 */
    char ch[2] = {0, 0};                    /* 꺼낸 글자 1개 (화면에 다시 보낼 때 글자 + 끝) */

    while (tail != cli_head) {                                  /* 보관함에 글자 있는 만큼 */
        ch[0] = cli_buf[tail];
        tail = (tail + 1) % CLI_BUF;                            /* 다음 칸 (끝이면 처음으로) */

        if (ch[0] == '\r' || ch[0] == '\n') {                   /* 엔터 : 한 줄 끝 */
            if (index == 0) continue;                           /*   빈 줄 (CR 뒤 LF) 은 무시 */
            line[index] = 0;
            index = 0;
            CLI_Print("\r\n");
            CLI_Command(line);
        }
        else if (ch[0] == '\b' || ch[0] == 0x7F) {              /* 지우기 (Backspace · Delete) */
            if (index == 0) continue;                           /*   지울 글자 없음 */
            index--;
            CLI_Print("\b \b");                                 /*   화면 : 한 칸 뒤로 → 빈칸으로 덮기 → 다시 뒤로 */
        }
        else if (index < CLI_SIZE - 1) {                        /* 글자 : 줄에 붙이기 (꽉 차면 무시) */
            line[index++] = ch[0];
            CLI_Print(ch);                                      /*   화면에 다시 보여 줌 (echo) */
        }
    }
}
