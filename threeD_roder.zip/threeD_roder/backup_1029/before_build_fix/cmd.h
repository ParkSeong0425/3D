/*
 * cmd.h
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#ifndef INC_CMD_H_
#define INC_CMD_H_

#include "run.h"

/* Motor_Task 초인종 번호 : 울린 번호대로 Motor_Run 이 run 함수 하나 실행 (0x01 XFER_DONE 과 겹치면 안 됨) */
#define MOTOR_FLAG  0x08        /* 원점 (켤 때 · HMI RUN · PC I → run.c Motor_Run) */
#define MI_FLAG     0x20        /* PC 입고 */
#define MO_FLAG     0x40        /* PC 출고 */
#define PO_FLAG     0x80        /* PC 분배 */

/* Comm_Task 초인종 번호 */
#define NET_FLAG    0x10        /* W6100 INT 핀 (PC 글자 옴 · 접속 · 끊김) → Comm_Task 바로 깸 (event.c EXTI 콜백) */

#define STX       0x02
#define ETX       0x03
#define ACK       0x06
#define NAK       0x15

extern char done_text[];    /* 완료응답 글자 AI_1_1_2 (cmd.c) : net.c send_cmd 가 PC 승인인지 비교 */
extern int done_no;         /* 승인 기다리는 명령 번호 (cmd.c) : 승인도 이 번호 (명령 하나 = 번호 하나) */

void CMD_Run(int no, char *s);  /* 명령 받기 (Comm_Task) : no 번호, s PC 내용만 → 확인 → NAK / ACK + 실행 (움직임은 Motor_Task 로) */
void CMD_Event(void);       /* 쪽지들 → PC (Comm_Task) */

#endif
