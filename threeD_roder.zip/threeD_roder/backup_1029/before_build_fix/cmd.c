/*
 * cmd.c : PC 명령 확인 → 틀리면 NAK / 맞으면 ACK + 그 파일 함수 실행 (움직임은 Motor_Task 초인종으로)
 *         프로토콜 글자는 그 파일에 : 만재 manjae.c · 카드 rfid.c · 상태 status.c · 램프 lamp.c · 부저 buzzer.c · MI/MO/PO 숫자 run.c
 *         PC 로 먼저 알림(FF · UT · PPAUSE · S)도 그 파일 *_PC() 가 (Comm_Task 반복문, app_freertos.c)
 *
 *  글자 모양 : STX + 번호 2글자 + (ACK / NAK) + 내용 + ETX  (번호는 net.c 가 CMD_Run(no, s) 로 따로 줌 → 대답에 그대로)
 *
 *  ── 함수 ──
 *   cmd_answer        : 명령 대답 (그 명령 번호 + ACK 받았다 / NAK 못 받았다 / 0 완료응답)
 *   done_event        : 완료응답 한 번 (렉이 R → W) → 다음 명령 받음
 *   done_repeat       : PC 승인까지 1초마다 다시 + 새 명령 NAK (시험 때 이 줄만 주석)
 *   CMD_Event         : (Comm_Task) done_event · done_repeat · homing done (I → W)
 *   CMD_Run           : (Comm_Task) 명령 확인
 *                       FS · FP · FI · FD (설정 저장) / MI · MO · PO · I (움직임 → 초인종) / C (상태) / S (일시정지)
 *                       D (억지로 풀기) / LL (램프) / R (카드) / B (부저) / AI… (완료 승인) / ALL_거래처 (FS + FP 기본 설정 저장)
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#include "cmd.h"
#include "save.h"
#include "net.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "event.h"
#include "alarm.h"
#include "rfid.h"
#include "lamp.h"
#include "buzzer.h"
#include "debug.h"
#include "cmsis_os2.h"

#include <stdio.h>
#include <string.h>

#define CMD_FS  (('F' << 8) | 'S')
#define CMD_FP  (('F' << 8) | 'P')
#define CMD_FI  (('F' << 8) | 'I')
#define CMD_C   ('C' << 8)
#define CMD_FD  (('F' << 8) | 'D')
#define CMD_RFID ('R' << 8)
#define CMD_LAMP (('L' << 8) | 'L')
#define CMD_D   ('D' << 8)
#define CMD_BUZZER (('B' << 8) | '_')   /* 01B_렉_1 켬 / 01B_렉_0 끔 */
#define CMD_ALL (('A' << 8) | 'L')      /* ALL_거래처 : 그 거래처 기본 설정(FS + FP) 한 번에 저장 */



/* 명령 대답 : STX + 번호(그 명령 번호 그대로) + A_N + 글자 + ETX
   A_N : ACK 받았다 (08<ACK>MI_1_1_2) / NAK 못 받았다 (08<NAK>bad_data) / 0 완료응답 (08AI_1_1_2) */
static void cmd_answer(int no, char A_N, char *text)
{
    char tx[170];
    int len;

    if (A_N == 0) len = snprintf(tx, sizeof(tx), "%c%02d%s%c", STX, no, text, ETX);           /* 완료응답 : 가운데 글자 없음 */
    else          len = snprintf(tx, sizeof(tx), "%c%02d%c%s%c", STX, no, A_N, text, ETX);    /* ACK / NAK */
    send_socket((uint8_t *)tx, len);
}



/* 명령 끝 대답 (Comm_Task 1ms 마다) : MI · MO · PO 완료응답 + PC I 의 homing done
   (만재 FF · 카드 UT · 일시정지 PPAUSE · 알람 S 는 그 파일 Manjae_PC · Rfid_PC · Status_PC · Alarm_PC) */
void CMD_Event(void)
{

    /* 원점 끝 (상태판, PC I 였을 때만) : 대기 → homing done 한 번 / 초기상태 · 알람 → 대답 없음 */
    if (home_no != 0 && status_1 == WAIT) {
        cmd_answer(home_no, ACK, "homing done");    /* 08<ACK>homing done */
        home_no = 0;
    }
    if (home_no != 0 && (status_1 == RESTART || status_1 == ALARM)) home_no = 0;
}

/* 명령 받기 (Comm_Task) : 명령이 맞나 확인 → 아니면 NAK / 맞으면 ACK + 그 파일 함수 실행. 움직이는 명령은 Motor_Task 에 넘기고 바로 돌아감
   no = 로더가 붙인 번호 (net.c send_cmd), s = PC 가 보낸 내용만 (STX · ETX · 번호 없음)  예) CMD_Run(8, "MI_1_1_2") */
void CMD_Run(int PC_num, char *s)
{
    int cmd;

    int rack;
    char type;
    int rack_channel;

    int in_x, in_y;
    int left_x, left_y;
    int right_x, right_y;
    int fi_no;                /* FI 의 항목 번호 */
    char fp_no;              /* FP 의 항목 글자 ('1' ~ '9', ':' 10 ';' 11 '<' 12 '=' 13) */
    int value[9];

    /* 완료 승인 : PC 가 받은 완료응답을 그대로 돌려줌 (AI_1_1_2) → 반복 끝 = 다음 명령 받을 준비 (대답 없음) */
    if (strcmp(s, done_text) == 0) {        /* strcmp : 두 글자가 같으면 0 */
        order_no = 0;                       /* 명령 끝 → MI · MO · PO 다시 받음 */
        done_no = 0;                        /* 승인 기다림 끝 */
        done_text[0] = 0;
        Log_Debug(LOG_ACCPT_COMMAND);       /* PC 가 완료를 확인함 */
        return;
    }

    /* 번호는 로더가 붙임 : PC 가 번호를 붙여 보냄 (52MI_…) → 거절 */
    if (s[0] >= '0' && s[0] <= '9') { cmd_answer(no, NAK, "wrong_number"); return; }

    cmd = (s[0] << 8) | s[1];

    switch (cmd)

    {
    /* FS */
    case CMD_FS:

        if (sscanf(s, "FS_%d_%c_%d_%d_%d_%d_%d_%d_%d_%d",
                   &rack, &type, &rack_channel,
                   &in_x, &in_y, &left_x, &left_y,
                   &right_x, &right_y, &option) == 10 &&
            FS(rack, type, rack_channel,
               in_x, in_y, left_x, left_y,
               right_x, right_y, option))
            cmd_answer(PC_num, ACK, s);
        else
            cmd_answer(PC_num, NAK, "bad_data");

        break;


        /* FP : 설정번호 확인 → 데이터 개수 확인 → 저장 */
        case CMD_FP:
        {
            int need = 0;    /* 데이터 넣는 수가 각자 다르기 때문에  */

            if (sscanf(s, "FP_%d_%c", &rack, &no) != 2) {
                cmd_answer(PC_num, NAK, "bad_data");
                break;
            }

            switch (no) {
            case '1': case '8': case '9': case ':':
                need = 1;
                break;

            case '2': need = save.fs.in_y;    break;
            case '3': need = save.fs.left_x;  break;
            case '4': need = save.fs.left_y;  break;
            case '5': need = save.fs.right_x; break;
            case '6': need = save.fs.right_y; break;

            case '7': need = 5; break;

            case ';': case '<':
                need = 3;
                break;

            case '=':
                need = save.fs.in_y + 1;
                break;
            }

            if (rack != 1 || need < 1 ||
                sscanf(s, "FP_%d_%c_%d_%d_%d_%d_%d_%d_%d_%d_%d",
                       &rack, &no,
                       &value[0], &value[1], &value[2],
                       &value[3], &value[4], &value[5],
                       &value[6], &value[7], &value[8]) != need + 2)
            {
                cmd_answer(PC_num, NAK, "bad_data");
                break;
            }

            if (FP(rack, fp_no, value))
                cmd_answer(PC_num, ACK, s);
            else
                cmd_answer(PC_num, NAK, "bad_data");

            break;
        }

    /* FI */
    case CMD_FI:

        /* FI 1~4 : IP 형식 */
        if (sscanf(s,
                "FI_1_%d_%d.%d.%d.%d",
                &fno,
                &value[0],
                &value[1],
                &value[2],
                &value[3]) == 5)
        {
            if (FI(fi_no, value))
                cmd_answer(PC_num, ACK, s);
            else
                cmd_answer(PC_num, NAK, "bad_data");

            break;
        }

        /* FI 5~7 : 숫자 하나 */
        if (sscanf(s,
                "FI_1_%d_%d",
                &fno,
                &value[0]) == 2)
        {
            if (FI(fno, value, 1))
                cmd_answer(PC_num, ACK, s);
            else
                cmd_answer(PC_num, NAK, "bad_data");

            break;
        }

        cmd_answer(PC_num, NAK, "bad_data");
        break;


    /* FD */
    case CMD_FD:

        if (strcmp(s, "FD_1") != 0)
        {
            cmd_answer(PC_num, NAK, "bad_data");
            break;
        }

        if (FD())
            cmd_answer(PC_num, ACK, s);
        else
            cmd_answer(PC_num, NAK, "fram_error");

        break;


    /* 입고 · 출고 · 분배 : 01MI_렉_열_단_XY속도_틸트속도_이동후대기_쏟는시간 → 확인 → 맞으면 Motor_Task 에 넘김 (실행은 run.c MI · MO · PO) */
    case CMD_MI:
    case CMD_MO:
    case CMD_PO:

        if (status_1 != WAIT || status_2 != WAIT || status_3 != WAIT || status_4 != WAIT ||   /* 동작 중 · 원점 중 · 대기 아님 */
            manual || order_no != 0)                                                      /* 수동 / 앞 명령이 아직 안 끝남 (PC 승인 전) */
        {
            cmd_answer(PC_num, NAK, "can_not_command");
            break;
        }

        /* 숫자 읽기 · 검사 → ACK → 초인종 : 주문서를 새로 정한 뒤 여기에 */
        break;

    /* 상태 조회 : 렉 수(rack_channel)만큼 S_1_W&S_2_A_03&S_3_W … + 만재 F_1_0001&F_2_0000 */
    case CMD_C:
    {
        char st[80];                                /* 렉 상태 (status.c) */
        char mj[24];                                /* 만재 (manjae.c) */
        char tx[110];

        Log_Debug(LOG_CHECK_PC);
        Status_Text(st, sizeof(st));
        Manjae_Text(mj, sizeof(mj));
        snprintf(tx, sizeof(tx), "%s&%s", st, mj);
        cmd_answer(PC_num, ACK, tx);
        break;
    }

    /* 일시정지 : S_1 → 모든 렉 멈춤 표시 (이유 M 사용자). MI 도착 · PO 정지선에서 섬, HMI RUN 으로 풂 */
    case CMD_S:

        if (strcmp(s, "S_1") != 0)
        {
            cmd_answer(PC_num, NAK, "bad_data");
            break;
        }

        Pause_Set(0, 'M');          /* 일시정지 : 모든 렉, 이유 사용자 (+ 부저 · 로그) */
        Log_Debug(LOG_PAUSE_PC);    /* PC S 로 멈춤 */
        cmd_answer(PC_num, ACK, s);
        break;

    /* 억지로 풀기 : D → 만재(F) · 틸트(T) 로 멈춘 것만 이어서 진행 (센서가 만재여도) */
    case CMD_D:

        if (strcmp(s, "D") != 0)
        {
            cmd_answer(PC_num, NAK, "bad_data");
            break;
        }

        if (pause_why == 'F'|| pause_why == 'T')
            Pause_Clear();          /* 만재 · 틸트로 멈춘 것만 풀기 (+ 부저 끔 · 로그) */
        cmd_answer(PC_num, ACK, s);
        break;

    /* 원점 : I → 확인 → 원점 중 + 부저 → Motor_Task (run.c motor_basic_init) */
    case CMD_I:

        if (strcmp(s, "I") != 0)
        {
            cmd_answer(PC_num, NAK, "bad_data");
            break;
        }

        if (status_1 == HOME ||                                         /* 원점 중 */
            status_1 == RUN   || status_2 == RUN   || status_3 == RUN   || status_4 == RUN ||      /* 동작 중 */
            status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE ||    /* 동작 중 멈춤 (PO 정지선) */
            manual)                                                                                 /* 수동 모드 중 (HMI 로 움직이는 중) */
        {
            cmd_answer(PC_num, NAK, "can_not_command");
            break;
        }

        cmd_answer(PC_num, ACK, s);                         /* 받았다 */
        home_no = PC_num;                                   /* 원점 끝나면 이 번호로 homing done (CMD_Event) */
        Status_HOME();                                  /* 원점 중 (초인종 전에 : CMD_Event 가 W 를 보고 끝났다고 착각하지 않게) */
        osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG); /* 원점 해 (run.c motor_basic_init) */
        break;

    /* 램프 : 01LL_렉_램프_모드시간&L_렉_램프_모드시간… (램프 1 적 2 녹 3 황, 모드 0 끔 1 켬 2 깜빡, 시간 '0'~'l' = 0~60초, 0 = 계속) */
    case CMD_LAMP:
        if (Lamp_Cmd(s)) cmd_answer(PC_num, ACK, s);        /* 풀기 · 확인 · 켜기 (lamp.c) */
        else             cmd_answer(PC_num, NAK, "bad_data");
        break;

    /* 카드 조회 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 (글자는 rfid.c) */
    case CMD_RFID:
    {
        char card[48];

        Log_Debug(LOG_RFID_PC);
        Rfid_Text(card, sizeof(card));
        cmd_answer(PC_num, ACK, card);
        break;
    }

    /* 부저 : 01B_렉_켜기(1) / 끄기(0) (buzzer.c) */
    case CMD_BUZZER:
        if (Buzzer_Cmd(s)) cmd_answer(PC_num, ACK, s);
        else               cmd_answer(PC_num, NAK, "bad_data");
        break;

    /* 거래처 기본 설정 : ALL_거래처 → FS + FP 를 그 거래처 값으로 한 번에 저장 (값은 save.c Setting_Default_거래처)
       거래처 추가 : 아래 if 줄을 복사해서 글자와 함수 이름만 바꿈 */
    case CMD_ALL:
        if (strcmp(s, "ALL_PIMZ") == 0 && Setting_Default_PIMZ()) { cmd_answer(PC_num, ACK, s); break; }   /* 거래처 PIMZ */

        cmd_answer(PC_num, NAK, "bad_data");                /* 모르는 거래처 · FRAM 저장 실패 */
        break;

    default:
        cmd_answer(PC_num, NAK, "bad_command");
        break;
    }
}
