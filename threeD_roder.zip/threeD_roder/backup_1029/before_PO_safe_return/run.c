#include "run.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "debug.h"
#include "event.h"
#include "cmsis_os2.h"
#include "status.h"
#include "cmd.h"
#include "alarm.h"
#include "manjae.h"
#include "rfid.h"
#include "buzzer.h"
#include "save.h"
#include "net.h"
#include "flag.h"
#include <stdio.h>


/* 원점 (켤 때 · HMI RUN · PC I · CLI INIT) : 원점 중 표시 → 드라이브 설정 (세 축 따로 다 보냄) → 원점 → 대기 / 초기상태. 도착 1 / 실패 0 */
int motor_basic_init(void)
{
    Status_HOME();                      /* 원점 중 → 램프 원점 깜빡 */
    Log_Debug(LOG_HOME_START);

    int x = IM_MapInit();               /* X 설정 */
    int y = AM_Init();                  /* Y 설정 */
    int t = TM_Init();                  /* 틸트 설정 */
    if (x == 0) Log_Debug(LOG_HOME_X_NO_ANSWER);
    if (y == 0) Log_Debug(LOG_HOME_Y_NO_ANSWER);
    if (t == 0) Log_Debug(LOG_HOME_T_NO_ANSWER);

    if (x && y && t && I()) {           /* 설정 다 됨 → 원점 도착 */
        Status_WAIT(1);                 /* 대기 → 램프 rfid */
        Status_WAIT(2);
        Status_WAIT(3);
        Status_WAIT(4);
    	Log_Debug(LOG_HOME_DONE);
        return 1;
    }

    if (status_1 != ALARM) { Status_HOME(); Buzzer_Off(); }     /* 못 감 → 초기화(I) 그대로 (알람이면 상태 · 부저 그대로) */
    Log_Debug(LOG_HOME_FAIL);
    return 0;
}

/* 기본 모터 시험 (CLI X Y C R L) : 명령만 보냄 (도착은 안 기다림) */
int motor_basic_run(int command, int32_t pulse, int deg , int rpm)
{
    if      (command == 'X') return IM_Move(pulse, rpm);
    else if (command == 'Y') return AM_Move(pulse, rpm);
    else if (command == 'C') return TM_C(rpm);
    else if (command == 'R') return TM_R(deg, rpm);
    else if (command == 'L') return TM_L(deg, rpm);
    return 0;
}

/* 정지선 (블록) : 일시정지(pause_why)면 풀릴 때까지 기다림. 알람이면 pause_why 0 이라 바로 나옴
   일시정지는 표시만 하고, 모터는 여기(MI 도착 뒤 · PO 기울이기 전 · PO 쏟은 뒤)에서 섬 */
static void pause_wait(void)
{
    while (pause_why) osDelay(20);
}

/* 통로로 : 틸트 가운데 → X 만 safe_x 까지 빠짐 (Y 그대로 : 입고대 안이어도 판이 안 걸림). MI · MO 맨 앞
   빠지는 거리 = in_x − safe_x (지금 1710 − 1618 = 92mm, 판 380mm 가 다 빠지는지 현장 확인) */
static void safe_out(int lift_speed, int tilt_speed)
{
    TM_C(tilt_speed);
    A_07(TM_Arrive(0));                                         /* 틸트 가운데 → 못 갔으면 알람 07 */
    IM_Move(save.fp.safe_x, lift_speed);                        /* safe_x = 빠지는 점 X (FP 13) */
    A_05(IM_Arrive(save.fp.safe_x));                            /* 통로 → 못 갔으면 알람 05 */
}

/* 입고 dan 단 : 출발 대기 → 통로로 → 그 단 안전 높이 (트레이 바로 아래) → 입고대 진입 → 들어 올림
   매개변수는 프로토콜 순서 그대로 (return_delay · tilt_angle 은 MI 에선 안 씀)
   긴급정지 · 알람이 걸리면 그 뒤 이동 · 기다림은 모터 함수가 알아서 안 함 → 마지막에 결과만 */
int MI(int dan, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle)
{
    /* 0. 출발 대기 (동작 대기 ms) */
    osDelay(delay);

    /* 1. 통로로 */
    safe_out(lift_speed, tilt_speed);

    /* 2. 그 단 안전 높이 (통로라 Y 만 바꿔도 안전) */
    AM_Move(save.fp.safe_y[dan - 1], lift_speed);
    A_06(AM_Arrive(save.fp.safe_y[dan - 1]));                   /* 못 갔으면 알람 06 */

    /* 3. 입고대 진입 (X 만) */
    IM_Move(save.fp.in_x, lift_speed);
    A_05(IM_Arrive(save.fp.in_x));                              /* 못 갔으면 알람 05 */

    /* 4. 들어 올림 (Y 만) */
    AM_Move(save.fp.in_y[dan - 1], lift_speed);
    A_06(AM_Arrive(save.fp.in_y[dan - 1]));                     /* 못 갔으면 알람 06 */

    /* 5. 정지선 : STOP 이면 RUN 까지 */
    pause_wait();

    return (estop == 0 && status_1 != ALARM);                   /* 멈춘 적 없으면 성공 */
}

/* 출고 : 출발 대기 → 통로로 → 렉 좌표 (x, y) 로 X · Y 같이 (이동만). 좌표는 부르는 쪽이 FRAM 표에서
   매개변수는 프로토콜 순서 그대로 (return_delay · tilt_angle 은 MO 에선 안 씀) */
int MO(int x, int y, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle)
{
    osDelay(delay);                             /* 0. 출발 대기 (동작 대기 ms) */
    safe_out(lift_speed, tilt_speed);           /* 1. 통로로 */
    IM_Move(x, lift_speed);                     /* 2. 통로에서 X · Y 같이 */
    AM_Move(y, lift_speed);
    A_05(IM_Arrive(x));                         /*    못 갔으면 알람 05 */
    A_06(AM_Arrive(y));                         /*    못 갔으면 알람 06 */
    pause_wait();                               /* 3. 정지선 */
    return (estop == 0 && status_1 != ALARM);   /* 멈춘 적 없으면 성공 */
}

/* 틸팅 검사 (PO 명령이 검사하라고 할 때) : 최대 ms 동안 그 단 센서 보기 → 닿으면 바로 끝 / 끝까지 안 닿으면 PPAUSE:T */
static void PO_tilt(int rack, int dan, int ms)
{
    for (; ms > 0; ms -= 20) {                  /* 20ms 마다, ms = 남은 시간 */
        if (manjae_on(rack, dan)) return;       /* 닿음 = 쏟아짐 → 끝 */
        osDelay(20);
    }
    Pause_Set(rack, 'T');                       /* 끝까지 안 닿음 → PPAUSE:T */
}

/* 분배 : 이동 → 정지선(만재 · 카드) → 틸트 → 쏟기 확인 → 복귀
   매개변수는 프로토콜 순서 그대로 + 틸팅 검사. 틸팅 Y · 속도는 FRAM FP 7 (save.fp.tilting_y · tilting_y_speed) */
int PO(int rack, int x, int y, int dan, int lift_speed, int tilt_speed,
       int delay, int return_delay, int tilt_angle, int tilt_check)
{
    int tilting_y = save.fp.tilting_y;                  /* 쏟을 때 Y 를 더 올리는 높이 (FP 7) */
    int tilting_y_speed = save.fp.tilting_y_speed;      /* 그때 속도 % (FP 7) */

    /* 1. 이동 (출발 대기는 MO 가 함 → PO 는 따로 안 기다림) */
    MO(x, y, lift_speed, tilt_speed, delay, return_delay, tilt_angle);

    /* 2. 정지선 : 그 단 만재 · 그 렉 카드 없음이면 멈춤 → HMI RUN 으로 이어서 (MI · MO 는 상관없음, 틸트 뒤 만재도 상관없음) */
    while (manjae_on(rack, dan) && manjae_stable(rack, dan) == 0) osDelay(20);    /* 만재 센서 바뀐 지 2초 안 : 스침인지 확정될 때까지 (최대 2초) */
    if (manjae_on(rack, dan) && manjae_stable(rack, dan)) Pause_Set(rack, 'F');   /* 그 단 만재 (2초 넘게 그대로, 스침 아님) → PPAUSE:F */
    if (card_on(rack) == 0) Pause_Set(rack, 'S');                                 /* 틸트하려는데 그 렉 카드 없음 → PPAUSE:S (카드 다시 들어와도 RUN 까지) */
    pause_wait();                                           /* RUN 까지 기다림 */

    /* 3. Y 올리면서 틸트 : Y 가 절반 올라가면 틸트 출발 */
    AM_Move(y + tilting_y, tilting_y_speed);
    AM_Arrive(y + tilting_y / 2);                                  /* Y 절반 기다림 (X 는 서 있음) */
    if (rack % 2 == 1) { TM_R(tilt_angle, tilting_y_speed); }     /* 홀수 렉 = 오른쪽 */
    else { TM_L(tilt_angle, tilting_y_speed); }                    /* 짝수 렉 = 왼쪽 */
    A_06(AM_Arrive(y + tilting_y));                                /* Y 끝 기다림 → 못 갔으면 알람 06 */
    A_07(TM_Arrive(tilt_angle));                                   /* 기울기 도착 기다림 → 못 갔으면 알람 07 */

    /* 4. 기울인 채 : FS 옵션 틸팅 검사가 켜져 있고(option 마지막 자리 1) 이 명령도 검사(1)면 틸팅 검사 (닿을 때까지, 안 닿으면 T)
          아니면 (옵션 0 이면 명령이 1 이어도) return_delay 만큼 기다리기만 */
    if (save.fs.option[4] == 1 && tilt_check == 1 && rack <= 2)
        PO_tilt(rack, dan, save.fp.tilt_check_time);
    else
        osDelay(return_delay * 10);

    /* 5. Y, 틸트 복귀 */
    TM_C(tilting_y_speed);
    AM_Move(y, tilting_y_speed);
    A_07(TM_Arrive(0));                                            /* 틸트 가운데 → 못 갔으면 알람 07 */
    A_06(AM_Arrive(y));                                            /* Y 제자리 → 못 갔으면 알람 06 */

    return (estop == 0 && status_1 != ALARM);   /* 멈춘 적 없으면 성공 */
}

/* 원점 : Tilt -> X -> Y 순서. 하나라도 실패하면 거기서 멈추고 0 */
int I(void)
{
    return TM_Home()      /* 1. 틸트 */
        && IM_Home()      /* 2. X */
        && AM_Home();     /* 3. Y */
}

/* 긴급정지 : 세 축 모두 멈춤. 하나가 통신 실패해도 나머지는 꼭 보냄 (IM_Stop 과 같은 방식) */
int E_S (void)
{
	int t = TM_Stop();     /* 1. 틸트 */
	int x = IM_Stop();     /* 2. X */
	int y = AM_Stop();   /* 3. Y */

	return t && x && y;    /* 하나라도 실패면 0 */
}

/* ======================= 모터 문 : 주문 받기 → Motor_Task ======================= */

static MOVE job;                                    /* 지금 할 주문 : Motor_Request 가 쓰고 Motor_Run 이 읽음 (이 파일 안에서만) */
static volatile int busy;                           /* 1 = Motor_Task 가 주문 하는 중 (Request 가 1, Run 끝이 0) */

/* 주문 받기 (아무 태스크) : 하는 중 · 알람 · 초기화(I) 중 MI·MO·PO 면 0 (못 받음) / 받으면 주문 보관 → 초인종 → 1 */
int Motor_Request(MOVE m)
{
    if (busy || status_1 == ALARM) return 0;                    /* 하는 중 (원점 중 포함) · 알람 (긴급정지 포함) */
    if (m.cmd != CMD_I && status_1 == HOME) return 0;           /* 초기화(I) 중엔 원점만 */
    busy = 1;
    job = m;                                                    /* 주문 보관 (칸 통째 복사) */
    osThreadFlagsSet(Motor_TaskHandle, MOVE_FLAG);              /* 초인종 */
    return 1;
}

/* Motor_Task : 주문대로 하나 → 끝나면 busy 0. 상태 R · W 는 보여 주기용 (HMI · 램프 · PC C) */
void Motor_Run(void)
{
    int x, y;                                                   /* 렉 좌표 (FRAM 표) */
    int ok = 0;                                                 /* 끝까지 감 (완료응답 만들 때 씀) */

    if (job.cmd == CMD_I) ok = motor_basic_init();              /* 원점 : I → W (실패면 I 그대로) */
    else {
        Status_RUN(job.rack);                                   /* 표시 : 운전 중 */
        if (job.rack % 2 == 1) { x = save.fp.right_x[job.col - 1]; y = save.fp.right_y[job.dan - 1]; }   /* 홀수 렉 = 오른쪽 표 */
        else                   { x = save.fp.left_x[job.col - 1];  y = save.fp.left_y[job.dan - 1];  }   /* 짝수 렉 = 왼쪽 표 */

        if (job.cmd == CMD_MI) ok = MI(job.dan, job.lift_speed, job.tilt_speed, job.delay, job.return_delay, job.tilt_angle);
        if (job.cmd == CMD_MO) ok = MO(x, y, job.lift_speed, job.tilt_speed, job.delay, job.return_delay, job.tilt_angle);
        if (job.cmd == CMD_PO) ok = PO(job.rack, x, y, job.dan, job.lift_speed, job.tilt_speed,
                                       job.delay, job.return_delay, job.tilt_angle, job.tilt_check);
        if (ok) Status_WAIT(job.rack);                          /* 표시 : 대기 (알람 · 긴급정지면 그대로) */
    }
    busy = 0;                                                   /* 끝 → 다음 주문 받음 */
}

