param([string]$hexPath, [string]$outPath)
# Intel HEX -> bytes -> printable strings (len >= 3) with address
$base = 0
$mem = @{}
$min = [int64]::MaxValue; $max = 0
foreach ($line in [System.IO.File]::ReadLines($hexPath)) {
    if (-not $line.StartsWith(':')) { continue }
    $n = [Convert]::ToInt32($line.Substring(1,2),16)
    $addr = [Convert]::ToInt32($line.Substring(3,4),16)
    $type = [Convert]::ToInt32($line.Substring(7,2),16)
    if ($type -eq 4) { $base = [Convert]::ToInt64($line.Substring(9,4),16) * 65536; continue }
    if ($type -ne 0) { continue }
    for ($i=0; $i -lt $n; $i++) {
        $a = $base + $addr + $i
        $mem[$a] = [Convert]::ToByte($line.Substring(9+2*$i,2),16)
        if ($a -lt $min) { $min = $a }; if ($a -gt $max) { $max = $a }
    }
}
$sb = New-Object System.Text.StringBuilder
$cur = New-Object System.Text.StringBuilder
$start = 0
for ($a=$min; $a -le $max+1; $a++) {
    $b = if ($mem.ContainsKey($a)) { $mem[$a] } else { 0 }
    if (($b -ge 0x20 -and $b -le 0x7E) -or $b -eq 9) {
        if ($cur.Length -eq 0) { $start = $a }
        [void]$cur.Append([char]$b)
    } else {
        if ($cur.Length -ge 3) { [void]$sb.AppendLine(('{0:X8} {1}' -f $start, $cur.ToString())) }
        [void]$cur.Clear()
    }
}
[System.IO.File]::WriteAllText($outPath, $sb.ToString())
"min {0:X} max {1:X}" -f $min, $max
