param([string]$dir)
$b = [IO.File]::ReadAllBytes("$dir\fw.bin")
function IsPort([uint32]$w) { return ($w -ge 0x48000000 -and $w -le 0x48001800 -and ($w % 0x400) -eq 0) }
$names = @{ 0x48000000='A'; 0x48000400='B'; 0x48000800='C'; 0x48000C00='D'; 0x48001000='E'; 0x48001400='F'; 0x48001800='G' }
for ($i = 0; $i -lt $b.Length - 60; $i += 4) {
    $w = [BitConverter]::ToUInt32($b, $i)
    if (-not (IsPort $w)) { continue }
    if (-not (IsPort ([BitConverter]::ToUInt32($b, $i + 20)))) { continue }
    if (-not (IsPort ([BitConverter]::ToUInt32($b, $i + 40)))) { continue }
    $line = '{0:X8} :' -f ($i + 0x08000000)
    for ($k = 0; $k -lt 12; $k++) {
        $o = $i + $k * 20
        if ($o + 20 -gt $b.Length) { break }
        $p = [BitConverter]::ToUInt32($b, $o)
        if (-not (IsPort $p)) { break }
        $pin = [BitConverter]::ToUInt16($b, $o + 4)
        $bit = -1; for ($x = 0; $x -lt 16; $x++) { if ($pin -eq (1 -shl $x)) { $bit = $x } }
        $line += ' [{0}]P{1}{2} on{3}/off{4}' -f $k, $names[[int64]$p], $bit, $b[$o + 6], $b[$o + 7]
    }
    $line
    $i += 200
}
