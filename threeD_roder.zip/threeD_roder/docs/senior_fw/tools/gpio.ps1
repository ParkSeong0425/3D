param([string]$dir, [string]$target)
$l = Get-Content "$dir\dis.txt"
$bin = [IO.File]::ReadAllBytes("$dir\fw.bin")
function Word([int64]$addr) { $o = $addr - 0x08000000; if ($o -lt 0 -or $o + 3 -ge $bin.Length) { return $null }; return [BitConverter]::ToUInt32($bin, [int]$o) }
function Str([int64]$addr) { $o = $addr - 0x08000000; if ($o -lt 0 -or $o -ge $bin.Length) { return $null }; $s = ''; while ($o -lt $bin.Length -and $bin[$o] -ge 0x20 -and $bin[$o] -le 0x7E -and $s.Length -lt 60) { $s += [char]$bin[$o]; $o++ }; if ($s.Length -ge 4 -and $bin[$o] -eq 0) { return $s }; return $null }
$ports = @{ '48000000'='A'; '48000400'='B'; '48000800'='C'; '48000C00'='D'; '48001000'='E'; '48001400'='F'; '48001800'='G' }
$out = New-Object System.Collections.Generic.List[string]
for ($i = 0; $i -lt $l.Count; $i++) {
    if ($l[$i] -notmatch ("bl\s+0x" + $target + "\b")) { continue }
    $addr = ($l[$i] -split ':')[0].Trim()
    $port = '?'; $pin = '?'; $val = '?'
    for ($j = $i - 1; $j -ge [Math]::Max(0, $i - 12); $j--) {
        $t = $l[$j]
        if ($port -eq '?' -and $t -match 'ldr\s+r0, \[pc, #\d+\]\s+@ \(0x([0-9a-f]+)\)') { $w = Word ([Convert]::ToInt64($matches[1], 16)); if ($w -ne $null) { $k = '{0:X8}' -f $w; if ($ports.ContainsKey($k)) { $port = $ports[$k] } else { $port = $k } } }
        if ($pin -eq '?' -and $t -match '(movs|mov\.w|movw)\s+r1, #(\d+)') { $pin = [int]$matches[2] }
        if ($val -eq '?' -and $t -match 'movs\s+r2, #(\d+)') { $val = $matches[1] }
    }
    # function start : search back for push {..., lr}
    $fs = '?'
    for ($j = $i; $j -ge [Math]::Max(0, $i - 3000); $j--) { if ($l[$j] -match 'push\s+\{.*lr\}') { $fs = ($l[$j] -split ':')[0].Trim(); break } }
    $pinName = $pin; if ($pin -is [int]) { for ($b = 0; $b -lt 16; $b++) { if ($pin -eq (1 -shl $b)) { $pinName = "P$b" } } }
    $out.Add("$fs`t$addr`tP$port $pinName`tval=$val")
}
$out
