param([string]$dir)
$names = @{ '801b4f0'='TRAVEL_Run(X)'; '801c230'='LIFT_Run(Y)'; '801c7b4'='TILT_Run'; '8006c0c'='Reply'; '801fdcc'='Log'; '801fe9c'='Log'; '80017ec'='PourStep'; '8016dac'='LED_On'; '80170b0'='DO_On'; '8017154'='DO_Off'; '80040a8'='LampByState'; '8004200'='Y=card'; '8017074'='Buzzer_On'; '801709c'='Buzzer_Off' }
$starts = @(0x8002748,0x8002850,0x8002D18,0x8002DD4,0x8002E9C,0x8002F8E,0x80033BC,0x8003480,0x8003608,0x80036CC,0x8003754)
$stepOf = @{ 0x8002748=1; 0x8002850=2; 0x8002D18=3; 0x8002DD4=4; 0x8002F8E=5; 0x80033BC=6; 0x8003480=7; 0x8003608=8; 0x80036CC=9; 0x8002E9C=10 }
$sorted = $starts | Sort-Object
for ($k = 0; $k -lt $sorted.Count - 1; $k++) {
    $a = $sorted[$k]; $e = $sorted[$k + 1]
    "===== step $($stepOf[$a])  (0x{0:X8})" -f $a
    $o = & powershell -NoProfile -File "$dir\ann.ps1" -dir $dir -from ('{0:x}' -f $a) -to ('{0:x}' -f $e)
    $prev = @()
    foreach ($x in $o) {
        if ($x -match 'bl 0x([0-9a-f]+)') { $n = $names[$matches[1]]; if (-not $n) { $n = '0x' + $matches[1] }; '   call ' + $n + '   (' + (($prev | Select-Object -Last 3) -join ' | ') + ')' }
        elseif ($x -match '"') { '   str  ' + ($x -replace '^.*; ', '') }
        elseif ($x -match 'adds r3, #(28|29|30|31|32|33|34|35)$') { $fld = $matches[1] }
        elseif ($x -match 'movs r2, #(\d+)') { $v = $matches[1] }
        elseif ($x -match 'strb r2, \[r3, #0\]' -and $fld) { '   set +' + $fld + ' = ' + $v; $fld = $null }
        elseif ($x -match 'cmp r3, #(\d+)') { '   if  == ' + $matches[1] }
        $prev += ($x -replace '^\s*[0-9a-f]+: [0-9a-f ]+ ', '')
    }
}
