param([string]$dir, [string]$tlist)
$targets = $tlist -split ","; $l = Get-Content "$dir\dis.txt"
$bin = [IO.File]::ReadAllBytes("$dir\fw.bin")
function Str([int64]$addr) { $o = $addr - 0x08000000; if ($o -lt 0 -or $o -ge $bin.Length) { return $null }; $s = ''; while ($o -lt $bin.Length -and $bin[$o] -ge 0x20 -and $bin[$o] -le 0x7E -and $s.Length -lt 50) { $s += [char]$bin[$o]; $o++ }; if ($s.Length -ge 4 -and $bin[$o] -eq 0) { return $s }; return $null }
# function starts
$starts = @{}
for ($i = 0; $i -lt $l.Count; $i++) { if ($l[$i] -match 'push\s+\{.*lr\}') { $starts[$i] = ($l[$i] -split ':')[0].Trim() } }
$startIdx = $starts.Keys | Sort-Object
function FuncOf([int]$i) { $best = -1; foreach ($s in $startIdx) { if ($s -le $i) { $best = $s } else { break } }; return $best }
# strings used per function (literal pool loads)
function StringsIn([int]$fi) {
    $res = @()
    for ($j = $fi; $j -lt [Math]::Min($l.Count, $fi + 1500); $j++) {
        if ($j -gt $fi -and $starts.ContainsKey($j)) { break }
        if ($l[$j] -match 'ldr\s+r\d, \[pc, #\d+\]\s+@ \(0x([0-9a-f]+)\)') {
            $o = [Convert]::ToInt64($matches[1], 16) - 0x08000000
            if ($o -ge 0 -and $o + 3 -lt $bin.Length) { $w = [BitConverter]::ToUInt32($bin, [int]$o); $s = Str $w; if ($s) { $res += $s } }
        }
    }
    return ($res | Select-Object -Unique) -join ' | '
}
foreach ($t in $targets) {
    "===== callers of 0x$t"
    for ($i = 0; $i -lt $l.Count; $i++) {
        if ($l[$i] -notmatch ("bl\s+0x" + $t + "\b")) { continue }
        $a0 = '?'; $a1 = '?'
        for ($j = $i - 1; $j -ge [Math]::Max(0, $i - 6); $j--) {
            if ($a0 -eq '?' -and $l[$j] -match 'movs\s+r0, #(\d+)') { $a0 = $matches[1] }
            if ($a1 -eq '?' -and $l[$j] -match '(movs|mov\.w|movw)\s+r1, #(\d+)') { $a1 = $matches[2] }
        }
        $fi = FuncOf $i
        $fname = if ($fi -ge 0) { $starts[$fi] } else { '?' }
        "{0}  in {1}  ch={2} arg={3}" -f (($l[$i] -split ':')[0].Trim()), $fname, $a0, $a1
    }
}
"===== strings per calling function"
$seen = @{}
foreach ($t in $targets) {
    for ($i = 0; $i -lt $l.Count; $i++) {
        if ($l[$i] -notmatch ("bl\s+0x" + $t + "\b")) { continue }
        $fi = FuncOf $i
        if ($fi -lt 0 -or $seen.ContainsKey($fi)) { continue }
        $seen[$fi] = 1
        "{0} : {1}" -f $starts[$fi], (StringsIn $fi)
    }
}

