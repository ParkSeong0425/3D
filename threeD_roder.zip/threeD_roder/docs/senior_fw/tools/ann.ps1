param([string]$dir, [string]$from, [string]$to)
$l = Get-Content "$dir\dis.txt"
$b = [IO.File]::ReadAllBytes("$dir\fw.bin")
function Str([int64]$a) { $o = $a - 0x08000000; if ($o -lt 0 -or $o -ge $b.Length) { return $null }; $s = ''; while ($o -lt $b.Length -and $b[$o] -ge 0x20 -and $b[$o] -le 0x7E -and $s.Length -lt 70) { $s += [char]$b[$o]; $o++ }; if ($s.Length -ge 2 -and $b[$o] -eq 0) { return $s }; return $null }
$f = [Convert]::ToInt64($from, 16); $t = [Convert]::ToInt64($to, 16)
foreach ($line in $l) {
    if ($line -notmatch '^\s*([0-9a-f]+):') { continue }
    $a = [Convert]::ToInt64($matches[1], 16)
    if ($a -lt $f -or $a -ge $t) { continue }
    $x = $line
    if ($line -match '@ \(0x([0-9a-f]+)\)') {
        $la = [Convert]::ToInt64($matches[1], 16) - 0x08000000
        if ($la -ge 0 -and $la + 3 -lt $b.Length) {
            $w = [BitConverter]::ToUInt32($b, [int]$la)
            $s = Str $w
            if ($s) { $x += "   ; `"$s`"" } else { $x += ('   ; =0x{0:X8}' -f $w) }
        }
    }
    $x -replace '\s+', ' '
}
