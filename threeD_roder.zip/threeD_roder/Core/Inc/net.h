/* net.h */
#ifndef INC_NET_H_
#define INC_NET_H_

#include "main.h"

extern volatile int tcp_on;
int NET_Init(void);
void NET_Run(void);
void NET_Send(uint8_t *buf, int len);   /* 2500 으로 보내기 + 서비스 창구에 [RX] 복사 */
#endif /* INC_NET_H_ */
