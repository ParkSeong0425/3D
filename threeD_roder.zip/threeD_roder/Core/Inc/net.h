/* net.h */
#ifndef INC_NET_H_
#define INC_NET_H_

#include "main.h"

extern volatile int tcp_on;
int PC_On(void);                          /* 1 = PC 가 2500 · 58080 · 50001 중 하나라도 연결 (완료응답 cmd.c 만 씀. 램프 · 부저는 tcp_on = 2500 만) */
int NET_Init(void);
void NET_Run(void);
void send_socket(uint8_t *buf, int len);  /* 2500 으로 보내기 + 서비스 58080 에 [RX] 복사 (cmd.c 대답 · 이벤트) */
void send_event(char *text);              /* 이벤트 · 완료응답 : STX + 마지막 PC 번호 + 글자 + ETX → send_socket */
/* 로그 한 줄 쌓기 Log_Debug 는 debug.h (debug.c) 로 옮김 */
#endif /* INC_NET_H_ */
