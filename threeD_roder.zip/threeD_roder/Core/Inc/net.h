/* net.h */
#ifndef INC_NET_H_
#define INC_NET_H_

#include "main.h"

extern volatile int tcp_on;
int NET_Init(void);
void NET_Run(void);
void NET_Send(uint8_t *buf, int len);   /* 2500 으로 보내기 + 서비스 창구에 [RX] 복사 */
int Roder_Number(void);                   /* 다음 일련번호 01 ~ 99 (PC 명령 · 이벤트 같이 이어서) */
void Log_Port(char *text);              /* 로그 창구(50001)로 한 줄 (어느 태스크든) */
#endif /* INC_NET_H_ */
