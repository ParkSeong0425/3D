/* net.h */
#ifndef INC_NET_H_
#define INC_NET_H_

#include "main.h"

extern volatile int tcp_on;
int NET_Init(void);
void NET_Run(void);
#endif /* INC_NET_H_ */
