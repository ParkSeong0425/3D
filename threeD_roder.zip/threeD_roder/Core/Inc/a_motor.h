#ifndef INC_A_MOTOR_H_
#define INC_A_MOTOR_H_

#include "main.h"

#define Y_PULSE            320
#define Y_GEAR             5
#define Y_PI               160


/* Y axis AIMotor */
#define AM_ID               1
#define AM_BAUD             115200
#define AM_MAX_RPM          3000

/* 1구간 절대위치 이동 */
#define AM_ACC_DEC_MS       100
#define AM_WAIT_MS          0
#define AM_DONE_GAP         10

/* Reverse mechanical torque home */
#define AM_HOME_MODE        10      /* 10 : 정방향 , 11 : 역방향  */
#define AM_HOME_HI_RPM      300     /* H05_32 */
#define AM_HOME_LO_RPM      200     /* H05_33 */
#define AM_HOME_ACC_MS      50     /* H05_34 */
#define AM_HOME_TIMEOUT_MS  60000   /* H05_35 */
#define AM_HOME_TORQUE      600    /* H05_58 : 0.1%, 100 = 10.0% */
#define AM_HOME_OFFSET      (-150 * Y_PULSE * Y_GEAR / Y_PI)   /* H05_36 : 원점 후 150mm 빠져나옴 (펄스, Y 는 방향 반대라 -) */

/* 기본 기능 */
int AM_Init(void);
int AM_Move(int32_t mm, int percent);
int AM_Home(void);
int AM_Stop(void);
int AM_EStop(int on);
/* 상태 읽기 */
int AM_Pos(int32_t *mm);
int AM_AlarmRead(uint16_t *alarm);      /* 알람 만들 때 사용 */

/* 보조 기능 */
int AM_AlarmReset(void);

/* 보드레이트 변경 : 드라이브 통신 속도 처음 바꿀 때 한 번 쓰는 도구 */
int AM_BaudInit(void);

#endif /* INC_A_MOTOR_H_ */
