#ifndef INC_A_MOTOR_H_
#define INC_A_MOTOR_H_

#include "main.h"
#include "usart.h"      /* MOTOR (칠판 한 칸) */

#define Y_PULSE            320
#define Y_GEAR             5
#define Y_PI               160


/* Y axis AIMotor */
#define AM_ID               1
#define AM_BAUD             115200
#define AM_MAX_RPM          3000

/* 1구간 절대위치 이동 */
#define AM_ACC_DEC_MS       500
#define AM_WAIT_MS          0
#define AM_DONE_GAP         10

/* Reverse mechanical torque home */
#define AM_HOME_MODE        10      /* 10 : 정방향 , 11 : 역방향  */
#define AM_HOME_HI_RPM      300     /* H05_32 */
#define AM_HOME_LO_RPM      200     /* H05_33 */
#define AM_HOME_ACC_MS      50     /* H05_34 */
#define AM_HOME_TIMEOUT_MS  60000   /* H05_35 */
#define AM_HOME_TORQUE      600    /* H05_58 : [현장] 600 / 사무실 100 */
#define AM_HOME_OFFSET      (-150 * Y_PULSE * Y_GEAR / Y_PI)   /* H05_36 : 원점 후 150mm 빠져나옴 (펄스, Y 는 방향 반대라 -) */

/* 기본 기능 */
int AM_Init(void);
int AM_Move(int32_t mm, int percent);
int AM_Home(void);
int AM_Stop(void);
int AM_Jog(int dir, int percent);       /* 수동 JOG : +1 위 / -1 아래 / 0 멈춤 (DI8 · DI9) */
int AM_EStop(int on);
/* 상태 읽기 */
/* 위치 · 상태 = 칠판 am (아래, Bus_Task 가 40ms 마다 적음). AM_Arrive 는 칠판만 봄 */
int AM_ReadReg(uint16_t reg, int32_t *out, uint8_t qty);   /* (디버그 · CLI YR) Y 레지스터 읽기 : 1 = 16bit, 2 = 32bit */
int AM_Arrive(int y);       /* y(mm) 에 도착할 때까지 기다림 (서는 곳, ±10mm 창. 8초 넘으면 실패 0) */
int AM_Pass(int y);         /* y(mm) 를 지나 위로 올라갈 때까지 기다림 (지나가는 점, "넘었나". 8초 넘으면 실패 0) */
int AM_Read(void);          /* (Bus_Task) Y 위치 0B07 + 고장 코드 0B22 → 칠판 am (한 번씩, MOTOR_WAIT_MS). 받으면 1 */

extern volatile MOTOR am;   /* 칠판 Y (ID 1) : 위치 mm · 고장 코드 H0B_34 · 놓친 횟수 (state 는 안 씀) */

/* 보조 기능 */
int AM_AlarmReset(void);

/* 보드레이트 변경 : 드라이브 통신 속도 처음 바꿀 때 한 번 쓰는 도구 */
int AM_BaudInit(void);

#endif /* INC_A_MOTOR_H_ */
