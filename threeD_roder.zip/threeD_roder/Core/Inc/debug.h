/*
 * debug.h : 로그 50001 — 문장 모음 (로그 문장을 고칠 땐 여기만) + 로그 칸 함수 (debug.c)
 */
#ifndef INC_DEBUG_H_
#define INC_DEBUG_H_

#define LOG_SIZE    512     /* 로그 칸 크기 : 노트북이 없는 동안 이만큼 모아 둠 (넘으면 새 줄 버림) */

/* 로그 한 줄 쌓기 (아무 태스크) : printf 처럼 문장 + 값. 보내기는 net.c log_port (Comm_Task)
   format 표시 : %d · %c 개수와 값 개수가 다르면 빌드 때 경고로 알려 줌 */
void Log_Debug(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
int  Log_Take(char *out);       /* (net.c) 쌓인 로그를 out(LOG_SIZE 칸)에 꺼내고 비움 → 글자 수 */

/* ── 원점 (run.c motor_basic_init) ── */
#define LOG_HOME_START          "HOME  start"
#define LOG_HOME_DONE           "HOME  done"
#define LOG_HOME_FAIL           "HOME  FAIL"
#define LOG_HOME_X_NO_ANSWER    "HOME  X ID 3 no answer -> check DIP / RS485 / power"
#define LOG_HOME_Y_NO_ANSWER    "HOME  Y ID 1 no answer -> check DIP / RS485 / power"
#define LOG_HOME_T_NO_ANSWER    "HOME  Tilt ID 2 no answer -> check DIP / RS485 / power"
#define LOG_HOME_X_FAIL         "HOME  X stopped -> 60s no touch / alarm / E-stop"
#define LOG_HOME_Y_FAIL         "HOME  Y stopped -> 60s no touch / alarm / E-stop"
#define LOG_HOME_T_FAIL         "HOME  Tilt stopped -> 60s no home sensor / alarm / E-stop"

/* ── 이동 시작 (cmd.c CMD_Run MI · MO · PO) : 명령 2글자, 렉, 열, 단 ── */
#define LOG_MOVE                "%c%c  rack %d  Block %d  floor %d  Move"
#define LOG_MOVE_DONE           "%c%c  rack %d  Block %d  floor %d  %s  %lu ms"                   /* Complete / FAIL, 걸린 시간 (run.c Motor_Run) */
#define LOG_MOVE_POS            "    now  X1 %ld  X2 %ld (X1-X2 %ld)  Y %ld  T %ld"               /* 끝난 위치 mm · 도 (X 두 모터 차이 = 틀어짐) */

/* ── 알람 (alarm.c) ── */
#define LOG_A01             "ALARM 01 REASON SOMETHING IS WRONG BY COMMUNICATION"
#define LOG_A02_REASON      "ALARM 02 REASON IS ERROR CHECK THIS BY ICL57-RS DATASHEET"   /* 드라이브가 알람 코드를 보냄 */
#define LOG_A02_REASON_REG   "ALARM 02  X  0x2203 = 0x%04X  %s"        /* 값, 이름 */
#define LOG_A03_REASON       "ALARM 03 REASON IS ERROR CHECK THIS BY AIMMOTOR DATASHEET"
#define LOG_A03_REASON_REG   "ALARM 03  Y  H0B_34 = 0x%04X  %s"        /* 값, 이름 */
#define LOG_A04_REASON       "ALARM 04 REASON IS ERROR CHECK THIS BY TL57_R DATASHEET"
#define LOG_A04_REASON_REG   "ALARM 04  Tilt  PA_005 = 0x%04X  %s"     /* 값, 이름 */
#define LOG_A05              "ALARM 05 REASON IS X CAN NOT MOVE OR SO LATE"
#define LOG_A06              "ALARM 06 REASON IS Y CAN NOT MOVE OR SO LATE"
#define LOG_A07              "ALARM 07 REASON IS T CAN NOT MOVE OR SO LATE"
#define LOG_A09              "ALARM 09  Manager USE Emergency stop NOW"
#define LOG_A10_REASON       "ALARM 10 REASON IS SO FAST TOUCHED BY SOMETHING"
#define LOG_A10              "ALARM 10  HOME FAIL (timeout / no answer) -> RESET then RUN"
#define LOG_A11_X            "ALARM 11  X ID 3 no answer -> check DIP / RS485 / power"       /* 모터 통신 끊김 : 어느 축인지 */
#define LOG_A11_Y            "ALARM 11  Y ID 1 no answer -> check DIP / RS485 / power"
#define LOG_A11_T            "ALARM 11  Tilt ID 2 no answer -> check DIP / RS485 / power"
#define LOG_A12              "ALARM 12  LAN cable unplugged while working"           /* 일하는 중 보드 랜선 빠짐 */
#define LOG_ALARM_CLEAR      "ALARM RESET CLEAR, RODER WILL BE GO HOME"
#define LOG_I_REBOOT         "I : alarm -> drive alarm reset + reboot (home after power on)"   /* cmd.c CMD_I 알람일 때 */

/* ── 이벤트 (일시정지 · 만재 · 카드 · PC 명령) ── */
#define LOG_PAUSE_SET        "PAUSE %c  rack %d  (M stop / F manjae / S card / T tilt, rack 0 = all)"   /* status.c Pause_Set */
#define LOG_MANJAE_FULL     "MANJAE SENSOR FULL OVER 2s"                /* manjae.c Manjae_Timer_2s (알림만, PO 는 run.c PO 정지선이 멈춤) */
#define LOG_CARD_OUT         "SEEDING WALL CARD OUT"                     /* rfid.c Rfid_Check (2초 넘게 없음 알림만, PO 는 run.c PO 정지선이 멈춤) */
#define LOG_RFID_PC          "READER WAS CHECKED BY PC COMMAND \"R\""     /* 문자열 안 큰따옴표는 \" */
#define LOG_CHECK_PC         "RODER WAS CHECKED BY PC COMMAND \"C\""
#define LOG_PAUSE_PC         "RODER WAS STOPPED BY PC COMMAND \"S\""
#define LOG_CLEAR            "EVENT PROBLEM CLEAR, RODER WILL BE DO WORK"


#endif /* INC_DEBUG_H_ */
