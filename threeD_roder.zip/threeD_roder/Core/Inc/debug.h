/*
 * debug.h : 로그 50001 (Log_Debug) 문장 모음 — 로그 문장을 고칠 땐 여기만
 */
#ifndef INC_DEBUG_H_
#define INC_DEBUG_H_

/* ── 원점 (run.c motor_basic_init) ── */
#define LOG_HOME_START          "HOME  start"
#define LOG_HOME_DONE           "HOME  done"
#define LOG_HOME_FAIL           "HOME  FAIL"
#define LOG_HOME_X_NO_ANSWER    "HOME  X drive no answer (setting)"
#define LOG_HOME_Y_NO_ANSWER    "HOME  Y drive no answer (setting)"
#define LOG_HOME_T_NO_ANSWER    "HOME  Tilt drive no answer (setting)"

/* ── 이동 시작 (cmd.c CMD_Run MI · MO · PO) : 명령 2글자, 렉, 열, 단 ── */
#define LOG_MOVE                "%c%c  rack %d  Block %d  floor %d  Move"
#define LOG_MOVE_DONE           "%c%c  rack %d  Block %d  floor %d  %s  %lu ms"                   /* Complete / FAIL, 걸린 시간 (run.c Motor_Run) */
#define LOG_MOVE_POS            "    now  X1 %ld  X2 %ld (X1-X2 %ld)  Y %ld  T %ld"               /* 끝난 위치 mm · 도 (X 두 모터 차이 = 틀어짐) */
#define LOG_MOVE_ERR            "    goal X %ld  Y %ld  ->  error X %ld  Y %ld"                    /* 목표와 오차 mm (+ 지나침 / - 못 감) */

/* ── 알람 (alarm.c) ── */
#define LOG_A01             "ALARM 01 REASON SOMETHING IS WRONG BY COMMUNICATION"
#define LOG_A02_REASON      "ALARM 02 REASON IS ERROR CHECK THIS BY ICL57-RS DATASHEET"   /* 드라이브가 알람 코드를 보냄 */
#define LOG_A02_REASON_REG   "ALARM 02  X  0x2203 = 0x%04X  %s"        /* 값, 이름 */
#define LOG_A03_REASON       "ALARM 03 REASON IS ERROR CHECK THIS BY AIMMOTOR DATASHEET"
#define LOG_A03_REASON_REG   "ALARM 03  Y  H0B_34 = 0x%04X  %s"        /* 값, 이름 */
#define LOG_A04_REASON       "ALARM 04 REASON IS ERROR CHECK THIS BY TL57_R DATASHEET"
#define LOG_A04_REASON_REG   "ALARM 04  Tilt  PA_005 = 0x%04X  %s"     /* 값, 이름 */
#define LOG_A05              "ALARM 05 REASON IS X CAN NOT MOVE OR SO LATE"
#define LOG_A06              "ALARM 06 REASON IS Y CAN NOT MOVE OR SO LATE"
#define LOG_A07              "ALARM 07 REASON IS T CAN NOT MOVE OR SO LATE"
#define LOG_A09              "ALARM 09  Manager USE Emergency stop NOW"
#define LOG_A10_REASON_2     "ALARM 10 REASON IS SO FAST TOUCHED BY SOMETHING"
#define LOG_A11_X            "ALARM 11  X no answer (RS485 line or X drive)"       /* 모터 통신 끊김 : 어느 축인지 */
#define LOG_A11_Y            "ALARM 11  Y no answer (RS485 line or Y drive)"
#define LOG_A11_T            "ALARM 11  Tilt no answer (RS485 line or tilt drive)"
#define LOG_A12              "ALARM 12  LAN cable unplugged while working"           /* 일하는 중 보드 랜선 빠짐 */
#define LOG_ALARM_CLEAR      "ALARM RESET CLEAR, RODER WILL BE GO HOME"

/* ── 이벤트 (일시정지 · 만재 · 카드 · PC 명령) ── */
#define LOG_PAUSE_SET        "PAUSE %c  rack %d  (M stop / F manjae / S card / T tilt, rack 0 = all)"   /* status.c Pause_Set */
#define LOG_MANJAE_FULL     "MANJAE SENSOR FULL OVER 2s"                /* manjae.c Manjae_Timer_2s (알림만, PO 는 run.c PO 정지선이 멈춤) */
#define LOG_CARD_OUT         "SEEDING WALL CARD OUT"                     /* rfid.c Rfid_Check (2초 넘게 없음 알림만, PO 는 run.c PO 정지선이 멈춤) */
#define LOG_RFID_PC          "READER WAS CHECKED BY PC COMMAND \"R\""     /* 문자열 안 큰따옴표는 \" */
#define LOG_CHECK_PC         "RODER WAS CHECKED BY PC COMMAND \"C\""
#define LOG_PAUSE_PC         "RODER WAS STOPPED BY PC COMMAND \"S\""
#define LOG_CLEAR            "EVENT PROBLEM CLEAR, RODER WILL BE DO WORK"


#endif /* INC_DEBUG_H_ */
