/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define FULL_2_1_Pin GPIO_PIN_7
#define FULL_2_1_GPIO_Port GPIOE
#define FULL_2_1_EXTI_IRQn EXTI9_5_IRQn
#define FULL_2_2_Pin GPIO_PIN_8
#define FULL_2_2_GPIO_Port GPIOE
#define FULL_2_2_EXTI_IRQn EXTI9_5_IRQn
#define FULL_2_3_Pin GPIO_PIN_9
#define FULL_2_3_GPIO_Port GPIOE
#define FULL_2_3_EXTI_IRQn EXTI9_5_IRQn
#define FULL_2_4_Pin GPIO_PIN_10
#define FULL_2_4_GPIO_Port GPIOE
#define FULL_2_4_EXTI_IRQn EXTI15_10_IRQn
#define FULL_1_1_Pin GPIO_PIN_11
#define FULL_1_1_GPIO_Port GPIOE
#define FULL_1_2_Pin GPIO_PIN_12
#define FULL_1_2_GPIO_Port GPIOE
#define FULL_1_2_EXTI_IRQn EXTI15_10_IRQn
#define FULL_1_3_Pin GPIO_PIN_13
#define FULL_1_3_GPIO_Port GPIOE
#define FULL_1_3_EXTI_IRQn EXTI15_10_IRQn
#define FULL_1_4_Pin GPIO_PIN_14
#define FULL_1_4_GPIO_Port GPIOE
#define FULL_1_4_EXTI_IRQn EXTI15_10_IRQn
#define ESTOP_Pin GPIO_PIN_11
#define ESTOP_GPIO_Port GPIOD
#define ESTOP_EXTI_IRQn EXTI15_10_IRQn
#define BUZZER_Pin GPIO_PIN_0
#define BUZZER_GPIO_Port GPIOD
#define Y_2_Pin GPIO_PIN_3
#define Y_2_GPIO_Port GPIOD
#define G_2_Pin GPIO_PIN_4
#define G_2_GPIO_Port GPIOD
#define R_2_Pin GPIO_PIN_5
#define R_2_GPIO_Port GPIOD
#define Y_1_Pin GPIO_PIN_7
#define Y_1_GPIO_Port GPIOD
#define G_1_Pin GPIO_PIN_5
#define G_1_GPIO_Port GPIOB
#define R_1_Pin GPIO_PIN_6
#define R_1_GPIO_Port GPIOB
#define W610_RST_Pin GPIO_PIN_0
#define W610_RST_GPIO_Port GPIOE
#define W610_INT_Pin GPIO_PIN_1
#define W610_INT_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
