/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "cmsis_os2.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
/* RTOS 것들 : 진짜는 app_freertos.c (짝 헤더가 없어서 여기서 공개) → main.h 만 include 하면 어디서든 씀 */
extern osThreadId_t Event_TaskHandle;     /* Event_Task  : 긴급정지 · 만재 인터럽트가 깨움 */
extern osThreadId_t Motor_TaskHandle;     /* Motor_Task  : MI · MO · PO · 원점 초인종 */
extern osThreadId_t Comm_TaskHandle;      /* Comm_Task   : W6100 INT 인터럽트가 깨움 (NET_FLAG) */
extern osTimerId_t  Manjae_TimerHandle;   /* 만재 2초 타이머 */
extern osTimerId_t  Rfid_TimerHandle;     /* 카드 0.5초 타이머 */
extern osMutexId_t  Uart2LockHandle;      /* UART2 모터 통신 : 한 번에 한 태스크만 */
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define FULL_2_1_Pin GPIO_PIN_7
#define FULL_2_1_GPIO_Port GPIOE
#define FULL_2_1_EXTI_IRQn EXTI9_5_IRQn
#define FULL_2_2_Pin GPIO_PIN_8
#define FULL_2_2_GPIO_Port GPIOE
#define FULL_2_2_EXTI_IRQn EXTI9_5_IRQn
#define FULL_2_3_Pin GPIO_PIN_9
#define FULL_2_3_GPIO_Port GPIOE
#define FULL_2_3_EXTI_IRQn EXTI9_5_IRQn
#define FULL_2_4_Pin GPIO_PIN_10
#define FULL_2_4_GPIO_Port GPIOE
#define FULL_2_4_EXTI_IRQn EXTI15_10_IRQn
#define FULL_1_1_Pin GPIO_PIN_11
#define FULL_1_1_GPIO_Port GPIOE
#define FULL_1_2_Pin GPIO_PIN_12
#define FULL_1_2_GPIO_Port GPIOE
#define FULL_1_2_EXTI_IRQn EXTI15_10_IRQn
#define FULL_1_3_Pin GPIO_PIN_13
#define FULL_1_3_GPIO_Port GPIOE
#define FULL_1_3_EXTI_IRQn EXTI15_10_IRQn
#define FULL_1_4_Pin GPIO_PIN_14
#define FULL_1_4_GPIO_Port GPIOE
#define FULL_1_4_EXTI_IRQn EXTI15_10_IRQn
#define ESTOP_Pin GPIO_PIN_11
#define ESTOP_GPIO_Port GPIOD
#define ESTOP_EXTI_IRQn EXTI15_10_IRQn
#define BUZZER_Pin GPIO_PIN_0
#define BUZZER_GPIO_Port GPIOD
#define R_2_Pin GPIO_PIN_3
#define R_2_GPIO_Port GPIOD
#define G_2_Pin GPIO_PIN_4
#define G_2_GPIO_Port GPIOD
#define Y_2_Pin GPIO_PIN_5
#define Y_2_GPIO_Port GPIOD
#define R_1_Pin GPIO_PIN_7
#define R_1_GPIO_Port GPIOD
#define G_1_Pin GPIO_PIN_5
#define G_1_GPIO_Port GPIOB
#define Y_1_Pin GPIO_PIN_6
#define Y_1_GPIO_Port GPIOB
#define W610_RST_Pin GPIO_PIN_0
#define W610_RST_GPIO_Port GPIOE
#define W610_INT_Pin GPIO_PIN_1
#define W610_INT_GPIO_Port GPIOE
#define W610_INT_EXTI_IRQn EXTI1_IRQn

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
