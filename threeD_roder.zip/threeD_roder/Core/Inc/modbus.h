/*
 * modbus.h : 모터 글 모양 (Modbus RTU) — 드라이브 종류와 상관없는 규칙만 (ID · 기능 · CRC · 다시 묻기 · 대답 검사)
 *
 *  층 : run.c (무엇을) → i · a · t_motor.c (레지스터 · 단위 · 32비트 순서) → modbus.c (글 모양) → usart.c UART2_Xfer (선)
 *  기다림 숫자는 comm.h 이름으로 받음 (MOTOR_WAIT_MS · X/Y/T_RX_MS)
 *
 *  Created on: Nov 23, 2026
 */
#ifndef INC_MODBUS_H_
#define INC_MODBUS_H_

#include <stdint.h>

uint16_t MB_Crc(const uint8_t *data, uint16_t len);     /* CRC16 (Modbus) : 글 끝 2바이트, 작은 바이트 먼저 */
int MB_Read(uint8_t id, uint16_t reg, uint8_t qty, uint16_t *out, uint8_t tries, uint32_t wait_ms);
                                                        /* FC03 읽기 : reg 부터 qty 칸 → out[0..qty-1] (칸마다 큰 바이트 먼저)
                                                           tries = 묻는 횟수 (Bus_Task 1 · 그 밖 MOTOR_RETRY), wait_ms = 대답 기다림. 받으면 1 */

#endif /* INC_MODBUS_H_ */
