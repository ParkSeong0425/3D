/*
 * event.h
 */
#ifndef INC_EVENT_H_
#define INC_EVENT_H_

extern volatile int estop;
extern volatile int manual;         /* 1 = 수동 모드 (설정 → 수동 버튼) */

void Event_Run(void);
int PO_event(int rack, int dan, int move_done, int sensor_check);   /* PO 상황 : 도착(move_done 1) 만재 · 카드 / 쏟기(sensor_check ms) 틸트. 긴급정지면 0 */

#endif
