/*
 * event.h
 */
#ifndef INC_EVENT_H_
#define INC_EVENT_H_

#define TOUCH_FLAG  0x10    /* 만재 센서 바뀜 → Motor_Task 깨움 (PO 쏟는 동안). Motor_Task 는 0x01 XFER_DONE · 0x08 MOTOR_FLAG 도 씀 */

extern volatile int estop;
extern volatile int manual;         /* 1 = 수동 모드 (설정 → 수동 버튼) */

void Event_Run(void);

#endif
