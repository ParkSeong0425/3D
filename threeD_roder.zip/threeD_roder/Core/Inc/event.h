/*
 * event.h
 */
#ifndef INC_EVENT_H_
#define INC_EVENT_H_


/* 긴급정지 · 수동은 상태 하나로 (status.h state.now == ST_ESTOP · ST_MANUAL, 11/16) */

void Event_Run(void);
void btn_manual(void);              /* 수동 모드 켜기 / 끄기 (HMI 33 · CLI MANUAL) */

#endif
