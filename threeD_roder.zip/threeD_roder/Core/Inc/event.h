/*
 * event.h
 */
#ifndef INC_EVENT_H_
#define INC_EVENT_H_


extern volatile int estop;
extern volatile int manual;         /* 1 = 수동 모드 (설정 → 수동 버튼) */

void Event_Run(void);

#endif
