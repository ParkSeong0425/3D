/*
 * event.h
 */
#ifndef INC_EVENT_H_
#define INC_EVENT_H_


extern volatile int estop;
extern volatile int manual;         /* 1 = 수동 모드 (설정 → 수동 버튼) */
extern int manjae_1;                /* 1 = 렉1 만재 알림 중 (2초 넘게 만재, HMI RUN 까지) */
extern int manjae_2;                /* 1 = 렉2 만재 알림 중 */
extern int card_1;                  /* 1 = 렉1 시딩월 이탈 알림 중 (카드 빠짐, HMI RUN 까지) */
extern int card_2;                  /* 1 = 렉2 시딩월 이탈 알림 중 */

void Event_Run(void);

#endif
