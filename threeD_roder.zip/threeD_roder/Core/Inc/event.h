/*
 * event.h
 */
#ifndef INC_EVENT_H_
#define INC_EVENT_H_

extern volatile int estop;
extern volatile int manual;         /* 1 = 수동 모드 (설정 → 수동 버튼) */

void Event_Run(void);
/* 분배 + 상황 (PC PO 명령이 부름) : 도착 시 만재 · 카드, 쏟은 뒤 틸트 확인 */
int PO_event(int rack, int x, int y, int dan,
             int xy_speed, int tilt_speed,
             int move_delay, int return_delay,
             int tilt_angle, int tilting_y, int tilting_y_speed);

#endif
