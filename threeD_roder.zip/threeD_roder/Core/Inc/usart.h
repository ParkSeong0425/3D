/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern UART_HandleTypeDef huart4;

extern UART_HandleTypeDef huart1;

extern UART_HandleTypeDef huart2;

/* USER CODE BEGIN Private defines */
#define CLI_BUF  64                     /* CLI 글자 보관함 크기 (붙여넣기 64글자까지 안 빠짐) */

/* ── 모터 RS485 (UART2) 통신 숫자 : 통신이 불안하면 여기만 고침 (11/9 전 값) ── */
#define MOTOR_RETRY     3               /* 대답 없거나 틀리면 다시 묻는 횟수 (i · a · t_motor 읽기 · 쓰기) */
#define X_RX_MS         500             /* X (iCL) 대답 기다리는 최대 ms (평소 1~2ms). 대답 없으면 이만큼 × MOTOR_RETRY 버스를 잡음 */
#define Y_RX_MS         50              /* Y (AIM) */
#define T_RX_MS         500             /* 틸트 (TL57) */
#define BUS_GAP_MS      2               /* 모터 글 하나 끝나고 쉬는 ms (열쇠 안에서 → 다른 태스크도 이만큼 뒤에 보냄) */

/* ── Bus_Task (11/17) : 모터 선 한 바퀴마다 4대에게 한 번씩 묻고 칠판에 적음 ── */
#define BUS_MS          40              /* 한 바퀴 ms : 4대 × (보내기 0.7 + 대답 약 2 + 쉬기 2) ≈ 18ms, 남는 시간 = 선 여유 */
#define BUS_RX_MS       5               /* 한 번 묻고 대답 기다리는 최대 ms (보통 2ms). 늦으면 이번엔 건너뛰고 다음 바퀴에 다시 */

/* 칠판 한 칸 = 모터 한 대 (i_motor im1 · im2 / a_motor am / t_motor tm). Bus_Task 만 적고, 다른 곳은 보기만 */
typedef struct {
    int32_t  pos;       /* 위치 : X · Y = mm, 틸트 = 도 */
    uint16_t state;     /* 상태 : X 0x1003 Motion state / Y H0B_05 DO / 틸트 PA_004 */
    uint16_t alarm;     /* 알람 : X 0x2203 / Y H0B_34 / 틸트 PA_005 */
    uint32_t miss;      /* 연속으로 대답 못 받은 바퀴 수 (받으면 0) */
} MOTOR;
/* USER CODE END Private defines */

void MX_UART4_Init(void);
void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);

/* USER CODE BEGIN Prototypes */
int UART2_Xfer(uint8_t *tx, uint16_t tn, uint8_t *rx, uint16_t rn, uint32_t timeout);   /* 모터 : 묻고 대답 받기. 성공 1 / 실패 0 */
int UART2_Send(uint8_t *tx, uint16_t tn);                                               /* 모터 : 보내기만 (브로드캐스트, 대답 없음). 성공 1 / 실패 0 */
void UART4_Start(void);                                                                 /* HMI : 늘 받기 시작 (켤 때 한 번, Event_Task) */
int UART4_Send(uint8_t *tx, uint16_t tn);                                               /* HMI : 보내기만 (인터럽트, 기다리지 않음). 성공 1 / 바쁨 0 */

extern uint8_t cli_buf[];               /* CLI 글자 보관함 (UART1 인터럽트가 넣음 → cli.c CLI_Run 이 꺼냄) */
extern volatile uint8_t cli_head;       /* 보관함에 다음에 넣을 칸 */
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

