/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */
#include "comm.h"                       /* 통신 손잡이 (MOTOR_MS · MOTOR_WAIT_MS · X/Y/T_RX_MS …) */
/* USER CODE END Includes */

extern UART_HandleTypeDef huart4;

extern UART_HandleTypeDef huart1;

extern UART_HandleTypeDef huart2;

/* USER CODE BEGIN Private defines */
#define CLI_BUF  64                     /* CLI 글자 보관함 크기 (붙여넣기 64글자까지 안 빠짐) */

/* ── 모터 RS485 (UART2) 고정값 : Modbus 규칙 (손잡이 아님, 박자 · 기다림 숫자는 comm.h) ── */
#define MOTOR_RETRY     3               /* 대답 없거나 틀리면 다시 묻는 횟수 (i · a · t_motor 쓰기 · 원점 읽기) */
#define BUS_GAP_MS      2               /* 모터 글 하나 끝나고 쉬는 ms (Modbus 1.75ms + 여유, 열쇠 안에서 → 다른 태스크도 이만큼 뒤에 보냄) */
/* Bus_Task 한 바퀴 : 보통 약 23ms / 한 대 늦음 · 죽음 약 71ms / 4대 다 죽음 약 211ms (→ 3바퀴 뒤 A11) */

/* 칠판 한 칸 = 모터 한 대 (i_motor im1 · im2 / a_motor am / t_motor tm). Bus_Task 만 적고, 다른 곳은 보기만 */
typedef struct {
    int32_t  pos;       /* 위치 : X · Y = mm, 틸트 = 도 */
    uint16_t state;     /* 상태 : X 0x1003 Motion state / 틸트 PA_004 (Y 는 안 읽음 : 아무도 안 씀) */
    uint16_t alarm;     /* 알람 : X 0x2203 / Y H0B_34 / 틸트 PA_005 */
    uint32_t miss;      /* 연속으로 대답 못 받은 바퀴 수 (받으면 0) */
} MOTOR;
/* USER CODE END Private defines */

void MX_UART4_Init(void);
void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);

/* USER CODE BEGIN Prototypes */
int UART2_Xfer(uint8_t *tx, uint16_t tn, uint8_t *rx, uint16_t rn, uint32_t timeout);   /* 모터 : 묻고 대답 받기. 성공 1 / 실패 0 */
int UART2_Send(uint8_t *tx, uint16_t tn);                                               /* 모터 : 보내기만 (브로드캐스트, 대답 없음). 성공 1 / 실패 0 */
void UART4_Start(void);                                                                 /* HMI : 늘 받기 시작 (켤 때 한 번, Event_Task) */
int UART4_Send(uint8_t *tx, uint16_t tn);                                               /* HMI : 보내기만 (인터럽트, 기다리지 않음). 성공 1 / 바쁨 0 */

extern uint8_t cli_buf[];               /* CLI 글자 보관함 (UART1 인터럽트가 넣음 → cli.c CLI_Run 이 꺼냄) */
extern volatile uint8_t cli_head;       /* 보관함에 다음에 넣을 칸 */
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

