/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern UART_HandleTypeDef huart4;

extern UART_HandleTypeDef huart1;

extern UART_HandleTypeDef huart2;

/* USER CODE BEGIN Private defines */
#define CLI_BUF  64                     /* CLI 글자 보관함 크기 (붙여넣기 64글자까지 안 빠짐) */
/* USER CODE END Private defines */

void MX_UART4_Init(void);
void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);

/* USER CODE BEGIN Prototypes */
int UART2_Xfer(uint8_t *tx, uint16_t tn, uint8_t *rx, uint16_t rn, uint32_t timeout);   /* 모터 : 묻고 대답 받기. 성공 1 / 실패 0 */
int UART2_Send(uint8_t *tx, uint16_t tn);                                               /* 모터 : 보내기만 (브로드캐스트, 대답 없음). 성공 1 / 실패 0 */
int UART4_Xfer(uint8_t *tx, uint16_t tn, uint8_t *rx, uint16_t rn, uint32_t timeout);   /* HMI : 묻고 대답 받기. 성공 1 / 실패 0 */

extern uint8_t cli_buf[];               /* CLI 글자 보관함 (UART1 인터럽트가 넣음 → cli.c CLI_Run 이 꺼냄) */
extern volatile uint8_t cli_head;       /* 보관함에 다음에 넣을 칸 */
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

