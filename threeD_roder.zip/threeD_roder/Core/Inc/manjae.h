/*
 * manjae.h
 *
 *  Created on: Oct 1, 2026
 *      Author: HWNOT
 */

#ifndef INC_MANJAE_H_
#define INC_MANJAE_H_

#define MANJAE_MS   2000             /* 만재 확정 : 센서가 이만큼 그대로여야 인정 (PPAUSE:F · HMI 작업 칸 · 램프 R · 부저). PC FF 는 바로 */

extern volatile int full_event_on;   /* 1 = 보낼 만재 이벤트 있음 */

int manjae_off(int rack, int dan);   /* 그 렉 그 단 빈칸 : 1 = 빈칸 */
int manjae_on(int rack, int dan);    /* 그 렉 그 단 만재 : 1 = 만재 */
int manjae_change(void);             /* 8칸 중 하나라도 바뀌었으면 1 */
void Manjae_Text(char *b, int size); /* 프로토콜 글자 F_1_0001&F_2_0000 (FF · C 대답) */
void Manjae_PC(void);                /* (Comm_Task) 바뀌었으면 PC 로 FF */

#endif /* INC_MANJAE_H_ */
