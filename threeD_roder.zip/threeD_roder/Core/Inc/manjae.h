/*
 * manjae.h
 *
 *  Created on: Oct 1, 2026
 *      Author: HWNOT
 */

#ifndef INC_MANJAE_H_
#define INC_MANJAE_H_

extern volatile int full_event_on;   /* 1 = 보낼 만재 이벤트 있음 */

/* 만재 : 0 = 빈칸, 1 = 만재 */
extern int full_1_1;    /* 렉1 (오른쪽) 1층 */
extern int full_1_2;
extern int full_1_3;
extern int full_1_4;

extern int full_2_1;    /* 렉2 (왼쪽) 1층 */
extern int full_2_2;
extern int full_2_3;
extern int full_2_4;

extern int full_1;      /* 1 = 렉1 만재 칸 하나라도 */
extern int full_2;      /* 1 = 렉2 만재 칸 하나라도 */

int Full_Read(void);
int floor_full(int rack, int y_no);     /* 그 렉 그 단 만재 : 1 = 만재 */

#endif /* INC_MANJAE_H_ */
