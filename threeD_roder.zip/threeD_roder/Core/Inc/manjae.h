/*
 * manjae.h : 만재 센서 8칸 (변수 · 판단은 manjae.c 한 곳)
 *
 *  Created on: Oct 1, 2026
 *      Author: HWNOT
 */

#ifndef INC_MANJAE_H_
#define INC_MANJAE_H_

#define MANJAE_MS   2000                    /* 만재 확정 : 센서가 이만큼 그대로여야 인정 (PPAUSE:F · HMI · 램프 R · 부저). PC FF 는 바로 */

extern int manjae_1;                        /* 1 = 렉1 만재 알림 중 (2초 넘게 만재) : 읽기만, 지우기는 HMI RUN (event.c btn_run) */
extern int manjae_2;                        /* 1 = 렉2 */

int  manjae_on(int rack, int dan);          /* 지금 만재 1 */
int  manjae_2s(int rack, int dan);          /* 2초 그대로였던 만재 1 (스침 X) */
void manjae_change(void);                   /* (Event_Task) 바뀌면 FF 쪽지 + 2초 타이머 */
void Manjae_Timer_2s(void);                 /* (타이머) 2초 확정 → 렉 알림 · 로그 · 부저 */
void Manjae_check_text(char *b, int size);  /* 프로토콜 글자 F_1_0001&F_2_0000 (C 대답 · FF) */
void Manjae_event_text(void);               /* (Comm_Task) 바뀌었으면 PC 로 FF */

#endif /* INC_MANJAE_H_ */
