/*
 * manjae.h
 *
 *  Created on: Oct 1, 2026
 *      Author: HWNOT
 */

#ifndef INC_MANJAE_H_
#define INC_MANJAE_H_

extern volatile int full_event_on;   /* 1 = 보낼 만재 이벤트 있음 */

int manjae_off(int rack, int dan);   /* 그 렉 그 단 빈칸 : 1 = 빈칸 */
int manjae_on(int rack, int dan);    /* 그 렉 그 단 만재 : 1 = 만재 */
int manjae_change(void);             /* 8칸 중 하나라도 바뀌었으면 1 */

#endif /* INC_MANJAE_H_ */
