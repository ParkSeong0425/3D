/*
 * comm.h : 통신 손잡이 — 통신 시간은 여기 숫자만 고치면 됨 (쓰는 곳은 이름으로 따라옴, 다시 빌드 · 올리기)
 *
 *  모든 선 = 박자 _MS (몇 ms 마다 묻나) · 기다림 _WAIT_MS (대답 최대) · 놓침 _MISS (몇 번 연속 못 받으면 알람)
 *  알람 시간 = 박자 × 놓침
 *
 *  여기 없는 것 : 통신 속도 115200 = ioc (CubeMX) / PC 끊기 시간 = FI 7 (FRAM, PC 명령)
 *                 Modbus 고정값 MOTOR_RETRY · BUS_GAP_MS = usart.h / 이동 · 원점 알람 MOVE_MS · HOME_FAST_MS = alarm 쪽
 *  ESP 짝       : ESP hmi.h TOUCH_ERR_MS = HMI_MS × 5 쯤 (ESP 는 따로 빌드 → 같이 고쳐 올림)
 *
 *  Created on: Nov 23, 2026
 */
#ifndef INC_COMM_H_
#define INC_COMM_H_

/* ── 모터 (RS485 UART2 · Modbus) : Bus_Task ── */
#define MOTOR_MS          40     /* 4대 읽기 한 바퀴 (Bus_Task osDelayUntil). 4대 × 4.5ms ≈ 19ms → 2배 이상으로 */
#define MOTOR_WAIT_MS     50     /* 읽기 대답 기다림 (보통 2ms 에 옴). 짧으면 늦은 대답이 다음 글과 부딪힘 (11/17 : 5 → 50) */
#define MOTOR_MISS        3      /* × MOTOR_MS = 120ms 대답 없음 → 그 축 A05 ~ 07 / 4대 다 A11 */
/* 쓰기 · 원점 읽기 기다림 (× MOTOR_RETRY 3번) : modbus 정리 때 MOTOR_WAIT_MS 하나로 합침 */
#define X_RX_MS           500    /* X (iCL) */
#define Y_RX_MS           50     /* Y (AIM) */
#define T_RX_MS           500    /* 틸트 (TL57) */

/* ── 화면 (RS485 UART4 · ESP) : Event_Task ── */
#define HMI_MS            20     /* 물음 = Event_Task 한 바퀴. X JOG 는 50ms 안에 다시 써야 계속 감 → 50 보다 작게 */
#define HMI_MISS          3      /* × HMI_MS = 60ms 대답 없음 → A01 */
#define HMI_BOOT_MS       3000   /* 켠 뒤 이 시간은 A01 안 봄 (ESP 켜지는 중) */

/* ── PC (이더넷 W6100) : Comm_Task ── */
#define NET_MS            100    /* 랜선 · FI 7 확인 주기, 빠지면 A12 */
#define MOVE_DONE_MS      1000   /* 완료응답 다시 보내기 (ANS_1 : PC 승인까지) */

/* ── 카드 리더 (CAN) : Rfid_Timer ── */
#define CARD_MS    500    /* 'C' 묻기. SENSOR_MS 보다 작게 (SENSOR_MS ÷ 이것 = 없음 횟수) */

/* ── 확정 (센서 · 카드 공통) ── */
#define SENSOR_MS         2000   /* 만재 · 카드 없음 : 이만큼 계속돼야 인정 (스침 막기). PC FF · UT/UU 는 바로 */

#endif /* INC_COMM_H_ */
