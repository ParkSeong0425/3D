/*
 * fram.h
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#ifndef INC_FRAM_H_
#define INC_FRAM_H_

#include "main.h"

int FRAM_Save(void);
int FRAM_Read(void);

#endif
