/*
 * fram.h
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#ifndef INC_FRAM_H_
#define INC_FRAM_H_

#include "main.h"

int FRAM_Write(uint16_t addr, void *data, int size);   /* addr 번지부터 size 바이트 쓰기 */
int FRAM_Read(uint16_t addr, void *data, int size);    /* addr 번지부터 size 바이트 읽기 */

#endif
