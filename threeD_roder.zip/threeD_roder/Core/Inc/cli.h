/*
 * cli.h
 *
 *  Created on: Sep 11, 2026
 *      Author: HWNOT
 */

#ifndef INC_CLI_H_
#define INC_CLI_H_

#include <stdint.h>

void CLI_Run(void);     /* (Comm_Task) UART1 CLI 한 줄 받아 실행 */

#endif /* INC_CLI_H_ */
