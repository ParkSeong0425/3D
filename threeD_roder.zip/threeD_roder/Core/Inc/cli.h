/*
 * cli.h
 *
 *  Created on: Sep 11, 2026
 *      Author: HWNOT
 */

#ifndef INC_CLI_H_
#define INC_CLI_H_

#include <stdint.h>

void CLI_Run(void);     /* (Comm_Task) UART1 CLI 한 줄 받아 실행 */
void CLI_Note(const char *text);   /* (아무 태스크) CLI 에 보여 줄 한 줄 쌓기 : 원점 결과 · 통신 실패 → CLI_Run 이 출력 */

#endif /* INC_CLI_H_ */
