/*
 * status.h : 기계 상태 (FSM, 11/16) — 로봇은 한 대 → 상태도 하나. 지금 무슨 상황인지 state.now 글자 하나만 보면 됨
 *
 *   state.now 글자
 *    'I' 초기상태   켠 직후 · RESET 뒤               → 시작 누르면 'H'
 *    'H' 원점중     원점 가는 중                      → 끝나면 'W' / 못 가면 'A' (알람 10)
 *    'W' 대기       서 있음                           → PC MI · MO · PO 오면 'R'
 *    'R' 운전       MI · MO · PO 하는 중              → 끝나면 'W' (AI · EO 는 PC 승인 때, AO 는 'R' 그대로)
 *    'S' 멈춤       시작 기다림 (why = 이유)          → 시작 누르면 전 상태 (prev)
 *    'M' 수동       JOG (대기 · 초기상태에서만)        → 수동 버튼 누르면 전 상태 (prev)
 *    'E' 긴급정지   버튼 눌림                          → 풀면 'A'
 *    'A' 알람       알람 01 ~ 12                       → RESET 하면 'I'
 *
 *   어디서 바뀌는지는 status.c 맨 위 표
 */
#ifndef INC_STATUS_H_
#define INC_STATUS_H_

/* 상태 한 묶음 (전엔 status · pause_why · pause_rack · run_rack · estop · manual · alarm_no 7개 변수) */
typedef struct {
    char now;       /* 지금 상태 글자 (위 표) */
    char prev;      /* 멈춤 'S' · 수동 'M' 전 상태 : 풀면 여기로 돌아감 */
    char why;       /* 멈춘 이유 ('S' 일 때) : 'M' 일시정지 · 'F' 만재 · 'T' 틸트 · 'S' 시딩월(카드 없음) */
    int  rack;      /* 운전 중인 렉 (멈춤이면 멈춘 렉. 이유 'M' 은 모든 렉) */
    int  alarm;     /* 알람 번호 01 ~ 12 (0 = 없음) */
} STATE;

extern volatile STATE state;

int  Motor_Stop(void);                   /* 문 2 : 1 = 모터 움직이면 안 됨 (긴급정지 'E' · 알람 'A'). 모터 움직임 함수 맨 앞 */
void Pause_Set(int rack, char why);      /* 멈춤 걸기 (운전 · 대기에서) : 'S' + 이유 + PC PPAUSE + 부저 + 로그 (렉 0 = 모두) */
void Pause_Clear(void);                  /* 멈춤 풀기 : 전 상태로 + 부저 끔 + 로그 → 정지선에서 이어서 */
void Status_Text(char *b, int size);     /* PC C 대답 글자 S_1_W&S_2_R… */
void Status_PC(void);                    /* (Comm_Task) 멈췄으면 PC 로 PPAUSE: 이유 */
#endif
