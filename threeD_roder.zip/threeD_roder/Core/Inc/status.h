/*
 * status.h : 기계 작업 상태
 */
#ifndef INC_STATUS_H_
#define INC_STATUS_H_


#define WAIT      'W'      /* 대기 */
#define RUN       'R'      /* 운전 */
#define HOME      'I'      /* 원점복귀 */
#define PAUSE     'P'      /* 일시정지 */
#define ALARM     'A'      /* 알람 */
#define RESTART   'N'      /* 초기상태 : RESET 후 RUN(원점) 기다림 */

/* 만재 / 카드는 상태가 아님 : manjae_on(rack, dan) (manjae.h) / card_ok_1, card_ok_2 (rfid.h) */

extern char status_1;   /* 렉1 상태 (렉 수 = FS rack_channel, 최대 4) */
extern char status_2;   /* 렉2 상태 */
extern char status_3;   /* 렉3 상태 */
extern char status_4;   /* 렉4 상태 */

/* 일시정지 이유 : M = STOP 버튼/S 명령, F = 만재, S = 카드 없음 */
extern volatile char pause_why;
extern volatile int pause_event_on;  /* 1 = 보낼 일시정지 이벤트 있음 */

void Status_WAIT(int rack);
void Status_RUN(int rack);
void Status_HOME(void);
void Status_PAUSE(int rack, char why);   /* 일시정지 + 이유 + PC 알림 (알람이면 안 바꿈) */
void Status_Resume(void);
void Status_Alarm(void);
void Status_INIT(void);
void Status_Text(char *b, int size);     /* 프로토콜 글자 S_1_W&S_2_A_03… (C 대답) */
void Status_PC(void);                    /* (Comm_Task) 일시정지 걸렸으면 PC 로 PPAUSE:이유 */
#endif
