/*
 * status.h : 기계 상태 (로봇은 한 대 → 상태도 하나)
 */
#ifndef INC_STATUS_H_
#define INC_STATUS_H_


#define WAIT      'W'      /* 대기 */
#define RUN       'R'      /* 운전 */
#define HOME      'I'      /* 초기화 : 켤 때 · RESET 뒤 (원점 기다림) · 원점 중 → 원점 끝나면 W (프로토콜 I) */
#define PAUSE     'P'      /* 일시정지 (PC C 대답 글자에만 씀. 일시정지 중인지는 pause_why 로 봄) */
#define ALARM     'A'      /* 알람 */

/* 만재 / 카드는 상태가 아님 : manjae_on(rack, dan) (manjae.h) / card_on(rack) (rfid.h) */

extern volatile char status;        /* 기계 상태 : I 원점 · W 대기 · R 운전 · A 알람 */
extern volatile int  run_rack;      /* 운전(R) 중인 렉 : PC C 대답에서 이 렉만 R, 나머지 렉은 W */
extern volatile char pause_why;     /* 일시정지 이유 : M = STOP 버튼 · S 명령, F = 만재, S = 카드 없음, T = 틸트 / 0 = 일시정지 아님 */
extern volatile int  pause_rack;    /* 일시정지 렉 : 1 ~ 4 / 0 = 모두 */

void Pause_Set(int rack, char why);      /* 일시정지 걸기 : 이유 + PC PPAUSE + 부저 + 로그 (렉 0 = 모두) */
void Pause_Clear(void);                  /* 일시정지 풀기 : 부저 끔 + 로그 → 정지선에서 이어서 */
void Status_Text(char *b, int size);     /* PC C 대답 글자 S_1_W&S_2_R… */
void Status_PC(void);                    /* (Comm_Task) 일시정지 걸렸으면 PC 로 PPAUSE: 이유 */
#endif
