/*
 * dwt.h : CPU 안의 스톱워치 (µs 측정용)
 * 클럭마다 1씩 올라감 → 170MHz면 1µs = 170
 * 사용처 : usart.c 의 uart2_us (통신 1번 시간). 최적화 끝나면 지워도 됨
 */
#ifndef INC_DWT_H_
#define INC_DWT_H_

#include "main.h"

/* 켜기 : 부팅 때 1번 */
static inline void DWT_Init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

/* 지금 카운트 */
static inline uint32_t DWT_Now(void)
{
    return DWT->CYCCNT;
}

/* start 부터 지난 µs */
static inline uint32_t DWT_Us(uint32_t start)
{
    return (DWT->CYCCNT - start) / (SystemCoreClock / 1000000);
}

#endif /* INC_DWT_H_ */
