/*
 * buzzer.h : 부저 켜기 / 끄기
 */
#ifndef INC_BUZZER_H_
#define INC_BUZZER_H_

void Buzzer_On(void);       /* 부저 켬 */
void Buzzer_Off(void);      /* 부저 끔 */
int  Buzzer_Cmd(char *s);   /* PC 부저 명령 B_채널_값@B_채널_값… (채널 1~8) : 맞으면 1 / 틀리면 0 (cmd.c 가 부름) */

#endif /* INC_BUZZER_H_ */
