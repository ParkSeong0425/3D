/*
 * buzzer.h : 부저 켜기 / 끄기
 */
#ifndef INC_BUZZER_H_
#define INC_BUZZER_H_

void Buzzer_On(void);       /* 부저 켬 */
void Buzzer_Off(void);      /* 부저 끔 */

#endif /* INC_BUZZER_H_ */
