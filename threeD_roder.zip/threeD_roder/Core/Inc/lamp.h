/*
 * lamp.h
 */
#ifndef INC_LAMP_H_
#define INC_LAMP_H_

#include "main.h"

#define LAMP_OFF    0
#define LAMP_ON     1

/* 긴급정지 / 알람 / 일시정지 : R 만 빠르게 깜박 (앞에서 정한 R 을 덮어씀) */
void lamp_alarm(void);

/* 원점 : 6개 전부 느리게 깜박 (맨 끝, 전부 덮어씀) */
void lamp_home(void);

/* 만재 : 알림 중인 렉의 R 느리게 깜빡 (1 = 알림 중) */
void lamp_manjae(int rack1, int rack2);

/* PC 램프 명령 글자 LL_렉_램프_모드시간&… 풀어서 저장 : 맞으면 1 / 틀리면 0 (cmd.c 가 부름) */
int Lamp_Cmd(char *s);

/* PC 램프 기억 전부 지우기 (net.c : PC 접속 순간) */
void Lamp_Clear(void);

/* 평소 : PC 연결 = 6개 전부 PC 가 정한 대로 / 안 연결 = R · G 끔, Y 는 2초 뒤 카드 */
void lamp_tcp(void);

#endif
