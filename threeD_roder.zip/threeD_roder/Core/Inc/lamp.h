/*
 * lamp.h
 */
#ifndef INC_LAMP_H_
#define INC_LAMP_H_

#include "main.h"

#define LAMP_OFF    0
#define LAMP_ON     1
#define LAMP_BLINK  2

/* 램프 하나 : LAMP_ON = 켬, LAMP_OFF = 끔 */
void Lamp_R1(int on);
void Lamp_Y1(int on);
void Lamp_G1(int on);
void Lamp_R2(int on);
void Lamp_Y2(int on);
void Lamp_G2(int on);

/* 긴급정지 / 알람 / 일시정지 : R 만 빠르게 깜박 (앞에서 정한 R 을 덮어씀) */
void lamp_alarm(void);

/* 원점 : 6개 전부 느리게 깜박 (맨 끝, 전부 덮어씀) */
void lamp_home(void);

/* 카드 : Y 담당 / 있으면 Y 켬, 없으면 끔 */
void lamp_rfid(void);

/* 만재 / 카드 없음 : R 깜빡 (만재 센서 바뀐 지 2초 안이면 안 건드림) */
void lamp_manjae(void);

/* PC 램프 명령 : 렉 1~2, 색 1 적 / 2 녹 / 3 황, 모드 0 끔 / 1 켬 / 2 깜빡, 시간 초 (0 = 계속) */
void Lamp_Tcp(int rack, int color, int mode, int sec);

/* PC 램프 명령 글자 LL_렉_램프_모드시간&… 풀어서 Lamp_Tcp : 맞으면 1 / 틀리면 0 (cmd.c 가 부름) */
int Lamp_Cmd(char *s);

/* 평소 : PC 연결 = 6개 전부 PC 가 정한 대로 / 안 연결 = R · G 끔, Y 는 2초 뒤 카드 */
void lamp_tcp(void);

#endif
