/*
 * t_motor.h
 *
 *  Created on: Sep 11, 2026
 *      Author: HWNOT
 */
#ifndef INC_T_MOTOR_H_
#define INC_T_MOTOR_H_

#include "main.h"

/* TL57-R : UART2 RS485 */
#define TM_BAUD          115200
#define TM_MAX_RPM       3000

/* 각도 변환 : 1000 pulse/rev, 웜기어 20:1 */
#define TM_PULSE           1000
#define TM_GEAR            20
#define TM_START_RPM       0
#define TM_ACC_MS          200
#define TM_DEC_MS          200

/* HOME */
#define TM_HOME_MODE     24
#define TM_HOME_RPM      50
#define TM_CREEP_RPM     30

/* PA_004 Run state */
#define TM_DONE          (1 << 0)
#define TM_HOMED         (1 << 1)
#define TM_RUN           (1 << 2)
#define TM_FAULT         (1 << 3)
#define TM_ENABLE        (1 << 4)

/* 기본 기능 */
int TM_Init(void);
int TM_Move(int32_t deg, int percent);
int TM_C(int percent);
int TM_R(int32_t deg, int percent);
int TM_L(int32_t deg, int percent);
int TM_Done(void);
int TM_Home(void);
int TM_Stop(void);
int TM_AlarmReset(void);

/* 상태 읽기 */
void TM_State(uint16_t *state);
int TM_Alarm(uint16_t *code);           /* 드라이브 알람 PA_005 : 0x01 과전류 0x02 과전압 0x03 저전압 */
int TM_Pos(int32_t *deg);
int TM_Arrive(int deg);     /* deg(도) 에 도착 + 멈췄나 (한 번 보고 1 / 0) */


#endif /* INC_T_MOTOR_H_ */
