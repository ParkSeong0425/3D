/*
 * t_motor.h
 *
 *  Created on: Sep 11, 2026
 *      Author: HWNOT
 */
#ifndef INC_T_MOTOR_H_
#define INC_T_MOTOR_H_

#include "main.h"
#include "usart.h"      /* MOTOR (칠판 한 칸) */

/* TL57-R : UART2 RS485 */
#define TM_MAX_RPM       3000

/* 각도 변환 : 1000 pulse/rev, 웜기어 20:1 */
#define TM_PULSE           1000
#define TM_GEAR            20
#define TM_START_RPM       0
#define TM_ACC_MS          300     /* 가감속 같이 */

/* HOME */
#define TM_HOME_MODE     24
#define TM_HOME_RPM      50
#define TM_CREEP_RPM     30

/* PA_004 Run state */
#define TM_DONE          (1 << 0)
#define TM_HOMED         (1 << 1)
#define TM_RUN           (1 << 2)
#define TM_FAULT         (1 << 3)
#define TM_ENABLE        (1 << 4)

/* 기본 기능 */
int TM_Init(void);
int TM_Move(int32_t deg, int percent);
int TM_C(int percent);
int TM_R(int32_t deg, int percent);
int TM_L(int32_t deg, int percent);
int TM_Home(void);
int TM_Stop(void);
int TM_Jog(int dir, int percent);       /* 수동 JOG : +1 왼쪽 / -1 오른쪽 (멈춤은 TM_Stop) */
int TM_AlarmReset(void);

/* 상태 읽기 */
int TM_ReadReg(uint16_t reg, uint16_t *out, uint8_t qty);   /* (디버그 · CLI) 틸트 레지스터 읽기 : qty 1 = 16bit / 2 = 32bit */
/* 위치 · 상태 = 칠판 tm (아래, Bus_Task 가 40ms 마다 적음). TM_Arrive 는 칠판만 봄 */
int TM_Arrive(int deg);     /* deg(도) 에 도착 + 멈출 때까지 기다림 (10초 넘으면 알람, 도착 1 / 실패 0) */
int TM_Read(void);          /* (Bus_Task) 틸트 6칸 → 칠판 tm (한 번만, BUS_RX_MS). 받으면 1 */

extern volatile MOTOR tm;   /* 칠판 틸트 (ID 2) : 위치 도 · 상태 · 알람 · 놓친 횟수 */


#endif /* INC_T_MOTOR_H_ */
