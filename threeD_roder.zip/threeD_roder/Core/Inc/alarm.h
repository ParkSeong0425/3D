/*
 * alarm.h
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */

#ifndef INC_ALARM_H_
#define INC_ALARM_H_

#include <stdint.h>

#define MOVE_MS     10000   /* 이동 최대 기다림 ms : *_Arrive 가 이만큼 기다리고, 못 가면 A_05 ~ 07 */

extern int alarm_1;                     /* 렉1 알람 번호 : 0 = 없음 */
extern int alarm_2;                     /* 렉2 알람 번호 */
extern int alarm_3;                     /* 렉3 알람 번호 */
extern int alarm_4;                     /* 렉4 알람 번호 */
extern volatile int alarm_event_on;     /* 1 = 보낼 알람 이벤트 있음 */

/* 알람 : 걸면 세우기(E_S) + 상태 A + 번호 + PC 로 S_1_A_09 (렉 수만큼) + 부저. 조건 · 숫자는 alarm.c */
void A_01(int button);                      /* HMI 통신 : HMI_Run 결과로 20번 연속 실패면 */
int  A_02(void);                            /* X 모터 : 두 모터 드라이브 알람(0x2203) 있음 (대답 없음은 11). 걸면 1 */
int  A_03(void);                            /* Y 모터 : 고장 코드(H0B_34) 있음 (ER.950 · 952 · 601 빼고, 대답 없음은 11). 걸면 1 */
int  A_04(void);                            /* 틸트 모터 : 드라이브 알람(PA_005) 있음 (대답 없음은 11). 걸면 1 */
int  A_05(int x);                           /* X 위치 : *_Arrive 로 기다린 뒤 X 가 x 에 없으면 알람. 걸면 1 */
int  A_06(int y);                           /* Y 위치 */
int  A_07(int deg);                         /* 틸트 위치 (각도 + 멈춤) */
void A_08(int rack);                        /* 안전센서 (센서 없음) */
void A_09(int rack);                        /* 비상정지 */
int  A_10(int32_t far, uint32_t start);     /* 원점 : 200mm 넘게 떨어져 있었는데 2초 안에 닿음. 걸면 1 */
int  A_11(char *log);                       /* 모터 통신 끊김 (드라이브 대답 없음, log = 축 문장). 걸면 1 */
void A_12(void);                            /* 일하는 중 보드 랜선 빠짐 (PC 로는 안 보냄) */

void Alarm_Clear(void); /* 알람 번호 지움 (상태는 RESET 이 초기상태로) */

#endif /* INC_ALARM_H_ */
