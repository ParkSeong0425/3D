/*
 * alarm.h
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */

#ifndef INC_ALARM_H_
#define INC_ALARM_H_

#include <stdint.h>

extern int alarm_1;                     /* 렉1 알람 번호 : 0 = 없음 */
extern int alarm_2;                     /* 렉2 알람 번호 */
extern int alarm_3;                     /* 렉3 알람 번호 */
extern int alarm_4;                     /* 렉4 알람 번호 */
extern volatile int alarm_event_on;     /* 1 = 보낼 알람 이벤트 있음 */

/* 알람 : 걸면 세우기(E_S) + 상태 A + 번호 + PC 로 S_1_A_09 (렉 수만큼) + 부저. 조건 · 숫자는 alarm.c */
void A_01(int button);                      /* HMI 통신 : HMI_Run 결과로 20번 연속 실패면 */
void A_02(int rack);                        /* X 모터 (드라이브 알람 : 내일) */
void A_03(int rack);                        /* Y 모터 */
void A_04(int rack);                        /* 틸트 모터 */
int  A_05(uint32_t start, int arrived);     /* X 위치 : 출발 10초 안에 도착 못 함. 걸면 1 */
int  A_06(uint32_t start, int arrived);     /* Y 위치 */
int  A_07(uint32_t start, int arrived);     /* 틸트 위치 */
void A_08(int rack);                        /* 안전센서 (센서 없음) */
void A_09(int rack);                        /* 비상정지 */
int  A_10(int32_t far, uint32_t start);     /* 원점 : 200mm 넘게 떨어져 있었는데 2초 안에 닿음. 걸면 1 */

void Alarm_Clear(void); /* 알람 번호 지움 (상태는 RESET 이 초기상태로) */

#endif /* INC_ALARM_H_ */
