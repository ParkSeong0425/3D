/*
 * alarm.h
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */

#ifndef INC_ALARM_H_
#define INC_ALARM_H_

#include <stdint.h>

#define MOVE_MS     8000   /* 이동 최대 기다림 ms : *_Arrive 가 이만큼 기다리고, 못 가면 A_05 ~ 07 */
#define ARRIVE_MS   20     /* 원점 안에서 직접 묻는 사이 쉬는 ms (도착 확인 Arrive · Pass 는 칠판 초인종 BOARD_NEW 로 기다림, 11/23) */
/* 대답 없음 알람 횟수 MOTOR_MISS · HMI_MISS 는 comm.h (11/23) */

/* 알람 번호 = status.h state.alarm (0 = 없음) */

/* 알람 : 걸면 세우기(E_S) + 상태 A + 번호 + PC 로 S_1_A_09 (렉 수만큼) + 부저. 조건 · 숫자는 alarm.c */
void A_01(void);                            /* HMI 통신 : ESP 가 연달아 3번 대답 안 하면 */
int  A_02(void);                            /* X 모터 : 칠판 im1 · im2 드라이브 알람(0x2203) 있음. 걸면 1 */
int  A_03(void);                            /* Y 모터 : 칠판 am 고장 코드(H0B_34) 있음 (ER.950 · 952 · 601 빼고). 걸면 1 */
int  A_04(void);                            /* 틸트 모터 : 칠판 tm 드라이브 알람(PA_005) 있음. 걸면 1 */
int  A_05(int arrived);                     /* X 위치 : A_05(IM_Arrive(x)) — 도착 못 함(0)이면 알람 → 그 자리에서 멈춤. 걸면 1 */
int  A_06(int arrived);                     /* Y 위치 : A_06(AM_Arrive(y)) */
int  A_07(int arrived);                     /* 틸트 위치 : A_07(TM_Arrive(deg)) */
void A_09(void);                            /* 비상정지 */
int  A_10(int32_t far, uint32_t start);     /* 원점 : ① (far, start) 2초 안에 닿음 = 걸림 / ② (0, 0) 원점 실패. 걸면 1 */
void A_12(void);                            /* 일하는 중 보드 랜선 빠짐 (PC 로는 안 보냄) */

void Alarm_Drive(void); /* (Bus_Task 40ms) 칠판 보고 : 대답 없음 11 (4대 다) · 05 ~ 07 (한 대) · X 차이 05 · 드라이브 알람 02 ~ 04 */
void Alarm_Clear(void); /* RESET : 수동 끔 · 드라이브 알람 리셋 · 번호 지움 · 초기화(I) · 부저 끔 */
void Alarm_PC(void);    /* (Comm_Task) 알람 걸렸으면 PC 로 S_1_A_09&… */

#endif /* INC_ALARM_H_ */
