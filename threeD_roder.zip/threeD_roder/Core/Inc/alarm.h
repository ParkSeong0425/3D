/*
 * alarm.h
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */

#ifndef INC_ALARM_H_
#define INC_ALARM_H_

#include <stdint.h>

#define MOVE_MS     8000   /* 이동 최대 기다림 ms : *_Arrive 가 이만큼 기다리고, 못 가면 A_05 ~ 07 */
#define ARRIVE_MS   20     /* *_Arrive 위치 묻는 사이 쉬는 ms : 이동 중 RS485 버스 약 30% 만 씀 (도착 아는 건 최대 20ms 늦음) */

extern int alarm_1;                     /* 렉1 알람 번호 : 0 = 없음 */
extern int alarm_2;                     /* 렉2 알람 번호 */
extern int alarm_3;                     /* 렉3 알람 번호 */
extern int alarm_4;                     /* 렉4 알람 번호 */

/* 알람 : 걸면 세우기(E_S) + 상태 A + 번호 + PC 로 S_1_A_09 (렉 수만큼) + 부저. 조건 · 숫자는 alarm.c */
void A_01(int button);                      /* HMI 통신 : HMI_Run 결과로 20번 연속 실패면 */
int  A_02(void);                            /* X 모터 : 두 모터 드라이브 알람(0x2203) 있음 (대답 없음은 11). 걸면 1 */
int  A_03(void);                            /* Y 모터 : 고장 코드(H0B_34) 있음 (ER.950 · 952 · 601 빼고, 대답 없음은 11). 걸면 1 */
int  A_04(void);                            /* 틸트 모터 : 드라이브 알람(PA_005) 있음 (대답 없음은 11). 걸면 1 */
int  A_05(int arrived);                     /* X 위치 : A_05(IM_Arrive(x)) — 도착 못 함(0)이면 알람 → 그 자리에서 멈춤. 걸면 1 */
int  A_06(int arrived);                     /* Y 위치 : A_06(AM_Arrive(y)) */
int  A_07(int arrived);                     /* 틸트 위치 : A_07(TM_Arrive(deg)) */
void A_09(int rack);                        /* 비상정지 */
int  A_10(int32_t far, uint32_t start);     /* 원점 : 200mm 넘게 떨어져 있었는데 2초 안에 닿음. 걸면 1 */
int  A_11(char *log);                       /* 모터 통신 끊김 (드라이브 대답 없음, log = 축 문장). 걸면 1 */
void A_12(void);                            /* 일하는 중 보드 랜선 빠짐 (PC 로는 안 보냄) */

void Alarm_Clear(void); /* 알람 번호 지움 (상태는 RESET 이 초기상태로) */
void Alarm_PC(void);    /* (Comm_Task) 알람 걸렸으면 PC 로 S_1_A_09&… */

#endif /* INC_ALARM_H_ */
