/*
 * alarm.h
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */

#ifndef INC_ALARM_H_
#define INC_ALARM_H_

extern int alarm_1;                     /* 렉1 알람 번호 : 0 = 없음 */
extern int alarm_2;                     /* 렉2 알람 번호 */
extern int alarm_3;                     /* 렉3 알람 번호 */
extern int alarm_4;                     /* 렉4 알람 번호 */
extern volatile int alarm_event_on;     /* 1 = 보낼 알람 이벤트 있음 */

/* 알람 걸기 : 렉 1 ~ 4 / 0 = 모두 → 상태 A + 번호 + PC 로 S_1_A_09 (렉 수만큼) */
void A_01(int rack);    /* HMI 통신 : 끊김, 버튼이 안 먹음, 통신 꼬임 */
void A_02(int rack);    /* X 모터 (데이터시트 보고 정할 것) */
void A_03(int rack);    /* Y 모터 (데이터시트 보고 정할 것) */
void A_04(int rack);    /* 틸트 모터 (데이터시트 보고 정할 것) */
void A_05(int rack);    /* X 위치 : 시간 초과, 가는 중 엔코더가 몇 초 그대로 */
void A_06(int rack);    /* Y 위치 : 시간 초과, 가는 중 엔코더가 몇 초 그대로 */
void A_07(int rack);    /* 틸트 위치 : 시간 초과, 가는 중 엔코더가 몇 초 그대로 */
void A_08(int rack);    /* 안전센서 */
void A_09(int rack);    /* 비상정지 */
void A_10(int rack);    /* 원점 : 너무 빨리 끝남(이물질), 리셋 → RUN 했는데 안 됨 */

void Alarm_Clear(void); /* 알람 번호 지움 (상태는 RESET 이 초기상태로) */

#endif /* INC_ALARM_H_ */
