/*
 * hmi.h
 *
 *  Created on: Sep 18, 2026
 *      Author: HWNOT
 */
#ifndef INC_HMI_H_
#define INC_HMI_H_

/* HMI 버튼 번호 : 기존 HMI ZIP 그대로 */

/* 메인 */
#define BTN_RUN            11   /* 화면 : 시작 */
#define BTN_STOP           12   /* 화면 : 일시정지 */

/* 수동 (JOG : 누르는 동안 움직임, 떼면 BTN_JOG_STOP) */
#define BTN_JOG_STOP        20   /* JOG 버튼 뗌 : 세 축 멈춤 */
#define BTN_TILT_Lift       21
#define BTN_TILT_Right      22
#define BTN_LIFT_UP         23
#define BTN_LIFT_Down       24
#define BTN_TRAVEL_Forward  25
#define BTN_TRAVEL_Back     26

/* 설정 */
#define BTN_SOUND_OFF       31
#define BTN_RESET           32
#define BTN_MANUAL          33

#include <stdint.h>

void HMI_Send(void);                            /* (Event_Task) 20ms 마다 상태 글자 = ESP 에 질문 */
void HMI_Receive(uint8_t *rx, uint16_t size);   /* (UART4 인터럽트) ESP 대답 → 살아 있음 + 버튼이 바뀌었으면 EventQueue */
extern volatile int hmi_miss;                   /* 물었는데 대답 없는 횟수 (alarm.c A_01 : 3번 = 알람 01) */
extern int jog_x;                               /* X JOG 중인 방향 (+1 · -1, 0 = 아님) : event.c 가 20ms 마다 다시 씀 */
void HMI_Manual(int button);                    /* 수동 JOG (21~26 누름 · 20 뗌) : 수동 모드 아니면 안 움직임 */

#endif
