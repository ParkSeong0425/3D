/*
 * rfid.h
 */

#ifndef INC_RFID_H_
#define INC_RFID_H_

#include "main.h"
#include "cmsis_os.h"

extern volatile int card_ok_1;
extern volatile int card_ok_2;
extern volatile int rfid_new;       /* 1 = 보낼 카드 이벤트 있음 */

void Rfid_Init(void);
void Rfid_Save(int rack, uint8_t *data);
void Rfid_Check(void);
void Rfid_Text(char *b, int size);
#endif
