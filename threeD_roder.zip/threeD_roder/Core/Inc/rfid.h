/*
 * rfid.h
 */

#ifndef INC_RFID_H_
#define INC_RFID_H_

#include "main.h"
#include "cmsis_os.h"

extern volatile int card_ok_1;      /* 렉1 카드 있음 1 / 없음 0 */
extern volatile int card_ok_2;      /* 렉2 */
extern volatile int card_event_on;  /* 1 = PC 로 카드 글자 보내 줘 (Rfid_PC 가 보내고 0) */
extern uint8_t uid_1[7];            /* 렉1 카드 번호 */
extern uint8_t uid_2[7];            /* 렉2 카드 번호 */

void Rfid_Init(void);                       /* 켤 때 : CAN 켜기 + 0.5초 묻기 시작 */
void Rfid_Save(int rack, uint8_t *data);    /* 리더 대답 (CAN 인터럽트) */
int  card_on(int rack);                     /* 그 렉 카드 있음 1 / 없음 0 (렉 3 · 4 = 1) */
int  card_stable(int rack);                 /* 그 렉 카드 상태가 2초 동안 안 바뀌었으면 1 (잠깐 못 읽음 = 0) */
int  card_out(void);                        /* 렉1 · 렉2(렉 수 2 이상) 중 카드 없는 곳 있으면 1 */
void Rfid_Check(void);                      /* 0.5초마다 리더에 묻기 (Rfid_Timer) */
void Rfid_Text(char *b, int size);          /* 프로토콜 글자 UT_1_…&UU_2_… (이벤트 · R 대답) */
void Rfid_PC(void);                         /* (Comm_Task) 카드 바뀌었으면 PC 로 */
#endif
