/*
 * rfid.h : 시딩월 카드 (변수 · 판단은 rfid.c 한 곳)
 */

#ifndef INC_RFID_H_
#define INC_RFID_H_

#include "main.h"
#include "cmsis_os.h"

extern volatile int card_event_on;  /* 1 = PC 로 UT · UU 보낼 것 있음 (net.c 접속 때 켬) */
extern int card_1;                  /* 1 = 렉1 시딩월 이탈 알림 중 (2초 넘게 없음) : 읽기만, 지우기는 HMI RUN (event.c btn_run) */
extern int card_2;                  /* 1 = 렉2 */

void Rfid_Init(void);                       /* 켤 때 : CAN 켜기 + 0.5초 묻기 시작 */
void Rfid_Save(int rack, uint8_t *data);    /* (CAN 인터럽트) 리더 대답 */
int  card_on(int rack);                     /* 지금 카드 있음 1 / 없음 0 (렉 3 · 4 = 1) */
void Rfid_Check(void);                      /* (Rfid_Timer 0.5초) 묻기 + 2초 없음 알림 */
void Rfid_check_text(char *b, int size);    /* 프로토콜 글자 UT_1_…&UU_2_… (R 대답 · UT · UU) */
void Rfid_event_text(void);                 /* (Comm_Task) 카드 바뀌었으면 PC 로 */

#endif
