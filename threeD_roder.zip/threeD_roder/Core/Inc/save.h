/*
 * save.h
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#ifndef INC_SAVE_H_
#define INC_SAVE_H_

#include "main.h"

/* FRAM 지도 : 덩어리마다 시작 주소를 정해 둠 → 한 덩어리에 칸을 늘려도 다른 덩어리는 안 밀림
   (칸을 늘릴 때는 다음 덩어리 주소를 넘지 않는지만 확인. 새 덩어리는 FI 뒤에 새 주소로) */
#define HEAD_ADDR   0x0001      /* magic 2 + version 2 = 4B */
#define VER_ADDR    0x0003
#define FS_ADDR     0x0010      /* 장비 / 위치 개수   9B  (~0x00FF 까지 여유) */
#define FP_ADDR     0x0100      /* 위치 설정        228B  (~0x03FF 까지 여유, int32 약 190칸) */
#define FI_ADDR     0x1000      /* 네트워크          24B */

/* 장비 / 위치 개수 */
typedef struct
{
    uint8_t rack;             /* 1 고정 */
    char type;                /* S / I */
    uint8_t rack_channel;     /* 렉 개수 1~4 (홀수 렉 = 오른쪽, 짝수 렉 = 왼쪽) */

    uint8_t in_x;             /* 1 고정 */
    uint8_t in_y;             /* 1~5 */

    uint8_t left_x;           /* 1~9 */
    uint8_t left_y;           /* 1~9 */

    uint8_t right_x;          /* 1~9 */
    uint8_t right_y;          /* 1~9 */

    uint16_t option[5];           /* 10000~00001 */

} FS_Data;


/* 위치 설정 */
/* 위치 설정 */
typedef struct
{
    /* FP 1 : 입고 X */
    int32_t in_x;

    /* FP 2 : 입고 Y */
    int32_t in_y[5];

    /* FP 3 : Left X */
    int32_t left_x[9];

    /* FP 4 : Left Y */
    int32_t left_y[9];

    /* FP 5 : Right X */
    int32_t right_x[9];

    /* FP 6 : Right Y */
    int32_t right_y[9];

    /* FP 7 : 리프트 / 틸팅 설정 */
    int32_t lift_y_offset;
    int32_t tilt_angle;
    int32_t tilting_y;
    int32_t tilting_y_speed;
    int32_t tilt_check_time;     /* 틸팅 검사시간 ms */

    /* FP 8 */
    int32_t y_offset;

    /* FP 9 */
    int32_t tilt_offset;

    /* FP 10 */
    int32_t x_offset;

    /* FP 11 */
    int32_t speed_x;
    int32_t speed_tilt;
    int32_t speed_y;

    /* FP 12 */
    int32_t accdec_x;
    int32_t accdec_tilt;
    int32_t accdec_y;

    /* FP 13 */
    int32_t safe_x;
    int32_t safe_y;


} FP_Data;


/* 네트워크 설정 */
typedef struct
{
    uint8_t ip[4];
    uint8_t sn[4];
    uint8_t gw[4];
    uint8_t dip[4];

    uint16_t port;
    uint8_t mode;
    uint32_t timeout;

} FI_Data;


/* 설정 전체 (RAM, 평소엔 이것만 봄) : 덩어리마다 FRAM 지도 주소에 따로 저장 */
typedef struct
{
    uint16_t magic;
    uint16_t version;

    FS_Data fs;
    FP_Data fp;
    FI_Data fi;

} SAVE_Data;

extern SAVE_Data save;

int Save_Init(void);
int FS(int rack, char type, int rack_channel,
       int in_x, int in_y,
       int left_x, int left_y,
       int right_x, int right_y,int option);
int FP(int rack, char no, int value[]);   /* no = 항목 글자 '1' ~ '9', ':' 10 ';' 11 '<' 12 '=' 13 (프로토콜 그대로) */
int FI(int no, int value[]);
int FD(void);

int Setting_Default_PIMZ(void);     /* 거래처 PIMZ 기본 설정 : FS + FP 한 번에 저장 (PC ALL_PIMZ) */

#endif
