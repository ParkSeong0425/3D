#ifndef INC_RUN_H_
#define INC_RUN_H_

#include <stdint.h>
#define CMD_I   ('I' << 8)
#define CMD_MI  (('M' << 8) | 'I')
#define CMD_MO  (('M' << 8) | 'O')
#define CMD_PO  (('P' << 8) | 'O')
#define CMD_S   (('S' << 8) | '_')
#define CMD_INIT (('I' << 8) | 'N')   /* CLI INIT : 초기화 재시도 */

int motor_basic_init(void);
int motor_basic_run(int command, int32_t pulse, int deg , int rpm);
int wait_xy(int x, int y);      /* X, Y 도착 기다림 (event.c PO_event 도 씀) */
int wait_tilt(int deg);         /* TILT 도착 기다림 */
int MI(int x, int y, int xy_speed, int tilt_speed);
int MO(int x, int y, int xy_speed, int tilt_speed);
int PO(int rack, int x, int y, int y_no,
       int xy_speed, int tilt_speed,
       int move_delay, int return_delay,
       int tilt_angle, int tilting_y, int tilting_y_speed);
int I (void);
int E_S (void);     /* 긴급정지 */

#endif
