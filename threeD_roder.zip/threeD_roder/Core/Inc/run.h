#ifndef INC_RUN_H_
#define INC_RUN_H_

#include <stdint.h>
#define CMD_I   ('I' << 8)
#define CMD_MI  (('M' << 8) | 'I')
#define CMD_MO  (('M' << 8) | 'O')
#define CMD_PO  (('P' << 8) | 'O')
#define CMD_S   (('S' << 8) | '_')
#define CMD_INIT (('I' << 8) | 'N')   /* CLI INIT : 초기화 재시도 */

int motor_basic_init(void);
int motor_basic_run(int command, int32_t pulse, int deg , int rpm);
int MI(int x, int y, int xy_speed, int tilt_speed);
int MO(int x, int y, int xy_speed, int tilt_speed);
int PO(int rack, int x, int y, int y_no,
       int xy_speed, int tilt_speed,
       int move_delay, int return_delay,
       int tilt_angle, int tilting_y, int tilting_y_speed);
int I (void);
int E_S (void);     /* 긴급정지 */

/* Motor_Task 에 넘길 숫자 (주문서) : cmd.c CMD_Run 이 확인하고 채움 → Motor_Run 이 run 함수에 넣음 */
extern int order_rack;             /* 렉 */
extern int order_col;               /* 열 */
extern int order_dan;               /* 단 */
extern int order_x;                 /* 갈 좌표 X (Order_Set 이 FRAM 표에서 찾음) */
extern int order_y;                 /* 갈 좌표 Y */
extern int order_xy_speed;          /* XY 속도 % */
extern int order_tilt_speed;        /* 틸트 속도 % */
extern int order_move_delay;        /* 이동 후 대기 ms */
extern int order_return_delay;      /* 틸트 복귀 대기 (x10ms) */
extern int order_tilt_angle;        /* 틸팅 각도 (도) */

int  Order_Set(int cmd, char *s);   /* 주문서 채우기 (cmd.c) : MI · MO · PO 글자 → 숫자 · 범위 확인 · 좌표. 맞으면 1 / 틀리면 0 */
void Motor_Run(int flag);           /* Motor_Task : 울린 초인종에 맞는 run 함수 하나 → 성공하면 그 렉 대기 */

#endif
