#ifndef INC_RUN_H_
#define INC_RUN_H_

#include <stdint.h>
#define CMD_I   ('I' << 8)
#define CMD_MI  (('M' << 8) | 'I')
#define CMD_MO  (('M' << 8) | 'O')
#define CMD_PO  (('P' << 8) | 'O')
#define CMD_S   (('S' << 8) | '_')
#define CMD_INIT (('I' << 8) | 'N')   /* CLI INIT : 초기화 재시도 */

/* 모터 주문 : 무슨 명령 + PC 명령 숫자 (프로토콜 순서 그대로). cmd.c 가 채워서 Motor_Request 로 넘김 */
typedef struct {
    int cmd;                    /* CMD_MI · CMD_MO · CMD_PO · CMD_I */
    int rack, col, dan;         /* 렉 · 열 · 단 */
    int lift_speed;             /* 리프트 속도 % (X · Y) */
    int tilt_speed;             /* 틸트 속도 % */
    int delay;                  /* 동작 대기 ms (출발 전) */
    int return_delay;           /* 틸트 복귀 대기 x10ms */
    int tilt_angle;             /* 틸팅 각도 */
    int tilt_check;             /* 틸팅 검사 0 / 1 (PO 만) */
} MOVE;

int motor_basic_init(void);
int motor_basic_run(int command, int32_t pulse, int deg , int rpm);
int MI(int dan, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle);                 /* 입고 dan 단 */
int MO(int x, int y, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle);            /* 출고 : 렉 좌표로 이동만 */
int PO(int rack, int x, int y, int dan, int lift_speed, int tilt_speed,
       int delay, int return_delay, int tilt_angle, int tilt_check);                                         /* 분배 */
int I (void);
int E_S (void);     /* 긴급정지 */

int  Motor_Request(MOVE m);     /* 모터 문 (아무 태스크) : 받으면 1 / 못 받으면 0 (하는 중 · 알람 · 초기화 중 MI·MO·PO) */
void Motor_Run(void);           /* (Motor_Task) 주문대로 하나 */           /* Motor_Task : 울린 초인종에 맞는 run 함수 하나 → 성공하면 그 렉 대기 */

#endif
