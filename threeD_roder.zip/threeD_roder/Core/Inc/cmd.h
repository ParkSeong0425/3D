/*
 * cmd.h
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#ifndef INC_CMD_H_
#define INC_CMD_H_

#include "run.h"

#define STX       0x02
#define ETX       0x03
#define ACK       0x06
#define NAK       0x15

void Done_Send(char *text);         /* (Motor_Task) 동작 끝 → 완료응답 AI · AO · EO 칸에 넣기 */
void CMD_Done(void);                /* (Comm_Task) 완료응답 보내기 : ANS_1 = PC 승인까지 1초마다 · 승인 때 W / ANS_0 = 한 번 · 바로 W */
void CMD_Run(int PC_num, char *s);  /* 명령 받기 (Comm_Task) : PC_num 번호, s PC 내용만 → 확인 → NAK / ACK + 실행 (움직임은 Motor_Task 로) */

#endif
