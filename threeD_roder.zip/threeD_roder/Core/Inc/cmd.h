/*
 * cmd.h
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#ifndef INC_CMD_H_
#define INC_CMD_H_

#include "run.h"

#define MOTOR_FLAG  0x08        /* Motor_Task 초인종 : PC 동작 명령 · 원점 요청이 깨움 (0x01 은 usart.c XFER_DONE 이 씀 → 겹치면 안 됨) */

void CMD_Run(char *s);      /* 명령 받기 (Comm_Task) */
void CMD_Move(void);        /* 동작 하기 (Motor_Task) : MI · MO · PO · I */
void CMD_Done(char *s, int ok);     /* 받은 명령 s 와 결과 ok(1 / 0) 로 완료응답 */
void CMD_Event(void);

#endif
