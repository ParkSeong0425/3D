/*
 * cmd.h
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#ifndef INC_CMD_H_
#define INC_CMD_H_

#include "run.h"

void CMD_Run(char *s);
void CMD_Done(char *s, int ok);     /* 받은 명령 s 와 결과 ok(1 / 0) 로 완료응답 */
void CMD_Event(void);

#endif
