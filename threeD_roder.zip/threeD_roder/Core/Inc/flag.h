/*
 * flag.h : 초인종(스레드 플래그) 번호표 — 한 곳에서 보기
 *
 *  플래그 = 태스크마다 있는 2진수 칸 하나 (1 · 2 · 4 · 8 · 0x10 …, 1 이 하나인 숫자만)
 *  같은 태스크 안에서 칸이 겹치면 안 됨 → 전체에서 안 겹치게 씀. 새 초인종은 0x100 부터
 *
 *  0x01  XFER_DONE   (usart.c 안)  UART2 · UART4 대답 끝 → 통신한 태스크 (Motor · Event · Comm 다 씀)
 */
#ifndef INC_FLAG_H_
#define INC_FLAG_H_

/* → Event_Task (event.c EXTI 콜백이 울림) */
#define ESTOP_FLAG  0x02        /* 긴급정지 핀 */
#define FULL_FLAG   0x04        /* 만재 핀 */

/* → Motor_Task (run.c Motor_Request 만 울림, 무슨 일인지는 주문서 job.cmd) */
#define MOVE_FLAG   0x20        /* 주문 있음 : MI · MO · PO · 원점 */

/* → Comm_Task */
#define NET_FLAG    0x10        /* W6100 INT 핀 (PC 글자 옴 · 접속 · 끊김, event.c EXTI 콜백) */

#endif
