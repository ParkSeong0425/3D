/*
 * flag.h : 초인종(스레드 플래그) 번호표 — 한 곳에서 보기
 *
 *  플래그 = 태스크마다 있는 2진수 칸 하나 (1 · 2 · 4 · 8 · 0x10 …, 1 이 하나인 숫자만)
 *  같은 태스크 안에서 칸이 겹치면 안 됨 → 전체에서 안 겹치게 씀. 새 초인종은 0x100 부터
 *
 *  0x01  XFER_DONE   (usart.c 안)  UART2 모터 대답 끝 → 통신한 태스크 (Motor · Event · Comm 다 씀)
 *
 *  큐 주문서 글자 (CommQueue) : 'F' 'U' 'P' 'A' 'N' — 플래그 숫자가 아니라 큐 안에 들어가는 1바이트 값
 */
#ifndef INC_FLAG_H_
#define INC_FLAG_H_

/* → Event_Task : 초인종 없음. 큐 EventQueue (ioc, 8칸 · 1바이트) 에 넣는 주문서 → event.c Event_Wait 가 꺼냄
   HMI 버튼은 번호 그대로 (11 · 12 · 20 · 21~26 · 31~33, hmi.h BTN_…) */
#define EV_ESTOP    'E'         /* 긴급정지 핀 (event.c EXTI) → 깨우기만 (estop_event 가 핀 읽음) */
#define EV_FULL     'M'         /* 만재 핀     (event.c EXTI) → 깨우기만 (manjae_change 가 핀 읽음) */

/* → Motor_Task : 초인종 없음. 주문은 큐 MoveQueue (ioc, run.c Motor_Request) 가 깨움 */

/* → Comm_Task : 초인종 없음. 큐 CommQueue (ioc, 8칸 · 1바이트) 에 넣는 주문서 글자 → cmd.c CMD_Event 가 그 파일 함수로 */
#define PC_FF       'F'         /* 만재 바뀜   (manjae.c)        → Manjae_event_text : FF */
#define PC_CARD     'U'         /* 카드 바뀜   (rfid.c · net.c)  → Rfid_event_text   : UT · UU */
#define PC_PAUSE    'P'         /* 일시정지    (status.c)        → Status_PC         : PPAUSE */
#define PC_ALARM    'A'         /* 알람        (alarm.c)         → Alarm_PC          : S_1_A_.. */
#define PC_NET      'N'         /* W6100 INT   (event.c EXTI)    → 깨우기만 (NET_Run 이 무슨 일인지 읽음) */

#endif
