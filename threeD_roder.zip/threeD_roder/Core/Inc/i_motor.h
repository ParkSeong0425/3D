#ifndef INC_I_MOTOR_H_
#define INC_I_MOTOR_H_

#include "main.h"
#include "usart.h"      /* MOTOR (칠판 한 칸) */

/* PR0 절대위치 운전 설정 */
#define IM_MAX_RPM        1000
#define IM_ACC_MS         1500
#define IM_DEC_MS         500
#define X_PULSE           10000    /* 데이터시트 : 1회전 10000펄스 */
#define X_PI              100      /* 폴리 : 1회전 100mm */

/* 입고대 드나들기 (IM_MoveSoft) : 입구 safe_x (FRAM FP 13) 에서 맞출 속도 % */
#define OUT_SPEED         27       /* 나올 때 : safe_x 에서 이 % → 지나며 명령 % 까지 빨라짐 (시험 값) */
#define SAFE_SPEED        20       /* 들어갈 때 : safe_x 에서 이 % → 줄어 in_x 에 섬 */

/* 토크 원점복귀 설정 */
#define IM_HOME_DIR       0          /* 0x600A Bit0 : 방향 (실측 확인) */
#define IM_HOME_TORQUE    (3 << 2)   /* 0x600A Bit2~ : 3 = 토크 원점 */
#define IM_HOME_HI_RPM    180        /* [현장] 180 / 사무실 50 */
#define IM_HOME_LO_RPM    80        /* [현장] 80 / 사무실 30 */
#define IM_HOME_ACC_MS    1500
#define IM_HOME_DEC_MS    1500
#define IM_HOME_TIME_MS   20
#define IM_HOME_FORCE     35         /* [현장] 35 / 사무실 10 */
#define IM_HOME_LIMIT     20000

/* 0x600F ~ 0x6015 연속 홈 설정값 */
#define IM_HOME_COUNT     7
static const uint16_t IM_HOME_DATA[IM_HOME_COUNT] = {
    IM_HOME_HI_RPM,      /* 0x600F Homing high velocity */
    IM_HOME_LO_RPM,      /* 0x6010 Homing low velocity */
    IM_HOME_ACC_MS,      /* 0x6011 Homing Acc */
    IM_HOME_DEC_MS,      /* 0x6012 Homing Dec */
    IM_HOME_TIME_MS,     /* 0x6013 Torque zero return time */
    IM_HOME_FORCE,       /* 0x6014 Torque zero return value */
    IM_HOME_LIMIT        /* 0x6015 Homing over-travel */
};

/* 0x1003 Motion state */
#define IM_PATH_DONE      (1 << 5)
#define IM_HOMED          (1 << 6)

/* 기본 기능 */
int IM_MoveSoft(int32_t mm, int percent);   /* X 이동 (하나뿐) : 입고대 드나들 때만 부드럽게 (나올 때 safe_x 에서 OUT_SPEED / 들어갈 때 SAFE_SPEED), 통로 → 통로는 평소 기울기 */
int IM_Home(void);
int IM_Stop(void);
int IM_Jog(int dir, int percent);       /* 수동 JOG : +1 앞 / -1 뒤. percent = 누를 때 속도 % / 0 = 다시 쓰기 (동작만). 50ms 안에 다시 불러야 계속 감 */
int IM_AlarmReset(void);

/* 상태 읽기 */
/* 위치 · 상태 = 칠판 im1 · im2 (아래, Bus_Task 가 40ms 마다 적음). 아래 둘은 칠판만 봄 */
int IM_Arrive(int x);       /* 두 모터 다 x(mm) 에 와서 멈출 때까지 기다림 (최대 MOVE_MS, 도착 1 / 실패 0) */
int IM_Pass(int x);         /* 두 모터 다 x(mm) 를 지나 바깥쪽에 올 때까지 기다림 (멈춤 안 봄, 최대 MOVE_MS, 지남 1 / 실패 0) — MO 가 Y 출발 시점 */
int IM_ReadReg(int motor, uint16_t reg, uint16_t *out, uint8_t qty);   /* (디버그 · CLI) X 레지스터 읽기 : motor 1 · 2, qty 1 = 16bit / 2 = 32bit */

/* Register Mapping */
int IM_MapInit(void);
int IM_Read(void);          /* (Bus_Task) X1 · X2 매핑 5칸 → 칠판 im1 · im2 (한 번씩, MOTOR_WAIT_MS). 둘 다 받으면 1 */

extern volatile MOTOR im1;  /* 칠판 X1 (ID 3) : 위치 mm · 상태 · 알람 · 놓친 횟수 */
extern volatile MOTOR im2;  /* 칠판 X2 (ID 4) */

#endif /* INC_I_MOTOR_H_ */
