#ifndef INC_I_MOTOR_H_
#define INC_I_MOTOR_H_

#include "main.h"

/* PR0 절대위치 운전 설정 */
#define IM_MAX_RPM        500
#define IM_ACC_MS         1500
#define IM_DEC_MS         1500
#define X_PULSE           10000    /* 데이터시트 : 1회전 10000펄스 */
#define X_PI              100      /* 폴리 : 1회전 100mm */
#define IM_GAP            10       /* 도착 판정 오차 (mm) : IM_Arrive · A_05 */

/* 토크 원점복귀 설정 */
#define IM_HOME_DIR       0          /* 0x600A Bit0 : 방향 (실측 확인) */
#define IM_HOME_TORQUE    (3 << 2)   /* 0x600A Bit2~ : 3 = 토크 원점 */
#define IM_HOME_HI_RPM    180
#define IM_HOME_LO_RPM    80
#define IM_HOME_ACC_MS    1500
#define IM_HOME_DEC_MS    1500
#define IM_HOME_TIME_MS   20
#define IM_HOME_FORCE     35         /* 사무실 10 , 현장 35*/
#define IM_HOME_LIMIT     20000

/* 0x600F ~ 0x6015 연속 홈 설정값 */
#define IM_HOME_COUNT     7
static const uint16_t IM_HOME_DATA[IM_HOME_COUNT] = {
    IM_HOME_HI_RPM,      /* 0x600F Homing high velocity */
    IM_HOME_LO_RPM,      /* 0x6010 Homing low velocity */
    IM_HOME_ACC_MS,      /* 0x6011 Homing Acc */
    IM_HOME_DEC_MS,      /* 0x6012 Homing Dec */
    IM_HOME_TIME_MS,     /* 0x6013 Torque zero return time */
    IM_HOME_FORCE,       /* 0x6014 Torque zero return value */
    IM_HOME_LIMIT        /* 0x6015 Homing over-travel */
};

/* 0x1003 Motion state */
#define IM_PATH_DONE      (1 << 5)
#define IM_HOMED          (1 << 6)

/* Mapping으로 한번에 읽는 상시 상태 */
typedef struct {
    uint16_t state;       /* 0x1003 Motion state */
    int32_t  pos;         /* 0x1014, 0x1015 Feedback position */
    uint16_t alarm;       /* 0x2203 Current alarm */
    uint16_t warn;        /* 0x601D PR/Home warning */
} IM_Info;

/* 기본 기능 */
int IM_Move(int32_t mm, int percent);
int IM_Home(void);
int IM_Stop(void);
int IM_AlarmReset(void);

/* 상태 읽기 */
int IM_Pos(int32_t *mm1, int32_t *mm2);   /* X 두 모터 위치 mm (ID 3 · ID 4), 둘 다 대답 1 */
int IM_Arrive(int x);       /* 두 모터 다 x(mm) 에 올 때까지 기다림 (최대 10초, 도착 1 / 실패 0) */
int IM_Alarm(uint16_t *code);       /* 드라이브 알람 0x2203 (두 모터 합침) : 0x01 과전류 0x02 과전압 0x40 전류측정 0x80 축잠금실패 0x100 오토튜닝 0x200 EEPROM */

/* Register Mapping */
int IM_MapInit(void);
int IM_MapRead(IM_Info *info);      /* 알람 만들 때 사용 */

#endif /* INC_I_MOTOR_H_ */
