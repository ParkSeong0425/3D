/*
 * alarm.c : 알람 조건 확인 + 걸기 (조건 · 숫자는 전부 여기, 부르는 곳은 한 줄씩)
 *
 *  부르는 곳 : event.c (01 HMI 통신, 09 긴급정지) / run.c (05 · 06 · 07 도착 기다림) / i_motor · a_motor (10 원점)
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */
#include "alarm.h"
#include "buzzer.h"
#include "status.h"
#include "run.h"
#include "hmi.h"
#include "net.h"
#include "debug.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "event.h"
#include "save.h"
#include "cmsis_os2.h"
#include <stdio.h>
#include <stdlib.h>

#define HMI_FAIL_MAX    20      /* 01 : HMI 연속 통신 실패 횟수 (약 3초) */
#define HOME_NEAR_MM    200     /* 10 : 원점에서 이만큼 안쪽이면 금방 닿아도 정상 */
#define HOME_FAST_MS    2000    /* 10 : 멀리 있었는데 이 시간 안에 닿으면 걸림 */

int alarm_1;                    /* 렉1 알람 번호 : 0 = 없음 */
int alarm_2;                    /* 렉2 알람 번호 */
int alarm_3;                    /* 렉3 알람 번호 */
int alarm_4;                    /* 렉4 알람 번호 */
volatile int alarm_event_on;    /* 1 = 보낼 알람 이벤트 있음 */



/* 알람 걸기 (공통) : 세우기 + 상태 A + 번호 + PC 알림 + 부저. 렉 1 ~ 4 / 0 = 모두 (로그는 부르는 A_xx 가 이름으로) */
static void alarm_go(int rack, int code)
{
    E_S();                                                              /* 세 축 멈춤 */
    if (rack == 1 || rack == 0) { status_1 = ALARM; alarm_1 = code; }
    if (rack == 2 || rack == 0) { status_2 = ALARM; alarm_2 = code; }
    if (rack == 3 || rack == 0) { status_3 = ALARM; alarm_3 = code; }
    if (rack == 4 || rack == 0) { status_4 = ALARM; alarm_4 = code; }
    alarm_event_on = 1;                                                 /* PC 로 알림 : S_1_A_09 */
    pause_why = 0;                                                      /* 일시정지 기다림 끝 (알람이 우선) */
    Buzzer_On();                                                       /* 부저 켬 (HMI 음소거 · RESET 으로 끔) */
}

/* 01 HMI 통신 : HMI_Run 결과가 HMI_FAIL 로 20번 연속이면 알람 (응답 오면 다시 0 부터) */
void A_01(int button)
{
    static int fail;                                    /* 연속 실패 횟수 */

    if (button != HMI_FAIL) { fail = 0; return; }       /* 응답 옴 */
    fail++;
    if (fail == HMI_FAIL_MAX) {                         /* 한 번만 */
        Log_Debug(LOG_A01);
        alarm_go(0, 1);
    }
}

/* 02 X 모터 : 두 모터 드라이브 알람(0x2203)이 있으면 알람 (대답 없음은 11). 걸면 1 */
int A_02(void)
{
    uint16_t code = 0;
    char *text;                                                         /* 알람 이름 */

    if (IM_Alarm(&code) == 0) return A_11(LOG_A11_X);                   /* 대답 없음 → 11 */
    if (code == 0) return 0;                                            /* 정상 */

    if      (code & 0x01)  text = "over current";                       /* 비트가 여러 개면 앞 것 이름 하나 (값은 다 보임) */
    else if (code & 0x02)  text = "over voltage";
    else if (code & 0x40)  text = "current sampling fault";
    else if (code & 0x80)  text = "failed to lock shaft";
    else if (code & 0x100) text = "auto tuning fault";
    else if (code & 0x200) text = "EEPROM fault";
    else                   text = "unknown";

    Log_Debug(LOG_A02_REASON);                                       /* 데이터시트 보라 */
    Log_Debug(LOG_A02_REASON_REG, code, text);                     /* 레지스터 · 값 · 이름 */
    alarm_go(0, 2);
    return 1;
}

/* 03 Y 모터 : 고장 코드(H0B_34)가 있으면 알람 (대답 없음은 11). 걸면 1
   빼는 것 (알람 아님) : ER.950 · 952 리밋 경고, ER.601 원점 시간 초과 */
int A_03(void)
{
    uint16_t code = 0;
    char *text;                                                         /* 알람 이름 */

    if (AM_Alarm(&code) == 0) return A_11(LOG_A11_Y);                   /* 대답 없음 → 11 */
    if (code == 0 || code == 0x950 || code == 0x952 || code == 0x601) return 0;   /* 정상 · 빼는 것 */

    if      (code == 0xB00) text = "position error";
    else if (code == 0x400) text = "over voltage";
    else if (code == 0x410) text = "under voltage";
    else if (code == 0x620) text = "overload";
    else if (code == 0x630) text = "motor stall";
    else if (code == 0x201) text = "hardware over current";
    else if (code == 0x207) text = "software over current";
    else if (code == 0x500) text = "over speed";
    else if (code == 0x650) text = "over temperature";
    else if (code == 0x668) text = "home mode mismatch";
    else if (code == 0xA33) text = "encoder fault";
    else if (code == 0x941) text = "parameter needs power off";
    else if (code == 0x900) text = "emergency stop DI on";
    else                    text = "see manual (ER. = value)";

    Log_Debug(LOG_A03_REASON);                                       /* 데이터시트 보라 */
    Log_Debug(LOG_A03_REASON_REG, code, text);                     /* 레지스터 · 값 · 이름 */
    alarm_go(0, 3);
    return 1;
}

/* 04 틸트 모터 : 드라이브 알람(PA_005)이 있으면 알람 (대답 없음은 11). 걸면 1 */
int A_04(void)
{
    uint16_t code = 0;
    char *text;                                                         /* 알람 이름 */

    if (TM_Alarm(&code) == 0) return A_11(LOG_A11_T);                   /* 대답 없음 → 11 */
    if (code == 0) return 0;                                            /* 정상 */

    if      (code == 0x01) text = "over current";
    else if (code == 0x02) text = "over voltage";
    else if (code == 0x03) text = "under voltage";
    else                   text = "unknown";

    Log_Debug(LOG_A04_REASON);                                       /* 데이터시트 보라 */
    Log_Debug(LOG_A04_REASON_REG, code, text);                     /* 레지스터 · 값 · 이름 */
    alarm_go(0, 4);
    return 1;
}

/* 05 X 위치 : A_05(IM_Arrive(x)) — MOVE_MS 안에 두 모터 다 도착 못 함(arrived 0)이면 알람 → E_S 로 그 자리에서 멈춤. 걸면 1 */
int A_05(int arrived)
{
    if (arrived || estop == 1 || status_1 == ALARM) return 0;          /* 도착 · 이미 멈춤 (덮어쓰지 않게) */
    Log_Debug(LOG_A05);
    alarm_go(0, 5);
    return 1;
}

/* 06 Y 위치 : A_06(AM_Arrive(y)) — 도착 못 함이면 알람. 걸면 1 */
int A_06(int arrived)
{
    if (arrived || estop == 1 || status_1 == ALARM) return 0;
    Log_Debug(LOG_A06);
    alarm_go(0, 6);
    return 1;
}

/* 07 틸트 위치 : A_07(TM_Arrive(deg)) — 도착 · 멈춤 못 함이면 알람. 걸면 1 */
int A_07(int arrived)
{
    if (arrived || estop == 1 || status_1 == ALARM) return 0;
    Log_Debug(LOG_A07);
    alarm_go(0, 7);
    return 1;
}

void A_09(int rack) { Log_Debug(LOG_A09); alarm_go(rack, 9); }     /* 비상정지 */

/* 10 원점 : 원점 시작 전 위치(far)가 200mm 넘게 떨어져 있었는데 시작(start)하고 2초 안에 닿음 = 가는 길에 걸림. 걸면 1 */
int A_10(int32_t far, uint32_t start)
{
    if (far <= HOME_NEAR_MM && far >= -HOME_NEAR_MM) return 0;          /* 원점 근처였음 (켠 직후 0 도 여기) */
    if (osKernelGetTickCount() - start >= HOME_FAST_MS) return 0;       /* 시간 걸려서 닿음 : 정상 */
    Log_Debug(LOG_A10_REASON_2);
    alarm_go(0, 10);
    return 1;
}

/* 11 모터 통신 끊김 : 드라이브가 대답 안 함 (A_02 · 03 · 04 가 축 이름 로그를 넘김). 걸면 1
   ※ 드라이브에 통신 감시가 없어서, 선이 끊겼으면 E_S 도 못 감 → 드라이브는 받은 목표까지 가서 섬 (진짜 정지는 비상정지 버튼) */
int A_11(char *log)
{
    Log_Debug(log);
    alarm_go(0, 11);
    return 1;
}

/* 12 랜선 빠짐 : PC 와 연결된 채로 보드 랜선이 빠지면 알람 (대기 · 운전 · 일시정지 · 원점 모두, net.c Net_On_Off 가 부름)
   PC 로는 안 보냄 (선이 없어서 못 감 + PC 프로토콜은 11 까지) → 로그 · 램프 · 부저로만 */
void A_12(void)
{
    if (estop == 1 || status_1 == ALARM) return;                       /* 이미 멈춤 : 덮어쓰지 않게 */
    Log_Debug(LOG_A12);
    alarm_go(0, 12);
    alarm_event_on = 0;                                                 /* PC 알림은 지움 (net.c 와 CMD_Event 가 같은 Comm_Task 라 사이에 못 나감) */
}

/* PC 로 알람 (Comm_Task) : 걸렸으면(alarm_event_on) 렉 수(rack_channel)까지, 걸린 렉만 이어서 S_1_A_09&S_3_A_05 */
void Alarm_PC(void)
{
    char b[64];
    int n = 0;                  /* b 에 쓴 글자 수 */

    if (alarm_event_on == 0) return;                    /* 보낼 것 없음 */
    alarm_event_on = 0;                                 /* 보내기 전에 0 */
    b[0] = 0;
    if (alarm_1 != 0 && save.fs.rack_channel >= 1) n += snprintf(b + n, sizeof(b) - n, "&S_1_A_%02d", alarm_1);
    if (alarm_2 != 0 && save.fs.rack_channel >= 2) n += snprintf(b + n, sizeof(b) - n, "&S_2_A_%02d", alarm_2);
    if (alarm_3 != 0 && save.fs.rack_channel >= 3) n += snprintf(b + n, sizeof(b) - n, "&S_3_A_%02d", alarm_3);
    if (alarm_4 != 0 && save.fs.rack_channel >= 4) n += snprintf(b + n, sizeof(b) - n, "&S_4_A_%02d", alarm_4);
    if (n > 0) send_event(b + 1);                       /* 맨 앞 & 하나 빼고 보냄 */
}

/* 알람 풀기 (HMI RESET) : 수동 끔 → 드라이브 알람 리셋 → Y 비상정지 해제 → 번호 지움 → 초기상태 (RUN 으로 원점) → 부저 끔
   긴급정지 · 동작 중 · 원점 중엔 안 함. 과전류 · 과전압 같은 드라이브 알람은 전원을 껐다 켜야 풀림. PC 는 원점 완료로 앎 */
void Alarm_Clear(void)
{
    if (estop == 1 || status_1 == RUN || status_2 == RUN || status_3 == RUN || status_4 == RUN || status_1 == HOME) return;
    manual = 0;                 /* 수동 모드 끔 */
    Log_Debug(LOG_ALARM_CLEAR);
    IM_AlarmReset();            /* 드라이브 알람 리셋 : X */
    AM_AlarmReset();            /*                     Y */
    TM_AlarmReset();            /*                     틸트 */
    AM_EStop(0);                /* Y 비상정지 해제 */
    alarm_1 = 0;                /* 알람 번호 지움 */
    alarm_2 = 0;
    alarm_3 = 0;
    alarm_4 = 0;
    Status_HOME();              /* 초기화(I) : HMI RUN 으로 원점 */
    Buzzer_Off();               /* 알람 부저 끔 */
}
