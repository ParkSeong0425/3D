/*
 * alarm.c : 알람 조건 확인 + 걸기 (조건 · 숫자는 전부 여기, 부르는 곳은 한 줄씩)
 *
 *  부르는 곳 : event.c (01 HMI 통신, 09 긴급정지) / run.c (05 · 06 · 07 도착 기다림) / i_motor · a_motor (10 원점)
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */
#include "alarm.h"
#include "buzzer.h"
#include "status.h"
#include "run.h"
#include "hmi.h"
#include "net.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "event.h"
#include "cmsis_os2.h"
#include <stdio.h>
#include <stdlib.h>

#define HMI_FAIL_MAX    20      /* 01 : HMI 연속 통신 실패 횟수 (약 3초) */
#define HOME_NEAR_MM    200     /* 10 : 원점에서 이만큼 안쪽이면 금방 닿아도 정상 */
#define HOME_FAST_MS    2000    /* 10 : 멀리 있었는데 이 시간 안에 닿으면 걸림 */

int alarm_1;                    /* 렉1 알람 번호 : 0 = 없음 */
int alarm_2;                    /* 렉2 알람 번호 */
int alarm_3;                    /* 렉3 알람 번호 */
int alarm_4;                    /* 렉4 알람 번호 */
volatile int alarm_event_on;    /* 1 = 보낼 알람 이벤트 있음 */



/* 알람 걸기 (공통) : 세우기 + 상태 A + 번호 + PC 알림 + 부저. 렉 1 ~ 4 / 0 = 모두 (로그는 부르는 A_xx 가 이름으로) */
static void alarm_go(int rack, int code)
{
    E_S();                                                              /* 세 축 멈춤 */
    if (rack == 1 || rack == 0) { status_1 = ALARM; alarm_1 = code; }
    if (rack == 2 || rack == 0) { status_2 = ALARM; alarm_2 = code; }
    if (rack == 3 || rack == 0) { status_3 = ALARM; alarm_3 = code; }
    if (rack == 4 || rack == 0) { status_4 = ALARM; alarm_4 = code; }
    alarm_event_on = 1;                                                 /* PC 로 알림 : S_1_A_09 */
    pause_why = 0;                                                      /* 일시정지 기다림 끝 (알람이 우선) */
    Buzzer_On();                                                       /* 부저 켬 (HMI 음소거 · RESET 으로 끔) */
}

/* 01 HMI 통신 : HMI_Run 결과가 HMI_FAIL 로 20번 연속이면 알람 (응답 오면 다시 0 부터) */
void A_01(int button)
{
    static int fail;                                    /* 연속 실패 횟수 */

    if (button != HMI_FAIL) { fail = 0; return; }       /* 응답 옴 */
    fail++;
    if (fail == HMI_FAIL_MAX) {                         /* 한 번만 */
        Log_Port("ALARM 01  HMI no answer");
        alarm_go(0, 1);
    }
}

/* 02 X 모터 : 두 모터 드라이브 알람(0x2203)이 있거나 대답 없으면 알람. 걸면 1 */
int A_02(void)
{
    uint16_t code = 0;
    char *text;                                                         /* 알람 이름 */
    char b[80];                                                         /* 로그 한 줄 */

    if (IM_Alarm(&code) == 0) {                                         /* 대답 없음 */
        Log_Port("ALARM 02  X no answer (RS485 line or X drive)");
        alarm_go(0, 2);
        return 1;
    }
    if (code == 0) return 0;                                            /* 정상 */

    if      (code & 0x01)  text = "over current";                       /* 비트가 여러 개면 앞 것 이름 하나 (값은 다 보임) */
    else if (code & 0x02)  text = "over voltage";
    else if (code & 0x40)  text = "current sampling fault";
    else if (code & 0x80)  text = "failed to lock shaft";
    else if (code & 0x100) text = "auto tuning fault";
    else if (code & 0x200) text = "EEPROM fault";
    else                   text = "unknown";

    snprintf(b, sizeof(b), "ALARM 02  X  0x2203 = 0x%04X  %s", code, text);   /* 번호 · 레지스터 · 값 · 이름 */
    Log_Port(b);
    alarm_go(0, 2);
    return 1;
}

/* 03 Y 모터 : 고장 코드(H0B_34)가 있거나 대답 없으면 알람. 걸면 1
   빼는 것 (알람 아님) : ER.950 · 952 리밋 경고, ER.601 원점 시간 초과 */
int A_03(void)
{
    uint16_t code = 0;
    char *text;                                                         /* 알람 이름 */
    char b[80];                                                         /* 로그 한 줄 */

    if (AM_Alarm(&code) == 0) {                                     /* 대답 없음 */
        Log_Port("ALARM 03  Y no answer (RS485 line or Y drive)");
        alarm_go(0, 3);
        return 1;
    }
    if (code == 0 || code == 0x950 || code == 0x952 || code == 0x601) return 0;   /* 정상 · 빼는 것 */

    if      (code == 0xB00) text = "position error";
    else if (code == 0x400) text = "over voltage";
    else if (code == 0x410) text = "under voltage";
    else if (code == 0x620) text = "overload";
    else if (code == 0x630) text = "motor stall";
    else if (code == 0x201) text = "hardware over current";
    else if (code == 0x207) text = "software over current";
    else if (code == 0x500) text = "over speed";
    else if (code == 0x650) text = "over temperature";
    else if (code == 0x668) text = "home mode mismatch";
    else if (code == 0xA33) text = "encoder fault";
    else if (code == 0x941) text = "parameter needs power off";
    else if (code == 0x900) text = "emergency stop DI on";
    else                    text = "see manual (ER. = value)";

    snprintf(b, sizeof(b), "ALARM 03  Y  H0B_34 = 0x%04X  %s", code, text);  /* 번호 · 레지스터 · 값 · 이름 */
    Log_Port(b);
    alarm_go(0, 3);
    return 1;
}

/* 04 틸트 모터 : 드라이브 알람(PA_005)이 있거나 대답 없으면 알람. 걸면 1 */
int A_04(void)
{
    uint16_t code = 0;
    char *text;                                                         /* 알람 이름 */
    char b[80];                                                         /* 로그 한 줄 */

    if (TM_Alarm(&code) == 0) {                                         /* 대답 없음 */
        Log_Port("ALARM 04  Tilt no answer (RS485 line or tilt drive)");
        alarm_go(0, 4);
        return 1;
    }
    if (code == 0) return 0;                                            /* 정상 */

    if      (code == 0x01) text = "over current";
    else if (code == 0x02) text = "over voltage";
    else if (code == 0x03) text = "under voltage";
    else                   text = "unknown";

    snprintf(b, sizeof(b), "ALARM 04  Tilt  PA_005 = 0x%04X  %s", code, text);   /* 번호 · 레지스터 · 값 · 이름 */
    Log_Port(b);
    alarm_go(0, 4);
    return 1;
}

/* 05 X 위치 : IM_Arrive 로 기다린 뒤 X 가 x 에 없으면 알람. 걸면 1 */
int A_05(int x)
{
    int32_t now = 0;

    if (estop == 1 || status_1 == ALARM) return 0;                     /* 이미 멈춤 : 덮어쓰지 않게 */
    if (IM_Pos(&now) && abs(now - x) < IM_GAP) return 0;               /* 도착해 있음 */
    Log_Port("ALARM 05  X move timeout (10s)");
    alarm_go(0, 5);
    return 1;
}

/* 06 Y 위치 : AM_Arrive 로 기다린 뒤 Y 가 y 에 없으면 알람. 걸면 1 */
int A_06(int y)
{
    int32_t now = 0;

    if (estop == 1 || status_1 == ALARM) return 0;
    if (AM_Pos(&now) && abs(now - y) < AM_GAP) return 0;
    Log_Port("ALARM 06  Y move timeout (10s)");
    alarm_go(0, 6);
    return 1;
}

/* 07 틸트 위치 : TM_Arrive 로 기다린 뒤 틸트가 deg 에 없거나 아직 움직이면 알람. 걸면 1 */
int A_07(int deg)
{
    int32_t now = 0;

    if (estop == 1 || status_1 == ALARM) return 0;
    if (TM_Pos(&now) && abs(abs(now) - deg) <= TM_GAP && TM_Done()) return 0;
    Log_Port("ALARM 07  Tilt move timeout (10s)");
    alarm_go(0, 7);
    return 1;
}

void A_09(int rack) { Log_Port("ALARM 09  emergency stop"); alarm_go(rack, 9); }     /* 비상정지 */

/* 10 원점 : 원점 시작 전 위치(far)가 200mm 넘게 떨어져 있었는데 시작(start)하고 2초 안에 닿음 = 가는 길에 걸림. 걸면 1 */
int A_10(int32_t far, uint32_t start)
{
    if (far <= HOME_NEAR_MM && far >= -HOME_NEAR_MM) return 0;          /* 원점 근처였음 (켠 직후 0 도 여기) */
    if (osKernelGetTickCount() - start >= HOME_FAST_MS) return 0;       /* 시간 걸려서 닿음 : 정상 */
    Log_Port("ALARM 10  home touched too fast (something in the way?)");
    alarm_go(0, 10);
    return 1;
}

/* 알람 풀기 : 번호만 지움 (상태는 RESET 이 초기상태로, PC 는 원점 완료로 앎) */
void Alarm_Clear(void)
{
    alarm_1 = 0;
    alarm_2 = 0;
    alarm_3 = 0;
    alarm_4 = 0;
}
