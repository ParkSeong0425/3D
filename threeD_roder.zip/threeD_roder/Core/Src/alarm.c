/*
 * alarm.c : 알람 켜기 / 끄기만 (언제 거는지는 event.c 가 정함)
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */
#include "alarm.h"
#include "status.h"

int alarm_1;                    /* 렉1 알람 번호 : 0 = 없음 */
int alarm_2;                    /* 렉2 알람 번호 */
volatile int alarm_event_on;    /* 1 = 보낼 알람 이벤트 있음 */


/* 알람 걸기 (공통) : 렉 1, 2 / 0 = 두 렉 모두 */
static void alarm_on(int rack, int code)
{
    if (rack == 1 || rack == 0) { status_1 = ALARM; alarm_1 = code; }
    if (rack == 2 || rack == 0) { status_2 = ALARM; alarm_2 = code; }
    alarm_event_on = 1;         /* PC 로 알림 : S_1_A_09 */
}

void A_01(int rack) { alarm_on(rack, 1);  }    /* HMI 통신 */
void A_02(int rack) { alarm_on(rack, 2);  }    /* X 모터 */
void A_03(int rack) { alarm_on(rack, 3);  }    /* Y 모터 */
void A_04(int rack) { alarm_on(rack, 4);  }    /* 틸트 모터 */
void A_05(int rack) { alarm_on(rack, 5);  }    /* X 위치 */
void A_06(int rack) { alarm_on(rack, 6);  }    /* Y 위치 */
void A_07(int rack) { alarm_on(rack, 7);  }    /* 틸트 위치 */
void A_08(int rack) { alarm_on(rack, 8);  }    /* 안전센서 */
void A_09(int rack) { alarm_on(rack, 9);  }    /* 비상정지 */
void A_10(int rack) { alarm_on(rack, 10); }    /* 원점 */

/* 알람 풀기 : 번호만 지움 (상태는 RESET 이 초기상태로, PC 는 원점 완료로 앎) */
void Alarm_Clear(void)
{
    alarm_1 = 0;
    alarm_2 = 0;
}
