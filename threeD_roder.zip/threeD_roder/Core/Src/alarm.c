/*
 * alarm.c : 알람 조건 확인 + 걸기 (조건 · 숫자는 전부 여기, 부르는 곳은 한 줄씩)
 *
 *  알람 번호 · 부르는 곳
 *   01 HMI 통신         Event_Task 스위치판        A_01()                   ESP 대답 3번 없음
 *   02 · 03 · 04 드라이브 Bus_Task Alarm_Drive (40ms) A_02() · A_03() · A_04()  칠판 알람 칸에 코드가 있음
 *   05 · 06 · 07 위치    run.c MI · MO · PO          A_05(IM_Arrive(x)) …     8초 안에 못 감
 *                대답 없음 Bus_Task Alarm_Drive    bus_alarm                그 축 하나만 BUS_MISS 번 연속 대답 없음 (로그 X1 · X2 · Y · Tilt)
 *                X 차이   Bus_Task Alarm_Drive    bus_alarm                X1 · X2 위치 차이 50mm 넘음 [현장]
 *   09 비상정지          event.c estop_event         A_09()
 *   10 원점              i · a_motor 원점 · run.c    A_10(far, start)
 *   11 모터 선 끊김       Bus_Task Alarm_Drive        bus_alarm                4대 다 BUS_MISS 번 연속 대답 없음 (UART2 선 · 전원)
 *   12 랜선 빠짐          net.c Net_On_Off            A_12()
 *   풀기 : Alarm_Clear (HMI RESET · PC I) / PC 로 알림 : Alarm_PC (Comm_Task)
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */
#include "alarm.h"
#include "buzzer.h"
#include "status.h"
#include "run.h"
#include "hmi.h"
#include "net.h"
#include "debug.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "event.h"
#include "flag.h"
#include "main.h"
#include "cmsis_os2.h"
#include <stdlib.h>         /* abs (X 차이) */

#define HMI_MISS        3       /* 01 : ESP 가 연달아 이만큼 대답 안 하면 (20ms 마다 물음 → 3번 = 60ms) */
#define HMI_BOOT_MS     3000    /* 01 : 켠 뒤 이 시간은 안 봄 (ESP 켜지는 중, 전과 같은 3초) */
#define HOME_FAST_MS    2000    /* 10 : 멀리 있었는데 이 시간 안에 닿으면 걸림 */
/* 05 ~ 07 · 11 대답 없음 BUS_MISS 는 alarm.h. X 차이 50mm 는 bus_alarm 안에 숫자로 [현장] */

/* 알람 번호는 status.h state.alarm (11/16 상태 하나로) */


/* 알람 걸기 (공통) : 로그 + 세우기 + 번호 + 상태 A + PC 알림(CommQueue 'A') + 부저 */
static void alarm_go(int code, const char *log)
{
    uint8_t task_copy = PC_ALARM;                                       /* 주문서 : 알람 */

    Log_Debug("%s", log);                                               /* 어떤 알람 · 이유 (debug.h LOG_A..) */
    HMI_Manual(BTN_JOG_STOP);                                           /* 수동 JOG 중이면 세움 (상태 A 가 되면 뗌 글자를 안 받아서 Y JOG 신호가 남음) */
    E_S();                                                              /* 세 축 멈춤 */
    state.alarm = code;                                                 /* 번호 */
    state.why = 0;                                                      /* 멈춤 이유 지움 (알람이 우선 → 정지선 기다림 끝) */
    state.now = 'A';                                                 /* 상태 A (수동 · 멈춤 중이었어도) */
    osMessageQueuePut(CommQueueHandle, &task_copy, 0, 0);               /* PC 로 알림 : S_1_A_09 → Comm_Task (Alarm_PC) */
    Buzzer_On();                                                        /* 부저 켬 (HMI 음소거 · RESET 으로 끔) */
}

/* 05 · 06 · 07 공통 : 도착 못 함(arrived 0)이면 알람. 이미 멈춤(긴급정지 · 알람)이면 덮어쓰지 않음. 걸면 1 */
static int arrive_alarm(int arrived, int code, const char *log)
{
    if (arrived || Motor_Stop()) return 0;
    alarm_go(code, log);
    return 1;
}

/* 01 HMI 통신 : 20ms 마다 물었는데 ESP 가 연달아 3번 대답 안 함 (꺼짐 · 선 빠짐 · 재시작) → 알람 (E_S 로 JOG 도 멈춤)
   시간이 아니라 횟수 : Event_Task 가 모터 열쇠를 기다려 못 물은 동안은 안 셈 (가짜 알람 없음). 이미 멈춤(긴급정지 · 알람)이면 다시 안 걸음 */
void A_01(void)
{
    if (hmi_miss < HMI_MISS || osKernelGetTickCount() < HMI_BOOT_MS || Motor_Stop()) return;
    HMI_Manual(BTN_JOG_STOP);           /* HMI 끊김 : JOG 멈춤 (X 다시 쓰기 그만 · Y JOG 신호 끔 · 틸트 정지) — 뗌 글자가 영영 안 오니까 (11/13) */
    alarm_go(1, LOG_A01);
}

/* 02 X 모터 : 칠판 두 모터 드라이브 알람(0x2203)이 있으면 알람 (알람은 비트라서 | 로 합침). 걸면 1 */
int A_02(void)
{
    uint16_t code = im1.alarm | im2.alarm;                              /* 칠판 (Bus_Task IM_Read) */
    char *text;                                                         /* 알람 이름 */

    if (code == 0) return 0;                                            /* 정상 */

    if      (code & 0x01)  text = "over current";                       /* 비트가 여러 개면 앞 것 이름 하나 (값은 다 보임) */
    else if (code & 0x02)  text = "over voltage";
    else if (code & 0x40)  text = "current sampling fault";
    else if (code & 0x80)  text = "failed to lock shaft";
    else if (code & 0x100) text = "auto tuning fault";
    else if (code & 0x200) text = "EEPROM fault";
    else                   text = "unknown";

    alarm_go(2, LOG_A02_REASON);                                        /* 데이터시트 보라 */
    Log_Debug(LOG_A02_REASON_REG, code, text);                          /* 레지스터 · 값 · 이름 */
    return 1;
}

/* 03 Y 모터 : 칠판 고장 코드(H0B_34)가 있으면 알람. 걸면 1
   빼는 것 (알람 아님) : ER.950 · 952 리밋 경고, ER.601 원점 시간 초과 */
int A_03(void)
{
    uint16_t code = am.alarm;                                           /* 칠판 (Bus_Task AM_Read) */
    char *text;                                                         /* 알람 이름 */

    if (code == 0 || code == 0x950 || code == 0x952 || code == 0x601) return 0;   /* 정상 · 빼는 것 */

    if      (code == 0xB00) text = "position error";
    else if (code == 0x400) text = "over voltage";
    else if (code == 0x410) text = "under voltage";
    else if (code == 0x620) text = "overload";
    else if (code == 0x630) text = "motor stall";
    else if (code == 0x201) text = "hardware over current";
    else if (code == 0x207) text = "software over current";
    else if (code == 0x500) text = "over speed";
    else if (code == 0x650) text = "over temperature";
    else if (code == 0x668) text = "home mode mismatch";
    else if (code == 0xA33) text = "encoder fault";
    else if (code == 0x941) text = "parameter needs power off";
    else if (code == 0x900) text = "emergency stop DI on";
    else                    text = "see manual (ER. = value)";

    alarm_go(3, LOG_A03_REASON);                                        /* 데이터시트 보라 */
    Log_Debug(LOG_A03_REASON_REG, code, text);                          /* 레지스터 · 값 · 이름 */
    return 1;
}

/* 04 틸트 모터 : 칠판 드라이브 알람(PA_005)이 있으면 알람. 걸면 1 */
int A_04(void)
{
    uint16_t code = tm.alarm;                                           /* 칠판 (Bus_Task TM_Read) */
    char *text;                                                         /* 알람 이름 */

    if (code == 0) return 0;                                            /* 정상 */

    if      (code == 0x01) text = "over current";
    else if (code == 0x02) text = "over voltage";
    else if (code == 0x03) text = "under voltage";
    else                   text = "unknown";

    alarm_go(4, LOG_A04_REASON);                                        /* 데이터시트 보라 */
    Log_Debug(LOG_A04_REASON_REG, code, text);                          /* 레지스터 · 값 · 이름 */
    return 1;
}

/* 대답 없음 · X 차이 (칠판 miss · pos) : 걸면 1
   ① 4대 다 BUS_MISS 번 연속 대답 없음 → 11 (모터 선 UART2 · 전원)
   ② 한 대만 (다른 하나라도 대답함) → 그 축 05 · 06 · 07 + 어느 모터인지 로그
      선이 뽑히는 순간엔 한 바퀴 안에서 먼저 놓친 축이 생김 → "다른 하나라도 대답함" 일 때만 한 대로 봄 (아니면 ① 을 기다림)
   ③ X1 · X2 둘 다 방금 대답했는데 위치 차이 50mm 넘음 → 05 (한쪽이 걸림 · 벨트) */
static int bus_alarm(void)
{
    int alive = (im1.miss == 0 || im2.miss == 0 || am.miss == 0 || tm.miss == 0);   /* 하나라도 이번에 대답함 */
    int32_t gap = im1.pos - im2.pos;                                                  /* X1 - X2 mm */

    if (alive == 0 && im1.miss >= BUS_MISS && im2.miss >= BUS_MISS
                   && am.miss >= BUS_MISS && tm.miss >= BUS_MISS) { alarm_go(11, LOG_A11);    return 1; }   /* ① */
    if (alive && im1.miss >= BUS_MISS)                               { alarm_go(5, LOG_A05_X1);  return 1; }   /* ② */
    if (alive && im2.miss >= BUS_MISS)                               { alarm_go(5, LOG_A05_X2);  return 1; }
    if (alive && am.miss >= BUS_MISS)                                { alarm_go(6, LOG_A06_Y);   return 1; }
    if (alive && tm.miss >= BUS_MISS)                                { alarm_go(7, LOG_A07_T);   return 1; }
    if (im1.miss == 0 && im2.miss == 0 && abs(gap) > 50) {      /* ③ [현장] 50mm (읽는 시각 차이 약 8 + 평소 차이 + 여유). 시험 때만 작게 (예 3) */
        alarm_go(5, LOG_A05_SKEW);
        Log_Debug(LOG_A05_SKEW_POS, (long)im1.pos, (long)im2.pos, (long)gap);
        return 1;
    }
    return 0;
}

/* (Bus_Task 40ms) 칠판 보고 알람 : 선은 안 씀 (읽기는 바로 앞 IM_Read · AM_Read · TM_Read 가 함)
   안 보는 때 : 긴급정지 · 알람 (이미 멈춤) · I 원점 전 (X 매핑 전이라 못 읽는 게 정상) · H 원점 중 (X1 이 원점 끝에서 0.5초 조용) */
void Alarm_Drive(void)
{
    if (Motor_Stop() || state.now == 'I' || state.now == 'H') return;

    if (bus_alarm()) return;    /* 대답 없음 11 · 05 ~ 07 / X 차이 05 */
    if (A_02()) return;         /* X 드라이브 알람 */
    if (A_03()) return;         /* Y 드라이브 알람 */
    A_04();                     /* 틸트 드라이브 알람 */
}

/* 05 · 06 · 07 위치 : A_05(IM_Arrive(x)) 처럼 — MOVE_MS 안에 도착 못 함이면 알람 → E_S 로 그 자리에서 멈춤. 걸면 1 */
int A_05(int arrived) { return arrive_alarm(arrived, 5, LOG_A05); }    /* X */
int A_06(int arrived) { return arrive_alarm(arrived, 6, LOG_A06); }    /* Y */
int A_07(int arrived) { return arrive_alarm(arrived, 7, LOG_A07); }    /* 틸트 */

void A_09(void) { alarm_go(9, LOG_A09); state.now = 'E'; }          /* 비상정지 : 알람 09 + 상태 E (풀면 event.c 가 A 로) */

/* 10 원점 (걸면 1) — 두 가지
   ① 원점 중 : A_10(far, start)  IM_Home · AM_Home 이 닿은 순간. 200mm 넘게 떨어져 있었는데 2초 안에 닿음 = 가는 길에 걸림
   ② 원점 실패 : A_10(0, 0)      motor_basic_init 끝. 60초 초과 · 드라이브 대답 없음 → 무조건 (사수 · 문서 "원점복귀실패") */
int A_10(int32_t far, uint32_t start)
{
    if (start == 0) {                                                   /* ② 원점 실패 */
        if (Motor_Stop()) return 0;                                     /* 이미 알람(09 · 10 · 11) : 번호 그대로 */
        alarm_go(10, LOG_A10);
        return 1;
    }
    if (far <= 200 && far >= -200) return 0;                            /* ① 원점 200mm 안쪽이었음 (켠 직후 0 도 여기) */
    if (osKernelGetTickCount() - start >= HOME_FAST_MS) return 0;       /* ① 시간 걸려서 닿음 : 정상 */
    alarm_go(10, LOG_A10_REASON);                                       /* ① 걸림 */
    return 1;
}

/* 12 랜선 빠짐 : PC 와 연결된 채로 보드 랜선이 빠지면 알람 (대기 · 운전 · 일시정지 · 원점 모두, net.c Net_On_Off 가 부름)
   PC 로는 안 보냄 (선이 없어서 못 감 + PC 프로토콜은 11 까지) → 로그 · 램프 · 부저로만 */
void A_12(void)
{
    if (Motor_Stop()) return;                                           /* 이미 멈춤 : 덮어쓰지 않게 */
    alarm_go(12, LOG_A12);                                              /* PC 알림은 Alarm_PC 가 안 보냄 (선이 빠져서 못 감) */
}

/* PC 로 알람 (Comm_Task) : 'A' 받으면 S_1_A_09&S_2_A_09 (C 대답과 같은 글자, cmd.c CMD_Event 가 부름) */
void Alarm_PC(void)
{
    char b[64];

    if (state.alarm == 12) return;                      /* 랜선 빠짐 : PC 로 못 감 + PC 프로토콜은 11 까지 */
    Status_Text(b, sizeof(b));                          /* 알람이면 렉마다 S_n_A_번호 (status.c) */
    send_event(b);
}

/* RESET (HMI RESET · PC I) : 무엇이든 처음으로 → I 초기상태. 원점은 안 감 (원점은 시작만)
   JOG 멈춤 → 드라이브 알람 리셋 → Y 비상정지 해제 → 번호 · 이유 지움 → I → 부저 끔
   안 되는 때 : E 긴급정지 눌림 · R 운전 · H 원점중 · 운전 중 멈춤 (하던 동작이 이어져 버림 → 시작으로 풀기)
   과전류 · 과전압 같은 드라이브 알람은 전원을 껐다 켜야 풀림. PC 는 C 로 앎 */
void Alarm_Clear(void)
{
    if (state.now == 'E' || state.now == 'R' || state.now == 'H') return;
    if (state.now == 'S' && state.prev == 'R') return;
    HMI_Manual(BTN_JOG_STOP);   /* 수동 JOG 중이었으면 세움 (상태 바꾸기 전에) */
    Log_Debug(LOG_ALARM_CLEAR);
    IM_AlarmReset();            /* 드라이브 알람 리셋 : X */
    AM_AlarmReset();            /*                     Y */
    TM_AlarmReset();            /*                     틸트 */
    AM_EStop(0);                /* Y 비상정지 해제 */
    state.alarm = 0;            /* 알람 번호 지움 */
    state.why = 0;              /* 멈춤 이유 지움 */
    state.now = 'I';          /* 초기상태 : 시작 누르면 원점 */
    Buzzer_Off();               /* 알람 부저 끔 */
}
