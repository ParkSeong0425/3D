/*
 * alarm.c : 알람 조건 확인 + 걸기 (조건 · 숫자는 전부 여기, 부르는 곳은 한 줄씩)
 *
 *  부르는 곳 : event.c (01 HMI 통신, 09 긴급정지) / run.c (05 · 06 wait_xy, 07 wait_tilt) / i_motor · a_motor (10 원점)
 *
 *  Created on: Oct 8, 2026
 *      Author: HWNOT
 */
#include "alarm.h"
#include "buzzer.h"
#include "status.h"
#include "run.h"
#include "hmi.h"
#include "cmsis_os2.h"

#define HMI_FAIL_MAX    20      /* 01 : HMI 연속 통신 실패 횟수 (약 3초) */
#define MOVE_MS         10000   /* 05 ~ 07 : 이 시간 안에 목표 못 가면 */
#define HOME_NEAR_MM    200     /* 10 : 원점에서 이만큼 안쪽이면 금방 닿아도 정상 */
#define HOME_FAST_MS    2000    /* 10 : 멀리 있었는데 이 시간 안에 닿으면 걸림 */

int alarm_1;                    /* 렉1 알람 번호 : 0 = 없음 */
int alarm_2;                    /* 렉2 알람 번호 */
int alarm_3;                    /* 렉3 알람 번호 */
int alarm_4;                    /* 렉4 알람 번호 */
volatile int alarm_event_on;    /* 1 = 보낼 알람 이벤트 있음 */


/* 알람 걸기 (공통) : 세우기 + 상태 A + 번호 + PC 알림 + 부저. 렉 1 ~ 4 / 0 = 모두 */
static void alarm_go(int rack, int code)
{
    E_S();                                                              /* 세 축 멈춤 */
    if (rack == 1 || rack == 0) { status_1 = ALARM; alarm_1 = code; }
    if (rack == 2 || rack == 0) { status_2 = ALARM; alarm_2 = code; }
    if (rack == 3 || rack == 0) { status_3 = ALARM; alarm_3 = code; }
    if (rack == 4 || rack == 0) { status_4 = ALARM; alarm_4 = code; }
    alarm_event_on = 1;                                                 /* PC 로 알림 : S_1_A_09 */
    Buzzer_On();                                                        /* 부저 켬 (HMI 음소거 · RESET 으로 끔) */
}

/* 01 HMI 통신 : HMI_Run 결과가 HMI_FAIL 로 20번 연속이면 알람 (응답 오면 다시 0 부터) */
void A_01(int button)
{
    static int fail;                                    /* 연속 실패 횟수 */

    if (button != HMI_FAIL) { fail = 0; return; }       /* 응답 옴 */
    fail++;
    if (fail == HMI_FAIL_MAX) alarm_go(0, 1);           /* 한 번만 */
}

void A_02(int rack) { alarm_go(rack, 2); }      /* X 모터 (드라이브 알람 : 내일) */
void A_03(int rack) { alarm_go(rack, 3); }      /* Y 모터 */
void A_04(int rack) { alarm_go(rack, 4); }      /* 틸트 모터 */

/* 05 X 위치 : 출발(start)하고 10초 지났는데 도착 못 했으면 알람. 걸면 1 */
int A_05(uint32_t start, int arrived)
{
    if (arrived == 1 || osKernelGetTickCount() - start <= MOVE_MS) return 0;
    alarm_go(0, 5);
    return 1;
}

/* 06 Y 위치 : 05 와 같음 */
int A_06(uint32_t start, int arrived)
{
    if (arrived == 1 || osKernelGetTickCount() - start <= MOVE_MS) return 0;
    alarm_go(0, 6);
    return 1;
}

/* 07 틸트 위치 : 05 와 같음 */
int A_07(uint32_t start, int arrived)
{
    if (arrived == 1 || osKernelGetTickCount() - start <= MOVE_MS) return 0;
    alarm_go(0, 7);
    return 1;
}

void A_08(int rack) { alarm_go(rack, 8); }      /* 안전센서 (센서 없음) */
void A_09(int rack) { alarm_go(rack, 9); }      /* 비상정지 */

/* 10 원점 : 원점 시작 전 위치(far)가 200mm 넘게 떨어져 있었는데 시작(start)하고 2초 안에 닿음 = 가는 길에 걸림. 걸면 1 */
int A_10(int32_t far, uint32_t start)
{
    if (far <= HOME_NEAR_MM && far >= -HOME_NEAR_MM) return 0;          /* 원점 근처였음 (켠 직후 0 도 여기) */
    if (osKernelGetTickCount() - start >= HOME_FAST_MS) return 0;       /* 시간 걸려서 닿음 : 정상 */
    alarm_go(0, 10);
    return 1;
}

/* 알람 풀기 : 번호만 지움 (상태는 RESET 이 초기상태로, PC 는 원점 완료로 앎) */
void Alarm_Clear(void)
{
    alarm_1 = 0;
    alarm_2 = 0;
    alarm_3 = 0;
    alarm_4 = 0;
}
