/*
 * status.c
 *
 *  Created on: Sep 17, 2026
 *      Author: HWNOT
 *
 * 렉 수 = FS rack_channel (1 ~ 4). 칸은 4개까지 있고, 렉 수만큼만 PC · HMI 로 나간다.
 * "모두" (원점 · 초기상태 · 알람 · 풀기 · 렉 0) 는 1 ~ 4 를 같이 바꿈 → 안 쓰는 렉도 같은 상태라 조건이 안 꼬임
 */
#include "status.h"
#include "main.h"
#include "event.h"
#include <stdio.h>
#include "run.h"
#include "net.h"
#include "debug.h"
#include "alarm.h"
#include "save.h"
#include "buzzer.h"

/* 전원 켜지면 모두 초기상태 */
char status_1 = RESTART;
char status_2 = RESTART;
char status_3 = RESTART;
char status_4 = RESTART;

volatile char pause_why = 0;    /* M = STOP 버튼/S 명령, F = 만재, S = 카드 없음, T = 틸트 */
volatile int pause_event_on;         /* 1 = 보낼 일시정지 이벤트 있음 */

/* 대기 */
void Status_WAIT(int rack)
{
    if (rack == 1) status_1 = WAIT;
    if (rack == 2) status_2 = WAIT;
    if (rack == 3) status_3 = WAIT;
    if (rack == 4) status_4 = WAIT;
}

/* 이동 (일시정지였으면 풀림) */
void Status_RUN(int rack)
{
    if (rack == 1) status_1 = RUN;
    if (rack == 2) status_2 = RUN;
    if (rack == 3) status_3 = RUN;
    if (rack == 4) status_4 = RUN;
    pause_why = 0;                                       /* 일시정지 아님 */
}

/* 원점 : 기계 전체라 모두 */
void Status_HOME(void)
{
    status_1 = HOME;
    status_2 = HOME;
    status_3 = HOME;
    status_4 = HOME;
}

/* 일시정지 : 렉 1 ~ 4 / 0 = 모두, 이유(M 사용자 F 만재 S 카드 T 틸트) + PC 로 PPAUSE. 알람이면 안 바꿈 */
void Status_PAUSE(int rack, char why)
{
    if (status_1 == ALARM) return;                       /* 알람을 일시정지로 덮어쓰지 않음 */
    if (rack == 1 || rack == 0) status_1 = PAUSE;
    if (rack == 2 || rack == 0) status_2 = PAUSE;
    if (rack == 3 || rack == 0) status_3 = PAUSE;
    if (rack == 4 || rack == 0) status_4 = PAUSE;
    pause_why = why;                                     /* 일시정지 중 + 이유 (0 = 일시정지 아님) */
    pause_event_on = 1;                                  /* PC 로 PPAUSE:이유 */
    Buzzer_On();                                         /* 일시정지 = 이유 상관없이 부저 (M · F · S · T) */
}

/* 일시정지 풀기 : 일시정지인 렉만 대기로 */
void Status_Resume(void)
{
    if (status_1 == PAUSE) status_1 = WAIT;
    if (status_2 == PAUSE) status_2 = WAIT;
    if (status_3 == PAUSE) status_3 = WAIT;
    if (status_4 == PAUSE) status_4 = WAIT;
    pause_why = 0;                                       /* 일시정지 아님 */
    Log_Debug(LOG_CLEAR);                                /* HMI RUN · PC D 로 풀림 */
    Buzzer_Off();                                        /* 일시정지 부저 끔 */
}

/* 초기상태 : RESET 버튼, 모두 (RUN 누르면 원점) */
void Status_INIT(void)
{
    status_1 = RESTART;
    status_2 = RESTART;
    status_3 = RESTART;
    status_4 = RESTART;
}

/* 알람 : 긴급정지, 모두 */
void Status_Alarm(void)
{
    status_1 = ALARM;
    status_2 = ALARM;
    status_3 = ALARM;
    status_4 = ALARM;
}

/* 렉 상태 한 칸 : W, R, I, P / 알람이면 A_05 */
static void rack_text(char *b, int size, char status, int alarm)
{
    if (status == ALARM)
        snprintf(b, size, "A_%02d", alarm);
    else
        snprintf(b, size, "%c", status);
}

/* 프로토콜 글자 (C 대답) : 렉 수(rack_channel)만큼 S_1_W&S_2_A_03&S_3_W … */
void Status_Text(char *b, int size)
{
    char r[8];
    int len;

    rack_text(r, sizeof(r), status_1, alarm_1);                          /* 렉 1 */
    len = snprintf(b, size, "S_1_%s", r);

    if (save.fs.rack_channel >= 2) {                                     /* 렉 2 */
        rack_text(r, sizeof(r), status_2, alarm_2);
        len += snprintf(b + len, size - len, "&S_2_%s", r);
    }
    if (save.fs.rack_channel >= 3) {                                     /* 렉 3 */
        rack_text(r, sizeof(r), status_3, alarm_3);
        len += snprintf(b + len, size - len, "&S_3_%s", r);
    }
    if (save.fs.rack_channel >= 4) {                                     /* 렉 4 */
        rack_text(r, sizeof(r), status_4, alarm_4);
        snprintf(b + len, size - len, "&S_4_%s", r);
    }
}

/* PC 로 일시정지 (Comm_Task) : Status_PAUSE 가 걸었으면(pause_event_on) PPAUSE:M · F · S · T */
void Status_PC(void)
{
    char b[16];

    if (pause_event_on == 0) return;                     /* 보낼 것 없음 */
    pause_event_on = 0;                                  /* 보내기 전에 0 */
    snprintf(b, sizeof(b), "PPAUSE:%c", pause_why);
    send_event(b);
}

