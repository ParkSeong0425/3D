/*
 * status.c
 *
 *  Created on: Sep 17, 2026
 *      Author: HWNOT
 */
#include "status.h"
#include "main.h"
#include "event.h"
#include <stdio.h>
#include "run.h"

/* 전원 켜지면 둘 다 초기상태 */
char status_1 = RESTART;
char status_2 = RESTART;

volatile char pause_why = 0;    /* M = STOP 버튼/S 명령, F = 만재, S = 카드 없음 */
volatile int pause_event_on;         /* 1 = 보낼 일시정지 이벤트 있음 */

/* 대기 */
void Status_WAIT(int rack)
{
    if (rack == 1) status_1 = WAIT;
    if (rack == 2) status_2 = WAIT;
}

/* 이동 */
void Status_RUN(int rack)
{
    if (rack == 1) status_1 = RUN;
    if (rack == 2) status_2 = RUN;
}

/* 원점 : 기계 전체라 두 렉 모두 */
void Status_HOME(void)
{
    status_1 = HOME;
    status_2 = HOME;
}

/* 일시정지 */
void Status_PAUSE(int rack)
{
    if (rack == 1) status_1 = PAUSE;
    if (rack == 2) status_2 = PAUSE;
}

/* 일시정지 풀기 : 일시정지인 렉만 대기로 */
void Status_Resume(void)
{
    if (status_1 == PAUSE) status_1 = WAIT;
    if (status_2 == PAUSE) status_2 = WAIT;
}

/* 초기상태 : RESET 버튼, 두 렉 모두 (RUN 누르면 원점) */
void Status_INIT(void)
{
    status_1 = RESTART;
    status_2 = RESTART;
}

/* 알람 : 긴급정지, 두 렉 모두 */
void Status_Alarm(void)
{
    status_1 = ALARM;
    status_2 = ALARM;
}

