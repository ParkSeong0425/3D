/*
 * status.c : 기계 상태 (FSM) + 멈춤
 *
 *  로봇은 한 대라 상태도 하나 (state.now 글자). 글자 뜻은 status.h 맨 위
 *  상태는 보여 주기 + 문지기. 모터를 실제로 세우는 건 : 멈춤 = run.c 정지선 (while 'S'), 알람 = E_S
 *
 *  ── 상태가 바뀌는 곳 (state.now = 글자 를 쓰는 곳) ──
 *   'I' 초기상태   켤 때 (처음 값) · RESET (alarm.c Alarm_Clear) · 수동 끄기 (전 상태가 'I') · 시작 (수동 중, 전 'I')
 *   'H' 원점중     원점 시작 (run.c motor_basic_init) ← 켤 때 자동 · 시작 버튼 · PC I
 *   'W' 대기       원점 끝 (run.c motor_basic_init) · AI · EO 승인 (cmd.c done_end) · 수동 끄기 (전 상태가 'W')
 *   'R' 운전       MI · MO · PO 시작 (run.c Motor_Run)
 *   'S' 멈춤       일시정지 버튼 · PC S ('M') · PO 만재 ('F') · 카드 없음 ('S') · 틸트 ('T') (status.c Pause_Set)
 *   (멈춤 풀림)    시작 버튼 (event.c btn_run) · PC D (만재만) · 카드 들어옴 (run.c po_stop) → 전 상태 (status.c Pause_Clear)
 *   'M' 수동       수동 버튼 (event.c btn_manual) : 대기 · 초기상태에서만
 *   'E' 긴급정지   눌림 (alarm.c A_09)  → 풀림 (event.c estop_event) → 'A'
 *   'A' 알람       알람 01 ~ 12 (alarm.c alarm_go)
 *
 *  ── 버튼 하나 = 일 하나 ──
 *   RESET   alarm.c   Alarm_Clear   무엇이든 처음으로 (→ 'I'). 안 됨 : 'E' · 'R' · 'H' · 운전 중 멈춤
 *   시작     event.c   btn_run       'I' → 원점 / 'S' → 이어서 (그 칸 아직 만재면 X) / 'M'(전 'I') → 수동 끄고 원점
 *   수동     event.c   btn_manual    'W' · 'I' → 'M' / 'M' → 전 상태
 *   PC 명령  run.c     Motor_Request 'W' : 원점 · MI · MO · PO / 'I' : 원점만 / 'R' : MI · MO · PO 만 (MO 뒤 PO)
 *
 *  ── 모터가 움직여도 되나 (문 두 개) ──
 *   문 1  run.c      Motor_Request   명령 받기 전 (한 번) : 위 표 + 동작 중(큐 참) → NAK
 *   문 2  status.c   Motor_Stop      움직임 한 번마다 : 'E' · 'A' 면 안 움직임 (모터 파일 움직임 함수 맨 앞)
 */
#include "status.h"
#include "alarm.h"
#include "event.h"
#include "net.h"
#include "buzzer.h"
#include "manjae.h"
#include "debug.h"
#include "flag.h"
#include "main.h"
#include <stdio.h>

volatile STATE state = { 'I' };         /* 켜지면 'I' (Comm_Task 가 바로 원점 주문 → 'H') */


/* 문 2 : 1 = 지금 모터 움직이면 안 됨 (긴급정지 'E' · 알람 'A')
   모터 파일 움직임 함수 · 도착 기다림이 맨 앞에서 부름 → 규칙을 바꿀 땐 여기만 */
int Motor_Stop(void)
{
    return state.now == 'E' || state.now == 'A';
}

/* 멈춤 걸기 : 운전 'R' · 대기 'W' 에서 → 'S' (이미 'S' 면 이유만 바꿈). 그 밖 ('I' 'H' 'M' 'E' 'A') 은 안 함
   모터는 안 세움 → Motor_Task 가 정지선(run.c while 'S')에서 섬. 대기에서 멈추면 시작 누를 때까지 PC 명령 안 받음 */
void Pause_Set(int rack, char why)
{
    uint8_t task_copy = PC_PAUSE;                       /* 주문서 : 일시정지 */

    if (state.now == 'R' || state.now == 'W') {         /* 운전 · 대기 → 멈춤 */
        state.prev = state.now;                         /*   풀면 돌아갈 곳 */
        state.now = 'S';
    }
    if (state.now == 'S') {                             /* 멈춤 : 이유 + 알림 */
        state.why = why;
        osMessageQueuePut(CommQueueHandle, &task_copy, 0, 0);   /* PC 로 PPAUSE → Comm_Task (Status_PC) */
        Buzzer_On();
        Log_Debug(LOG_PAUSE_SET, why, rack);            /* PAUSE F rack 1 */
    }
}

/* 멈춤 풀기 : 'S' 면 전 상태로 → 정지선에서 기다리던 Motor_Task 가 이어서 + 부저 끔 + 로그 */
void Pause_Clear(void)
{
    if (state.now == 'S') {
        state.why = 0;
        state.now = state.prev;
        Buzzer_Off();
        Log_Debug(LOG_CLEAR);
    }
}

/* 렉 하나 상태 글자 (PC 프로토콜 : I · W · R · P · F). 위에서부터 맞으면 끝 */
static char rack_letter(int r)
{
    char now = state.now;
    int mine = (state.rack == r);                                   /* 로봇이 이 렉 일을 하는 중 */

    if (now == 'S' && (state.why == 'M' || mine)) {                 /* 이 렉 멈춤 (일시정지 'M' 은 모든 렉) */
        if (state.why == 'F') return 'F';                           /*   만재 */
        return 'P';                                                 /*   그 밖 */
    }
    if (now == 'S' || now == 'M') now = state.prev;                 /* 다른 렉 멈춤 · 수동 : 전 상태 글자로 */
    if (now == 'R' && mine) return 'R';
    if (now == 'I' || now == 'H') return 'I';                       /* 원점 전 · 원점 중 = I */
    return 'W';                                                     /* 대기 · 다른 렉 운전 중 */
}

/* PC C 대답 글자 (렉 2개) : S_1_W&S_2_R  /  긴급정지 · 알람이면  S_1_A_05&S_2_A_05
   렉 3 · 4 장비가 생기면 이 두 줄에 S_3 · S_4 를 붙임 */
void Status_Text(char *b, int size)
{
    if (Motor_Stop()) snprintf(b, size, "S_1_A_%02d&S_2_A_%02d", state.alarm, state.alarm);   /* 알람 */
    else              snprintf(b, size, "S_1_%c&S_2_%c", rack_letter(1), rack_letter(2));   /* 그 밖 */
}

/* PC 로 일시정지 (Comm_Task) : 'P' 받으면 PPAUSE: M · F · S · T (cmd.c CMD_Event 가 부름)
   만재(F)면 어느 칸인지 FF 먼저 (프로토콜 : 투입 금지 셀의 분배 명령 발생시 이벤트 송신) */
void Status_PC(void)
{
    char b[32];

    if (state.why == 'F') {                             /* 만재로 멈춤 : FF_1_0010&F_2_0000 */
        b[0] = 'F';
        Manjae_check_text(b + 1, sizeof(b) - 1);        /* 만재 글자는 manjae.c */
        send_event(b);
    }
    snprintf(b, sizeof(b), "PPAUSE: %c", state.why);   /* 콜론 뒤 공백 (문서 · 사수 : PPAUSE: F) */
    send_event(b);
}
