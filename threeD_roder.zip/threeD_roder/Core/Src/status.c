/*
 * status.c : 기계 상태 + 일시정지
 *
 *  로봇은 한 대라 상태도 하나 (status). 렉마다 다른 건 "어느 렉이 운전 중인지(run_rack)" 와 "어느 렉이 일시정지인지(pause_rack)" 뿐.
 *  상태는 보여 주기용 (HMI · 램프 · PC C). 모터를 세우는 건 상태가 아님 : 일시정지 = run.c 정지선, 알람 = E_S
 *
 *  상태 바꾸는 곳
 *   I  켤 때 (처음 값) · 원점 시작 (run.c motor_basic_init) · RESET (alarm.c Alarm_Clear)
 *   W  원점 끝 (run.c) · MI · PO 완료 끝 (cmd.c done_end : ANS_1 = PC 승인 때 / ANS_0 = 바로. MO 는 R 그대로)
 *   R  MI · MO · PO 시작 (run.c Motor_Run)
 *   A  알람 (alarm.c alarm_go) · 긴급정지 풀림 (event.c)
 *
 *  "지금 해도 되나" 확인은 그 일을 하는 블록 맨 앞에 (안 되면 return)
 *   일시정지   status.c  Pause_Set       알람 · 원점 X / STOP(M) 은 운전 중일 때만
 *   RESET     alarm.c   Alarm_Clear     긴급정지 · 운전 · 원점 X
 *   HMI RUN   event.c   btn_run         원점(I) 이면 원점 / 일시정지면 풀기 (PO 가 선 칸이 아직 만재면 X)
 *   HMI 수동   event.c   btn_manual      대기 · 알람 02 ~ 07 · 10
 *   PC 명령    cmd.c     CMD_Run         수동 X
 *              run.c     Motor_Request   하는 중(busy) · 알람 X / 원점(I) 중엔 원점만
 */
#include "status.h"
#include "alarm.h"
#include "net.h"
#include "buzzer.h"
#include "manjae.h"
#include "debug.h"
#include <stdio.h>

volatile char status = HOME;        /* 켜지면 I → 원점 끝나면 W */
volatile int  run_rack;             /* 운전 중인 렉 */
volatile char pause_why;            /* 일시정지 이유, 0 = 아님 */
volatile int  pause_rack;           /* 일시정지 렉, 0 = 모두 */
static volatile int pause_event_on; /* 1 = PC 로 PPAUSE 보낼 것 있음 (Pause_Set 켬 → Status_PC 보내고 끔) */


/* 일시정지 걸기 : 이유 + PC PPAUSE + 부저 + 로그. 상태(status)는 그대로 → 풀면 저절로 원래대로
   모터는 안 세움 → Motor_Task 가 정지선(run.c pause_wait)에서 섬 */
void Pause_Set(int rack, char why)
{
    if (status == ALARM || status == HOME) return;      /* 알람 · 원점 중엔 안 함 */
    if (why == 'M' && status != RUN) return;            /* STOP 은 운전 중일 때만 (서 있으면 무시) */

    pause_why = why;                                    /* 일시정지 중 + 이유 */
    pause_rack = rack;                                  /* 어느 렉 (0 = 모두) */
    pause_event_on = 1;                                 /* PC 로 PPAUSE (Status_PC) */
    Buzzer_On();
    Log_Debug(LOG_PAUSE_SET, why, rack);                /* PAUSE F rack 1 */
}

/* 일시정지 풀기 : pause_why 0 → 정지선에서 기다리던 Motor_Task 가 이어서 + 부저 끔 + 로그 */
void Pause_Clear(void)
{
    pause_why = 0;
    Buzzer_Off();
    Log_Debug(LOG_CLEAR);
}

/* 렉 하나 상태 글자 (위에서부터 맞으면 끝) */
static char rack_letter(int r)
{
    int paused = pause_why && (pause_rack == r || pause_rack == 0);    /* 이 렉 일시정지 중 */

    if (paused && pause_why == 'F')     return 'F';     /* 만재 일시정지 */
    if (paused)                         return 'P';     /* 그 밖 일시정지 */
    if (status == RUN && run_rack == r) return 'R';     /* 로봇이 이 렉 일을 하는 중 */
    if (status == RUN)                  return 'W';     /* 로봇이 다른 렉 일을 하는 중 → 이 렉은 대기 */
    return status;                                      /* I 원점 · W 대기 */
}

/* PC C 대답 글자 (렉 2개) : S_1_W&S_2_R  /  알람이면  S_1_A_05&S_2_A_05
   렉 3 · 4 장비가 생기면 이 두 줄에 S_3 · S_4 를 붙임 */
void Status_Text(char *b, int size)
{
    if (status == ALARM) snprintf(b, size, "S_1_A_%02d&S_2_A_%02d", alarm_no, alarm_no);   /* 알람 */
    else                 snprintf(b, size, "S_1_%c&S_2_%c", rack_letter(1), rack_letter(2)); /* 그 밖 */
}

/* PC 로 일시정지 (Comm_Task) : 걸렸으면(pause_event_on) PPAUSE: M · F · S · T
   만재(F)면 어느 칸인지 FF 먼저 (프로토콜 : 투입 금지 셀의 분배 명령 발생시 이벤트 송신) */
void Status_PC(void)
{
    char b[32];

    if (pause_event_on == 0) return;                    /* 보낼 것 없음 */
    pause_event_on = 0;                                 /* 보내기 전에 0 */
    if (pause_why == 'F') {                             /* 만재로 멈춤 : FF_1_0010&F_2_0000 */
        b[0] = 'F';
        Manjae_check_text(b + 1, sizeof(b) - 1);        /* 만재 글자는 manjae.c */
        send_event(b);
    }
    snprintf(b, sizeof(b), "PPAUSE: %c", pause_why);   /* 콜론 뒤 공백 (문서 · 사수 : PPAUSE: F) */
    send_event(b);
}
