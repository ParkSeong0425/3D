/*
 * status.c
 *
 *  Created on: Sep 17, 2026
 *      Author: HWNOT
 *
 * 렉 수 = FS rack_channel (1 ~ 4). 칸은 4개까지 있고, 렉 수만큼만 PC · HMI 로 나간다.
 * "모두" (원점 · 초기상태 · 알람 · 풀기 · 렉 0) 는 1 ~ 4 를 같이 바꿈 → 안 쓰는 렉도 같은 상태라 조건이 안 꼬임
 */
#include "status.h"
#include "main.h"
#include "event.h"
#include <stdio.h>
#include "run.h"

/* 전원 켜지면 모두 초기상태 */
char status_1 = RESTART;
char status_2 = RESTART;
char status_3 = RESTART;
char status_4 = RESTART;

volatile char pause_why = 0;    /* M = STOP 버튼/S 명령, F = 만재, S = 카드 없음, T = 틸트 */
volatile int pause_event_on;         /* 1 = 보낼 일시정지 이벤트 있음 */

/* 대기 */
void Status_WAIT(int rack)
{
    if (rack == 1) status_1 = WAIT;
    if (rack == 2) status_2 = WAIT;
    if (rack == 3) status_3 = WAIT;
    if (rack == 4) status_4 = WAIT;
}

/* 이동 */
void Status_RUN(int rack)
{
    if (rack == 1) status_1 = RUN;
    if (rack == 2) status_2 = RUN;
    if (rack == 3) status_3 = RUN;
    if (rack == 4) status_4 = RUN;
}

/* 원점 : 기계 전체라 모두 */
void Status_HOME(void)
{
    status_1 = HOME;
    status_2 = HOME;
    status_3 = HOME;
    status_4 = HOME;
}

/* 일시정지 : 렉 1 ~ 4 / 0 = 모두 */
void Status_PAUSE(int rack)
{
    if (rack == 1 || rack == 0) status_1 = PAUSE;
    if (rack == 2 || rack == 0) status_2 = PAUSE;
    if (rack == 3 || rack == 0) status_3 = PAUSE;
    if (rack == 4 || rack == 0) status_4 = PAUSE;
}

/* 일시정지 풀기 : 일시정지인 렉만 대기로 */
void Status_Resume(void)
{
    if (status_1 == PAUSE) status_1 = WAIT;
    if (status_2 == PAUSE) status_2 = WAIT;
    if (status_3 == PAUSE) status_3 = WAIT;
    if (status_4 == PAUSE) status_4 = WAIT;
}

/* 초기상태 : RESET 버튼, 모두 (RUN 누르면 원점) */
void Status_INIT(void)
{
    status_1 = RESTART;
    status_2 = RESTART;
    status_3 = RESTART;
    status_4 = RESTART;
}

/* 알람 : 긴급정지, 모두 */
void Status_Alarm(void)
{
    status_1 = ALARM;
    status_2 = ALARM;
    status_3 = ALARM;
    status_4 = ALARM;
}

