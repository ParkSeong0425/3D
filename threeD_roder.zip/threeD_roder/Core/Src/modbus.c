/*
 * modbus.c : 모터 글 모양 (Modbus RTU) — i · a · t_motor 가 같이 씀 (11/23 : 세 파일에 따로 있던 crc16 · read_reg · read_regs 를 하나로)
 *
 *  MB_Crc    CRC16 계산 (쓰기 · 읽기 글 끝 2바이트)
 *  MB_Read   FC03 읽기 : [ID][03][reg H][reg L][00][qty][CRC L][CRC H] → 대답 [ID][03][qty×2][데이터 …][CRC L][CRC H]
 *
 *  32비트 값을 두 칸으로 나누는 순서 (위 칸 먼저 / 아래 칸 먼저) 는 드라이브마다 달라서 모터 파일이 정함
 */
#include "modbus.h"
#include "usart.h"          /* UART2_Xfer (선 · 열쇠 · DMA) */

/* CRC16 Modbus : 0xFFFF 에서 시작, 바이트마다 8번 밀면서 0xA001 로 섞음 */
uint16_t MB_Crc(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;

    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 1) crc = (crc >> 1) ^ 0xA001;     /* 맨 아래 비트 1 : 밀고 섞음 */
            else         crc = crc >> 1;                /* 0 : 밀기만 */
        }
    }
    return crc;
}

/* FC03 읽기 : 성공 1 / tries 번 다 실패 0 (대답 없음 · 길이 · ID · 기능 · CRC 중 하나라도 틀림) */
int MB_Read(uint8_t id, uint16_t reg, uint8_t qty, uint16_t *out, uint8_t tries, uint32_t wait_ms)
{
    uint8_t tx[8], rx[32];
    uint16_t n = 5 + qty * 2;                           /* 대답 길이 : ID 기능 길이 + 데이터 qty×2 + CRC 2 */
    uint16_t crc;

    tx[0] = id;          tx[1] = 0x03;                  /* 1. 물음 만들기 */
    tx[2] = reg >> 8;    tx[3] = (uint8_t)reg;
    tx[4] = 0;           tx[5] = qty;
    crc = MB_Crc(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);  /*    CRC 만 작은 바이트 먼저 */

    for (uint8_t retry = 0; retry < tries; retry++) {
        if (UART2_Xfer(tx, 8, rx, n, wait_ms) == 0) continue;          /* 2. 묻고 받기 (안 오면 다시) */
        crc = MB_Crc(rx, n - 2);
        if (rx[0] == id && rx[1] == 0x03 && rx[2] == qty * 2           /* 3. 검사 : 누가 · 무슨 기능 · 길이 */
                && rx[n - 2] == (uint8_t)crc && rx[n - 1] == (uint8_t)(crc >> 8)) {   /*    CRC */
            for (uint8_t i = 0; i < qty; i++)
                out[i] = ((uint16_t)rx[3 + i * 2] << 8) | rx[4 + i * 2];   /* 4. 칸마다 큰 바이트 먼저 */
            return 1;
        }
    }
    return 0;
}
