/*
 * buzzer.c : 부저 켜기 / 끄기만 (DO9 = PD0, 부저가 스스로 삐 · 삐 끊어서 울림)
 *
 *  켜기 : 원점 시작 (cmd.c) · 알람 (alarm.c alarm_go) · PC B_1_1
 *  끄기 : 원점 성공 (cmd.c) · RESET · 음소거 (event.c) · PC B_1_0
 */
#include "buzzer.h"
#include "main.h"

/* 부저 켬 */
void Buzzer_On(void)
{
    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET);
}

/* 부저 끔 */
void Buzzer_Off(void)
{
    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
}
