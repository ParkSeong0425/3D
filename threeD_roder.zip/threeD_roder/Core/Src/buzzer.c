/*
 * buzzer.c : 부저 켜기 / 끄기만 (DO9 = PD0, 부저가 스스로 삐 · 삐 끊어서 울림)
 *
 *  켜기 : 원점 시작 (cmd.c) · 알람 (alarm.c alarm_go) · PC B_1_1
 *  끄기 : 원점 성공 (cmd.c) · RESET · 음소거 (event.c) · PC B_1_0
 *  Buzzer_Cmd : PC 부저 명령 글자 B_렉_1/0 (cmd.c 가 부름)
 */
#include "buzzer.h"
#include "main.h"
#include "save.h"
#include <stdio.h>

/* 부저 켬 */
void Buzzer_On(void)
{
    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET);
}

/* 부저 끔 */
void Buzzer_Off(void)
{
    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
}

/* PC 부저 명령 : B_렉_1 켬 / B_렉_0 끔 — 부저가 하나라 렉 번호는 확인만. 맞으면 1 / 틀리면 0 */
int Buzzer_Cmd(char *s)
{
    int rack, on;

    if (sscanf(s, "B_%d_%d", &rack, &on) != 2 || rack < 1 || rack > save.fs.rack_channel || on < 0 || on > 1)
        return 0;
    if (on == 1) Buzzer_On();
    else         Buzzer_Off();
    return 1;
}
