/*
 * net.c : W6100 (SPI4) 로 TCP 서버 — 포트 3개 = W6100 소켓 3개, 소켓 하나에 연결 하나
 *  ── W6100 라이브러리 함수 (socket.h · w6100.h · wizchip_conf.h) ──
 *   켤 때     reg_wizchip_cs_cbfunc / reg_wizchip_spi_cbfunc : 우리 SPI 함수를 라이브러리에 알려 줌
 *             getCIDR / getVER   : 칩 이름 · 버전 (0x6100 · 0x4661 이면 W6100)
 *             wizchip_init       : 소켓마다 보내기 · 받기 칸 크기 (8개 × 2KB = 16KB + 16KB)
 *             NETUNLOCK          : 네트워크 설정 레지스터 잠금 풀기
 *             wizchip_setnetinfo : IP · 서브넷 · 게이트웨이 · MAC 쓰기
 *             setSIMR            : INT 핀을 0 으로 만들 소켓 고르기 (0x07 = 소켓 0 · 1 · 2)
 *             setSn_IMR          : 그 소켓의 어떤 일에 INT 핀을 0 으로 (0x0F = CON · DISCON · RECV · TIMEOUT)
 *   소켓 열기 socket             : CLOSED → INIT
 *             listen             : INIT → LISTEN (PC 접속 기다림)
 *             disconnect         : 상대에게 FIN 보내고 닫힐 때까지 기다림 (대답 없으면 TIMEOUT)
 *             setSn_RCR          : 대답 없을 때 다시 보낼 횟수 (열기 전에)
 *             setSn_KPALVTR      : keep-alive — 5초 단위로 조용하면 상대에게 확인 (열고 나서)
 *             getSn_SR           : 소켓 상태 (CLOSED · INIT · LISTEN · ESTABLISHED 연결됨 · CLOSE_WAIT 상대가 끊음)
 *   일 알기   getSn_IR           : 그 소켓에 생긴 일 비트 (CON 0x01 · DISCON 0x02 · RECV 0x04 · TIMEOUT 0x08 · SENDOK 0x10)
 *             setSn_IRCLR        : 그 비트 끄기 (안 끄면 INT 핀이 계속 0)
 *   주고받기  getSn_RX_RSR       : 받기 칸에 온 글자 수
 *             recv               : 받기 칸에서 글자 꺼내기
 *             getSn_TX_FSR       : 보내기 칸에 남은 자리
 *             send               : 보내기 (앞에 보낸 것의 SENDOK 까지 기다림)
 *   랜선      wizphy_getphylink  : 보드 랜선 꽂힘 PHY_LINK_ON / 빠짐 PHY_LINK_OFF
 */
#include "net.h"
#include "save.h"
#include "cmd.h"
#include "spi.h"
#include "wizchip_conf.h"
#include "socket.h"
#include "cmsis_os2.h"
#include "rfid.h"
#include "alarm.h"
#include "status.h"
#include "manjae.h"
#include "buzzer.h"
#include "lamp.h"
#include "debug.h"
#include "flag.h"
#include "main.h"
#include <stdio.h>
#include <string.h>

#define NET_SPI         hspi4
#define TCP_SOCK        0       /* 작업 : 소켓 0번 (포트는 FI 5) */
#define Service_SOCK    1       /* 서비스 : 소켓 1번 */
#define Service_PORT    58080   /*          포트 */
#define LOG_SOCK        2       /* 로그 : 소켓 2번 */
#define LOG_PORT        50001   /*        포트 */
#define PHY_MS          100     /* 랜선 · FI 7 시간 확인 간격 (SPI 아끼기) */

volatile int tcp_on;        /* 1 = PC 와 연결됨 (2500) */
static volatile int service_on;     /* 1 = 노트북 58080 연결됨 */
static volatile int log_on;         /* 1 = 노트북 50001 연결됨 */
static uint32_t last;       /* 마지막으로 PC 명령 받은 시각 */
static int unplug;          /* 1 = 연결 중에 보드 랜선 뽑혔었음 (tcp_port · Net_On_Off 가 같이 씀) */
static int number;          /* PC 가 마지막에 보낸 번호 (00 ~ 99) : 대답 · 이벤트 · 완료응답에 그대로 붙임 */

static uint16_t net_port;       /* FI 5 포트 (켤 때 복사 → 재부팅 후 적용) */
static uint8_t net_mode;        /* FI 6 0 서버 / 1 클라이언트 */
static uint32_t net_timeout;    /* FI 7 명령 없으면 끊는 시간 ms (10000 ~ 60000, 기본 20000) */

/* 네트워크 값 : IP · 서브넷 · 게이트웨이는 NET_Init 이 FRAM(FI)에서 채움. MAC 은 임시 (나중에 24AA02E48 에서) */
static wiz_NetInfo net_info = {
    .mac = {0x02, 0x00, 0x00, 0x00, 0x00, 0x01},
    .ipmode = NETINFO_STATIC_V4
};

/* Hardware NSS: SPI enable -> NSS LOW */
static void cs_on(void)
{
    __HAL_SPI_ENABLE(&NET_SPI);
}

/* Hardware NSS: SPI disable -> NSS released HIGH by pull-up */
static void cs_off(void)
{
    while (__HAL_SPI_GET_FLAG(&NET_SPI, SPI_FLAG_BSY));
    __HAL_SPI_DISABLE(&NET_SPI);
}

/* SPI 1 byte read */
static uint8_t spi_rb(void)
{
    uint8_t tx = 0xFF;
    uint8_t rx = 0;

    HAL_SPI_TransmitReceive(&NET_SPI, &tx, &rx, 1, 100);
    return rx;
}

/* SPI 1 byte write */
static void spi_wb(uint8_t data)
{
    HAL_SPI_Transmit(&NET_SPI, &data, 1, 100);
}

/* SPI buffer read */
static void spi_rbuf(uint8_t *buf, datasize_t len)
{
    for (datasize_t i = 0; i < len; i++)
        buf[i] = spi_rb();
}

/* SPI buffer write */
static void spi_wbuf(uint8_t *buf, datasize_t len)
{
    if (len > 0)
        HAL_SPI_Transmit(&NET_SPI, buf, (uint16_t)len, 1000);
}

/* W6100 hardware reset */
static void w610_reset(void)
{
    HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_RESET);
    osDelay(10);

    HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_SET);
    osDelay(100);
}


/* ======================= 공통 ======================= */

/* PC 가 세 포트 중 하나라도 연결돼 있으면 1 (아무 태스크 : 변수만 읽음, SPI 안 씀)
   완료응답(cmd.c)만 씀 : 58080 으로 시험할 때도 승인 기다리게. 램프 · 부저는 2500(tcp_on)만 봄 */
int PC_On(void)
{
    return tcp_on || service_on || log_on;
}

/* 포트 연결 순간 (on = 그 포트 표시 : &tcp_on · &service_on · &log_on)
   2500 이면 램프 기억 지우고 부저 끔 → 이제 램프 · 부저는 PC 가 (알람 부저는 보드 그대로). 58080 · 50001 은 표시만 */
static void pc_join(volatile int *on)
{
    if (on == &tcp_on) {                        /* 2500 (상위 PC) */
        Lamp_Clear();                           /* 꺼진 상태에서 PC 가 LL 로 새로 */
        if (Motor_Stop() == 0) Buzzer_Off();    /* 알람 · 긴급정지 부저는 보드 그대로 */
    }
    *on = 1;
}

/* 포트 끊긴 순간 : 2500 이면 램프 · 부저가 보드 담당으로 → 알람 · 일시정지 · 만재 알림 중이면 부저 다시 */
static void pc_leave(volatile int *on)
{
    *on = 0;
    if (on == &tcp_on && (Motor_Stop() || state.now == 'S' || manjae_1 || manjae_2)) Buzzer_On();
}

/* 소켓 열어 두기 : 한 번 부르면 LISTEN(PC 접속 기다림)까지
   2500 = 빨리 알아채기 (대답 없으면 2번만 다시 보냄 · 5초마다 살아 있나 → 약 6~7초에 닫힘)
   58080 · 50001 = 안 끊기게 (다시 보내기 기본 8번 · 60초마다 살아 있나 → 노트북이 1분 넘게 사라졌을 때만 닫힘, 살아 있으면 절대 안 닫힘) */
static void net_open(uint8_t sock, uint16_t port)
{
    if (getSn_SR(sock) == SOCK_CLOSE_WAIT)          /* 상대가 끊었음 */
        disconnect(sock);                           /* 우리도 끊기 → CLOSED */

    if (getSn_SR(sock) == SOCK_CLOSED) {            /* 닫혀 있음 */
        setSn_RCR(sock, sock == TCP_SOCK ? 2 : 8);  /* 대답 없을 때 다시 보낼 횟수 (열기 전에 써야 함, 8 = W6100 기본) */
        socket(sock, Sn_MR_TCP4, port, 0);          /* 열기 → INIT */
        setSn_KPALVTR(sock, sock == TCP_SOCK ? 1 : 12);   /* 살아 있나 묻는 간격 (5초 단위) : 2500 5초 / 나머지 60초 */
    }

    if (getSn_SR(sock) == SOCK_INIT)                /* 열려 있음 */
        listen(sock);                               /* → LISTEN */
}

/* 소켓 하나의 일 읽기 : 그 소켓에 생긴 일 비트 (CON · DISCON · RECV · TIMEOUT) 를 돌려주고 바로 끔. INT 핀 1 이면 0 (SPI 안 함) */
static uint8_t port_doing(uint8_t sock)
{
    uint8_t doing;

    if (HAL_GPIO_ReadPin(W610_INT_GPIO_Port, W610_INT_Pin) == GPIO_PIN_SET) return 0; /* INT 핀 1 = 어느 소켓에도 일 없음 */

    doing = getSn_IR(sock) & 0x0F;                          /* CON · DISCON · RECV · TIMEOUT (SENDOK 는 send() 가 쓰는 것이라 안 건드림) */
    setSn_IRCLR(sock, doing);                               /* 읽은 비트 끄기 */
    return doing;
}


/* ======================= 켤 때 ======================= */

/* W6100 켜기 : FI 값 복사 → 리셋 → 칩 확인 → IP → INT 규칙 → 소켓 3개 열기. 성공 1 / 실패 0 */
int NET_Init(void)
{
    uint8_t size[8] = {2, 2, 2, 2, 2, 2, 2, 2};     /* 소켓마다 보내기 · 받기 칸 2KB */

    /* 저장된 네트워크 값 (FI) */
    memcpy(net_info.ip, save.fi.ip, 4);
    memcpy(net_info.sn, save.fi.sn, 4);
    memcpy(net_info.gw, save.fi.gw, 4);
    net_port = save.fi.port;
    net_mode = save.fi.mode;
    net_timeout = save.fi.timeout;

    reg_wizchip_cs_cbfunc(cs_on, cs_off);
    reg_wizchip_spi_cbfunc(spi_rb, spi_wb, spi_rbuf, spi_wbuf);
    w610_reset();

    if (getCIDR() != 0x6100 || getVER() != 0x4661) return 0;   /* W6100 아님 · SPI 안 됨 */
    if (wizchip_init(size, size) != 0) return 0;                /* 칸 크기 틀림 */

    NETUNLOCK();
    wizchip_setnetinfo(&net_info);

    /* INT 핀 : 소켓 0 · 1 · 2 의 CON · DISCON · RECV · TIMEOUT 만 (SENDOK 는 뺌) */
    setSIMR(0x07);
    setSn_IMR(TCP_SOCK, 0x0F);
    setSn_IMR(Service_SOCK, 0x0F);
    setSn_IMR(LOG_SOCK, 0x0F);

    /* 소켓 3개 열어 두기 (서버 모드만) */
    if (net_mode == 0) {
        net_open(TCP_SOCK, net_port);           /* 작업 */
        net_open(Service_SOCK, Service_PORT);   /* 서비스 */
        net_open(LOG_SOCK, LOG_PORT);           /* 로그 */
    }
    return 1;
}


/* ======================= 서비스 58080 (소켓 1) : 20초 끊기 없는 2500 + 오간 것 [TX] · [RX] 로 보여 줌 ======================= */

static void Socket_Line(uint8_t sock);              /* 아래 2500 칸에 있음 (service_port 가 먼저 써서 이름만 미리) */

/* [TX] PC → 로더 : 번호 + PC 가 보낸 명령  예) [TX] 08MI_1_1_2 (노트북 없거나 자리 없으면 안 보냄) */
static void Service_TX(int no, char *cmd)
{
    char n[3];                                      /* 번호 2글자 + 끝 */
    int len = strlen(cmd);

    if (getSn_SR(Service_SOCK) != SOCK_ESTABLISHED || getSn_TX_FSR(Service_SOCK) < len + 9)
        return;

    snprintf(n, sizeof(n), "%02d", no);
    send(Service_SOCK, (uint8_t *)"[TX] ", 5);
    send(Service_SOCK, (uint8_t *)n, 2);            /* 그 명령 번호 */
    send(Service_SOCK, (uint8_t *)cmd, len);        /* PC 가 보낸 내용 그대로 */
    send(Service_SOCK, (uint8_t *)"\r\n", 2);       /* 줄 바꿈 */
}

/* [RX] 로더 → PC : 로더가 보낸 대답 · 이벤트 그대로 (노트북 없거나 자리 없으면 안 보냄) */
static void Service_RX(uint8_t *buf, int len)
{
    if (getSn_SR(Service_SOCK) != SOCK_ESTABLISHED || getSn_TX_FSR(Service_SOCK) < len + 7)
        return;

    send(Service_SOCK, (uint8_t *)"[RX] ", 5);
    send(Service_SOCK, buf, len);                   /* 로더가 보낸 내용 그대로 */
    send(Service_SOCK, (uint8_t *)"\r\n", 2);       /* 줄 바꿈 */
}

/* 소켓 1 : 명령 받기 (2500 과 같음) / 노트북이 끊음 · 대답 없음 → 다시 LISTEN */
static void service_port(void)
{
    uint8_t doing = port_doing(Service_SOCK);                                     /* 이 소켓에 생긴 일 */
    if (doing & Sn_IR_CON)
        pc_join(&service_on);                                                     /* 연결 → 램프 · 부저 PC 가 */
    if (doing & Sn_IR_RECV)
        Socket_Line(Service_SOCK);
    if (doing & Sn_IR_DISCON)  Log_Debug("58080 closed by laptop");          /* 끊긴 이유 : 노트북이 끊음 */
    if (doing & Sn_IR_TIMEOUT) Log_Debug("58080 timeout (no answer)");       /*            노트북 대답 없음 */
    if (doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT)) {
        pc_leave(&service_on);
        net_open(Service_SOCK, Service_PORT);
    }
}


/* ======================= 로그 50001 (소켓 2) ======================= */

/* 소켓 2 (Comm_Task) : 노트북이 끊음 · 대답 없음 → 다시 LISTEN / 노트북 있으면 debug.c 로그 칸에서 꺼내 보냄
   노트북 없으면 꺼내지 않고 모아 둠 (켜자마자 생긴 알람도 나중에 연결해서 보임). 쌓기는 debug.c Log_Debug */
static void log_port(void)
{
    char out[LOG_SIZE];                                         /* 꺼낼 칸 (로그 칸과 같은 크기) */
    int n;

    uint8_t doing = port_doing(LOG_SOCK);
    if (doing & Sn_IR_CON)
        pc_join(&log_on);                                                         /* 연결 → 램프 · 부저 PC 가 */
    if (doing & Sn_IR_DISCON)  Log_Debug("50001 closed by laptop");          /* 끊긴 이유 : 노트북이 끊음 */
    if (doing & Sn_IR_TIMEOUT) Log_Debug("50001 timeout (no answer)");       /*            노트북 대답 없음 */
    if (doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT)) {
        pc_leave(&log_on);
        net_open(LOG_SOCK, LOG_PORT);
    }

    if (log_on == 0) return;                                    /* 노트북 없음 : 모아 둠 (표시만 봄 → 1ms 마다 SPI 안 함) */

    n = Log_Take(out);                                          /* 쌓인 것 꺼내기 (debug.c) */
    if (n > 0) send(LOG_SOCK, (uint8_t *)out, n);               /* 보내기 (보내기 칸 2KB > 로그 칸 512) */
}


/* ======================= 작업 2500 (소켓 0) ======================= */

/* PC 한 줄 = 번호 2글자 + 내용 → 번호 기억 (대답 · 이벤트 · 완료응답에 씀) → cmd.c 로 (명령 · PC 승인 · 대답 전부 cmd.c 가 봄)
   번호 없음 → 버림 */
static void send_cmd(char *cmd)
{
    if (cmd[0] < '0' || cmd[0] > '9' || cmd[1] < '0' || cmd[1] > '9') return;   /* 번호 없음 : 버림 */
    number = (cmd[0] - '0') * 10 + (cmd[1] - '0');      /* PC 번호 기억 */
    cmd += 2;                                           /* 번호 뺀 내용 */

    Service_TX(number, cmd);                            /* 서비스에 [TX] 23MI_1_1_2 */
    CMD_Run(number, cmd);                               /* cmd.c */
}

/* 로더 → PC : 2500 으로 보내기 → 서비스에 [RX] 복사 (cmd.c 의 대답 · 이벤트가 전부 여기로) */
void send_socket(uint8_t *buf, int len)
{
    send(TCP_SOCK, buf, len);                       /* PC 로 */
    Service_RX(buf, len);                           /* 서비스에 복사 */
}

/* 이벤트 → PC : STX + 마지막 번호 + 글자 + ETX (만재 FF · 일시정지 PPAUSE · 카드 U · 알람 S · 완료응답) */
void send_event(char *text)
{
    char tx[80];
    int len = snprintf(tx, sizeof(tx), "%c%02d%s%c", STX, number, text, ETX);

    send_socket((uint8_t *)tx, len);
}

/* 소켓 한 줄 모으기 (0 = 2500 · 1 = 58080) : 받은 글자를 rx 다음 칸에 바로 받고, STX 면 처음부터 / ETX 면 한 줄 완성 → send_cmd
   rx 에는 STX ~ ETX 사이 내용만 남음. 한 줄이 두 번에 나눠 와도 되게 rx · index 는 static,
   두 소켓 글자가 섞이지 않게 소켓마다 칸 따로 ([0] 2500 / [1] 58080) */
static void Socket_Line(uint8_t sock)
{
    static char rx[2][160];                                     /* 한 줄 칸 (소켓마다) */
    static uint8_t index[2];                                    /* 다음 글자 넣을 칸 (소켓마다, 0~159 라 1바이트) */
    char *line = rx[sock];                                      /* 이 소켓 칸 */

    for (uint16_t len = getSn_RX_RSR(sock); len > 0; len--) {                   /* 받기 칸에 온 글자 수만큼 */
        if (recv(sock, (uint8_t *)line + index[sock], 1) != 1) return;          /* 1글자를 line[index] 에 바로 받기 */

        if (line[index[sock]] == STX) index[sock] = 0;                          /* STX : 처음부터 */
        else if (line[index[sock]] == ETX) {                                    /* ETX : 한 줄 완성 */
            line[index[sock]] = 0;                                              /*   ETX 자리를 문자열 끝으로 */
            if (sock == TCP_SOCK) last = osKernelGetTickCount();                /*   명령 받은 시각 (FI 7 20초는 2500 만) */
            send_cmd(line);
            index[sock] = 0;
        }
        else if (index[sock] < sizeof(rx[0]) - 1) index[sock]++;                /* 내용 : 다음 칸으로 (꽉 차면 마지막 칸에 덮어씀) */
    }
}

/* 우리가 끊기 (PHY_MS 마다) : 보드 랜선 뽑힘 표시 / FI 7 시간(기본 20초) 명령 없음 · 랜선 다시 꽂음 → 끊고 다시 LISTEN */
static void Net_On_Off(void)
{
    static uint32_t check_at;                   /* 마지막으로 확인한 시각 */

    if (osKernelGetTickCount() - check_at < PHY_MS) return;     /* 100ms 마다만 (랜선 확인 = SPI) */
    check_at = osKernelGetTickCount();

    /* 보드 랜선 뽑힘 : 선이 없어 PC 에 알릴 수 없으니 표시만 */
    if (tcp_on && wizphy_getphylink() == PHY_LINK_OFF) {
        pc_leave(&tcp_on);                      /* 연결 끝 (먼저 해야 아래 알람 12 부저가 켜짐) */
        unplug = 1;
        A_12();                                 /* 일하는 중이면 알람 12 (조건은 alarm.c) */
    }

    /* FI 7 시간 동안 명령 없음 / 보드 랜선 다시 꽂음 */
    if ((tcp_on && osKernelGetTickCount() - last >= net_timeout) ||
        (unplug && wizphy_getphylink() == PHY_LINK_ON)) {
        Log_Debug(unplug ? "2500 closed : board LAN re-plugged" : "2500 closed : no command (FI 7 time)");   /* 끊긴 이유 */
        pc_leave(&tcp_on);                      /* 연결 끝 */
        unplug = 0;
        disconnect(TCP_SOCK);                   /* PC 에 FIN */
        net_open(TCP_SOCK, net_port);           /* 바로 다시 LISTEN */
    }
}

/* 소켓 0 : 접속 → 명령 받기 → 끊김 → 랜선 · FI 7 시간 */
static void tcp_port(void)
{
    uint8_t doing = port_doing(TCP_SOCK);
    uint8_t card = PC_CARD;                     /* 주문서 : 카드 상태 보내기 */

    /* PC 접속 */
    if (doing & Sn_IR_CON) {
        Log_Debug("2500 connected");
        pc_join(&tcp_on);                       /* 연결 → 램프 · 부저 PC 가 */
        osMessageQueuePut(CommQueueHandle, &card, 0, 0);   /* 접속하자마자 지금 카드 상태를 PC 로 (주문서 'U' → rfid.c Rfid_event_text) */
        last = osKernelGetTickCount();          /* FI 7 시간 재기 시작 */
    }

    /* 글자 옴 */
    if (doing & Sn_IR_RECV)
        Socket_Line(TCP_SOCK);

    /* PC 가 끊음 / 대답 없음 : 다시 LISTEN (글자 먼저 읽고 나서) */
    if (doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT)) {
        Log_Debug((doing & Sn_IR_DISCON) ? "2500 closed by PC" : "2500 timeout (PC no answer)");   /* 끊긴 이유 */
        pc_leave(&tcp_on);                      /* 연결 끝 */
        unplug = 0;                             /* 이미 닫혔으니 다시 꽂아도 끊을 것 없음 */
        net_open(TCP_SOCK, net_port);
    }

    Net_On_Off();                                /* 랜선 · FI 7 시간 */
}


/* ======================= 1ms 마다 ======================= */

/* TCP 서버 (Comm_Task 1ms 마다) : 포트 3개 = 함수 3개 */
void NET_Run(void)
{
    if (net_mode != 0) return;                  /* 서버 모드만 */

    tcp_port();                                 /* 작업 2500 */
    service_port();                             /* 서비스 58080 */
    log_port();                                 /* 로그 50001 */
}
