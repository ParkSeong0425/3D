/* net.c : W6100 Ethernet only. Command parsing is not handled here. */
#include "net.h"
#include "save.h"
#include "cmd.h"
#include "spi.h"
#include "wizchip_conf.h"
#include "socket.h"
#include "cmsis_os2.h"

#define NET_SPI         hspi4
#define TCP_SOCK        0
#define Service_SOCK    1       /* 서비스 창구 : 소켓 1번 */
#define Service_PORT    58080   /*              포트 */
#define LOG_SOCK        2       /* 로그 창구   : 소켓 2번 */
#define LOG_PORT        50001   /*              포트 */

volatile int tcp_on;        /* 1 = PC 와 연결됨 */
static uint32_t last;       /* 마지막으로 PC 명령 받은 시각 */

static uint16_t net_port;
static uint8_t net_mode;
static uint32_t net_timeout;

/* Temporary network values for first ping test.
 * MAC will later be replaced by 24AA02E48.
 * IP settings will later be replaced by FRAM values.
 */
static wiz_NetInfo net_info = {
    .mac = {0x02, 0x00, 0x00, 0x00, 0x00, 0x01},
    .dns = {0, 0, 0, 0},
    .ipmode = NETINFO_STATIC_V4
};

/* Hardware NSS: SPI enable -> NSS LOW */
static void cs_on(void)
{
    __HAL_SPI_ENABLE(&NET_SPI);
}

/* Hardware NSS: SPI disable -> NSS released HIGH by pull-up */
static void cs_off(void)
{
    while (__HAL_SPI_GET_FLAG(&NET_SPI, SPI_FLAG_BSY));
    __HAL_SPI_DISABLE(&NET_SPI);
}

/* SPI 1 byte read */
static uint8_t spi_rb(void)
{
    uint8_t tx = 0xFF;
    uint8_t rx = 0;

    HAL_SPI_TransmitReceive(&NET_SPI, &tx, &rx, 1, 100);
    return rx;
}

/* SPI 1 byte write */
static void spi_wb(uint8_t data)
{
    HAL_SPI_Transmit(&NET_SPI, &data, 1, 100);
}

/* SPI buffer read */
static void spi_rbuf(uint8_t *buf, datasize_t len)
{
    for (datasize_t i = 0; i < len; i++)
        buf[i] = spi_rb();
}

/* SPI buffer write */
static void spi_wbuf(uint8_t *buf, datasize_t len)
{
    if (len > 0)
        HAL_SPI_Transmit(&NET_SPI, buf, (uint16_t)len, 1000);
}

/* W6100 hardware reset */
static void w610_reset(void)
{
    HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_RESET);
    osDelay(10);

    HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_SET);
    osDelay(100);
}

/* 창구 열어 두기 (작업 · 서비스 · 로그) : 한 번 부르면 손님 대기(LISTEN)까지 */
static void net_open(uint8_t sock, uint16_t port)
{
    if (getSn_SR(sock) == SOCK_CLOSE_WAIT)          /* 손님이 끊었음 */
        disconnect(sock);                           /* 우리도 끊기 → 닫힘 */

    if (getSn_SR(sock) == SOCK_CLOSED) {            /* 닫혀 있음 */
        setSn_RCR(sock, 2);                     /* 대답 없으면 2번만 다시 보내고 포기 (열기 전에 써야 함) */
        socket(sock, Sn_MR_TCP4, port, 0);          /* 열기 → 열림 */
        setSn_KPALVTR(sock, 1);                     /* 상대가 5초(1 x 5초) 랜선 끊겨 있으면  W6100 이 스스로 닫음 */
    }

    if (getSn_SR(sock) == SOCK_INIT)                /* 열려 있음 */
        listen(sock);                               /* 손님 대기 */
}

/* 서비스 창구로 보여 주기 : 앞에 "[TX] " / "[RX] " 붙이고 2500 내용 그대로 (노트북 없거나 자리 없으면 안 보냄) */
static void service_port(char *tr, uint8_t *buf, int len)
{
    if (getSn_SR(Service_SOCK) != SOCK_ESTABLISHED || getSn_TX_FSR(Service_SOCK) < len + 7)
        return;

    send(Service_SOCK, (uint8_t *)tr, 5);           /* "[TX] " 또는 "[RX] " */
    send(Service_SOCK, buf, len);                   /* 2500 내용 그대로 */
    send(Service_SOCK, (uint8_t *)"\r\n", 2);       /* 줄 바꿈 */
}

/* 작업 창구(2500)로 보내기 + 서비스 창구에 [RX] 로 복사 (cmd.c 가 부름) */
void NET_Send(uint8_t *buf, int len)
{
    send(TCP_SOCK, buf, len);
    service_port("[RX] ", buf, len);
}

/* Ethernet initialization for first ping test */
int NET_Init(void)
{
    uint8_t size[8] = {2, 2, 2, 2, 2, 2, 2, 2};

    /* 저장된 네트워크 값 적용 */
    net_info.ip[0] = save.fi.ip[0];
    net_info.ip[1] = save.fi.ip[1];
    net_info.ip[2] = save.fi.ip[2];
    net_info.ip[3] = save.fi.ip[3];

    net_info.sn[0] = save.fi.sn[0];
    net_info.sn[1] = save.fi.sn[1];
    net_info.sn[2] = save.fi.sn[2];
    net_info.sn[3] = save.fi.sn[3];

    net_info.gw[0] = save.fi.gw[0];
    net_info.gw[1] = save.fi.gw[1];
    net_info.gw[2] = save.fi.gw[2];
    net_info.gw[3] = save.fi.gw[3];

    net_port = save.fi.port;
    net_mode = save.fi.mode;
    net_timeout = save.fi.timeout;

    reg_wizchip_cs_cbfunc(cs_on, cs_off);
    reg_wizchip_spi_cbfunc(spi_rb, spi_wb, spi_rbuf, spi_wbuf);

    w610_reset();

    if (getCIDR() != 0x6100)
        return -1;

    if (getVER() != 0x4661)
        return -2;

    if (wizchip_init(size, size) != 0)
        return -3;

    NETUNLOCK();

    wizchip_setnetinfo(&net_info);

    /* 초인종(INT 핀) : 소켓 0 · 1 · 2 의 접속 · 끊김 · 받음 · 대답없음 만 (보냄완료 SENDOK 는 뺌) */
    setSIMR(0x07);                      /* 소켓 0, 1, 2 */
    setSn_IMR(TCP_SOCK, 0x0F);          /* CON · DISCON · RECV · TIMEOUT */
    setSn_IMR(Service_SOCK, 0x0F);
    setSn_IMR(LOG_SOCK, 0x0F);

    /* 창구 3개 열어 두기 (서버 모드만) */
    if (net_mode == 0) {
        net_open(TCP_SOCK, net_port);           /* 작업 */
        net_open(Service_SOCK, Service_PORT);   /* 서비스 */
        net_open(LOG_SOCK, LOG_PORT);           /* 로그 */
    }

    return 1;
}


/* TCP Server */
void NET_Run(void)
{
    uint8_t w6100_doing = 0;                    /* W6100 표시등 복사본 (평소 0, 일 있으면 그 비트 1) */
    static char rx[160];                        /* 받은 명령 모으기 */
    static int index;                           /* rx 몇 칸 찼나 */
    uint8_t ch;                                 /* 읽은 글자 1개 */
    uint16_t len;                               /* 남은 글자 수 */
    static int unplug;                          /* 1 = 연결 중에 보드 랜선 뽑혔었음 */

    /* 현재는 Server만 처리 */
    if (net_mode != 0)
        return;

    /* 초인종 : INT 핀은 거꾸로 (0 = 일 있음) */
    if (HAL_GPIO_ReadPin(W610_INT_GPIO_Port, W610_INT_Pin) == 0)
    {
        w6100_doing = getSn_IR(TCP_SOCK) & 0x0F;    /* 작업 창구에 무슨 일? (SENDOK 는 send() 것이라 안 건드림) */
        setSn_IRCLR(TCP_SOCK, w6100_doing);     /* 읽었으니 바로 끔 */
    }

    /* PC 접속 */
    if (w6100_doing & Sn_IR_CON)
    {
        tcp_on = 1;                             /* 연결됨 */
        last = osKernelGetTickCount();          /* 20초 재기 시작 */
    }

    /* 글자 옴 : STX ~ ETX 모아서 CMD_Run */
    if (w6100_doing & Sn_IR_RECV)
    {
        len = getSn_RX_RSR(TCP_SOCK);           /* 받은 글자 수 */

        while (len > 0)
        {
            if (recv(TCP_SOCK, &ch, 1) != 1)
                break;

            len--;

            /* STX */
            if (ch == STX)
            {
                index = 0;
            }

            /* ETX */
            else if (ch == ETX)
            {
                rx[index] = 0;

                service_port("[TX] ", (uint8_t *)rx, index);   /* 서비스 창구에 복사 */
                CMD_Run(rx);
                last = osKernelGetTickCount();  /* 명령 받은 시각 : 시간 다시 재기 */
                index = 0;
            }

            /* 명령 내용을 rx 배열에 한 글자씩 모으는 부분 */
            else
            {
                if (index < sizeof(rx) - 1)     /* 배열에 자리가 남아 있으면 */
                {
                    rx[index] = ch;             /* 받은 글자 저장 */
                    index++;                    /* 다음칸으로 넘김 */
                }
            }
        }
    }

    /* PC 가 끊음 / 대답 없음 : 다시 손님 대기 */
    if (w6100_doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT))
    {
        tcp_on = 0;                             /* 끊김 */
        unplug = 0;                             /* 이미 닫혔으니 다시 꽂아도 끊을 것 없음 */
        net_open(TCP_SOCK, net_port);           /* 정리하고 다시 LISTEN (keep-alive 포함) */
    }

    /* 보드 랜선 뽑힘 : 선이 없어 PC 에 알릴 수 없으니 표시만 */
    if (tcp_on == 1 && wizphy_getphylink() == PHY_LINK_OFF)
    {
        tcp_on = 0;
        unplug = 1;
    }

    /* 우리가 끊기 : 20초 명령 없음 / 보드 랜선 다시 꽂음 */
    if ((tcp_on == 1 && osKernelGetTickCount() - last >= net_timeout) ||
        (unplug == 1 && wizphy_getphylink() == PHY_LINK_ON))
    {
        tcp_on = 0;
        unplug = 0;
        disconnect(TCP_SOCK);                   /* PC 에 "끊을게" */
        net_open(TCP_SOCK, net_port);           /* 바로 다시 LISTEN */
    }

    /* 서비스 · 로그 창구 : 핀이 아직 0 이면 이쪽 일 → 끊기면 다시 열기 (받기 · 보내기는 다음 작업) */
    if (HAL_GPIO_ReadPin(W610_INT_GPIO_Port, W610_INT_Pin) == 0)
    {
        w6100_doing = getSn_IR(Service_SOCK) & 0x0F;    /* 서비스 창구에 무슨 일? */
        setSn_IRCLR(Service_SOCK, w6100_doing);
        if (w6100_doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT))
            net_open(Service_SOCK, Service_PORT);

        w6100_doing = getSn_IR(LOG_SOCK) & 0x0F;        /* 로그 창구에 무슨 일? */
        setSn_IRCLR(LOG_SOCK, w6100_doing);
        if (w6100_doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT))
            net_open(LOG_SOCK, LOG_PORT);
    }
}
