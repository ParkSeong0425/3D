/*
 * net.c : W6100 (SPI4) 로 TCP 서버 — 포트 3개 = W6100 소켓 3개, 소켓 하나에 연결 하나
 *
 *   소켓 0  2500 (FI 5)  작업 : PC 명령 받기 · 대답 보내기
 *   소켓 1  58080        서비스 : 2500 에서 오간 것을 [TX] / [RX] 로 복사
 *   소켓 2  50001        로그 : Log_Debug 로 쌓인 줄
 *
 *  ── W6100 라이브러리 함수 (socket.h · w6100.h · wizchip_conf.h) ──
 *   켤 때     reg_wizchip_cs_cbfunc / reg_wizchip_spi_cbfunc : 우리 SPI 함수를 라이브러리에 알려 줌
 *             getCIDR / getVER   : 칩 이름 · 버전 (0x6100 · 0x4661 이면 W6100)
 *             wizchip_init       : 소켓마다 보내기 · 받기 칸 크기 (8개 × 2KB = 16KB + 16KB)
 *             NETUNLOCK          : 네트워크 설정 레지스터 잠금 풀기
 *             wizchip_setnetinfo : IP · 서브넷 · 게이트웨이 · MAC 쓰기
 *             setSIMR            : INT 핀을 0 으로 만들 소켓 고르기 (0x07 = 소켓 0 · 1 · 2)
 *             setSn_IMR          : 그 소켓의 어떤 일에 INT 핀을 0 으로 (0x0F = CON · DISCON · RECV · TIMEOUT)
 *   소켓 열기 socket             : CLOSED → INIT
 *             listen             : INIT → LISTEN (PC 접속 기다림)
 *             disconnect         : 상대에게 FIN 보내고 닫힐 때까지 기다림 (대답 없으면 TIMEOUT)
 *             setSn_RCR          : 대답 없을 때 다시 보낼 횟수 (열기 전에)
 *             setSn_KPALVTR      : keep-alive — 5초 단위로 조용하면 상대에게 확인 (열고 나서)
 *             getSn_SR           : 소켓 상태 (CLOSED · INIT · LISTEN · ESTABLISHED 연결됨 · CLOSE_WAIT 상대가 끊음)
 *   일 알기   getSn_IR           : 그 소켓에 생긴 일 비트 (CON 0x01 · DISCON 0x02 · RECV 0x04 · TIMEOUT 0x08 · SENDOK 0x10)
 *             setSn_IRCLR        : 그 비트 끄기 (안 끄면 INT 핀이 계속 0)
 *   주고받기  getSn_RX_RSR       : 받기 칸에 온 글자 수
 *             recv               : 받기 칸에서 글자 꺼내기
 *             getSn_TX_FSR       : 보내기 칸에 남은 자리
 *             send               : 보내기 (앞에 보낸 것의 SENDOK 까지 기다림)
 *   랜선      wizphy_getphylink  : 보드 랜선 꽂힘 PHY_LINK_ON / 빠짐 PHY_LINK_OFF
 *
 *  ── 이 파일 함수 (NET_Run 이 Comm_Task 1ms 마다 : 포트 하나 = 함수 하나) ──
 *   공통         net_open · port_doing
 *   서비스 58080  Service_TX · Service_RX (2500 복사) / service_port (소켓 1)
 *   로그 50001    Log_Debug (한 줄 쌓기, 아무 태스크) / log_port (소켓 2 + 보내기)
 *   작업 2500     Socket0_Line (STX~ETX 한 줄) → send_cmd (번호 + CMD_Run) / send_socket (cmd.c 대답 보내기)
 *                 Net_On_Off (랜선 · FI 7) / tcp_port (소켓 0)
 *   (static 함수는 쓰는 곳보다 위에 있어야 해서 서비스 · 로그가 2500 보다 먼저)
 *   ※ W6100 은 Comm_Task 만 만짐 (SPI 를 두 태스크가 같이 쓰면 명령이 섞임)
 */
#include "net.h"
#include "save.h"
#include "cmd.h"
#include "spi.h"
#include "wizchip_conf.h"
#include "socket.h"
#include "cmsis_os2.h"
#include "rfid.h"
#include <stdio.h>
#include <string.h>

#define NET_SPI         hspi4
#define TCP_SOCK        0       /* 작업 : 소켓 0번 (포트는 FI 5) */
#define Service_SOCK    1       /* 서비스 : 소켓 1번 */
#define Service_PORT    58080   /*          포트 */
#define LOG_SOCK        2       /* 로그 : 소켓 2번 */
#define LOG_PORT        50001   /*        포트 */

volatile int tcp_on;        /* 1 = PC 와 연결됨 */
static uint32_t last;       /* 마지막으로 PC 명령 받은 시각 */
static int unplug;          /* 1 = 연결 중에 보드 랜선 뽑혔었음 (tcp_port · Net_On_Off 가 같이 씀) */
static uint8_t w6100_doing; /* 방금 읽은 소켓의 IR 비트 (CON · DISCON · RECV · TIMEOUT, 없으면 0) — port_doing 이 채움 */
static int number;          /* 일련번호 01 ~ 99 : 마지막으로 쓴 번호 (PC 명령 · 로더 이벤트 같이) */

static uint16_t net_port;       /* FI 5 포트 (켤 때 복사 → 재부팅 후 적용) */
static uint8_t net_mode;        /* FI 6 0 서버 / 1 클라이언트 */
static uint32_t net_timeout;    /* FI 7 명령 없으면 끊는 시간 ms (10000 ~ 60000, 기본 20000) */

static char log_text[512];  /* 로그 칸 : 여러 태스크가 한 줄씩 쌓고, Comm_Task 의 log_port 가 50001 로 보내고 비움 */
static int log_len;         /* 로그 칸에 쌓인 글자 수 */

/* 네트워크 값 : IP · 서브넷 · 게이트웨이는 NET_Init 이 FRAM(FI)에서 채움. MAC 은 임시 (나중에 24AA02E48 에서) */
static wiz_NetInfo net_info = {
    .mac = {0x02, 0x00, 0x00, 0x00, 0x00, 0x01},
    .ipmode = NETINFO_STATIC_V4
};

/* Hardware NSS: SPI enable -> NSS LOW */
static void cs_on(void)
{
    __HAL_SPI_ENABLE(&NET_SPI);
}

/* Hardware NSS: SPI disable -> NSS released HIGH by pull-up */
static void cs_off(void)
{
    while (__HAL_SPI_GET_FLAG(&NET_SPI, SPI_FLAG_BSY));
    __HAL_SPI_DISABLE(&NET_SPI);
}

/* SPI 1 byte read */
static uint8_t spi_rb(void)
{
    uint8_t tx = 0xFF;
    uint8_t rx = 0;

    HAL_SPI_TransmitReceive(&NET_SPI, &tx, &rx, 1, 100);
    return rx;
}

/* SPI 1 byte write */
static void spi_wb(uint8_t data)
{
    HAL_SPI_Transmit(&NET_SPI, &data, 1, 100);
}

/* SPI buffer read */
static void spi_rbuf(uint8_t *buf, datasize_t len)
{
    for (datasize_t i = 0; i < len; i++)
        buf[i] = spi_rb();
}

/* SPI buffer write */
static void spi_wbuf(uint8_t *buf, datasize_t len)
{
    if (len > 0)
        HAL_SPI_Transmit(&NET_SPI, buf, (uint16_t)len, 1000);
}

/* W6100 hardware reset */
static void w610_reset(void)
{
    HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_RESET);
    osDelay(10);

    HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_SET);
    osDelay(100);
}


/* ======================= 공통 ======================= */

/* 소켓 열어 두기 : 한 번 부르면 LISTEN(PC 접속 기다림)까지 */
static void net_open(uint8_t sock, uint16_t port)
{
    if (getSn_SR(sock) == SOCK_CLOSE_WAIT)          /* 상대가 끊었음 */
        disconnect(sock);                           /* 우리도 끊기 → CLOSED */

    if (getSn_SR(sock) == SOCK_CLOSED) {            /* 닫혀 있음 */
        setSn_RCR(sock, 2);                         /* 대답 없으면 2번만 다시 보내고 포기 (열기 전에 써야 함) */
        socket(sock, Sn_MR_TCP4, port, 0);          /* 열기 → INIT */
        setSn_KPALVTR(sock, 1);                     /* 5초 조용하면 상대 확인 → 대답 없으면 W6100 이 스스로 닫음 (약 6~7초) */
    }

    if (getSn_SR(sock) == SOCK_INIT)                /* 열려 있음 */
        listen(sock);                               /* → LISTEN */
}

/* 소켓 하나의 일 읽기 : INT 핀이 0 이면 그 소켓 IR 을 w6100_doing 에 담고 바로 끔. INT 핀 1 이면 0 (SPI 안 함) */
static void port_doing(uint8_t sock)
{
    w6100_doing = 0;                                        /* 처음엔 일 없음 */

    if (HAL_GPIO_ReadPin(W610_INT_GPIO_Port, W610_INT_Pin) == GPIO_PIN_SET) return;   /* INT 핀 1 = 어느 소켓에도 일 없음 */

    w6100_doing = getSn_IR(sock) & 0x0F;                    /* CON · DISCON · RECV · TIMEOUT (SENDOK 는 send() 가 쓰는 것이라 안 건드림) */
    setSn_IRCLR(sock, w6100_doing);                         /* 읽은 비트 끄기 */
}


/* ======================= 켤 때 ======================= */

/* W6100 켜기 : FI 값 복사 → 리셋 → 칩 확인 → IP → INT 규칙 → 소켓 3개 열기. 성공 1 / 실패 0 */
int NET_Init(void)
{
    uint8_t size[8] = {2, 2, 2, 2, 2, 2, 2, 2};     /* 소켓마다 보내기 · 받기 칸 2KB */

    /* 저장된 네트워크 값 (FI) */
    memcpy(net_info.ip, save.fi.ip, 4);
    memcpy(net_info.sn, save.fi.sn, 4);
    memcpy(net_info.gw, save.fi.gw, 4);
    net_port = save.fi.port;
    net_mode = save.fi.mode;
    net_timeout = save.fi.timeout;

    reg_wizchip_cs_cbfunc(cs_on, cs_off);
    reg_wizchip_spi_cbfunc(spi_rb, spi_wb, spi_rbuf, spi_wbuf);
    w610_reset();

    if (getCIDR() != 0x6100 || getVER() != 0x4661) return 0;   /* W6100 아님 · SPI 안 됨 */
    if (wizchip_init(size, size) != 0) return 0;                /* 칸 크기 틀림 */

    NETUNLOCK();
    wizchip_setnetinfo(&net_info);

    /* INT 핀 : 소켓 0 · 1 · 2 의 CON · DISCON · RECV · TIMEOUT 만 (SENDOK 는 뺌) */
    setSIMR(0x07);
    setSn_IMR(TCP_SOCK, 0x0F);
    setSn_IMR(Service_SOCK, 0x0F);
    setSn_IMR(LOG_SOCK, 0x0F);

    /* 소켓 3개 열어 두기 (서버 모드만) */
    if (net_mode == 0) {
        net_open(TCP_SOCK, net_port);           /* 작업 */
        net_open(Service_SOCK, Service_PORT);   /* 서비스 */
        net_open(LOG_SOCK, LOG_PORT);           /* 로그 */
    }
    return 1;
}


/* ======================= 서비스 58080 (소켓 1) : 2500 에서 오간 것 복사 ======================= */

/* [TX] PC → 로더 : PC 가 보낸 명령 그대로 (노트북 없거나 자리 없으면 안 보냄) */
static void Service_TX(uint8_t *buf, int len)
{
    if (getSn_SR(Service_SOCK) != SOCK_ESTABLISHED || getSn_TX_FSR(Service_SOCK) < len + 7)
        return;

    send(Service_SOCK, (uint8_t *)"[TX] ", 5);
    send(Service_SOCK, buf, len);                   /* PC 가 보낸 내용 그대로 */
    send(Service_SOCK, (uint8_t *)"\r\n", 2);       /* 줄 바꿈 */
}

/* [RX] 로더 → PC : 로더가 보낸 대답 · 이벤트 그대로 (노트북 없거나 자리 없으면 안 보냄) */
static void Service_RX(uint8_t *buf, int len)
{
    if (getSn_SR(Service_SOCK) != SOCK_ESTABLISHED || getSn_TX_FSR(Service_SOCK) < len + 7)
        return;

    send(Service_SOCK, (uint8_t *)"[RX] ", 5);
    send(Service_SOCK, buf, len);                   /* 로더가 보낸 내용 그대로 */
    send(Service_SOCK, (uint8_t *)"\r\n", 2);       /* 줄 바꿈 */
}

/* 소켓 1 : 노트북이 끊음 · 대답 없음 → 다시 LISTEN */
static void service_port(void)
{
    port_doing(Service_SOCK);
    if (w6100_doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT))
        net_open(Service_SOCK, Service_PORT);
}


/* ======================= 로그 50001 (소켓 2) ======================= */

/* 로그 한 줄 쌓기 (아무 태스크) : 글자 + 줄바꿈을 log_text 에 붙임. 칸이 꽉 차면 버림
   W6100 은 Comm_Task 만 만져야 해서 여기선 쌓기만, 보내기는 log_port.  예) Log_Debug("HOME  start") */
void Log_Debug(char *text)
{
    int n = strlen(text);                                   /* 글자 수 */

    osKernelLock();                                         /* 칸에 붙이는 동안 다른 태스크 못 끼게 */
    if (log_len + n + 2 <= sizeof(log_text)) {              /* 줄바꿈 2글자까지 자리 있으면 */
        memcpy(log_text + log_len, text, n);                /* 글자 붙이기 */
        log_len += n;
        log_text[log_len++] = '\r';                         /* 줄바꿈 */
        log_text[log_len++] = '\n';
    }
    osKernelUnlock();
}

/* 소켓 2 (Comm_Task) : 노트북이 끊음 · 대답 없음 → 다시 LISTEN / 노트북 있으면 쌓인 줄 보내고 비움
   노트북 없으면 비우지 않고 모아 둠 (켜자마자 생긴 알람도 나중에 연결해서 보임) */
static void log_port(void)
{
    char out[512];
    int n;

    port_doing(LOG_SOCK);
    if (w6100_doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT))
        net_open(LOG_SOCK, LOG_PORT);

    if (log_len == 0 || getSn_SR(LOG_SOCK) != SOCK_ESTABLISHED) return;   /* 쌓인 것 없음 · 노트북 없음 : 모아 둠 */

    osKernelLock();                                             /* 꺼내는 동안 다른 태스크 못 끼게 */
    n = log_len;
    memcpy(out, log_text, n);                                   /* 빨리 복사만 하고 */
    log_len = 0;                                                /* 칸 비우기 */
    osKernelUnlock();

    send(LOG_SOCK, (uint8_t *)out, n);                          /* 보내기는 잠금 밖에서 (보내기 칸 2KB > 로그 칸 512) */
}


/* ======================= 작업 2500 (소켓 0) ======================= */

/* 다음 일련번호 : 마지막 번호 + 1, 99 다음 01 (PC 명령 · 로더 이벤트가 같은 번호를 이어서 씀) */
int Roder_Number(void)
{
    number++;
    if (number > 99) number = 1;
    return number;
}

/* PC 명령 한 줄 → cmd.c : 서비스에 [TX] 복사 → 로더 번호는 따로 넘겨 CMD_Run (명령 배열엔 PC 가 보낸 내용만)
   예) MI_1_1_2 → CMD_Run(8, "MI_1_1_2") → 대답 08<ACK>MI_1_1_2 */
static void send_cmd(char *cmd)
{
    Service_TX((uint8_t *)cmd, strlen(cmd));        /* 서비스에 PC 가 보낸 그대로 */
    CMD_Run(Roder_Number(), cmd);                   /* 명령 확인 → ACK / NAK (cmd.c) */
}

/* 로더 → PC : 2500 으로 보내기 → 서비스에 [RX] 복사 (cmd.c 의 대답 · 이벤트가 전부 여기로) */
void send_socket(uint8_t *buf, int len)
{
    send(TCP_SOCK, buf, len);                       /* PC 로 */
    Service_RX(buf, len);                           /* 서비스에 복사 */
}

/* 이벤트 → PC : STX + 새 번호 + 글자 + ETX (만재 FF · 일시정지 PPAUSE · 카드 U · 알람 S)  예) 09PPAUSE:F */
void send_event(char *text)
{
    char tx[80];
    int len = snprintf(tx, sizeof(tx), "%c%02d%s%c", STX, Roder_Number(), text, ETX);

    send_socket((uint8_t *)tx, len);
}

/* 소켓 0 한 줄 모으기 : 받은 글자를 rx 다음 칸에 바로 받고, STX 면 처음부터 / ETX 면 한 줄 완성 → send_cmd
   rx 에는 STX ~ ETX 사이 내용만 남음. 한 줄이 두 번에 나눠 와도 되게 rx · index 는 static */
static void Socket0_Line(void)
{
    static char rx[160];                                        /* 한 줄 칸 */
    static int index;                                           /* 다음 글자 넣을 칸 */

    for (uint16_t len = getSn_RX_RSR(TCP_SOCK); len > 0; len--) {          /* 받기 칸에 온 글자 수만큼 */
        if (recv(TCP_SOCK, (uint8_t *)rx + index, 1) != 1) return;         /* 1글자를 rx[index] 에 바로 받기 */

        if (rx[index] == STX) index = 0;                                    /* STX : 처음부터 */
        else if (rx[index] == ETX) {                                        /* ETX : 한 줄 완성 */
            rx[index] = 0;                                                  /*   ETX 자리를 문자열 끝으로 */
            last = osKernelGetTickCount();                                  /*   명령 받은 시각 (FI 7 다시 재기) */
            send_cmd(rx);
            index = 0;
        }
        else if (index < sizeof(rx) - 1) index++;                           /* 내용 : 다음 칸으로 (꽉 차면 마지막 칸에 덮어씀) */
    }
}

/* 우리가 끊기 : 보드 랜선 뽑힘 표시 / FI 7 시간(기본 20초) 명령 없음 · 랜선 다시 꽂음 → 끊고 다시 LISTEN */
static void Net_On_Off(void)
{
    /* 보드 랜선 뽑힘 : 선이 없어 PC 에 알릴 수 없으니 표시만 */
    if (tcp_on && wizphy_getphylink() == PHY_LINK_OFF) {
        tcp_on = 0;
        unplug = 1;
    }

    /* FI 7 시간 동안 명령 없음 / 보드 랜선 다시 꽂음 */
    if ((tcp_on && osKernelGetTickCount() - last >= net_timeout) ||
        (unplug && wizphy_getphylink() == PHY_LINK_ON)) {
        tcp_on = 0;
        unplug = 0;
        disconnect(TCP_SOCK);                   /* PC 에 FIN */
        net_open(TCP_SOCK, net_port);           /* 바로 다시 LISTEN */
    }
}

/* 소켓 0 : 접속 → 명령 받기 → 끊김 → 랜선 · FI 7 시간 */
static void tcp_port(void)
{
    port_doing(TCP_SOCK);

    /* PC 접속 */
    if (w6100_doing & Sn_IR_CON) {
        tcp_on = 1;
        card_event_on = 1;                      /* 접속하자마자 지금 카드 상태를 PC 로 (CMD_Event 가 보냄) */
        last = osKernelGetTickCount();          /* FI 7 시간 재기 시작 */
    }

    /* 글자 옴 */
    if (w6100_doing & Sn_IR_RECV)
        Socket0_Line();

    /* PC 가 끊음 / 대답 없음 : 다시 LISTEN (글자 먼저 읽고 나서) */
    if (w6100_doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT)) {
        tcp_on = 0;
        unplug = 0;                             /* 이미 닫혔으니 다시 꽂아도 끊을 것 없음 */
        net_open(TCP_SOCK, net_port);
    }

    Net_On_Off();                                /* 랜선 · FI 7 시간 */
}


/* ======================= 1ms 마다 ======================= */

/* TCP 서버 (Comm_Task 1ms 마다) : 포트 3개 = 함수 3개 */
void NET_Run(void)
{
    if (net_mode != 0) return;                  /* 서버 모드만 */

    tcp_port();                                 /* 작업 2500 */
    service_port();                             /* 서비스 58080 */
    log_port();                                 /* 로그 50001 */
}
