/*
 *  ── W6100 라이브러리 함수 (socket.h · w6100.h · wizchip_conf.h) ──
 *   켤 때      reg_wizchip_cs_cbfunc / reg_wizchip_spi_cbfunc : 우리 SPI 함수를 라이브러리에 알려 줌
 *              getCIDR / getVER   : 칩 이름 · 버전 읽기 (0x6100 · 0x4661 이면 W6100 맞음)
 *              wizchip_init       : 소켓마다 보내기 · 받기 칸 크기 정하기
 *              NETUNLOCK          : 네트워크 설정 칸 잠금 풀기 (W6100 은 잠겨 있어야 못 바꿈)
 *              wizchip_setnetinfo : IP · 서브넷 · 게이트웨이 · MAC 쓰기
 *              setSIMR            : 초인종(INT 핀)을 울릴 소켓 고르기 (0x07 = 0 · 1 · 2)
 *              setSn_IMR          : 그 소켓에서 초인종 울릴 일 고르기 (0x0F = CON · DISCON · RECV · TIMEOUT)
 *   창구 열기  socket             : 창구 열기 (CLOSED → INIT)
 *              listen             : 손님 대기 (INIT → LISTEN)
 *              disconnect         : 상대에게 "끊을게" 하고 닫기 (상대 대답 기다림)
 *              setSn_RCR          : 대답 없을 때 다시 보낼 횟수 (열기 전에)
 *              setSn_KPALVTR      : keep-alive — 5초 단위로 조용하면 "살아 있어?" 물음 (열고 나서)
 *              getSn_SR           : 창구 상태 (CLOSED · INIT · LISTEN · ESTABLISHED 연결됨 · CLOSE_WAIT 상대가 끊음)
 *   일 알기    getSn_IR           : 그 창구에 생긴 일 (표시등 비트 : CON 0x01 · DISCON 0x02 · RECV 0x04 · TIMEOUT 0x08 · SENDOK 0x10)
 *              setSn_IRCLR        : 그 표시등 끄기 (안 끄면 INT 핀이 계속 0)
 *   주고받기   getSn_RX_RSR       : 받은 글자 수
 *              recv               : 받은 글자 꺼내기
 *              getSn_TX_FSR       : 보내기 칸에 남은 자리
 *              send               : 보내기 (앞에 보낸 것 도착(SENDOK)까지 기다릴 수 있음)
 *   랜선       wizphy_getphylink  : 보드 랜선 꽂힘 PHY_LINK_ON / 빠짐 PHY_LINK_OFF
 */
#include "net.h"
#include "save.h"
#include "cmd.h"
#include "spi.h"
#include "wizchip_conf.h"
#include "socket.h"
#include "cmsis_os2.h"
#include "rfid.h"
#include <stdio.h>
#include <string.h>

#define NET_SPI         hspi4
#define TCP_SOCK        0
#define Service_SOCK    1       /* 서비스 창구 : 소켓 1번 */
#define Service_PORT    58080   /*              포트 */
#define LOG_SOCK        2       /* 로그 창구   : 소켓 2번 */
#define LOG_PORT        50001   /*              포트 */

volatile int tcp_on;        /* 1 = PC 와 연결됨 */
static uint32_t last;       /* 마지막으로 PC 명령 받은 시각 */
static int unplug;          /* 1 = 연결 중에 보드 랜선 뽑혔었음 (tcp_port · tcp_check 가 같이 씀) */
static uint8_t w6100_doing; /* 방금 꺼낸 편지 : 그 창구에 무슨 일 (비트, 일 없으면 0) — port_doing 이 채움 */
static int number;          /* 일련번호 01 ~ 99 : 마지막으로 쓴 번호 (PC 명령 · 로더 이벤트 같이) */

static uint16_t net_port;       /* FI 5 포트 (켤 때 복사 → 재부팅 후 적용) */
static uint8_t net_mode;        /* FI 6 0 서버 / 1 클라이언트 */
static uint32_t net_timeout;    /* FI 7 명령 없으면 끊는 시간 ms (10000 ~ 60000, 기본 20000) */

static char log_text[512];  /* 로그 칸 : 여러 태스크가 한 줄씩 쌓고, Comm_Task 가 50001 로 보내고 비움 */
static int log_len;         /* 로그 칸에 쌓인 글자 수 */

/* Temporary network values for first ping test.
 * MAC will later be replaced by 24AA02E48.
 * IP settings will later be replaced by FRAM values.
 */
static wiz_NetInfo net_info = {
    .mac = {0x02, 0x00, 0x00, 0x00, 0x00, 0x01},
    .dns = {0, 0, 0, 0},
    .ipmode = NETINFO_STATIC_V4
};

/* Hardware NSS: SPI enable -> NSS LOW */
static void cs_on(void)
{
    __HAL_SPI_ENABLE(&NET_SPI);
}

/* Hardware NSS: SPI disable -> NSS released HIGH by pull-up */
static void cs_off(void)
{
    while (__HAL_SPI_GET_FLAG(&NET_SPI, SPI_FLAG_BSY));
    __HAL_SPI_DISABLE(&NET_SPI);
}

/* SPI 1 byte read */
static uint8_t spi_rb(void)
{
    uint8_t tx = 0xFF;
    uint8_t rx = 0;

    HAL_SPI_TransmitReceive(&NET_SPI, &tx, &rx, 1, 100);
    return rx;
}

/* SPI 1 byte write */
static void spi_wb(uint8_t data)
{
    HAL_SPI_Transmit(&NET_SPI, &data, 1, 100);
}

/* SPI buffer read */
static void spi_rbuf(uint8_t *buf, datasize_t len)
{
    for (datasize_t i = 0; i < len; i++)
        buf[i] = spi_rb();
}

/* SPI buffer write */
static void spi_wbuf(uint8_t *buf, datasize_t len)
{
    if (len > 0)
        HAL_SPI_Transmit(&NET_SPI, buf, (uint16_t)len, 1000);
}

/* W6100 hardware reset */
static void w610_reset(void)
{
    HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_RESET);
    osDelay(10);

    HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_SET);
    osDelay(100);
}

/* ======================= 창구 공통 ======================= */

/* 창구 열어 두기 (작업 · 서비스 · 로그) : 한 번 부르면 손님 대기(LISTEN)까지 */
static void net_open(uint8_t sock, uint16_t port)
{
    if (getSn_SR(sock) == SOCK_CLOSE_WAIT)          /* 손님이 끊었음 */
        disconnect(sock);                           /* 우리도 끊기 → 닫힘 */

    if (getSn_SR(sock) == SOCK_CLOSED) {            /* 닫혀 있음 */
        setSn_RCR(sock, 2);                         /* 대답 없으면 2번만 다시 보내고 포기 (열기 전에 써야 함) */
        socket(sock, Sn_MR_TCP4, port, 0);          /* 열기 → 열림 */
        setSn_KPALVTR(sock, 1);                     /* 5초 조용하면 "살아 있어?" → 대답 없으면 W6100 이 스스로 닫음 (약 6~7초) */
    }

    if (getSn_SR(sock) == SOCK_INIT)                /* 열려 있음 */
        listen(sock);                               /* 손님 대기 */
}

/* 창구 하나 편지 꺼내기 (세 창구 공통) : 벨이 울렸으면(INT 핀 0) 그 창구에 무슨 일인지 w6100_doing 에 담고 바로 끔
   w6100_doing = 그 일의 비트 (CON 접속 · RECV 글자 · DISCON 끊김 · TIMEOUT 대답없음), 벨 안 울렸으면 0 */
static void port_doing(uint8_t sock)
{
    w6100_doing = 0;                                        /* 처음엔 일 없음 */

    if (HAL_GPIO_ReadPin(W610_INT_GPIO_Port, W610_INT_Pin) == GPIO_PIN_SET) return;   /* 벨 안 울림 : SPI 안 함 */

    w6100_doing = getSn_IR(sock) & 0x0F;                    /* 무슨 일? (SENDOK 는 send() 것이라 안 건드림) */
    setSn_IRCLR(sock, w6100_doing);                         /* 읽었으니 바로 끔 */
}


/* ======================= 켤 때 ======================= */

/* W6100 켜기 : FI 값 복사 → 리셋 → 칩 확인 → IP → 초인종 규칙 → 창구 3개 열기. 성공 1 / 실패 -1 ~ -3 */
int NET_Init(void)
{
    uint8_t size[8] = {2, 2, 2, 2, 2, 2, 2, 2};     /* 소켓마다 보내기 · 받기 칸 2KB */

    /* 저장된 네트워크 값 적용 */
    net_info.ip[0] = save.fi.ip[0];
    net_info.ip[1] = save.fi.ip[1];
    net_info.ip[2] = save.fi.ip[2];
    net_info.ip[3] = save.fi.ip[3];

    net_info.sn[0] = save.fi.sn[0];
    net_info.sn[1] = save.fi.sn[1];
    net_info.sn[2] = save.fi.sn[2];
    net_info.sn[3] = save.fi.sn[3];

    net_info.gw[0] = save.fi.gw[0];
    net_info.gw[1] = save.fi.gw[1];
    net_info.gw[2] = save.fi.gw[2];
    net_info.gw[3] = save.fi.gw[3];

    net_port = save.fi.port;
    net_mode = save.fi.mode;
    net_timeout = save.fi.timeout;

    reg_wizchip_cs_cbfunc(cs_on, cs_off);
    reg_wizchip_spi_cbfunc(spi_rb, spi_wb, spi_rbuf, spi_wbuf);

    w610_reset();

    if (getCIDR() != 0x6100)
        return -1;

    if (getVER() != 0x4661)
        return -2;

    if (wizchip_init(size, size) != 0)
        return -3;

    NETUNLOCK();

    wizchip_setnetinfo(&net_info);

    /* 초인종(INT 핀) : 소켓 0 · 1 · 2 의 접속 · 끊김 · 받음 · 대답없음 만 (보냄완료 SENDOK 는 뺌) */
    setSIMR(0x07);                      /* 소켓 0, 1, 2 */
    setSn_IMR(TCP_SOCK, 0x0F);          /* CON · DISCON · RECV · TIMEOUT */
    setSn_IMR(Service_SOCK, 0x0F);
    setSn_IMR(LOG_SOCK, 0x0F);

    /* 창구 3개 열어 두기 (서버 모드만) */
    if (net_mode == 0) {
        net_open(TCP_SOCK, net_port);           /* 작업 */
        net_open(Service_SOCK, Service_PORT);   /* 서비스 */
        net_open(LOG_SOCK, LOG_PORT);           /* 로그 */
    }

    return 1;
}


/* ======================= 2500 주고받기 + 서비스 58080 복사 ([TX] · [RX] 는 여기 한 곳) ======================= */

/* 서비스 창구로 보여 주기 : 앞에 "[TX] " / "[RX] " 붙이고 2500 내용 그대로 (노트북 없거나 자리 없으면 안 보냄) */
static void service_port(char *tr, uint8_t *buf, int len)
{
    if (getSn_SR(Service_SOCK) != SOCK_ESTABLISHED || getSn_TX_FSR(Service_SOCK) < len + 7)
        return;

    send(Service_SOCK, (uint8_t *)tr, 5);           /* "[TX] " 또는 "[RX] " */
    send(Service_SOCK, buf, len);                   /* 2500 내용 그대로 */
    send(Service_SOCK, (uint8_t *)"\r\n", 2);       /* 줄 바꿈 */
}

/* 다음 일련번호 : 마지막 번호 + 1, 99 다음 01 (PC 명령 · 로더 이벤트가 같은 번호를 이어서 씀) */
int Roder_Number(void)
{
    number++;
    if (number > 99) number = 1;
    return number;
}

/* [TX] PC → 로더 : 명령 한 줄 받음 → 번호 붙이기 → 서비스에 복사 → CMD_Run → 20초 다시 재기 (tcp_recv 가 부름)
   번호 없이 오면 (MI_1_1_2_…) → 로더가 다음 번호를 붙임 (01MI_1_1_2_…)
   번호 붙어 오면 (52MI_…)      → 그대로, 그 번호부터 이어서 셈
   완료 승인 (52 <ACK> AI_…)    → 그대로 (같은 번호를 다시 보내는 것이라 안 셈) */
static void tcp_cmd(char *cmd)
{
    char line[164];                                 /* 번호 2글자 + 받은 명령 */

    if (cmd[0] >= '0' && cmd[0] <= '9' && cmd[1] >= '0' && cmd[1] <= '9') {   /* 이미 번호 있음 : 그대로 */
        snprintf(line, sizeof(line), "%s", cmd);
        if (cmd[2] != ACK) number = (cmd[0] - '0') * 10 + (cmd[1] - '0');    /* PC 명령이면 그 번호부터 이어서 */
    }
    else {                                          /* 번호 없음 : 로더가 붙임 */
        snprintf(line, sizeof(line), "%02d%s", Roder_Number(), cmd);   /* 01MI_1_1_2_… */
    }

    service_port("[TX] ", (uint8_t *)line, strlen(line));      /* 서비스 창구에 복사 (번호 붙은 모양) */
    CMD_Run(line);                                  /* 명령 처리 (cmd.c) : 대답에 이 번호가 그대로 붙음 */
    last = osKernelGetTickCount();                  /* 명령 받은 시각 : FI 7 시간 다시 재기 */
}

/* [RX] 로더 → PC : 2500 으로 보냄 → 서비스에 복사 (cmd.c 가 부름) */
void NET_Send(uint8_t *buf, int len)
{
    send(TCP_SOCK, buf, len);                       /* PC 로 */
    service_port("[RX] ", buf, len);                /* 서비스 창구에 복사 */
}


/* ======================= 작업 창구 2500 ======================= */

/* 명령 받기 : 받은 글자를 STX ~ ETX 로 모아서 한 줄이 되면 tcp_cmd */
static void tcp_recv(void)
{
    static char rx[160];                        /* 받은 명령 모으기 */
    static int index;                           /* rx 몇 칸 찼나 */
    uint8_t ch;                                 /* 읽은 글자 1개 */
    uint16_t len;                               /* 남은 글자 수 */

    len = getSn_RX_RSR(TCP_SOCK);               /* 받은 글자 수 */

    while (len > 0)
    {
        if (recv(TCP_SOCK, &ch, 1) != 1)
            break;

        len--;

        /* STX : 처음부터 */
        if (ch == STX)
        {
            index = 0;
        }

        /* ETX : 한 줄 완성 → 처리 */
        else if (ch == ETX)
        {
            rx[index] = 0;
            tcp_cmd(rx);
            index = 0;
        }

        /* 명령 내용을 rx 배열에 한 글자씩 모으는 부분 */
        else
        {
            if (index < sizeof(rx) - 1)         /* 배열에 자리가 남아 있으면 */
            {
                rx[index] = ch;                 /* 받은 글자 저장 */
                index++;                        /* 다음칸으로 넘김 */
            }
        }
    }
}

/* 우리가 끊기 : 보드 랜선 뽑힘 표시 / FI 7 시간(기본 20초) 명령 없음 · 랜선 다시 꽂음 → 끊고 다시 손님 대기 */
static void tcp_check(void)
{
    /* 보드 랜선 뽑힘 : 선이 없어 PC 에 알릴 수 없으니 표시만 */
    if (tcp_on == 1 && wizphy_getphylink() == PHY_LINK_OFF)
    {
        tcp_on = 0;
        unplug = 1;
    }

    /* FI 7 시간 동안 명령 없음 / 보드 랜선 다시 꽂음 */
    if ((tcp_on == 1 && osKernelGetTickCount() - last >= net_timeout) ||
        (unplug == 1 && wizphy_getphylink() == PHY_LINK_ON))
    {
        tcp_on = 0;
        unplug = 0;
        disconnect(TCP_SOCK);                   /* PC 에 "끊을게" */
        net_open(TCP_SOCK, net_port);           /* 바로 다시 LISTEN */
    }
}

/* 작업 창구 2500 : 접속 → 명령 받기 → 끊김 → 랜선 · FI 7 시간 */
static void tcp_port(void)
{
    port_doing(TCP_SOCK);                       /* 편지 꺼내기 → w6100_doing */

    /* PC 접속 */
    if (w6100_doing & Sn_IR_CON)
    {
        tcp_on = 1;                             /* 연결됨 */
        card_event_on = 1;                           /* 접속하자마자 지금 카드 상태를 PC 로 (CMD_Event 가 보냄) */
        last = osKernelGetTickCount();          /* FI 7 시간 재기 시작 */
    }

    /* 글자 옴 */
    if (w6100_doing & Sn_IR_RECV)
        tcp_recv();

    /* PC 가 끊음 / 대답 없음 : 다시 손님 대기 (글자 먼저 읽고 나서) */
    if (w6100_doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT))
    {
        tcp_on = 0;                             /* 끊김 */
        unplug = 0;                             /* 이미 닫혔으니 다시 꽂아도 끊을 것 없음 */
        net_open(TCP_SOCK, net_port);           /* 정리하고 다시 LISTEN (keep-alive 포함) */
    }

    /* 랜선 · FI 7 시간 */
    tcp_check();
}


/* ======================= 서비스 58080 · 로그 50001 ======================= */

/* 서비스 · 로그 창구 : 끊기면 다시 열기 */
static void service_log_port(void)
{
    /* 서비스 창구 */
    port_doing(Service_SOCK);                               /* 편지 꺼내기 → w6100_doing */
    if (w6100_doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT))       /* 끊김 · 대답없음 → 다시 손님 대기 */
        net_open(Service_SOCK, Service_PORT);

    /* 로그 창구 */
    port_doing(LOG_SOCK);
    if (w6100_doing & (Sn_IR_DISCON | Sn_IR_TIMEOUT))       /* 끊김 · 대답없음 → 다시 손님 대기 */
        net_open(LOG_SOCK, LOG_PORT);
}

/* 로그 한 줄 쌓기 (어느 태스크든) : 글자 + 줄바꿈을 로그 칸(라인 버퍼)에 붙임. 칸이 꽉 차면 버림
   보내는 건 Comm_Task 의 log_send.  예) Log_Port("HOME  start") */
void Log_Port(char *text)
{
    int n = strlen(text);                                   /* 글자 수 */

    osKernelLock();                                         /* 칸에 붙이는 동안 다른 태스크 못 끼게 */
    if (log_len + n + 2 <= sizeof(log_text)) {              /* 줄바꿈 2글자까지 자리 있으면 */
        memcpy(log_text + log_len, text, n);                /* 글자 붙이기 */
        log_len += n;
        log_text[log_len++] = '\r';                         /* 줄바꿈 */
        log_text[log_len++] = '\n';
    }
    osKernelUnlock();
}

/* 로그 보내기 : 여러 태스크가 Log_Port 로 쌓아 둔 줄(라인 버퍼)을 50001 로 보내고 비움 (노트북 없거나 자리 없으면 버림) */
static void log_send(void)
{
    char out[512];
    int n;

    if (log_len == 0) return;                           /* 쌓인 것 없음 */

    osKernelLock();                                     /* 꺼내는 동안 다른 태스크 못 끼게 */
    n = log_len;
    memcpy(out, log_text, n);                           /* 빨리 복사만 하고 */
    log_len = 0;                                        /* 칸 비우기 */
    osKernelUnlock();

    if (getSn_SR(LOG_SOCK) == SOCK_ESTABLISHED && getSn_TX_FSR(LOG_SOCK) >= n)
        send(LOG_SOCK, (uint8_t *)out, n);              /* 보내기는 잠금 밖에서 */
}


/* ======================= 1ms 마다 ======================= */

/* TCP 서버 (Comm_Task 1ms 마다) : 창구 3개 + 로그 보내기 */
void NET_Run(void)
{
    if (net_mode != 0) return;                          /* 서버 모드만 */

    tcp_port();                                         /* 작업 2500 : 접속 · 명령 · 끊김 · 랜선 · FI 7 시간 */
    service_log_port();                                 /* 서비스 58080 · 로그 50001 : 끊기면 다시 열기 */
    log_send();                                         /* 로그 칸 → 50001 */
}
