/*
 * event.c : "이런 상황이면 이렇게" (기본 함수 파일들을 모아서 상황 처리)
 *
 *  1. Event_Task (High) : Event_Run 이 100ms 마다 돌림 (긴급정지 · 만재 인터럽트면 바로)
 *       읽기  estop_event  긴급정지 눌림 / 풀림
 *             manjae_event 만재 : 바뀌면 FF · 2초 넘게 만재면 그 렉 알림 + 부저 (멈춤은 PO 만, run.c PO)
 *             rfid_event   카드 : 빠지면 로그 (멈춤은 PO 만, run.c PO)
 *             hmi_event    HMI 통신 (실패 → 알람 01) · 버튼 하나 → 블록 한 줄 (btn_run · Pause_Set · Alarm_Clear · btn_manual · 음소거 · HMI_Manual)
 *             alarm_event  드라이브 알람 02 ~ 04 · 통신 11 (1초마다)
 *       (카드 RFID 묻기는 Rfid_Timer 가 0.5초마다 Rfid_Check)
 *       램프  lamp_event
 *     "지금 해도 되나" 확인이 어디 있는지는 status.c 맨 위 목록
 *     멈춤 · 풀림은 status.c 블록 (Pause_Set · Pause_Clear) → Motor_Task 는 run.c pause_wait 에서 섬
 *  2. 인터럽트 : HAL_GPIO_EXTI_Callback (Event_Task · Comm_Task 깨우기만)
 */

#include "event.h"
#include "hmi.h"
#include "rfid.h"
#include "status.h"
#include "manjae.h"
#include "lamp.h"
#include "net.h"
#include "alarm.h"
#include "cmd.h"
#include "a_motor.h"
#include "buzzer.h"
#include "save.h"
#include "debug.h"
#include "flag.h"
#include "cmsis_os.h"

#define EVENT_MS    100     /* 이벤트 확인 간격 */
#define ALARM_CHECK_MS 1000 /* 드라이브 알람 · 통신 확인 간격 */


volatile int estop;         /* 1 = 긴급정지 눌림 */
volatile int manual;        /* 1 = 수동 모드 (설정 → 수동 버튼) */
int manjae_1;               /* 1 = 렉1 만재 알림 중 (2초 넘게 만재 → HMI 일시정지 만재 · 부저 · 빨간불) : HMI RUN 누를 때까지 */
int manjae_2;               /* 1 = 렉2 만재 알림 중 */
int card_1;                 /* 1 = 렉1 시딩월 이탈 알림 중 (카드 빠짐 → HMI 시딩월 · 빨간불) : HMI RUN 누를 때까지 */
int card_2;                 /* 1 = 렉2 시딩월 이탈 알림 중 */

/* ======================= 1. Event_Task : 100ms 마다 확인 ======================= */

/* 긴급정지 : 핀을 직접 읽음 (접점이 떨려도 한 번만) / 눌리면 멈춤, 풀리면 Y 해제 (원점은 RESET → RUN) */
static void estop_event(void)
{
    int pressed = (HAL_GPIO_ReadPin(ESTOP_GPIO_Port, ESTOP_Pin) == GPIO_PIN_SET);

    /* 눌림 (한 번) : 알람 09 (세우기 + 상태 A + 번호 + PC + 부저) */
    if (pressed == 1 && estop == 0) {
        estop = 1;
        A_09(0);
    }

    /* 풀림 (한 번) : Y 비상정지만 풀고 멈춰 있음. 알람 다시 걸어 둠 (눌린 사이 바뀌었어도 RESET → RUN 으로만) */
    if (pressed == 0 && estop == 1) {
        estop = 0;
        AM_EStop(0);
        Status_Alarm();
    }
}

/* RUN : 부저 · 만재 알림 끔 → 초기화(I) 면 원점 / 일시정지(M · T · F · S)면 이어서 */
static void btn_run(void)
{
    MOVE home = { CMD_I };                              /* 원점 주문 (나머지 칸 0) */

    Buzzer_Off();                                       /* 부저 끔 */
    manjae_1 = 0;                                       /* 만재 알림 끝 (빨간불 끔) */
    manjae_2 = 0;
    card_1 = 0;                                         /* 시딩월 알림 끝 */
    card_2 = 0;

    if (estop == 0 && status_1 == HOME) {               /* 초기화(I) : 켤 때 · 리셋 뒤 (원점 중이면 Motor_Request 가 안 받음) */
        manual = 0;                                     /* 수동 모드 끔 */
        Motor_Request(home);                            /* 원점 (run.c 모터 문) */
        return;
    }

    if (pause_why) Pause_Clear();                       /* 일시정지 풀기 → 정지선에서 이어서 (status.c) */
}

/* 수동 모드 : 켜져 있으면 끔 / 대기 · 알람 02 ~ 07 · 10 (끼임 풀기) 이면 켬. 긴급정지 중엔 안 켬 */
static void btn_manual(void)
{
    if (manual == 1) { manual = 0; return; }                                                                 /* 끄기 */
    if (status_1 == WAIT && status_2 == WAIT && status_3 == WAIT && status_4 == WAIT) manual = 1;             /* 대기 */
    if (estop == 0 && status_1 == ALARM && ((alarm_1 >= 2 && alarm_1 <= 7) || alarm_1 == 10)) manual = 1;    /* 알람 */
}

/* 터치패드 : HMI 통신 (실패 → 알람 01) → 눌린 버튼 하나 (안 눌림 0 · 통신 실패는 어느 case 에도 안 맞음) */
static void hmi_event(void)
{
    int button = HMI_Run();     /* 상태 보내고 버튼 받기 */
    A_01(button);               /* 통신 안 되면 알람 01 (사무실 시험 · HMI 없으면 이 줄 주석) */

    switch (button)
    {
    case BTN_RUN:            btn_run();             break;   /* 원점 / 일시정지 풀기 */
    case BTN_STOP:           Pause_Set(0, 'M');     break;   /* 일시정지 M : 상태 P + PPAUSE:M + 부저 + 로그 (status.c) */
    case BTN_RESET:          Alarm_Clear();         break;   /* 수동 · 알람 풀고 초기화(I) (alarm.c) */
    case BTN_MANUAL:         btn_manual();          break;   /* 수동 모드 켜기 / 끄기 */
    case BTN_SOUND_OFF:      Buzzer_Off();          break;   /* 음소거 (다음 일시정지 · 알람 때 다시 켜짐) */
    case BTN_TILT_Lift:                                      /* 수동 버튼 21 ~ 26 : 수동 모드일 때만 움직임 (hmi.c) */
    case BTN_TILT_Right:
    case BTN_LIFT_UP:
    case BTN_LIFT_Down:
    case BTN_TRAVEL_Forward:
    case BTN_TRAVEL_Back:    HMI_Manual(button);    break;
    }
}

/* 만재 : 알림 (멈추지 않음 — MI · MO 는 계속, PO 는 run.c PO 가 그 단이면 틸트 안 하고 기다림)
   센서 바뀌면 바로 FF / 바뀐 뒤 2초 그대로 만재면 그 렉 알림 (부저 + 빨간불) → 센서가 풀려도 HMI RUN 까지 유지 (btn_run) */
static void manjae_event(void)
{
    static int check;                                   /* 1 = 바뀐 뒤 2초 확인 기다림 */

    /* 센서 바뀜 : PC 로 FF 바로 + 2초 다시 재기 */
    if (manjae_change()) {
        full_event_on = 1;
        check = 1;
    }

    /* 2초 그대로 : 만재인 렉 알림 */
    if (check == 1 && manjae_stable(0, 0)) {            /* 8칸 다 2초 그대로 */
        check = 0;
        if (manjae_rack(1)) manjae_1 = 1;               /* 렉1 만재 */
        if (manjae_rack(2)) manjae_2 = 1;               /* 렉2 만재 */
        if (manjae_full()) {
            Log_Debug(LOG_MANJAE_FULL);                 /* 로그 */
            Buzzer_On();                                /* 부저 (빨간불은 lamp_event → lamp_manjae) */
        }
    }
}

/* 카드 : 빠지면 그 렉 알림 (빨간불 · HMI 시딩월, HMI RUN 까지) + 로그 (PC UU 는 rfid.c, PO 는 run.c 가 그 렉이면 PPAUSE:S) */
static void rfid_event(void)
{
    static int done_1, done_2;                          /* 1 = 이번 이탈 알림 했음 (카드 다시 들어오면 0) */

    /* 카드 있음 : 다음 이탈 기다림 */
    if (card_on(1)) done_1 = 0;
    if (card_on(2)) done_2 = 0;

    /* 2초 넘게 카드 없음 : 그 렉 알림 (빨간불 · HMI 시딩월, RUN 까지) */
    if (done_1 == 0 && card_on(1) == 0 && card_stable(1)) { done_1 = 1; card_1 = 1; Log_Debug(LOG_CARD_OUT); }   /* 렉1 */
    if (done_2 == 0 && save.fs.rack_channel >= 2 && card_on(2) == 0 && card_stable(2)) { done_2 = 1; card_2 = 1; Log_Debug(LOG_CARD_OUT); }   /* 렉2 */
}

/* 드라이브 알람 02 ~ 04 · 모터 통신 끊김 11 : 1초마다, 대기 · 운전 · 일시정지에 물음
   (초기화 I = 원점 전 · 원점 중 : 드라이브 설정 전일 수 있음 / 알람 · 긴급정지 중엔 다시 안 물음) */
static void alarm_event(void)
{
    static uint32_t last;                       /* 마지막으로 물어본 시각 */

    if (osKernelGetTickCount() - last < ALARM_CHECK_MS) return;
    last = osKernelGetTickCount();

    if (estop == 1 || status_1 == ALARM || status_1 == HOME) return;    /* 긴급정지 · 알람 · 초기화(I : 원점 전 · 원점 중) 엔 안 물음 */

    if (A_02()) return;                         /* X : 걸었으면 나머지는 안 물음 */
    if (A_03()) return;                         /* Y */
    A_04();                                     /* 틸트 */
}

/* 램프 : 아래로 갈수록 우선 (뒤 함수가 앞에서 켠 램프를 덮어씀) */
static void lamp_event(void)
{
    lamp_tcp();         /* 평소 : PC 연결 = PC LL / 안 연결 = R · G 끔, Y 카드 */
    lamp_manjae(manjae_1 || card_1, manjae_2 || card_2);   /* 만재 · 시딩월 알림 중인 렉 : R 느리게 깜빡 (RUN 까지) */
    lamp_alarm();       /* 긴급정지 · 알람 = 두 렉 / 일시정지 = 그 렉만 : R 빠르게 깜빡 */
    lamp_home();        /* 원점 중 : 6개 전부 느리게 깜빡 */
}

/* Event_Task 본체 : 읽기 → 램프 → 쉬기 반복 */
void Event_Run(void)
{
    Rfid_Init();                /* CAN 켜기 + 카드 0.5초 타이머 시작 (한 번만) */

    for (;;) {
        /* 1. 읽기 */
        estop_event();          /* 긴급정지 */
        manjae_event();         /* 만재 : FF · 2초 → 그 렉 알림 · 부저 */
        rfid_event();           /* 카드 : 빠짐 로그 */
        hmi_event();            /* 터치 버튼 */
        alarm_event();          /* 드라이브 알람 02 ~ 04 (1초마다) */

        /* 2. 램프 */
        lamp_event();

        /* 3. 100ms 쉬기 : 긴급정지, 만재면 바로 깨어남 */
        osThreadFlagsWait(ESTOP_FLAG | FULL_FLAG, osFlagsWaitAny, EVENT_MS);
    }
}


/* ============ 2. 인터럽트 : 태스크 깨우기만 (판단은 깨어난 태스크가) ============ */

/* 핀 인터럽트 (EXTI) : 긴급정지 · 만재 → Event_Task / W6100 INT → Comm_Task 깨우기만 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    /* W6100 (PE1, 1 → 0 순간) : PC 글자 옴 · 접속 · 끊김 → Comm_Task 바로 깨움 (무슨 일인지는 net.c 가 읽음) */
    if (GPIO_Pin == W610_INT_Pin)
        osThreadFlagsSet(Comm_TaskHandle, NET_FLAG);

    /* 긴급정지 : 깨우기만 (눌림 / 풀림 판단은 estop_event 가 핀을 읽어서) */
    if (GPIO_Pin == ESTOP_Pin)
        osThreadFlagsSet(Event_TaskHandle, ESTOP_FLAG);

    /* 만재 (PE11 FULL_1_1 은 EXTI11 이 긴급정지라 빠짐 : 100ms 읽기로 확인) */
    if (GPIO_Pin == FULL_2_1_Pin || GPIO_Pin == FULL_2_2_Pin ||
        GPIO_Pin == FULL_2_3_Pin || GPIO_Pin == FULL_2_4_Pin ||
        GPIO_Pin == FULL_1_2_Pin || GPIO_Pin == FULL_1_3_Pin ||
        GPIO_Pin == FULL_1_4_Pin) {
        osThreadFlagsSet(Event_TaskHandle, FULL_FLAG);
    }
}
