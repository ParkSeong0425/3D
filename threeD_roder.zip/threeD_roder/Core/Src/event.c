/*
 * event.c : Event_Task 가 부르는 블록 모음 (순서 = 스위치판은 app_freertos.c Start_Event_Task, 11/17)
 *
 *  Event_Wait     주문 기다림 (최대 20ms) : HMI 버튼 (UART4 인터럽트) · 긴급정지 'E' · 만재 'M' (EXTI) 가 깨움 → 꺼내 둠
 *  estop_event    긴급정지 눌림 → 'E' (알람 09) / 풀림 → Y 해제 + 'A' (RESET → 시작 으로 원점)
 *  hmi_event      꺼내 둔 버튼 하나 → 블록 한 줄 (없으면 X JOG 다시 쓰기)
 *                   btn_run (원점 / 멈춤 풀기, 켤 때 원점도) · btn_manual (수동 켜기 · 끄기) · HMI_Manual (JOG)
 *  lamp_event     램프 (아래로 갈수록 우선)
 *  만재 manjae_change · 화면 HMI_Send · 터치 알람 A_01 · 카드 Rfid_Init 은 그 파일에 (스위치판에서 한 줄씩)
 *  드라이브 알람 02 ~ 04 · 11 은 Bus_Task (alarm.c Alarm_Drive), "지금 해도 되나" 는 status.c 맨 위 표
 *  인터럽트 : HAL_GPIO_EXTI_Callback (Event_Task · Comm_Task 큐에 주문서 — 깨우기만)
 */

#include "event.h"
#include "hmi.h"
#include "rfid.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "lamp.h"
#include "alarm.h"
#include "a_motor.h"
#include "buzzer.h"
#include "flag.h"
#include "cmsis_os.h"

#define EVENT_MS    20      /* 주문 없을 때 한 바퀴 간격 (주문이 오면 바로) : ESP 묻기 20ms · X JOG 는 드라이브가 50ms 안에 다시 받아야 계속 감 */

static uint8_t button;      /* Event_Wait 가 꺼내 둔 주문서 (HMI 버튼 · 긴급정지 'E' · 만재 'M', 0 = 없음) → hmi_event 가 씀 */


/* ======================= 1. Event_Task 블록 ======================= */

/* 주문 기다림 : 오면 바로, 없어도 20ms (기다리는 동안 잠 = CPU 안 씀). 꺼낸 주문서는 button 에 (없으면 0) */
void Event_Wait(void)
{
    button = 0;
    osMessageQueueGet(EventQueueHandle, &button, NULL, EVENT_MS);
}

/* 긴급정지 : 핀을 직접 읽음 (접점이 떨려도 한 번만) / 눌림 → 'E' (알람 09), 풀림 → Y 해제 + 'A' (RESET → 시작 으로 원점) */
void estop_event(void)
{
    int pressed = (HAL_GPIO_ReadPin(ESTOP_GPIO_Port, ESTOP_Pin) == GPIO_PIN_SET);

    if (pressed == 0 && state.now == 'E') { AM_EStop(0); state.now = 'A'; }   /* 풀림 (한 번) : 알람으로 */
    if (pressed == 1 && state.now == 'E') return;                              /* 눌린 채 : 이미 함 */
    if (pressed == 1) A_09();                                                  /* 눌림 (한 번) : 세우기 + 'E' + 번호 + PC + 부저 */
}

/* 시작 : 부저 · 만재 알림 끔 → 'M'(전 'I') 면 수동 끄고 → 'I' 면 원점 / 'S' 면 이어서
   켤 때도 이걸로 원점 (Comm_Task : FRAM 읽은 뒤) */
void btn_run(void)
{
    MOVE home = { CMD_I };                              /* 원점 주문 (나머지 칸 0) */

    Buzzer_Off();                                       /* 부저 끔 */
    manjae_1 = 0;                                       /* 만재 알림 끝 (빨간불 끔) */
    manjae_2 = 0;
    card_1 = 0;                                         /* 시딩월 알림 끝 */
    card_2 = 0;

    if (state.now == 'M' && state.prev == 'I') {        /* 수동 중 (원점 전) : JOG 세우고 수동 끔 → 아래 원점 */
        HMI_Manual(BTN_JOG_STOP);
        state.now = 'I';
    }
    if (state.now == 'I') Motor_Request(home);          /* 초기상태 → 원점 (run.c 모터 문) */
    if (state.now == 'S') {                             /* 멈춤 → 이어서 */
        if ((state.why == 'F' || state.why == 'T') && PO_manjae()) return;   /* 만재 · 틸트로 멈췄는데 그 칸 아직 만재 → 안 풀림 (치우고 다시, 억지로는 PC D) */
        Pause_Clear();                                  /* 정지선에서 이어서 (status.c) */
    }
}

/* 수동 (HMI 33 · CLI MANUAL) : 'M' 이면 끔 (전 상태로) / 'W' · 'I' 면 켬 (그 밖은 안 함)
   알람 중엔 안 켬 → 먼저 RESET. 순서 : 알람 → RESET → 수동 → JOG 로 위치 맞춤 → 시작 (수동 꺼지고 원점) */
void btn_manual(void)
{
    if (state.now == 'M') {                             /* 끄기 : JOG 중이었으면 세우고 전 상태로 */
        HMI_Manual(BTN_JOG_STOP);
        state.now = state.prev;
        return;
    }
    if (state.now == 'W' || state.now == 'I') {         /* 켜기 : 대기 · 초기상태에서만 */
        state.prev = state.now;                         /*   끄면 돌아갈 곳 */
        state.now = 'M';
    }
}

/* 터치 버튼 : Event_Wait 가 꺼내 둔 것 하나 (바뀐 순간만 옴) → 블록 한 줄. 없으면 X JOG 다시 쓰기 (안 쓰면 섬) */
void hmi_event(void)
{
    switch (button)
    {
    case 0:                  if (jog_x) HMI_Manual(0);   break;   /* 버튼 없음 : X JOG 중이면 다시 쓰기 */
    case BTN_RUN:            btn_run();             break;   /* 원점 / 멈춤 풀기 */
    case BTN_STOP:           Pause_Set(0, 'M');     break;   /* 일시정지 M (status.c) */
    case BTN_RESET:          Alarm_Clear();         break;   /* 무엇이든 처음으로 → 'I' (alarm.c) */
    case BTN_MANUAL:         btn_manual();          break;   /* 수동 켜기 / 끄기 */
    case BTN_SOUND_OFF:      Buzzer_Off();          break;   /* 음소거 (다음 일시정지 · 알람 때 다시 켜짐) */
    case BTN_JOG_STOP:                                       /* JOG 뗌 · 21 ~ 26 누름 : 수동일 때만 (hmi.c) */
    case BTN_TILT_Lift:
    case BTN_TILT_Right:
    case BTN_LIFT_UP:
    case BTN_LIFT_Down:
    case BTN_TRAVEL_Forward:
    case BTN_TRAVEL_Back:    HMI_Manual(button);    break;
    default:                 break;                          /* 긴급정지 'E' · 만재 'M' : 깨우기만 (estop_event · manjae_change 가 핀 읽음) */
    }
}

/* 램프 : 아래로 갈수록 우선 (뒤 함수가 앞에서 켠 램프를 덮어씀). PC(2500) 연결 중엔 알람 · 원점만 보드, 나머지는 PC LL */
void lamp_event(void)
{
    lamp_tcp();         /* 평소 : PC 연결 = PC LL 6개 / 안 연결 = R · G 끔, Y 카드 */
    lamp_manjae(manjae_1 || card_1, manjae_2 || card_2);   /* 만재 · 시딩월 알림 중인 렉 : R 느리게 (PC 연결 중엔 안 함) */
    lamp_alarm();       /* 긴급정지 · 알람 = 두 렉 R 빠르게 (늘) / 일시정지 = 그 렉만 (PC 연결 중엔 안 함) */
    lamp_home();        /* 원점 중 : 6개 전부 느리게 (늘) */
}


/* ============ 2. 인터럽트 : 태스크 깨우기만 (판단은 깨어난 태스크가) ============ */

/* 핀 인터럽트 (EXTI) : 긴급정지 · 만재 → Event_Task (EventQueue 'E' · 'M') / W6100 INT → Comm_Task (CommQueue 'N') 깨우기만 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    uint8_t task_copy = PC_NET;     /* 주문서 : W6100 일 있음 */
    uint8_t ev_copy;                /* 주문서 : Event_Task 로 (긴급정지 · 만재) */

    /* W6100 (PE1, 1 → 0 순간) : PC 글자 옴 · 접속 · 끊김 → Comm_Task 바로 깨움 (무슨 일인지는 net.c 가 읽음, 인터럽트라 기다림 0) */
    if (GPIO_Pin == W610_INT_Pin)
        osMessageQueuePut(CommQueueHandle, &task_copy, 0, 0);

    /* 긴급정지 : 깨우기만 (눌림 / 풀림 판단은 estop_event 가 핀을 읽어서) */
    if (GPIO_Pin == ESTOP_Pin) {
        ev_copy = EV_ESTOP;
        osMessageQueuePut(EventQueueHandle, &ev_copy, 0, 0);
    }

    /* 만재 (PE11 FULL_1_1 은 EXTI11 이 긴급정지라 빠짐 : 20ms 읽기로 확인) */
    if (GPIO_Pin == FULL_2_1_Pin || GPIO_Pin == FULL_2_2_Pin ||
        GPIO_Pin == FULL_2_3_Pin || GPIO_Pin == FULL_2_4_Pin ||
        GPIO_Pin == FULL_1_2_Pin || GPIO_Pin == FULL_1_3_Pin ||
        GPIO_Pin == FULL_1_4_Pin) {
        ev_copy = EV_FULL;
        osMessageQueuePut(EventQueueHandle, &ev_copy, 0, 0);
    }
}
