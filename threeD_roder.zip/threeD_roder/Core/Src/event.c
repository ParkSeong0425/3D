/*
 * event.c : "이런 상황이면 이렇게" (기본 함수 파일들을 모아서 상황 처리)
 *
 *  1. Event_Task (High) : Event_Run 이 100ms 마다 돌림 (긴급정지 · 만재 인터럽트면 바로)
 *       읽기  estop_event  긴급정지 눌림 / 풀림
 *             hmi_event    HMI 통신 (실패 → 알람 01) · RUN · STOP · RESET · 수동 모드 · 음소거 (수동 움직임은 hmi.c)
 *             manjae_event 만재 바뀌면 PC 로
 *             rfid_event   카드 확인
 *             alarm_event  드라이브 알람 (지금 뺌)
 *       램프  lamp_event
 *  2. 인터럽트 : HAL_GPIO_EXTI_Callback (Event_Task 깨우기만)
 */

#include "event.h"
#include "hmi.h"
#include "rfid.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "lamp.h"
#include "cli.h"
#include "net.h"
#include "alarm.h"
#include "cmd.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "buzzer.h"
#include "cmsis_os.h"
#include <stdio.h>

#define ESTOP_FLAG  0x02    /* 긴급정지 인터럽트 → Event_Task 깨움 */
#define FULL_FLAG   0x04    /* 만재 인터럽트 → Event_Task 깨움 */
#define EVENT_MS    100     /* 이벤트 확인 간격 */

extern osThreadId_t Event_TaskHandle;
extern osThreadId_t Motor_TaskHandle;   /* 원점 요청 때 깨움 */
extern osTimerId_t Manjae_TimerHandle;  /* 만재 2초 타이머 (app_freertos.c) */

volatile int estop;         /* 1 = 긴급정지 눌림 */
volatile int manual;        /* 1 = 수동 모드 (설정 → 수동 버튼) */


/* ======================= 1. Event_Task : 100ms 마다 확인 ======================= */

/* 긴급정지 : 핀을 직접 읽음 (접점이 떨려도 한 번만) / 눌리면 멈춤, 풀리면 Y 해제 (원점은 RESET → RUN) */
static void estop_event(void)
{
    int pressed = (HAL_GPIO_ReadPin(ESTOP_GPIO_Port, ESTOP_Pin) == GPIO_PIN_SET);

    /* 눌림 (한 번) : 알람 09 (세우기 + 상태 A + 번호 + PC + 부저) */
    if (pressed == 1 && estop == 0) {
        estop = 1;
        A_09(0);
    }

    /* 풀림 (한 번) : Y 비상정지만 풀고 멈춰 있음. 알람 다시 걸어 둠 (눌린 사이 바뀌었어도 RESET → RUN 으로만) */
    if (pressed == 0 && estop == 1) {
        estop = 0;
        AM_EStop(0);
        Status_Alarm();
    }
}

/* 터치패드 : HMI 통신 (실패 → 알람 01) · RUN · STOP · RESET · 수동 모드 · 음소거 (수동 움직임은 hmi.c) */
static void hmi_event(void)
{
    int button;

    button = HMI_Run();          /* 상태 보내고 버튼 받기 */
    A_01(button);                /* 통신 안 되면 알람 01 */

    if (button == 0) return;     /* 안 눌림 */

    /* 수동 버튼 (21~26) : 수동 모드일 때만 hmi.c 가 움직임 */
    if (button >= BTN_TILT_Lift && button <= BTN_TRAVEL_Back) {
        if (manual == 1) HMI_Manual(button);
        return;
    }

    switch (button)
    {
    case BTN_RUN:
        if (estop == 0 && status_1 == RESTART) {       /* 리셋 뒤 : 원점 요청 → Motor_Task 가 I() */
            manual = 0;
            Status_HOME();
            osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);   /* 초인종 : Motor_Task 가 원점 */
            break;
        }
        if (pause_why == 'M' || pause_why == 'T') Status_Resume();   /* 일시정지 풀기 : 사용자 · 틸트만 */
        break;

    case BTN_STOP:
        Status_PAUSE(0);                            /* 일시정지 : 모든 렉 빨간불 (MI / PO 가 정지선에서 섬) */
        pause_why = 'M';                            /* 이유 : 사용자 (HMI 화면 4번) */
        pause_event_on = 1;                         /* PC 로 PPAUSE:M */
        break;

    case BTN_RESET:
        /* 처음 상태로 : 드라이브 알람, 일시정지, 수동 모두 풀고 RUN(원점) 기다림. 긴급정지 중 / 동작 중엔 안 함 */
        if (estop == 1) break;
        if (status_1 == RUN || status_2 == RUN || status_3 == RUN || status_4 == RUN || status_1 == HOME) break;
        IM_AlarmReset();            /* 드라이브 알람 리셋 : X */
        AM_AlarmReset();            /*                     Y */
        TM_AlarmReset();            /*                     틸트 */
        AM_EStop(0);
        manual = 0;
        Alarm_Clear();              /* 알람 번호 지움 */
        Status_INIT();
        Buzzer_Off();               /* 알람 부저 끔 */
        break;

    case BTN_MANUAL:
        /* 수동 모드 켜기 / 끄기 : 대기 중일 때만 켬 */
        if (manual == 1) manual = 0;
        else if (status_1 == WAIT && status_2 == WAIT && status_3 == WAIT && status_4 == WAIT) manual = 1;
        break;

    case BTN_SOUND_OFF:
        Buzzer_Off();               /* 음소거 : 어떤 상황이든 부저 끔 (다음 원점 · 알람 때 다시 켜짐) */
        break;
    }
}

/* 만재 : 센서가 바뀔 때마다 2초 타이머 다시 감기 (2초 동안 그대로면 Callback_Manjae_Timer 가 한 번 알림) */
static void manjae_event(void)
{
    if (manjae_change())                            /* 센서 바뀜 (스침 포함) */
        osTimerStart(Manjae_TimerHandle, 2000);     /* 처음부터 다시 2초 */
}
/* 카드 : 리더에 묻고 card_ok_1, card_ok_2 바꿈 */
static void rfid_event(void)
{
    Rfid_Check();
}

/* 램프 : Event_Task 에서 */
static void lamp_event(void)
{
    static uint32_t TCP_last_connetTime;   /* 마지막으로 PC 가 연결돼 있던 시각 */

    /* 긴급정지 / 원점 / 일시정지 : 전부 깜빡, 나머지는 안 함 */
    if (lamp_alarm_home() == 1)
        return;

    /* PC 연결 : 램프는 전부 PC 가 (LL 명령) */
    if (tcp_on == 1) {
        TCP_last_connetTime = osKernelGetTickCount();
        lamp_tcp();
    }

    /* PC 안 연결 : R, G 끔 / Y 는 끊긴 지 2초 뒤 카드로 */
    else {
        Lamp_R1(LAMP_OFF); Lamp_G1(LAMP_OFF);
        Lamp_R2(LAMP_OFF); Lamp_G2(LAMP_OFF);

        if (osKernelGetTickCount() - TCP_last_connetTime >= 2000) lamp_rfid();
    }

    /* 만재 / 카드 없음 : R 깜빡 (PC 램프보다 먼저) */
    lamp_manjae();
}

/* Event_Task 본체 : 읽기 → 램프 → 쉬기 반복 */
void Event_Run(void)
{
	Rfid_Init();

    for (;;) {
        /* 1. 읽기 */
    	estop_event();          /* 긴급정지 */
        hmi_event();            /* 터치 버튼 */
        manjae_event();         /* 만재 */
        rfid_event();           /* 카드 */
        // alarm_event();       /* 드라이브 알람 → A_02 ~ A_04 (잠시 뺌 : X 대답 없으면 Event_Task 가 멈춰서 카드 오인식) */

        /* 2. 램프 */
        lamp_event();

        /* 3. 100ms 쉬기 : 긴급정지, 만재면 바로 깨어남 */
        osThreadFlagsWait(ESTOP_FLAG | FULL_FLAG, osFlagsWaitAny, EVENT_MS);
    }
}


/* ============ 2. 인터럽트 : Event_Task 깨우기만 (판단은 Event_Task 가) ============ */

/* 긴급정지 인터럽트 (PD11, 누를 때 / 뗄 때) : 눌림 / 풀림 표시 + Event_Task 깨우기 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    /* 긴급정지 : 깨우기만 (눌림 / 풀림 판단은 estop_event 가 핀을 읽어서) */
    if (GPIO_Pin == ESTOP_Pin)
        osThreadFlagsSet(Event_TaskHandle, ESTOP_FLAG);

    /* 만재 (PE11 FULL_1_1 은 EXTI11 이 긴급정지라 빠짐 : 100ms 읽기로 확인) */
    if (GPIO_Pin == FULL_2_1_Pin || GPIO_Pin == FULL_2_2_Pin ||
        GPIO_Pin == FULL_2_3_Pin || GPIO_Pin == FULL_2_4_Pin ||
        GPIO_Pin == FULL_1_2_Pin || GPIO_Pin == FULL_1_3_Pin ||
        GPIO_Pin == FULL_1_4_Pin) {
        osThreadFlagsSet(Event_TaskHandle, FULL_FLAG);
        osThreadFlagsSet(Motor_TaskHandle, TOUCH_FLAG);     /* PO 쏟는 동안 기다리는 Motor_Task 도 깨움 */
    }
}
