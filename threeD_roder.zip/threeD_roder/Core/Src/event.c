/*
 * event.c : "이런 상황이면 이렇게" (기본 함수 파일들을 모아서 상황 처리)
 *
 *  1. Event_Task (High) : Event_Run 이 100ms 마다 돌림 (긴급정지 · 만재 인터럽트면 바로)
 *       읽기  estop_event  긴급정지 눌림 / 풀림
 *             hmi_event    HMI 통신 (실패 → 알람 01) · RUN · STOP · RESET · 수동 모드 · 음소거 (수동 움직임은 hmi.c)
 *             manjae_event 만재 바뀌면 2초 타이머 (확정은 Callback_Manjae_Timer)
 *             alarm_event  드라이브 알람 02 ~ 04 (1초마다)
 *       (카드 RFID 는 Rfid_Timer 가 0.5초마다 Rfid_Check)
 *       램프  lamp_event
 *  2. 인터럽트 : HAL_GPIO_EXTI_Callback (Event_Task 깨우기만)
 */

#include "event.h"
#include "hmi.h"
#include "rfid.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "lamp.h"
#include "cli.h"
#include "net.h"
#include "alarm.h"
#include "cmd.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "buzzer.h"
#include "debug.h"
#include "cmsis_os.h"
#include <stdio.h>

#define ESTOP_FLAG  0x02    /* 긴급정지 인터럽트 → Event_Task 깨움 */
#define FULL_FLAG   0x04    /* 만재 인터럽트 → Event_Task 깨움 */
#define EVENT_MS    100     /* 이벤트 확인 간격 */
#define ALARM_CHECK_MS 1000 /* 드라이브 알람 · 통신 확인 간격 */


volatile int estop;         /* 1 = 긴급정지 눌림 */
volatile int manual;        /* 1 = 수동 모드 (설정 → 수동 버튼) */


/* ======================= 1. Event_Task : 100ms 마다 확인 ======================= */

/* 긴급정지 : 핀을 직접 읽음 (접점이 떨려도 한 번만) / 눌리면 멈춤, 풀리면 Y 해제 (원점은 RESET → RUN) */
static void estop_event(void)
{
    int pressed = (HAL_GPIO_ReadPin(ESTOP_GPIO_Port, ESTOP_Pin) == GPIO_PIN_SET);

    /* 눌림 (한 번) : 알람 09 (세우기 + 상태 A + 번호 + PC + 부저) */
    if (pressed == 1 && estop == 0) {
        estop = 1;
        A_09(0);
    }

    /* 풀림 (한 번) : Y 비상정지만 풀고 멈춰 있음. 알람 다시 걸어 둠 (눌린 사이 바뀌었어도 RESET → RUN 으로만) */
    if (pressed == 0 && estop == 1) {
        estop = 0;
        AM_EStop(0);
        Status_Alarm();
    }
}

/* 터치패드 : HMI 통신 (실패 → 알람 01) · RUN · STOP · RESET · 수동 모드 · 음소거 (수동 움직임은 hmi.c) */
static void hmi_event(void)
{
    int button;

    button = HMI_Run();          /* 상태 보내고 버튼 받기 */
    A_01(button);                /* 통신 안 되면 알람 01 — 사무실 시험(HMI 없음)이라 꺼 둠 : 현장에선 주석 풀 것 */

    if (button == 0) return;     /* 안 눌림 */

    /* 수동 버튼 (21~26) : 수동 모드일 때만 hmi.c 가 움직임 */
    if (button >= BTN_TILT_Lift && button <= BTN_TRAVEL_Back) {
        if (manual == 1) HMI_Manual(button);
        return;
    }

    switch (button)
    {
    case BTN_RUN:
    	Buzzer_Off();
        /* 리셋 뒤 : 원점 (상태 · 부저 · 움직임은 run.c Motor_Run) */
        if (estop == 0 && status_1 == RESTART) {
            manual = 0;
            osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);   /* 원점 해 */
            break;
        }
        if (pause_why == 'M' || pause_why == 'T') Status_Resume();   /* 일시정지 풀기 : 사용자 · 틸트만 */
        break;

    case BTN_STOP:
        Status_PAUSE(0, 'M');                       /* 일시정지 : 모든 렉, 이유 사용자 (HMI 4번 · PC PPAUSE:M). MI / PO 가 정지선에서 섬 */
        Log_Debug(LOG_PAUSE);
        break;

    case BTN_RESET:
        /* 처음부터 다시 : 알람 · 수동 풀고 → 바로 원점 (Motor_Task). 긴급정지 · 동작 · 원점 중엔 안 함 */
        if (estop == 1 || status_1 == RUN || status_2 == RUN || status_3 == RUN || status_4 == RUN || status_1 == HOME) break;
        manual = 0;                                       /* 수동 모드 끔 */
        Alarm_Clear();                                    /* 드라이브 알람 리셋 · 번호 지움 · 초기상태 · 부저 끔 (alarm.c) */
        osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);   /* 원점 해 (run.c motor_basic_init : 설정 → 원점 → 대기) */
        break;

    case BTN_MANUAL:
        /* 수동 모드 켜기 / 끄기 : 대기 / 알람 05 · 06 · 07 · 10 (끼임 풀기 : 소프트웨어 알람이라 드라이브는 멀쩡) 일 때만 켬 */
        if (manual == 1) manual = 0;
        else if (status_1 == WAIT && status_2 == WAIT && status_3 == WAIT && status_4 == WAIT) manual = 1;
        else if (status_1 == ALARM && (alarm_1 == 5 || alarm_1 == 6 || alarm_1 == 7 || alarm_1 == 10)) manual = 1;
        break;

    case BTN_SOUND_OFF:
        Buzzer_Off();               /* 음소거 : 어떤 상황이든 부저 끔 (다음 원점 · 알람 때 다시 켜짐) */
        break;
    }
}

/* 만재 : 센서가 바뀌면 바로 PC FF + 2초 타이머 다시 감기 (2초 동안 그대로면 Callback_Manjae_Timer 가 부저) */
static void manjae_event(void)
{
    if (manjae_change()) {                          /* 센서 바뀜 (스침 포함) */
        full_event_on = 1;                          /* PC 로 FF 바로 (CMD_Event) */
        osTimerStart(Manjae_TimerHandle, MANJAE_MS);    /* 처음부터 다시 2초 */
    }
}

/* 드라이브 알람 02 ~ 04 · 모터 통신 끊김 11 : 1초마다, 원점 중 · 대기 · 운전 · 일시정지에 물음
   (초기상태 = 아직 드라이브 설정 전 / 알람 · 긴급정지 중엔 다시 안 물음) */
static void alarm_event(void)
{
    static uint32_t last;                       /* 마지막으로 물어본 시각 */

    if (osKernelGetTickCount() - last < ALARM_CHECK_MS) return;
    last = osKernelGetTickCount();

    if (estop == 1 || status_1 == ALARM || status_1 == RESTART) return;

    if (A_02()) return;                         /* X : 걸었으면 나머지는 안 물음 */
    if (A_03()) return;                         /* Y */
    A_04();                                     /* 틸트 */
}

/* 램프 : 아래로 갈수록 우선 (뒤 함수가 앞에서 켠 램프를 덮어씀) */
static void lamp_event(void)
{
    lamp_tcp();         /* 평소 : PC 연결 = PC LL / 안 연결 = R · G 끔, Y 카드 */
    lamp_manjae();      /* 만재(2초) · 카드 없음 : R 느리게 깜빡 */
    lamp_alarm();       /* 긴급정지 · 알람 · 일시정지 : R 빠르게 깜빡 */
    lamp_home();        /* 원점 중 : 6개 전부 느리게 깜빡 */
}

/* Event_Task 본체 : 읽기 → 램프 → 쉬기 반복 */
void Event_Run(void)
{
    Rfid_Init();                /* CAN 켜기 + 카드 0.5초 타이머 시작 (한 번만) */

    for (;;) {
        /* 1. 읽기 */
    	estop_event();          /* 긴급정지 */
        manjae_event();         /* 만재 */
        hmi_event();            /* 터치 버튼 */
        alarm_event();          /* 드라이브 알람 02 ~ 04 (1초마다) */

        /* 2. 램프 */
        lamp_event();

        /* 3. 100ms 쉬기 : 긴급정지, 만재면 바로 깨어남 */
        osThreadFlagsWait(ESTOP_FLAG | FULL_FLAG, osFlagsWaitAny, EVENT_MS);
    }
}


/* ============ 2. 인터럽트 : Event_Task 깨우기만 (판단은 Event_Task 가) ============ */

/* 긴급정지 인터럽트 (PD11, 누를 때 / 뗄 때) : 눌림 / 풀림 표시 + Event_Task 깨우기 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    /* 긴급정지 : 깨우기만 (눌림 / 풀림 판단은 estop_event 가 핀을 읽어서) */
    if (GPIO_Pin == ESTOP_Pin)
        osThreadFlagsSet(Event_TaskHandle, ESTOP_FLAG);

    /* 만재 (PE11 FULL_1_1 은 EXTI11 이 긴급정지라 빠짐 : 100ms 읽기로 확인) */
    if (GPIO_Pin == FULL_2_1_Pin || GPIO_Pin == FULL_2_2_Pin ||
        GPIO_Pin == FULL_2_3_Pin || GPIO_Pin == FULL_2_4_Pin ||
        GPIO_Pin == FULL_1_2_Pin || GPIO_Pin == FULL_1_3_Pin ||
        GPIO_Pin == FULL_1_4_Pin) {
        osThreadFlagsSet(Event_TaskHandle, FULL_FLAG);
    }
}
