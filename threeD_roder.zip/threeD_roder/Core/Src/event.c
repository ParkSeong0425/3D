/*
 * event.c : 상황 확인 (Event_Task)
 */

#include "event.h"
#include "hmi.h"
#include "rfid.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "lamp.h"
#include "cli.h"
#include "net.h"
#include "alarm.h"
#include "cmd.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "cmsis_os.h"
#include <stdio.h>

#define ESTOP_FLAG  0x02    /* 긴급정지 인터럽트 → Event_Task 깨움 */
#define FULL_FLAG   0x04    /* 만재 인터럽트 → Event_Task 깨움 */
#define EVENT_MS    100     /* 이벤트 확인 간격 */
#define Y           50      /* 수동 이동 한 번 : mm */
#define X           100

extern osThreadId_t Event_TaskHandle;
extern osThreadId_t Motor_TaskHandle;   /* 원점 요청 때 깨움 */

volatile int estop;         /* 1 = 긴급정지 눌림 */
volatile int manual;        /* 1 = 수동 모드 (설정 → 수동 버튼) */


/* 긴급정지 : 핀을 직접 읽음 (접점이 떨려도 한 번만) / 눌리면 멈춤, 풀리면 Y 해제 (원점은 RESET → RUN) */
static void estop_event(void)
{
    int pressed = (HAL_GPIO_ReadPin(ESTOP_GPIO_Port, ESTOP_Pin) == GPIO_PIN_SET);

    /* 눌림 (한 번) : 알람 (A_09 안에서 E_S 로 세움) */
    if (pressed == 1 && estop == 0) {
        estop = 1;
        A_09(0);                    /* 알람 09 비상정지 : 모든 렉, PC 로 S_1_A_09&S_2_A_09 */
    }

    /* 풀림 (한 번) : Y 비상정지만 풀고 멈춰 있음. 알람 다시 걸어 둠 (눌린 사이 바뀌었어도 RESET → RUN 으로만) */
    if (pressed == 0 && estop == 1) {
        estop = 0;
        AM_EStop(0);
        Status_Alarm();
    }
}

/* 터치 버튼 : 눌린 버튼마다 할 일 */
static void hmi_event(void)
{
    static int fail;             /* HMI 연속 통신 실패 횟수 */
    int button;
    int32_t now = 0;

    button = HMI_Run();          /* 상태 보내고 버튼 받기 */
    if (button != HMI_FAIL) fail = 0;   /* 응답 옴 */
    if (button == 0) return;     /* 안 눌림 */

    /* 수동 버튼 (21~26) : 수동 모드일 때만 */
    if (button >= BTN_TILT_Lift && button <= BTN_TRAVEL_Back && manual == 0) return;

    switch (button)
    {
    case HMI_FAIL:                  /* HMI 응답 없음 · 꼬임 */
        fail++;
        if (fail == 20) A_01(0);    /* 약 3초 계속 → 알람 한 번 */
        break;

    case BTN_RUN:
        if (estop == 0 && status_1 == RESTART) {       /* 리셋 뒤 : 원점 요청 → Motor_Task 가 I() */
            manual = 0;
            Status_HOME();
            osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);   /* 초인종 : Motor_Task 가 원점 */
            break;
        }
        if (pause_why == 'M' || pause_why == 'T') Status_Resume();   /* 일시정지 풀기 : 사용자 · 틸트만 */
        break;

    case BTN_STOP:
        Status_PAUSE(0);                            /* 일시정지 : 모든 렉 빨간불 (MI / PO 가 정지선에서 섬) */
        pause_why = 'M';                            /* 이유 : 사용자 (HMI 화면 4번) */
        pause_event_on = 1;                         /* PC 로 PPAUSE:M */
        break;

    case BTN_TILT_Lift:
    	TM_Pos(&now);
        TM_R(now-10, 50);
        break;

    case BTN_TILT_Right:
    	TM_Pos(&now);
        TM_L(now-10, 50);
        break;

    case BTN_LIFT_UP:
        AM_Pos(&now);
        AM_Move(now + Y, 30);        /* AM_Move 는 "그 위치로" 이동 */
        break;

    case BTN_LIFT_Down:
        AM_Pos(&now);
        AM_Move(now - Y, 30);
        break;

    case BTN_TRAVEL_Forward:
        IM_Pos(&now);
        IM_Move(now + X, 20);
        break;

    case BTN_TRAVEL_Back:
        IM_Pos(&now);
        IM_Move(now - X, 20);
        break;

    case BTN_RESET:
        /* 처음 상태로 : 드라이브 알람, 일시정지, 수동 모두 풀고 RUN(원점) 기다림. 긴급정지 중 / 동작 중엔 안 함 */
        if (estop == 1) break;
        if (status_1 == RUN || status_2 == RUN || status_3 == RUN || status_4 == RUN || status_1 == HOME) break;
        IM_AlarmReset();            /* 드라이브 알람 리셋 : X */
        AM_AlarmReset();            /*                     Y */
        TM_AlarmReset();            /*                     틸트 */
        AM_EStop(0);
        manual = 0;
        Alarm_Clear();              /* 알람 번호 지움 */
        Status_INIT();
        break;

    case BTN_MANUAL:
        /* 수동 모드 켜기 / 끄기 : 대기 중일 때만 켬 */
        if (manual == 1) manual = 0;
        else if (status_1 == WAIT && status_2 == WAIT && status_3 == WAIT && status_4 == WAIT) manual = 1;
        break;
    }
}

/* 만재 : 바뀌었을 때만 */
static void manjae_event(void)
{
    if (Full_Read() == 0) return;       /* 그대로면 할 일 없음 */
    full_event_on = 1;                       /* PC 로 알림 (full_1, full_2 는 Full_Read 가 바꿈) */
}

/* 카드 : 리더에 묻고 card_ok_1, card_ok_2 바꿈 */
static void rfid_event(void)
{
    Rfid_Check();
}

/* PO 만재 : 도착했을 때(move_done 1) 그 단이 만재면 멈춤 → 센서가 풀리거나 PC D 까지 */
static void PO_manjae(int rack, int dan, int move_done)
{
    if (move_done == 0) return;                            /* 도착 때만 */
    if (floor_full(rack, dan) == 0) return;                /* 만재 아님 */

    Status_PAUSE(rack); pause_why = 'F'; pause_event_on = 1;                                        /* 멈춤 + PC 알림 */
    while (floor_full(rack, dan) == 1 && (status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE) && estop == 0) osDelay(20);   /* 풀릴 때까지 (PC D 면 PAUSE 가 풀림) */
    Status_RUN(rack);                                      /* 다시 운전 */
}

/* PO 카드 : 도착했을 때(move_done 1) 그 렉 카드가 없으면 멈춤 → 카드가 들어올 때까지 */
static void PO_rfid(int rack, int move_done)
{
    if (move_done == 0) return;                            /* 도착 때만 */
    if (rack == 1 && card_ok_1 == 1) return;               /* 카드 있음 */
    if (rack == 2 && card_ok_2 == 1) return;

    Status_PAUSE(rack); pause_why = 'S'; pause_event_on = 1;                /* 멈춤 + PC 알림 */
    while (rack == 1 && card_ok_1 == 0 && estop == 0) osDelay(20);          /* 들어올 때까지 */
    while (rack == 2 && card_ok_2 == 0 && estop == 0) osDelay(20);
    Status_RUN(rack);                                      /* 다시 운전 */
}

/* PO 틸트 : 쏟는 동안(sensor_check ms) 그 단 만재 센서를 스쳤나 → 안 스쳤으면 틸트 일시정지 → 틸트 · STOP 이면 기울인 채 RUN 까지 */
static void PO_tilt(int rack, int dan, int sensor_check)
{
    int touch = 0;                                         /* 스쳤나 : 처음엔 안 스침 */

    if (sensor_check == 0) return;                         /* 쏟을 때만 */
    for (int i = 0; i < sensor_check && estop == 0; i += 20) {   /* 1. 쏟는 동안 20ms 마다 */
        if (floor_full(rack, dan) == 1) touch = 1;         /*    한 번이라도 스치면 기억 */
        osDelay(20);
    }
    if (touch == 0) { Status_PAUSE(rack); pause_why = 'T'; pause_event_on = 1; }   /* 2. 안 스침 → 멈춤 */
    while ((status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE) && estop == 0) osDelay(20);    /* 3. RUN 까지 */
    Status_RUN(rack);                                      /* 4. 다시 운전 */
}

/* PO 상황 : 함수만 부름. move_done 1 = 도착했을 때 / sensor_check = 쏟는 동안 센서 볼 시간(ms). 긴급정지면 0 → PO 그만 */
int PO_event(int rack, int dan, int move_done, int sensor_check)
{
    if (rack > 2) {                 /* 렉 3 · 4 : 만재 · 카드 센서가 아직 없음 → 확인 안 함 (센서 붙일 때 지움) */
        if (estop == 1) return 0;
        return 1;
    }

    PO_manjae(rack, dan, move_done);   /* 만재 */
    PO_rfid(rack, move_done);          /* 카드 */
    PO_tilt(rack, dan, sensor_check);     /* 틸트 */

    if (estop == 1) return 0;   /* 긴급정지 */
    return 1;
}

/* 알람 : 1초마다 드라이브 알람 읽기 (비상정지 · 이미 알람 · 초기상태면 안 봄) */
static void alarm_event(void)
{
    static uint32_t last;       /* 마지막 확인 시각 */
    IM_Info x = {0};            /* X : 상태 · 위치 · 알람 한 번에 */
    uint16_t y = 0;
    uint16_t t = 0;

    if (osKernelGetTickCount() - last < 1000) return;      /* 1초마다 */
    last = osKernelGetTickCount();
    if (estop == 1 || status_1 == ALARM || status_1 == RESTART) return;

    if (IM_MapRead(&x) == 1 && x.alarm != 0) A_02(0);      /* X 모터 */
    if (AM_AlarmRead(&y) == 1 && y != 0)     A_03(0);      /* Y 모터 */
    TM_State(&t);
    if ((t & TM_FAULT) != 0)                 A_04(0);      /* 틸트 모터 */

    /* 05 ~ 07 위치 : run.c wait_xy · wait_tilt 30초 */
    /* 10 원점 : 다음에 */
}

/* 램프 : Event_Task 에서 */
static void lamp_event(void)
{
    static uint32_t TCP_last_connetTime;   /* 마지막으로 PC 가 연결돼 있던 시각 */

    /* 긴급정지 / 원점 / 일시정지 : 전부 깜빡, 나머지는 안 함 */
    if (lamp_alarm_home() == 1)
        return;

    /* PC 연결 : 램프는 전부 PC 가 (LL 명령) */
    if (tcp_on == 1) {
        TCP_last_connetTime = osKernelGetTickCount();
        lamp_tcp();
    }

    /* PC 안 연결 : R, G 끔 / Y 는 끊긴 지 2초 뒤 카드로 */
    else {
        Lamp_R1(LAMP_OFF); Lamp_G1(LAMP_OFF);
        Lamp_R2(LAMP_OFF); Lamp_G2(LAMP_OFF);

        if (osKernelGetTickCount() - TCP_last_connetTime >= 2000) lamp_rfid();
    }

    /* 만재 / 카드 없음 : R 깜빡 (PC 램프보다 먼저) */
    lamp_manjae();
}

void Event_Run(void)
{
	Rfid_Init();

    for (;;) {
        /* 1. 읽기 */
    	estop_event();          /* 긴급정지 */
        hmi_event();            /* 터치 버튼 */
        manjae_event();         /* 만재 */
        rfid_event();           /* 카드 */
        // alarm_event();       /* 드라이브 알람 → A_02 ~ A_04 (잠시 뺌 : X 대답 없으면 Event_Task 가 멈춰서 카드 오인식) */

        /* 2. 램프 */
        lamp_event();

        /* 3. 100ms 쉬기 : 긴급정지, 만재면 바로 깨어남 */
        osThreadFlagsWait(ESTOP_FLAG | FULL_FLAG, osFlagsWaitAny, EVENT_MS);
    }
}

/* 긴급정지 인터럽트 (PD11, 누를 때 / 뗄 때) : 눌림 / 풀림 표시 + Event_Task 깨우기 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    /* 긴급정지 : 깨우기만 (눌림 / 풀림 판단은 estop_event 가 핀을 읽어서) */
    if (GPIO_Pin == ESTOP_Pin)
        osThreadFlagsSet(Event_TaskHandle, ESTOP_FLAG);

    /* 만재 (PE11 FULL_1_1 은 EXTI11 이 긴급정지라 빠짐 : 100ms 읽기로 확인) */
    if (GPIO_Pin == FULL_2_1_Pin || GPIO_Pin == FULL_2_2_Pin ||
        GPIO_Pin == FULL_2_3_Pin || GPIO_Pin == FULL_2_4_Pin ||
        GPIO_Pin == FULL_1_2_Pin || GPIO_Pin == FULL_1_3_Pin ||
        GPIO_Pin == FULL_1_4_Pin)
        osThreadFlagsSet(Event_TaskHandle, FULL_FLAG);
}
