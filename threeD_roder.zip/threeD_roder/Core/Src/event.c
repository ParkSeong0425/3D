/*
 * event.c : 상황 확인 (Event_Task)
 */

#include "event.h"
#include "hmi.h"
#include "rfid.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "lamp.h"
#include "cli.h"
#include "net.h"
#include "alarm.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "cmsis_os.h"
#include <stdio.h>

#define ESTOP_FLAG  0x02    /* 긴급정지 인터럽트 → Event_Task 깨움 */
#define FULL_FLAG   0x04    /* 만재 인터럽트 → Event_Task 깨움 */
#define EVENT_MS    100     /* 이벤트 확인 간격 */
#define Y           50      /* 수동 이동 한 번 : mm */
#define X           100

extern osThreadId_t Event_TaskHandle;

volatile int estop;         /* 1 = 긴급정지 눌림 */
volatile int manual;        /* 1 = 수동 모드 (설정 → 수동 버튼) */


/* 긴급정지 : 핀을 직접 읽음 (접점이 떨려도 한 번만) / 눌리면 멈춤, 풀리면 Y 해제 (원점은 RESET → RUN) */
static void estop_event(void)
{
    int pressed = (HAL_GPIO_ReadPin(ESTOP_GPIO_Port, ESTOP_Pin) == GPIO_PIN_SET);

    /* 눌림 (한 번) : 세 축 긴급정지 + 알람 */
    if (pressed == 1 && estop == 0) {
        estop = 1;
        A_09(0);                    /* 알람 09 비상정지 : 두 렉, PC 로 S_1_A_09&S_2_A_09 */
        E_S();
    }

    /* 풀림 (한 번) : Y 비상정지만 풀고 멈춰 있음. 알람 다시 걸어 둠 (눌린 사이 바뀌었어도 RESET → RUN 으로만) */
    if (pressed == 0 && estop == 1) {
        estop = 0;
        AM_EStop(0);
        Status_Alarm();
    }
}

/* 터치 버튼 : 눌린 버튼마다 할 일 */
static void hmi_event(void)
{
    int button;
    int32_t now = 0;

    button = HMI_Run();          /* 상태 보내고 버튼 받기 */
    if (button == 0) return;     /* 안 눌림 */

    /* 수동 버튼 (21~26) : 수동 모드일 때만 */
    if (button >= BTN_TILT_Lift && button <= BTN_TRAVEL_Back && manual == 0) return;

    switch (button)
    {
    case BTN_RUN:
        if (estop == 0 && status_1 == RESTART) {       /* 리셋 뒤 : 원점 요청 → Motor_Task 가 I() */
            manual = 0;
            Status_HOME();
            break;
        }
        if (pause_why == 'M' || pause_why == 'T') Status_Resume();   /* 일시정지 풀기 : 사용자 · 틸트만 */
        break;

    case BTN_STOP:
        Status_PAUSE(1);                            /* 일시정지 : 빨간불 (MI / PO 가 정지선에서 섬) */
        Status_PAUSE(2);
        pause_why = 'M';                            /* 이유 : 사용자 (HMI 화면 4번) */
        pause_event_on = 1;                         /* PC 로 PPAUSE:M */
        break;

    case BTN_TILT_Lift:
    	TM_Pos(&now);
        TM_R(now-10, 50);
        break;

    case BTN_TILT_Right:
    	TM_Pos(&now);
        TM_L(now-10, 50);
        break;

    case BTN_LIFT_UP:
        AM_Pos(&now);
        AM_Move(now + Y, 30);        /* AM_Move 는 "그 위치로" 이동 */
        break;

    case BTN_LIFT_Down:
        AM_Pos(&now);
        AM_Move(now - Y, 30);
        break;

    case BTN_TRAVEL_Forward:
        IM_Pos(&now);
        IM_Move(now + X, 20);
        break;

    case BTN_TRAVEL_Back:
        IM_Pos(&now);
        IM_Move(now - X, 20);
        break;

    case BTN_RESET:
        /* 처음 상태로 : 드라이브 알람, 일시정지, 수동 모두 풀고 RUN(원점) 기다림. 긴급정지 중 / 동작 중엔 안 함 */
        if (estop == 1) break;
        if (status_1 == RUN || status_2 == RUN || status_1 == HOME) break;
        AM_AlarmReset();
        AM_EStop(0);
        IM_MapInit();               /* 드라이브 설정 다시 (긴급정지로 전원이 끊겼어도) */
        AM_Init();
        TM_Init();
        manual = 0;
        Alarm_Clear();              /* 알람 번호 지움 */
        Status_INIT();
        break;

    case BTN_MANUAL:
        /* 수동 모드 켜기 / 끄기 : 대기 중일 때만 켬 */
        if (manual == 1) manual = 0;
        else if (status_1 == WAIT && status_2 == WAIT) manual = 1;
        break;
    }
}

/* 만재 : 바뀌었을 때만 */
static void manjae_event(void)
{
    if (Full_Read() == 0) return;       /* 그대로면 할 일 없음 */
    full_event_on = 1;                       /* PC 로 알림 (full_1, full_2 는 Full_Read 가 바꿈) */
}

/* 카드 : 리더에 묻고 card_ok_1, card_ok_2 바꿈 */
static void rfid_event(void)
{
    Rfid_Check();
}

/* PO 쏟는 동안 : 그 단 만재 센서를 한 번이라도 스쳤나 (1 = 스침) */
static int PO_pour(int rack, int dan, int ms)
{
    int touch = 0;

    for (int t = 0; t < ms; t += 20) {              /* 20ms 씩 쏟는 시간만큼 */
        if (estop == 1) break;                      /* 긴급정지 */
        if (floor_full(rack, dan) == 1) touch = 1;  /* 닿음 */
        osDelay(20);
    }
    return touch;
}

/* PO 도착했을 때 : 그 단 만재 · 그 렉 카드 없음 · 일시정지면 멈추고, 풀리면 진행. 긴급정지면 0 */
static int PO_arrive(int rack, int dan)
{
    /* 1. 멈출 이유 */
    if      (floor_full(rack, dan) == 1)   { Status_PAUSE(rack); pause_why = 'F'; pause_event_on = 1; }  /* 만재 */
    else if (rack == 1 && card_ok_1 == 0)  { Status_PAUSE(rack); pause_why = 'S'; pause_event_on = 1; }  /* 렉1 카드 없음 */
    else if (rack == 2 && card_ok_2 == 0)  { Status_PAUSE(rack); pause_why = 'S'; pause_event_on = 1; }  /* 렉2 카드 없음 */

    /* 2. 풀릴 때까지 */
    for (;;) {
        if      (estop == 1)                                      return 0;  /* 긴급정지 */
        else if (status_1 != PAUSE && status_2 != PAUSE)          break;     /* RUN · D 로 풀림 */
        else if (pause_why == 'F' && floor_full(rack, dan) == 0)  break;     /* 만재 풀림 */
        else if (pause_why == 'S' && rack == 1 && card_ok_1 == 1) break;     /* 렉1 카드 들어옴 */
        else if (pause_why == 'S' && rack == 2 && card_ok_2 == 1) break;     /* 렉2 카드 들어옴 */
        else osDelay(20);
    }

    /* 3. 다시 운전 */
    Status_RUN(rack);
    return 1;
}

/* PO 쏟은 뒤 : 만재 센서를 한 번도 안 스쳤으면 틸트 일시정지 (기울인 채로 RUN 까지). 긴급정지면 0 */
static int PO_poured(int rack, int touch)
{
    /* 1. 안 스침 : 틸트 일시정지 */
    if (touch == 0) { Status_PAUSE(rack); pause_why = 'T'; pause_event_on = 1; }

    /* 2. 풀릴 때까지 (틸트 · 사용자 일시정지 모두 RUN 으로) */
    while ((status_1 == PAUSE || status_2 == PAUSE) && estop == 0) osDelay(20);
    if (estop == 1) return 0;

    /* 3. 다시 운전 */
    Status_RUN(rack);
    return 1;
}

/* 분배 + 상황 (PC PO 명령) : run.c PO 의 줄을 나눠서, 단계 사이에 만재 · 카드 · 틸트 확인. 긴급정지면 0 */
int PO_event(int rack, int x, int y, int dan,
             int xy_speed, int tilt_speed,
             int move_delay, int return_delay,
             int tilt_angle, int tilting_y, int tilting_y_speed)
{
    int touch;      /* 쏟는 동안 만재 센서를 스쳤나 */

    /* 1. 이동 (run.c MO) */
    MO(x, y, xy_speed, tilt_speed);
    osDelay(move_delay);

    /* 2. 도착했을 때 : 그 단 만재 · 카드 없음 · 일시정지면 풀릴 때까지 */
    if (PO_arrive(rack, dan) == 0) return 0;

    /* 3. Y 올리면서 틸트 : Y 가 절반 올라가면 틸트 출발 (run.c PO 2번과 같음) */
    AM_Move(y + tilting_y, tilting_y_speed);
    wait_xy(x, y + tilting_y / 2);
    if (rack == 1) { TM_R(tilt_angle, tilting_y_speed); }
    else { TM_L(tilt_angle, tilting_y_speed); }
    wait_xy(x, y + tilting_y);
    wait_tilt(tilt_angle);

    /* 4. 쏟기 : 쏟는 동안 그 단 만재 센서를 스쳤나 */
    touch = PO_pour(rack, dan, return_delay * 10);

    /* 5. 쏟은 뒤 : 안 스쳤으면 틸트 일시정지, 기울인 채로 RUN 까지 */
    if (PO_poured(rack, touch) == 0) return 0;

    /* 6. Y, 틸트 복귀 (run.c PO 4번과 같음) */
    TM_C(tilting_y_speed);
    AM_Move(y, tilting_y_speed);
    wait_tilt(0);
    wait_xy(x, y);

    return 1;
}

/* 램프 : Event_Task 에서 */
static void lamp_event(void)
{
    static uint32_t TCP_last_connetTime;   /* 마지막으로 PC 가 연결돼 있던 시각 */

    /* 긴급정지 / 원점 / 일시정지 : 전부 깜빡, 나머지는 안 함 */
    if (lamp_alarm_home() == 1)
        return;

    /* PC 연결 : 램프는 전부 PC 가 (LL 명령) */
    if (tcp_on == 1) {
        TCP_last_connetTime = osKernelGetTickCount();
        lamp_tcp();
    }

    /* PC 안 연결 : R, G 끔 / Y 는 끊긴 지 2초 뒤 카드로 */
    else {
        Lamp_R1(LAMP_OFF); Lamp_G1(LAMP_OFF);
        Lamp_R2(LAMP_OFF); Lamp_G2(LAMP_OFF);

        if (osKernelGetTickCount() - TCP_last_connetTime >= 2000) lamp_rfid();
    }

    /* 만재 / 카드 없음 : R 깜빡 (PC 램프보다 먼저) */
    lamp_manjae();
}

void Event_Run(void)
{
	Rfid_Init();

    for (;;) {
        /* 1. 읽기 */
    	estop_event();          /* 긴급정지 */
        hmi_event();            /* 터치 버튼 */
        manjae_event();         /* 만재 */
        rfid_event();           /* 카드 */

        /* 2. 램프 */
        lamp_event();

        /* 3. 100ms 쉬기 : 긴급정지, 만재면 바로 깨어남 */
        osThreadFlagsWait(ESTOP_FLAG | FULL_FLAG, osFlagsWaitAny, EVENT_MS);
    }
}

/* 긴급정지 인터럽트 (PD11, 누를 때 / 뗄 때) : 눌림 / 풀림 표시 + Event_Task 깨우기 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    /* 긴급정지 : 깨우기만 (눌림 / 풀림 판단은 estop_event 가 핀을 읽어서) */
    if (GPIO_Pin == ESTOP_Pin)
        osThreadFlagsSet(Event_TaskHandle, ESTOP_FLAG);

    /* 만재 (PE11 FULL_1_1 은 EXTI11 이 긴급정지라 빠짐 : 100ms 읽기로 확인) */
    if (GPIO_Pin == FULL_2_1_Pin || GPIO_Pin == FULL_2_2_Pin ||
        GPIO_Pin == FULL_2_3_Pin || GPIO_Pin == FULL_2_4_Pin ||
        GPIO_Pin == FULL_1_2_Pin || GPIO_Pin == FULL_1_3_Pin ||
        GPIO_Pin == FULL_1_4_Pin)
        osThreadFlagsSet(Event_TaskHandle, FULL_FLAG);
}
