#include "fram.h"
#include "save.h"
#include "spi.h"
#include "cmsis_os2.h"

#define WREN   0x06
#define WRITE  0x02
#define READ   0x03

/* NSS : 1 = 선택(Low), 0 = 해제(High) */
static void chip(int on)
{
    if (on) {
        __HAL_SPI_ENABLE(&hspi1);
    }
    else {
        __HAL_SPI_DISABLE(&hspi1);
        osDelay(2);        /* 풀업으로 High 될 때까지 */
    }
}

/* save 전체를 FRAM 0번지에 저장 */
int FRAM_Save(void)
{
    uint8_t wren[1] = { WREN };
    uint8_t cmd[3]  = { WRITE, 0, 0 };
    int ok;

    /* 쓰기 허용 : NSS가 High로 올라가야 적용됨 */
    chip(1);
    ok = HAL_SPI_Transmit(&hspi1, wren, 1, 100) == HAL_OK;
    chip(0);
    if (!ok) return 0;

    /* 0번지부터 save 저장 */
    chip(1);
    ok = HAL_SPI_Transmit(&hspi1, cmd, 3, 100) == HAL_OK
      && HAL_SPI_Transmit(&hspi1, (uint8_t *)&save, sizeof(save), 100) == HAL_OK;
    chip(0);

    return ok;
}

/* FRAM 0번지에서 save 전체 읽기 */
int FRAM_Read(void)
{
    uint8_t cmd[3] = { READ, 0, 0 };
    int ok;

    chip(1);
    ok = HAL_SPI_Transmit(&hspi1, cmd, 3, 100) == HAL_OK
      && HAL_SPI_Receive(&hspi1, (uint8_t *)&save, sizeof(save), 100) == HAL_OK;
    chip(0);

    return ok;
}
