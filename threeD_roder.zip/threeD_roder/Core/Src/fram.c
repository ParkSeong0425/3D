/*
 * fram.c : FRAM 칩 읽기 · 쓰기만 (SPI1). 무엇을 어디에 둘지는 save.h 의 FRAM 지도 (HEAD · FS · FP · FI _ADDR)
 *
 *   FRAM_Write(주소, 칸, 크기) : 주소부터 크기만큼 쓰기
 *   FRAM_Read (주소, 칸, 크기) : 주소부터 크기만큼 읽기
 *
 *   명령 = [명령 1바이트][주소 2바이트][데이터 …]  (주소 2바이트 = 최대 64KB 칩)
 *   FRAM 은 지우기 없이 바로 써지고, 거의 무한히 다시 써도 됨
 */
#include "fram.h"
#include "spi.h"
#include "cmsis_os2.h"

#define WREN   0x06     /* 쓰기 허용 */
#define WRITE  0x02     /* 쓰기 */
#define READ   0x03     /* 읽기 */

/* 칩 선택 (NSS) : 1 = 선택(Low), 0 = 해제(High) */
static void chip(int on)
{
    if (on) {
        __HAL_SPI_ENABLE(&hspi1);
    }
    else {
        __HAL_SPI_DISABLE(&hspi1);
        osDelay(2);        /* 풀업으로 High 될 때까지 */
    }
}

/* addr 번지부터 data 를 size 바이트 쓰기. 성공 1 / 실패 0 */
int FRAM_Write(uint16_t addr, void *data, int size)
{
    uint8_t wren = WREN;
    uint8_t cmd[3] = { WRITE, addr >> 8, addr & 0xFF };     /* 쓰기 + 주소 (높은 바이트 먼저) */
    int ok;

    /* 1. 쓰기 허용 : NSS 가 High 로 올라가야 적용됨 */
    chip(1);
    ok = HAL_SPI_Transmit(&hspi1, &wren, 1, 100) == HAL_OK;
    chip(0);
    if (ok == 0) return 0;

    /* 2. 명령 + 주소 → 데이터 */
    chip(1);
    ok = HAL_SPI_Transmit(&hspi1, cmd, 3, 100) == HAL_OK
      && HAL_SPI_Transmit(&hspi1, (uint8_t *)data, size, 100) == HAL_OK;
    chip(0);

    return ok;
}

/* addr 번지부터 size 바이트 읽어 data 에. 성공 1 / 실패 0 */
int FRAM_Read(uint16_t addr, void *data, int size)
{
    uint8_t cmd[3] = { READ, addr >> 8, addr & 0xFF };      /* 읽기 + 주소 */
    int ok;

    chip(1);
    ok = HAL_SPI_Transmit(&hspi1, cmd, 3, 100) == HAL_OK
      && HAL_SPI_Receive(&hspi1, (uint8_t *)data, size, 100) == HAL_OK;
    chip(0);

    return ok;
}
