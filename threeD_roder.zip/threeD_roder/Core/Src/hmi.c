/*
 * hmi.c : 터치패드 통신만 (버튼 할 일은 event.c hmi_event)
 *
 * STM -> HMI : STX '1' 'C' 작업 일시정지 알람 센서20 ETX (27바이트)
 * HMI -> STM : STX '1' 버튼 ETX (버튼 = 번호 + '0', 11 RUN / 12 일시정지 / 21~26 수동 / 31~33 설정)
 */

#include "hmi.h"
#include "usart.h"
#include "status.h"
#include "event.h"
#include "manjae.h"
#include "rfid.h"
#include <stdint.h>

#define STX     0x02
#define ETX     0x03

/* 작업 : 0 초기상태, 1 대기, 2 운전, 3 일시정지, 5 원점설정, 6 알람 */
static char hmi_task(void)
{
    if (estop == 1 || status_1 == ALARM || status_2 == ALARM)  return '6';
    if (status_1 == HOME  || status_2 == HOME)                 return '5';
    if (status_1 == PAUSE || status_2 == PAUSE)                return '3';
    if (status_1 == RUN   || status_2 == RUN)                  return '2';
    if (status_1 == RESTART || status_2 == RESTART)            return '0';
    return '1';
}

/* 일시정지 : 0 없음, 1 시딩월(카드 없음), 2 만재, 3 틸트, 4 사용자 */
static char hmi_pause(void)
{
    if (status_1 == PAUSE || status_2 == PAUSE) {   /* 일시정지면 이유대로 */
        if (pause_why == 'F') return '2';           /* 만재 */
        if (pause_why == 'S') return '1';           /* 시딩월 */
        if (pause_why == 'T') return '3';           /* 틸트 */
        return '4';                                 /* 사용자 */
    }
    if (full_1 == 1 || full_2 == 1)             return '2';
    if (card_ok_1 == 0 || card_ok_2 == 0)       return '1';
    return '0';
}

/* 알람 : 0 없음, 1 수동, 9 비상정지 */
static char hmi_alarm(void)
{
    if (estop == 1 || status_1 == ALARM || status_2 == ALARM) return '9';
    if (manual == 1) return '1';
    return '0';
}

/* 보낼 틀 : 고정 칸은 처음부터 채워 두고, 바뀌는 칸(작업 일시정지 알람, 만재 8칸)만 매번 쓴다 */
static uint8_t tx[27] = { STX, '1', 'C',
                          '0', '0', '0',                /* 작업 / 일시정지 / 알람 */
                          '0', '0', '0', '0', '0',      /* 화면 왼쪽 칸  : 렉2 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 화면 오른쪽 칸 : 렉1 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 3번째 칸 : 안 씀 */
                          '0', '0', '0', '0', '0',      /* 4번째 칸 : 안 씀 */
                          ETX };

/* HMI 통신 : 상태 보내고 버튼 받기. 눌린 버튼 번호, 없으면 0 */
int HMI_Run(void)
{
    uint8_t rx[4];

    tx[3]  = hmi_task();                /* 작업 */
    tx[4]  = hmi_pause();               /* 일시정지 */
    tx[5]  = hmi_alarm();               /* 알람 */

    tx[6]  = full_2_1 ? '1' : '0';      /* 왼쪽 칸 : 렉2 */
    tx[7]  = full_2_2 ? '1' : '0';
    tx[8]  = full_2_3 ? '1' : '0';
    tx[9]  = full_2_4 ? '1' : '0';

    tx[11] = full_1_1 ? '1' : '0';      /* 오른쪽 칸 : 렉1 */
    tx[12] = full_1_2 ? '1' : '0';
    tx[13] = full_1_3 ? '1' : '0';
    tx[14] = full_1_4 ? '1' : '0';

    /* STM -> HMI 보내고, HMI -> STM 응답 올 때까지 잠든다 (최대 50ms) */
    if (UART4_Xfer(tx, 27, rx, 4, 50) != HAL_OK)
        return 0;

    /* 노이즈 막기 : 대답은 STX '1' 버튼 ETX. 고정된 3칸이 맞을 때만 버튼으로 본다 */
    if (rx[0] != STX ||
        rx[1] != '1' ||
        rx[3] != ETX)
        return 0;

    /* 버튼 : ESP 가 번호 + '0'(48) 으로 보냄 (STX 2, ETX 3 과 안 겹치게). 48 을 빼서 진짜 번호로 */
    return rx[2] - '0';
}
