/*
 * hmi.c : 터치패드 통신 + 수동 버튼 움직임 (RUN · STOP · RESET · 음소거 · 수동 모드는 event.c hmi_event)
 *
 * STM -> HMI : STX '1' 'C' 작업 일시정지 알람 센서20 ETX (27바이트)
 * HMI -> STM : STX '1' 버튼 ETX (버튼 = 번호 + '0', 11 RUN / 12 일시정지 / 21~26 수동 / 31~33 설정)
 */

#include "hmi.h"
#include "usart.h"
#include "status.h"
#include "event.h"
#include "manjae.h"
#include "rfid.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include <stdint.h>

#define STX     0x02
#define ETX     0x03
#define MANUAL_X     100     /* 수동 이동 한 번 : X mm */
#define MANUAL_Y     50      /*                   Y mm */
#define MANUAL_TILT  10      /*                   틸트 도 */

/* 작업 : 0 초기상태, 1 대기, 2 운전, 3 일시정지, 5 원점설정, 6 알람 */
static char hmi_task(void)
{
    if (estop == 1 || status_1 == ALARM || status_2 == ALARM || status_3 == ALARM || status_4 == ALARM)  return '6';
    if (status_1 == HOME    || status_2 == HOME    || status_3 == HOME    || status_4 == HOME)             return '5';
    if (status_1 == PAUSE   || status_2 == PAUSE   || status_3 == PAUSE   || status_4 == PAUSE)            return '3';
    if (status_1 == RUN     || status_2 == RUN     || status_3 == RUN     || status_4 == RUN)              return '2';
    if (status_1 == RESTART || status_2 == RESTART || status_3 == RESTART || status_4 == RESTART)          return '0';
    return '1';
}

/* 일시정지 : 0 없음, 1 시딩월(카드 없음), 2 만재, 3 틸트, 4 사용자 */
static char hmi_pause(void)
{
    if (status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE) {   /* 일시정지면 이유대로 */
        if (pause_why == 'F') return '2';           /* 만재 */
        if (pause_why == 'S') return '1';           /* 시딩월 */
        if (pause_why == 'T') return '3';           /* 틸트 */
        return '4';                                 /* 사용자 */
    }
    if (manjae_on(1, 1) || manjae_on(1, 2) || manjae_on(1, 3) || manjae_on(1, 4) ||
        manjae_on(2, 1) || manjae_on(2, 2) || manjae_on(2, 3) || manjae_on(2, 4)) return '2';   /* 만재 */
    if (card_ok_1 == 0 || card_ok_2 == 0)       return '1';
    return '0';
}

/* 알람 : 0 없음, 1 수동, 9 비상정지 */
static char hmi_alarm(void)
{
    if (estop == 1 || status_1 == ALARM || status_2 == ALARM || status_3 == ALARM || status_4 == ALARM) return '9';
    if (manual == 1) return '1';
    return '0';
}

/* 보낼 틀 : 고정 칸은 처음부터 채워 두고, 바뀌는 칸(작업 일시정지 알람, 만재 8칸)만 매번 쓴다 */
static uint8_t tx[27] = { STX, '1', 'C',
                          '0', '0', '0',                /* 작업 / 일시정지 / 알람 */
                          '0', '0', '0', '0', '0',      /* 화면 왼쪽 칸  : 렉2 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 화면 오른쪽 칸 : 렉1 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 3번째 칸 : 안 씀 */
                          '0', '0', '0', '0', '0',      /* 4번째 칸 : 안 씀 */
                          ETX };

/* HMI 통신 : 상태 보내고 버튼 받기. 눌린 버튼 번호, 없으면 0 */
int HMI_Run(void)
{
    uint8_t rx[4];

    tx[3]  = hmi_task();                /* 작업 */
    tx[4]  = hmi_pause();               /* 일시정지 */
    tx[5]  = hmi_alarm();               /* 알람 */

    tx[6]  = manjae_on(2, 1) ? '1' : '0';      /* 왼쪽 칸 : 렉2 */
    tx[7]  = manjae_on(2, 2) ? '1' : '0';
    tx[8]  = manjae_on(2, 3) ? '1' : '0';
    tx[9]  = manjae_on(2, 4) ? '1' : '0';

    tx[11] = manjae_on(1, 1) ? '1' : '0';      /* 오른쪽 칸 : 렉1 */
    tx[12] = manjae_on(1, 2) ? '1' : '0';
    tx[13] = manjae_on(1, 3) ? '1' : '0';
    tx[14] = manjae_on(1, 4) ? '1' : '0';

    /* STM -> HMI 보내고, HMI -> STM 응답 올 때까지 잠든다 (최대 50ms) */
    if (UART4_Xfer(tx, 27, rx, 4, 50) != HAL_OK)
        return HMI_FAIL;                /* 응답 없음 */

    /* 노이즈 막기 : 대답은 STX '1' 버튼 ETX. 고정된 3칸이 맞을 때만 버튼으로 본다 */
    if (rx[0] != STX ||
        rx[1] != '1' ||
        rx[3] != ETX)
        return HMI_FAIL;                /* 꼬임 */

    /* 버튼 : ESP 가 번호 + '0'(48) 으로 보냄 (STX 2, ETX 3 과 안 겹치게). 48 을 빼서 진짜 번호로 */
    return rx[2] - '0';
}

/* 수동 버튼 (21~26) : 지금 위치에서 조금씩 움직이기 (수동 모드일 때 event.c 가 부름) */
void HMI_Manual(int button)
{
    int32_t now = 0;

    switch (button)
    {
    case BTN_TILT_Lift:                     /* 틸트 왼쪽 (+) 10도 */
        TM_Pos(&now);
        TM_Move(now + MANUAL_TILT, 50);
        break;

    case BTN_TILT_Right:                    /* 틸트 오른쪽 (-) 10도 */
        TM_Pos(&now);
        TM_Move(now - MANUAL_TILT, 50);
        break;

    case BTN_LIFT_UP:                       /* Y 위로 */
        AM_Pos(&now);
        AM_Move(now + MANUAL_Y, 30);        /* AM_Move 는 "그 위치로" 이동 */
        break;

    case BTN_LIFT_Down:                     /* Y 아래로 */
        AM_Pos(&now);
        AM_Move(now - MANUAL_Y, 30);
        break;

    case BTN_TRAVEL_Forward:                /* X 앞으로 */
        IM_Pos(&now);
        IM_Move(now + MANUAL_X, 20);
        break;

    case BTN_TRAVEL_Back:                   /* X 뒤로 */
        IM_Pos(&now);
        IM_Move(now - MANUAL_X, 20);
        break;
    }
}
