/*
 * hmi.c : 터치패드 통신 + 수동 버튼 움직임 (RUN · STOP · RESET · 음소거 · 수동 모드는 event.c hmi_event)
 *
 * STM -> HMI : STX '1' 'C' 작업 일시정지 알람 센서20 ETX (27바이트)
 * HMI -> STM : STX '1' 버튼 ETX (버튼 = 번호 + '0', 11 RUN / 12 일시정지 / 21~26 수동 / 31~33 설정)
 */

#include "hmi.h"
#include "usart.h"
#include "status.h"
#include "event.h"
#include "manjae.h"
#include "rfid.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "alarm.h"
#include "save.h"
#include "cmsis_os2.h"
#include <stdint.h>

#define STX     0x02
#define ETX     0x03

/* 보낼 틀 : 고정 칸은 처음부터 채워 두고, 바뀌는 칸(작업 일시정지 알람, 만재 8칸)만 매번 쓴다 */
static uint8_t tx[27] = { STX, '1', 'C',
                          '0', '0', '0',                /* 작업 / 일시정지 / 알람 */
                          '0', '0', '0', '0', '0',      /* 화면 왼쪽 칸  : 렉2 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 화면 오른쪽 칸 : 렉1 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 3번째 칸 : 안 씀 */
                          '0', '0', '0', '0', '0',      /* 4번째 칸 : 안 씀 */
                          ETX };

/* 작업 : 0 초기상태, 1 대기, 2 운전, 3 일시정지, 5 원점설정, 6 알람
   만재 · 시딩월은 PO 가 그 렉에서 막혔을 때만 일시정지(3) (PO_pause → Pause_Set 이 상태를 P 로). 만재 칸은 센서 그대로 */
static char hmi_task(void)
{
    if (estop == 1 || status == ALARM)  return '6';                                                       /* 알람 */
    if (status == HOME)                 return '5';                                                       /* 원점 */
    if (pause_why)                      return '3';                                                       /* 일시정지 */
    if (status == RUN)                  return '2';                                                       /* 운전 */
    if (manjae_1 || manjae_2 || card_1 || card_2)                                                          return '3';   /* 만재 2초 넘음 · 시딩월 이탈 (RUN 까지) */
    return '1';
}

/* 일시정지 : 0 없음, 1 시딩월(카드 없음), 2 만재, 3 틸트, 4 사용자 */
static char hmi_pause(void)
{
    if (pause_why) {                                /* 일시정지면 이유대로 */
        if (pause_why == 'F') return '2';           /* 만재 */
        if (pause_why == 'S') return '1';           /* 시딩월 */
        if (pause_why == 'T') return '3';           /* 틸트 */
        return '4';                                 /* 사용자 */
    }
    if (card_1 || card_2)     return '1';           /* 시딩월 이탈 (RUN 까지) */
    if (manjae_1 || manjae_2) return '2';           /* 만재 2초 넘음 (RUN 까지) */
    return '0';
}

/* 알람 : 걸린 알람 번호 그대로 (HMI 표와 같음 : 2 주행모터 3 리프팅 4 틸팅 5~7 이탈 8 안전 9 비상정지 10 원점)
   01(HMI 통신)은 HMI 에 맞는 이름이 없어서 안 보냄. 수동 모드면 1, 없으면 0. ⚠️ HMI 는 0~10 만 (넘으면 ESP 가 멈출 수 있음)
   11 모터 통신 · 12 랜선 은 ESP 가 아직 모름 → 0 (작업 칸은 6 알람). ESP 고친 뒤 11 → '5', 12 → '9' */
static char hmi_alarm(void)
{
    if (estop == 1)   return '9';               /* 비상정지 */
    if (manual == 1)  return '1';               /* 수동 모드 : 알람 중이라도 먼저 (HMI 가 수동 화면 · 버튼을 열게) */
    if (alarm_no > 10) return '0';              /* 11 · 12 : ESP 가 아직 모름 */
    if (alarm_no >= 2) return '0' + alarm_no;   /* 10 은 ':' 글자 → HMI 가 10 으로 읽음 */
    return '0';
}

/* HMI 통신 : 상태 보내고 버튼 받기. 눌린 버튼 번호, 없으면 0 */
int HMI_Run(void)
{
    uint8_t rx[4];

    /* 만재 8칸 : 2초 그대로였던 값 (스침은 화면에 안 나옴, 바뀌는 2초 동안은 전 화면 그대로) */
    tx[6]  = manjae_2s(2, 1) ? '1' : '0';      /* 왼쪽 칸 : 렉2 */
    tx[7]  = manjae_2s(2, 2) ? '1' : '0';
    tx[8]  = manjae_2s(2, 3) ? '1' : '0';
    tx[9]  = manjae_2s(2, 4) ? '1' : '0';

    tx[11] = manjae_2s(1, 1) ? '1' : '0';      /* 오른쪽 칸 : 렉1 */
    tx[12] = manjae_2s(1, 2) ? '1' : '0';
    tx[13] = manjae_2s(1, 3) ? '1' : '0';
    tx[14] = manjae_2s(1, 4) ? '1' : '0';

    tx[3]  = hmi_task();                /* 작업 */
    tx[4]  = hmi_pause();               /* 일시정지 */
    tx[5]  = hmi_alarm();               /* 알람 */

    /* STM -> HMI 보내고, HMI -> STM 응답 올 때까지 잠든다 (최대 50ms) */
    if (UART4_Xfer(tx, 27, rx, 4, 50) == 0)
        return HMI_FAIL;                /* 응답 없음 */

    /* 노이즈 막기 : 대답은 STX '1' 버튼 ETX. 고정된 3칸이 맞을 때만 버튼으로 본다 */
    if (rx[0] != STX ||
        rx[1] != '1' ||
        rx[3] != ETX)
        return HMI_FAIL;                /* 꼬임 */

    /* 버튼 : ESP 가 번호 + '0'(48) 으로 보냄 (STX 2, ETX 3 과 안 겹치게). 48 을 빼서 진짜 번호로 */
    return rx[2] - '0';
}

/* 수동 버튼 (21~26) : 지금 위치에서 조금씩, 속도 20%. 수동 모드 아니면 · 위치 못 읽으면 안 움직임 (못 읽은 채 움직이면 0 에서 계산해 엉뚱한 곳으로 감) */
void HMI_Manual(int button)
{
    int32_t now, now2;                      /* 지금 위치 (now2 = X 2번 모터, 안 씀) */

    if (manual == 0) return;                /* 수동 모드 아님 */

    switch (button)
    {
    case BTN_TILT_Lift:      if (TM_Pos(&now))        TM_Move(now + 10, 10);  break;   /* 틸트 왼쪽 (+) 10도 */
    case BTN_TILT_Right:     if (TM_Pos(&now))        TM_Move(now - 10, 10);  break;   /* 틸트 오른쪽 (-) 10도 */
    case BTN_LIFT_UP:        if (AM_Pos(&now))        AM_Move(now + 10, 10);  break;   /* Y 위로 50mm */
    case BTN_LIFT_Down:      if (AM_Pos(&now))        AM_Move(now - 10, 10);  break;   /* Y 아래로 50mm */
    case BTN_TRAVEL_Forward: if (IM_Pos(&now, &now2)) IM_Move(now + 20, 10); break;   /* X 앞으로 100mm */
    case BTN_TRAVEL_Back:    if (IM_Pos(&now, &now2)) IM_Move(now - 20, 10); break;   /* X 뒤로 100mm */
    }
}
