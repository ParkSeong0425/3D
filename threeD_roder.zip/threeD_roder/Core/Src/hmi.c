/*
 * hmi.c : 터치패드 통신 + 수동 버튼 움직임 (RUN · STOP · RESET · 음소거 · 수동 모드는 event.c hmi_event)
 *
 * STM -> HMI : STX '1' 'C' 작업 일시정지 알람 센서20 ETX (27바이트)
 * HMI -> STM : STX '1' 버튼 ETX (버튼 = 번호 + '0', 11 RUN / 12 일시정지 / 21~26 수동 / 31~33 설정)
 */

#include "hmi.h"
#include "usart.h"
#include "status.h"
#include "event.h"
#include "manjae.h"
#include "rfid.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "alarm.h"
#include "save.h"
#include "cmsis_os2.h"
#include <stdint.h>

#define STX     0x02
#define ETX     0x03
#define MANUAL_X     100     /* 수동 이동 한 번 : X mm */
#define MANUAL_Y     50      /*                   Y mm */
#define MANUAL_TILT  10      /*                   틸트 도 */

/* 보낼 틀 : 고정 칸은 처음부터 채워 두고, 바뀌는 칸(작업 일시정지 알람, 만재 8칸)만 매번 쓴다 */
static uint8_t tx[27] = { STX, '1', 'C',
                          '0', '0', '0',                /* 작업 / 일시정지 / 알람 */
                          '0', '0', '0', '0', '0',      /* 화면 왼쪽 칸  : 렉2 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 화면 오른쪽 칸 : 렉1 1~4단 (5단 안 씀) */
                          '0', '0', '0', '0', '0',      /* 3번째 칸 : 안 씀 */
                          '0', '0', '0', '0', '0',      /* 4번째 칸 : 안 씀 */
                          ETX };

/* 작업 : 0 초기상태, 1 대기, 2 운전, 3 일시정지, 5 원점설정, 6 알람
   만재 · 시딩월은 PO 가 그 렉에서 막혔을 때만 일시정지(3) (PO_pause → Pause_Set 이 상태를 P 로). 만재 칸은 센서 그대로 */
static char hmi_task(void)
{
    if (estop == 1 || status_1 == ALARM || status_2 == ALARM || status_3 == ALARM || status_4 == ALARM)  return '6';
    if (status_1 == HOME    || status_2 == HOME    || status_3 == HOME    || status_4 == HOME)             return '5';
    if (status_1 == PAUSE   || status_2 == PAUSE   || status_3 == PAUSE   || status_4 == PAUSE)            return '3';
    if (status_1 == RUN     || status_2 == RUN     || status_3 == RUN     || status_4 == RUN)              return '2';
    if (status_1 == RESTART || status_2 == RESTART || status_3 == RESTART || status_4 == RESTART)          return '0';
    if (manjae_1 || manjae_2)                                                                               return '3';   /* 만재 2초 넘음 (RUN 까지) */
    return '1';
}

/* 일시정지 : 0 없음, 1 시딩월(카드 없음), 2 만재, 3 틸트, 4 사용자 */
static char hmi_pause(void)
{
    if (status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE) {   /* 일시정지면 이유대로 */
        if (pause_why == 'F') return '2';           /* 만재 */
        if (pause_why == 'S') return '1';           /* 시딩월 */
        if (pause_why == 'T') return '3';           /* 틸트 */
        return '4';                                 /* 사용자 */
    }
    if (manjae_1 || manjae_2) return '2';           /* 만재 2초 넘음 (RUN 까지) */
    return '0';
}

/* 알람 : 걸린 알람 번호 그대로 (HMI 표와 같음 : 2 주행모터 3 리프팅 4 틸팅 5~7 이탈 8 안전 9 비상정지 10 원점)
   01(HMI 통신)은 HMI 에 맞는 이름이 없어서 안 보냄. 수동 모드면 1, 없으면 0. ⚠️ HMI 는 0~10 만 (넘으면 ESP 가 멈출 수 있음)
   11 모터 통신 · 12 랜선 은 ESP 가 아직 모름 → 0 (작업 칸은 6 알람). ESP 고친 뒤 11 → '5', 12 → '9' */
static char hmi_alarm(void)
{
    if (estop == 1)   return '9';               /* 비상정지 */
    if (manual == 1)  return '1';               /* 수동 모드 : 알람 중이라도 먼저 (HMI 가 수동 화면 · 버튼을 열게) */
    if (alarm_1 > 10) return '0';               /* 11 · 12 : ESP 가 아직 모름 (알람은 모든 렉 같이 걸려서 렉1 만 보면 됨) */
    if (alarm_1 >= 2) return '0' + alarm_1;     /* 10 은 ':' 글자 → HMI 가 10 으로 읽음 */
    if (alarm_2 >= 2) return '0' + alarm_2;
    if (alarm_3 >= 2) return '0' + alarm_3;
    if (alarm_4 >= 2) return '0' + alarm_4;
    return '0';
}

/* HMI 통신 : 상태 보내고 버튼 받기. 눌린 버튼 번호, 없으면 0 */
int HMI_Run(void)
{
    uint8_t rx[4];

    /* 만재 8칸 : 센서가 2초 동안 그대로일 때만 바꿈 (스침은 화면에 안 나옴, 바뀌는 2초 동안은 전 화면 그대로) */
    if (manjae_stable(0, 0)) {
        tx[6]  = manjae_on(2, 1) ? '1' : '0';  /* 왼쪽 칸 : 렉2 */
        tx[7]  = manjae_on(2, 2) ? '1' : '0';
        tx[8]  = manjae_on(2, 3) ? '1' : '0';
        tx[9]  = manjae_on(2, 4) ? '1' : '0';

        tx[11] = manjae_on(1, 1) ? '1' : '0';  /* 오른쪽 칸 : 렉1 */
        tx[12] = manjae_on(1, 2) ? '1' : '0';
        tx[13] = manjae_on(1, 3) ? '1' : '0';
        tx[14] = manjae_on(1, 4) ? '1' : '0';
    }

    tx[3]  = hmi_task();                /* 작업 */
    tx[4]  = hmi_pause();               /* 일시정지 */
    tx[5]  = hmi_alarm();               /* 알람 */

    /* STM -> HMI 보내고, HMI -> STM 응답 올 때까지 잠든다 (최대 50ms) */
    if (UART4_Xfer(tx, 27, rx, 4, 50) != HAL_OK)
        return HMI_FAIL;                /* 응답 없음 */

    /* 노이즈 막기 : 대답은 STX '1' 버튼 ETX. 고정된 3칸이 맞을 때만 버튼으로 본다 */
    if (rx[0] != STX ||
        rx[1] != '1' ||
        rx[3] != ETX)
        return HMI_FAIL;                /* 꼬임 */

    /* 버튼 : ESP 가 번호 + '0'(48) 으로 보냄 (STX 2, ETX 3 과 안 겹치게). 48 을 빼서 진짜 번호로 */
    return rx[2] - '0';
}

/* 수동 버튼 (21~26) : 지금 위치에서 조금씩 움직이기. 수동 모드 아니면 안 움직임 */
void HMI_Manual(int button)
{
    int32_t now = 0;
    int32_t now2 = 0;                       /* X 2번 모터(ID 4) 위치 : IM_Pos 가 두 모터를 같이 줌 (여기선 안 씀) */

    if (manual == 0) return;                /* 수동 모드 아님 */

    switch (button)
    {
    case BTN_TILT_Lift:                     /* 틸트 왼쪽 (+) 10도 */
        TM_Pos(&now);
        TM_Move(now + MANUAL_TILT, 20);
        break;

    case BTN_TILT_Right:                    /* 틸트 오른쪽 (-) 10도 */
        TM_Pos(&now);
        TM_Move(now - MANUAL_TILT, 20);
        break;

    case BTN_LIFT_UP:                       /* Y 위로 */
        AM_Pos(&now);
        AM_Move(now + MANUAL_Y, 20);        /* AM_Move 는 "그 위치로" 이동 */
        break;

    case BTN_LIFT_Down:                     /* Y 아래로 */
        AM_Pos(&now);
        AM_Move(now - MANUAL_Y, 20);
        break;

    case BTN_TRAVEL_Forward:                /* X 앞으로 */
        IM_Pos(&now, &now2);
        IM_Move(now + MANUAL_X, 20);
        break;

    case BTN_TRAVEL_Back:                   /* X 뒤로 */
        IM_Pos(&now, &now2);
        IM_Move(now - MANUAL_X, 20);
        break;
    }
}
