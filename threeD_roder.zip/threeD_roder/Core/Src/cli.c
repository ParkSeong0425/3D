/*
 * cli.c : UART1 디버그 창 (Tera Term 115200, 로컬 에코 켬 — 보드는 친 글자를 안 돌려보냄)
 *   받기   usart.c 인터럽트가 cli_buf 에 넣음 → CLI_Run (Comm_Task 1ms) 이 꺼내 한 줄 → CLI_Command
 *   명령   X mm %  ·  Y mm %  ·  C %  ·  R 각도 %  ·  L 각도 %     모터 이동
 *          X 주소 · Y 주소 · T 주소 (16진수)                       레지스터 읽기 (16bit · 32bit 둘 다)
 *          DATA                                                   세 모터 주요 레지스터 한 번에 + RAM (힙 · 태스크 스택 가장 적게 남았던 양)
 *          IP  ·  FRAM                                            저장된 네트워크 · FRAM 값
 *   읽는 동안 Comm_Task 가 멈춤 (PC 통신도) → 모터가 서 있을 때만
 *   원점 결과 · 통신 실패 · 2500 끊김 이유는 CLI 가 아니라 로그 50001 (debug.c)
 */
#include "cli.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "save.h"
#include "usart.h"
#include "FreeRTOS.h"       /* xPortGetMinimumEverFreeHeapSize (DATA 의 RAM 줄) */
#include <stdio.h>
#include <string.h>

#define CLI_SIZE 32         /* 한 줄 최대 글자 (명령은 길어야 10글자 정도) */

/* UART1 출력 */
static void CLI_Print(const char *text)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)text, strlen(text), 100);
}


/* 실행 결과 출력 : 이름 + OK / ERR  예) X_MOVE OK */
static void CLI_Result(const char *name, int ok)
{
    char text[32];

    snprintf(text, sizeof(text), "%s %s\r\n> ", name, ok ? "OK" : "ERR");
    CLI_Print(text);
}


/* FRAM 배열 출력 */
static void CLI_List(const char *name, int32_t *data, int count, int max)
{
    char buf[32];

    CLI_Print(name);

    if (count > max)
        count = max;

    for (int i = 1; i <= count; i++)                 /* FRAM 표는 1 번 칸부터 ([0] 안 씀) */
    {
        snprintf(buf, sizeof(buf), "%ld ", (long)data[i]);
        CLI_Print(buf);
    }

    CLI_Print("\r\n");
}


/* FRAM 저장값 출력 */
static void CLI_FRAM(void)
{
    char buf[500];

    snprintf(buf, sizeof(buf),
             "\r\n[FS]\r\n"
             "RACK         = %d\r\n"
             "TYPE         = %c\r\n"
             "CHANNEL      = %d\r\n"
             "IN_X         = %d\r\n"
             "IN_Y         = %d\r\n"
             "LEFT_X       = %d\r\n"
             "LEFT_Y       = %d\r\n"
             "RIGHT_X      = %d\r\n"
             "RIGHT_Y      = %d\r\n"
             "\r\n[FP]\r\n"
             "IN_X = %ld\r\n",
             save.fs.rack,
             save.fs.type,
             save.fs.rack_channel,
             save.fs.in_x,
             save.fs.in_y,
             save.fs.left_x,
             save.fs.left_y,
             save.fs.right_x,
             save.fs.right_y,
             (long)save.fp.in_x);

    CLI_Print(buf);

    CLI_List("IN_Y = ", save.fp.in_y, save.fs.in_y, 5);             /* FRAM 배열 그대로 */
    CLI_List("LEFT_X = ", save.fp.left_x, save.fs.left_x, 9);
    CLI_List("LEFT_Y = ", save.fp.left_y, save.fs.left_y, 9);
    CLI_List("RIGHT_X = ", save.fp.right_x, save.fs.right_x, 9);
    CLI_List("RIGHT_Y = ", save.fp.right_y, save.fs.right_y, 9);
    CLI_List("SAFE_Y = ", save.fp.safe_y, save.fs.in_y, 5);         /* 안전 Y : 입고 단 수만큼 */

    snprintf(buf, sizeof(buf),
             "\r\n"
             "LIFT Y OFFSET = %ld\r\n"
             "TILT ANGLE    = %ld\r\n"
             "TILTING Y     = %ld\r\n"
             "TILTING SPEED = %ld\r\n"
             "Y OFFSET      = %ld\r\n"
             "TILT OFFSET   = %ld\r\n"
             "X OFFSET      = %ld\r\n"
             "SPEED X       = %ld\r\n"
             "SPEED TILT    = %ld\r\n"
             "SPEED Y       = %ld\r\n"
             "ACCDEC X      = %ld\r\n"
             "ACCDEC TILT   = %ld\r\n"
             "ACCDEC Y      = %ld\r\n"
             "SAFE X        = %ld\r\n> ",
             (long)save.fp.lift_y_offset,
             (long)save.fp.tilt_angle,
             (long)save.fp.tilting_y,
             (long)save.fp.tilting_y_speed,
             (long)save.fp.y_offset,
             (long)save.fp.tilt_offset,
             (long)save.fp.x_offset,
             (long)save.fp.speed_x,
             (long)save.fp.speed_tilt,
             (long)save.fp.speed_y,
             (long)save.fp.accdec_x,
             (long)save.fp.accdec_tilt,
             (long)save.fp.accdec_y,
             (long)save.fp.safe_x);

    CLI_Print(buf);
}


/* (디버그) 레지스터 하나 읽어 한 줄 출력 : axis 'X' · 'Y' · 'T', motor = X 1 · 2 (Y · T 는 안 씀), qty 1 = 16bit / 2 = 32bit
   32bit 순서는 그 모터 파일 그대로 (X · 틸트 높은 칸 먼저, Y 는 AM_ReadReg 가 합침). 읽으면 1 / 대답 없음 0 */
static int reg_line(char axis, int motor, uint16_t reg, uint8_t qty, const char *name)
{
    uint16_t v[2] = {0, 0};
    int32_t value = 0;
    int ok = 0;
    char buf[64];

    if (axis == 'X') ok = IM_ReadReg(motor, reg, v, qty);
    if (axis == 'T') ok = TM_ReadReg(reg, v, qty);
    if (axis == 'Y') ok = AM_ReadReg(reg, &value, qty);
    if (axis != 'Y') value = (qty == 2) ? (int32_t)(((uint32_t)v[0] << 16) | v[1]) : v[0];

    if (ok) snprintf(buf, sizeof(buf), " %04X %-14s = %ld (0x%lX)\r\n", reg, name, (long)value, (unsigned long)value);
    else    snprintf(buf, sizeof(buf), " %04X %-14s = FAIL\r\n", reg, name);
    CLI_Print(buf);
    return ok;
}

/* (디버그) DATA : 세 모터 주요 레지스터를 한 번에 출력
   모터마다 첫 줄(state)이 대답 없으면 나머지는 안 물음 (줄마다 대답 없음 약 0.3초 버리지 않게)
   Comm_Task 라 읽는 동안 PC 통신이 멈춤 → 모터가 서 있을 때만 */
static void CLI_Data(void)
{
    char buf[100];

    for (int m = 1; m <= 2; m++) {                                  /* X 두 모터 (IM_1_ID · IM_2_ID) */
        CLI_Print(m == 1 ? "\r\n[X1]\r\n" : "[X2]\r\n");
        if (reg_line('X', m, 0x1003, 1, "state")) {
            reg_line('X', m, 0x1014, 2, "position pulse");
            reg_line('X', m, 0x2203, 1, "alarm");
            reg_line('X', m, 0x601D, 1, "warning");
            reg_line('X', m, 0x6017, 1, "stop ms");
            reg_line('X', m, 0x600A, 1, "home mode");
            reg_line('X', m, 0x600F, 1, "home hi rpm");
            reg_line('X', m, 0x6014, 1, "home force");
        }
    }

    CLI_Print("[Y]\r\n");
    if (reg_line('Y', 0, 0x0509, 1, "pulse/rev")) {                 /* H05_09 : 320 이어야 */
        reg_line('Y', 0, 0x0B07, 2, "position pulse");
        reg_line('Y', 0, 0x0B22, 1, "fault");
        reg_line('Y', 0, 0x0B05, 1, "DO state");
        reg_line('Y', 0, 0x051F, 1, "home mode");
        reg_line('Y', 0, 0x053A, 1, "home torque");
        reg_line('Y', 0, 0x0515, 1, "done gap");
        reg_line('Y', 0, 0x0C02, 1, "baud code");
    }

    CLI_Print("[T]\r\n");
    if (reg_line('T', 0, 0x0004, 1, "state")) {
        reg_line('T', 0, 0x0005, 1, "alarm");
        reg_line('T', 0, 0x0008, 2, "position pulse");
        reg_line('T', 0, 0x0023, 1, "subdivision");
        reg_line('T', 0, 0x0034, 1, "acc ms");
        reg_line('T', 0, 0x0035, 1, "dec ms");
        reg_line('T', 0, 0x0040, 1, "home mode");
        reg_line('T', 0, 0x010A, 1, "pos error");             /* PA_10A 위치 편차 알람 기준 (TM_Init 이 3000 으로 씀) */
    }

    /* RAM 재기 : 켠 뒤 가장 적게 남았던 양 (0 에 가까우면 넘치기 직전 → ioc 에서 늘림 / 많이 남으면 나중에 줄여도 됨) */
    snprintf(buf, sizeof(buf), "[RAM] min free  heap %u B  stack Event %lu B  Motor %lu B  Comm %lu B\r\n",
             (unsigned)xPortGetMinimumEverFreeHeapSize(),                /* 힙 20KB 중 (ioc TOTAL_HEAP_SIZE) */
             (unsigned long)osThreadGetStackSpace(Event_TaskHandle),     /* 태스크 스택 (ioc Tasks) */
             (unsigned long)osThreadGetStackSpace(Motor_TaskHandle),
             (unsigned long)osThreadGetStackSpace(Comm_TaskHandle));
    CLI_Print(buf);
    CLI_Print("> ");
}

/* 문자열 명령 처리 */
static void CLI_Command(char *text)
{
    long pulse;
    int persent;
    unsigned int reg;           /* (디버그) 읽을 레지스터 주소 : X 2203 · Y 0509 · T 0005 (16진수) */
    char buf[300];

    /* 네트워크 값 */
    if (strcmp(text, "IP") == 0)
    {
        snprintf(buf, sizeof(buf),
                 "\r\n[IP]\r\n"
                 "IP      = %d.%d.%d.%d\r\n"
                 "SUBNET  = %d.%d.%d.%d\r\n"
                 "GATEWAY = %d.%d.%d.%d\r\n"
                 "DEST IP = %d.%d.%d.%d\r\n"
                 "PORT    = %d\r\n"
                 "MODE    = %d\r\n"
                 "TIMEOUT = %lu\r\n> ",
                 save.fi.ip[0], save.fi.ip[1],
                 save.fi.ip[2], save.fi.ip[3],
                 save.fi.sn[0], save.fi.sn[1],
                 save.fi.sn[2], save.fi.sn[3],
                 save.fi.gw[0], save.fi.gw[1],
                 save.fi.gw[2], save.fi.gw[3],
                 save.fi.dip[0], save.fi.dip[1],
                 save.fi.dip[2], save.fi.dip[3],
                 save.fi.port, save.fi.mode,
                 (unsigned long)save.fi.timeout);

        CLI_Print(buf);
        return;
    }

    /* FRAM 값 */
    if (strcmp(text, "FRAM") == 0)
    {
        CLI_FRAM();
        return;
    }

    /* (시험) X2 하나만 : X2 mm 속도% → X 차이 알람 05 시험 (운전엔 안 씀, 짧게 · 느리게). "X 숫자" 보다 먼저 봐야 함 */
    if (sscanf(text, "X2 %ld %d", &pulse, &persent) == 2)
        CLI_Result("X2_MOVE", IM_Move2(pulse, persent));

    /* X 모터 : X mm 속도% (그 위치로) */
    else if (sscanf(text, "X %ld %d", &pulse, &persent) == 2)
        CLI_Result("X_MOVE", IM_MoveSoft(pulse, persent));

    /* Y 모터 : Y mm 속도% (그 위치로) */
    else if (sscanf(text, "Y %ld %d", &pulse, &persent) == 2)
        CLI_Result("Y_MOVE", AM_Move(pulse, persent));

    /* Tilt 중앙 : C 속도% */
    else if (sscanf(text, "C %d", &persent) == 1)
        CLI_Result("CENTER", TM_C(persent));

    /* Tilt 오른쪽 : R 각도 속도% (읽은 숫자는 각도) */
    else if (sscanf(text, "R %ld %d", &pulse, &persent) == 2)
        CLI_Result("RIGHT", TM_R(pulse, persent));

    /* Tilt 왼쪽 : L 각도 속도% */
    else if (sscanf(text, "L %ld %d", &pulse, &persent) == 2)
        CLI_Result("LEFT", TM_L(pulse, persent));

    /* (디버그) 레지스터 읽기 : 축 글자 + 16진수 주소 하나 (숫자 둘이면 위의 이동). Y 는 H0B_34 = 0B22 처럼 뒤 번호를 16진수로 */
    else if (sscanf(text, "X %x", &reg) == 1) {                    /* X 2203 : 두 모터 */
        reg_line('X', 1, (uint16_t)reg, 1, "X1 16bit");
        reg_line('X', 1, (uint16_t)reg, 2, "X1 32bit");
        reg_line('X', 2, (uint16_t)reg, 1, "X2 16bit");
        reg_line('X', 2, (uint16_t)reg, 2, "X2 32bit");
        CLI_Print("> ");
    }
    else if (sscanf(text, "Y %x", &reg) == 1) {                    /* Y 0509 */
        reg_line('Y', 0, (uint16_t)reg, 1, "Y 16bit");
        reg_line('Y', 0, (uint16_t)reg, 2, "Y 32bit");
        CLI_Print("> ");
    }
    else if (sscanf(text, "T %x", &reg) == 1) {                    /* T 0005 */
        reg_line('T', 0, (uint16_t)reg, 1, "T 16bit");
        reg_line('T', 0, (uint16_t)reg, 2, "T 32bit");
        CLI_Print("> ");
    }

    /* (디버그) 세 모터 주요 레지스터 한 번에 */
    else if (strcmp(text, "DATA") == 0)
        CLI_Data();

    else
        CLI_Print("BAD COMMAND\r\n> ");
}


/* UART1 CLI (Comm_Task 1ms 마다) : 보관함(cli_buf, usart.c 인터럽트가 넣음)에 온 글자를 전부 꺼내 한 줄 만들기
   글자 → 줄에 붙이고 화면에 다시 보여 줌 / 지우기 → 하나 빼고 화면에서도 지움 / 엔터 → 명령 실행 */
void CLI_Run(void)
{
    static char line[CLI_SIZE];             /* 지금 치는 한 줄 */
    static uint8_t index = 0;               /* 줄에서 다음 글자 넣을 칸 */
    static uint8_t tail = 0;                /* 보관함에서 다음에 꺼낼 칸 */
    char c;                                 /* 꺼낸 글자 1개 */

    while (tail != cli_head) {                                  /* 보관함에 글자 있는 만큼 */
        c = cli_buf[tail];
        tail = (tail + 1) % CLI_BUF;                            /* 다음 칸 (끝이면 처음으로) */

        if (c == '\r' || c == '\n') {                           /* 엔터 : 한 줄 끝 */
            if (index == 0) continue;                           /*   빈 줄 (CR 뒤 LF) 은 무시 */
            line[index] = 0;
            index = 0;
            CLI_Print("\r\n");
            CLI_Command(line);
        }
        else if (c == '\b' || c == 0x7F) {                      /* 지우기 (Backspace · Delete) */
            if (index == 0) continue;                           /*   지울 글자 없음 */
            index--;
            CLI_Print(" \b");                                   /*   화면 : Tera Term 이 이미 한 칸 뒤로 감 → 빈칸으로 덮고 다시 뒤로 */
        }
        else if (index < CLI_SIZE - 1) {                        /* 글자 : 줄에 붙이기 (꽉 차면 무시) */
            line[index++] = c;                                  /*   화면은 Tera Term 로컬 에코가 보여 줌 (보드는 안 돌려보냄) */
        }
    }
}
