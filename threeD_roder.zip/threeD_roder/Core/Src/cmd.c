/*
 * cmd.c
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#include "cmd.h"
#include "save.h"
#include "socket.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "event.h"
#include "alarm.h"
#include "rfid.h"
#include "lamp.h"
#include "cmsis_os2.h"

#include <stdio.h>
#include <string.h>
#include <stdint.h>

#define STX       0x02
#define ETX       0x03
#define ACK       0x06
#define NAK       0x15

#define CMD_FS  (('F' << 8) | 'S')
#define CMD_FP  (('F' << 8) | 'P')
#define CMD_FI  (('F' << 8) | 'I')
#define CMD_C   ('C' << 8)
#define CMD_FD  (('F' << 8) | 'D')
#define CMD_RFID ('R' << 8)
#define CMD_LAMP (('L' << 8) | 'L')
#define CMD_D   ('D' << 8)

#define TCP_SOCK  0

static char done_text[32];  /* 완료응답 "05AI_1_1_2" : PC 승인 올 때까지 1초마다, 승인 오면 비움 */
static uint32_t done_time;  /* 완료응답 마지막으로 보낸 시각 */
static char home_text[24];  /* 원점 완료 "05<ACK>homing done" : 한 번 보내고 비움 */


static void ack(char *s)
{
    char tx[160];

    int len = snprintf(tx, sizeof(tx),
            "%c%c%c%c%s%c",
            0x02,
            s[0], s[1],
            0x06,
            s + 2,
            0x03);

    send(TCP_SOCK, (uint8_t *)tx, len);
}


static void nak(char *s, char *error)
{
    char tx[80];

    int len = snprintf(tx, sizeof(tx),
            "%c%c%c%c%s%c",
            0x02,
            s[0], s[1],
            0x15,
            error,
            0x03);

    send(TCP_SOCK, (uint8_t *)tx, len);
}

/* 렉 상태 한 칸 : W, R, I, P / 알람이면 A_01 */
static void rack_text(char *b, int size, char status, int alarm)
{
    if (status == ALARM)
        snprintf(b, size, "A_%02d", alarm);
    else
        snprintf(b, size, "%c", status);
}

/* PC 로 이벤트 1개 : STX + 일련번호(01~99) + 내용 + ETX */
static void event_send(const char *text)
{
    static int number = 0;      /* 이벤트 일련번호 : 보낼 때마다 1 늘림, 99 다음 01 */
    char tx[80];
    int len;

    number++;                   /* 다음 번호 */
    if (number > 99) number = 1;

    len = snprintf(tx, sizeof(tx), "%c%02d%s%c", STX, number, text, ETX);
    send(TCP_SOCK, (uint8_t *)tx, len);
}

/* 이벤트 : 표시가 있으면 PC 로 먼저 보냄 (Comm_Task 1ms 마다) */
void CMD_Event(void)
{
    char b[64];
    char card[48];

    /* 만재 : FF_1_0001&F_2_0000 */
    if (full_event_on) {
        full_event_on = 0;
        snprintf(b, sizeof(b), "FF_1_%d%d%d%d&F_2_%d%d%d%d",
                 full_1_1, full_1_2, full_1_3, full_1_4,
                 full_2_1, full_2_2, full_2_3, full_2_4);
        event_send(b);
    }

    /* 일시정지 : PPAUSE:M */
    if (pause_event_on) {
        pause_event_on = 0;
        snprintf(b, sizeof(b), "PPAUSE:%c", pause_why);
        event_send(b);
    }

    /* 카드 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 */
    if (rfid_new) {
        rfid_new = 0;
        Rfid_Text(card, sizeof(card));
        event_send(card);
    }

    /* 알람 : 걸린 렉만 S_1_A_09 / 둘 다면 S_1_A_09&S_2_A_09 */
    if (alarm_event_on) {
        alarm_event_on = 0;
        if (alarm_1 != 0 && alarm_2 != 0) snprintf(b, sizeof(b), "S_1_A_%02d&S_2_A_%02d", alarm_1, alarm_2);
        else if (alarm_1 != 0)            snprintf(b, sizeof(b), "S_1_A_%02d", alarm_1);
        else                              snprintf(b, sizeof(b), "S_2_A_%02d", alarm_2);
        event_send(b);
    }

    /* 완료응답 : PC 승인 올 때까지 1초마다 (긴급정지면 버림) */
    if (estop == 1) done_text[0] = 0;

    if (done_text[0] != 0 && osKernelGetTickCount() - done_time >= 1000) {
        done_time = osKernelGetTickCount();
        snprintf(b, sizeof(b), "%c%s%c", 0x02, done_text, 0x03);
        send(TCP_SOCK, (uint8_t *)b, strlen(b));
    }

    /* 원점 완료 : 한 번만 (승인 필요 없음) */
    if (home_text[0] != 0) {
        snprintf(b, sizeof(b), "%c%s%c", 0x02, home_text, 0x03);
        send(TCP_SOCK, (uint8_t *)b, strlen(b));
        home_text[0] = 0;
    }
}

/* 완료응답 만들기 : 받은 명령 s 와 결과 ok 로. MI→AI, MO→AO, PO→EO, I→homing done / 보내는 건 CMD_Event 가 */
void CMD_Done(char *s, int ok)
{
    int rack = 0;
    int yeol= 0;
    int dan = 0;

    /* 원점 (01I) : 성공 → 대기 + homing done, 실패 → 초기상태 */
    if (s[2] == 'I') {
        if (ok == 0) { Status_INIT(); return; }
        Status_WAIT(1);
        Status_WAIT(2);
        snprintf(home_text, sizeof(home_text), "%c%c%choming done", s[0], s[1], ACK);
        return;
    }

    /* MI / MO / PO : 못 했으면 완료 아님 */
    if (ok == 0) return;

    /* 01MI_렉_열_단_… 에서 렉 · 열 · 단 */
    sscanf(s + 5, "%d_%d_%d", &rack, &yeol, &dan);
    Status_WAIT(rack);                                      /* 끝 → 대기 */

    /* 번호 2글자 + (PO 면 E, 아니면 A) + (I 또는 O) : 05AI_1_1_2 / 05AO_… / 05EO_… */
    snprintf(done_text, sizeof(done_text), "%c%c%c%c_%d_%d_%d",
             s[0], s[1], s[2] == 'P' ? 'E' : 'A', s[3], rack, yeol, dan);

    done_time = osKernelGetTickCount() - 1000;              /* 바로 첫 전송 */
}

/* 명령 처리 */
void CMD_Run(char *s)
{
    int cmd;
    int x = 0;              /* 갈 곳 : FRAM 에서 찾은 좌표 */
    int y = 0;

    int rack;
    char type;
    int rack_channel;

    int in_x, in_y;
    int left_x, left_y;
    int right_x, right_y;

    int x_no;
    int y_no;
    int xy_speed;
    int tilt_speed;
    int move_delay;
    int return_delay;

    int no;
    int value[9];
    int count;

    /* 완료응답 승인 : 05-AI_1_1_2 → 번호, 내용이 같으면 반복 끝 */
    if (s[2] == '-') {
        if (done_text[0] != 0 && s[0] == done_text[0] && s[1] == done_text[1] &&
            strcmp(s + 3, done_text + 2) == 0)
            done_text[0] = 0;
        return;
    }

    cmd = (s[2] << 8) | s[3];

    switch (cmd)

    {
    /* FS */
    case CMD_FS:

        if (sscanf(s + 2,
                "FS_%d_%c_%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &type,
                &rack_channel,
                &in_x,
                &in_y,
                &left_x,
                &left_y,
                &right_x,
                &right_y) != 9)
        {
            nak(s, "bad_data");
            break;
        }

        if (FS(rack, type, rack_channel,
               in_x, in_y,
               left_x, left_y,
               right_x, right_y))
            ack(s);
        else
            nak(s, "bad_data");

        break;


    /* FP */
    case CMD_FP:

        count = sscanf(s + 2,
                "FP_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &no,
                &value[0],
                &value[1],
                &value[2],
                &value[3],
                &value[4],
                &value[5],
                &value[6],
                &value[7],
                &value[8]);

        count -= 2;

        if (count < 1)
        {
            nak(s, "bad_data");
            break;
        }

        if (FP(rack, no, value, count))
            ack(s);
        else
            nak(s, "bad_data");

        break;


    /* FI */
    case CMD_FI:

        /* FI 1~4 : IP 형식 */
        if (sscanf(s + 2,
                "FI_1_%d_%d.%d.%d.%d",
                &no,
                &value[0],
                &value[1],
                &value[2],
                &value[3]) == 5)
        {
            if (FI(no, value, 4))
                ack(s);
            else
                nak(s, "bad_data");

            break;
        }

        /* FI 5~7 : 숫자 하나 */
        if (sscanf(s + 2,
                "FI_1_%d_%d",
                &no,
                &value[0]) == 2)
        {
            if (FI(no, value, 1))
                ack(s);
            else
                nak(s, "bad_data");

            break;
        }

        nak(s, "bad_data");
        break;


    /* FD */
    case CMD_FD:

        if (strcmp(s + 2, "FD_1") != 0)
        {
            nak(s, "bad_data");
            break;
        }

        if (FD())
            ack(s);
        else
            nak(s, "fram_error");

        break;


    /* 입고 */
    case CMD_MI:

        if (status_1 != WAIT || status_2 != WAIT || manual == 1 || done_text[0] != 0)    /* 대기 아님 / 수동 / 완료응답 승인 전 */
        {
            nak(s, "can_not_command");
            break;
        }

        if (sscanf(s + 5, "%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &x_no,
                &y_no,
                &xy_speed,
                &tilt_speed,
                &move_delay,
                &return_delay) != 7)
        {
            nak(s, "bad_data");
            break;
        }

        if (x_no != 1 || y_no < 1 || y_no > save.fs.in_y)
        {
            nak(s, "bad_data");
            break;
        }

        x = save.fp.in_x;

        if (y_no == 1) y = save.fp.in_y1;
        else if (y_no == 2) y = save.fp.in_y2;
        else if (y_no == 3) y = save.fp.in_y3;
        else if (y_no == 4) y = save.fp.in_y4;
        else if (y_no == 5) y = save.fp.in_y5;

        ack(s);                                                 /* 받았다 */
        Status_RUN(rack);                                       /* 운전 중 */
        CMD_Done(s, MI(x, y, xy_speed, tilt_speed));            /* 움직이고 → 결과로 완료응답 */
        break;


    /* 출고 */
    case CMD_MO:

        if (status_1 != WAIT || status_2 != WAIT || manual == 1 || done_text[0] != 0)    /* 대기 아님 / 수동 / 완료응답 승인 전 */
        {
            nak(s, "can_not_command");
            break;
        }

        if (sscanf(s + 5, "%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &x_no,
                &y_no,
                &xy_speed,
                &tilt_speed,
                &move_delay,
                &return_delay) != 7)
        {
            nak(s, "bad_data");
            break;
        }

        if (rack == 1)
        {
            if (x_no < 1 || x_no > save.fs.right_x ||
                y_no < 1 || y_no > save.fs.right_y)
            {
                nak(s, "bad_data");
                break;
            }

            if (x_no == 1) x = save.fp.right_x1;
            else if (x_no == 2) x = save.fp.right_x2;
            else if (x_no == 3) x = save.fp.right_x3;
            else if (x_no == 4) x = save.fp.right_x4;
            else if (x_no == 5) x = save.fp.right_x5;
            else if (x_no == 6) x = save.fp.right_x6;
            else if (x_no == 7) x = save.fp.right_x7;
            else if (x_no == 8) x = save.fp.right_x8;
            else if (x_no == 9) x = save.fp.right_x9;

            if (y_no == 1) y = save.fp.right_y1;
            else if (y_no == 2) y = save.fp.right_y2;
            else if (y_no == 3) y = save.fp.right_y3;
            else if (y_no == 4) y = save.fp.right_y4;
            else if (y_no == 5) y = save.fp.right_y5;
            else if (y_no == 6) y = save.fp.right_y6;
            else if (y_no == 7) y = save.fp.right_y7;
            else if (y_no == 8) y = save.fp.right_y8;
            else if (y_no == 9) y = save.fp.right_y9;
        }
        else
        {
            if (x_no < 1 || x_no > save.fs.left_x ||
                y_no < 1 || y_no > save.fs.left_y)
            {
                nak(s, "bad_data");
                break;
            }

            if (x_no == 1) x = save.fp.left_x1;
            else if (x_no == 2) x = save.fp.left_x2;
            else if (x_no == 3) x = save.fp.left_x3;
            else if (x_no == 4) x = save.fp.left_x4;
            else if (x_no == 5) x = save.fp.left_x5;
            else if (x_no == 6) x = save.fp.left_x6;
            else if (x_no == 7) x = save.fp.left_x7;
            else if (x_no == 8) x = save.fp.left_x8;
            else if (x_no == 9) x = save.fp.left_x9;

            if (y_no == 1) y = save.fp.left_y1;
            else if (y_no == 2) y = save.fp.left_y2;
            else if (y_no == 3) y = save.fp.left_y3;
            else if (y_no == 4) y = save.fp.left_y4;
            else if (y_no == 5) y = save.fp.left_y5;
            else if (y_no == 6) y = save.fp.left_y6;
            else if (y_no == 7) y = save.fp.left_y7;
            else if (y_no == 8) y = save.fp.left_y8;
            else if (y_no == 9) y = save.fp.left_y9;
        }

        ack(s);                                                 /* 받았다 */
        Status_RUN(rack);                                       /* 운전 중 */
        CMD_Done(s, MO(x, y, xy_speed, tilt_speed));            /* 움직이고 → 결과로 완료응답 */
        break;


    /* 분배 */
    case CMD_PO:

        if (status_1 != WAIT || status_2 != WAIT || manual == 1 || done_text[0] != 0)    /* 대기 아님 / 수동 / 완료응답 승인 전 */
        {
            nak(s, "can_not_command");
            break;
        }

        if (sscanf(s + 5, "%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &x_no,
                &y_no,
                &xy_speed,
                &tilt_speed,
                &move_delay,
                &return_delay) != 7)
        {
            nak(s, "bad_data");
            break;
        }

        if (rack == 1)
        {
            if (x_no < 1 || x_no > save.fs.right_x ||
                y_no < 1 || y_no > save.fs.right_y)
            {
                nak(s, "bad_data");
                break;
            }

            if (x_no == 1) x = save.fp.right_x1;
            else if (x_no == 2) x = save.fp.right_x2;
            else if (x_no == 3) x = save.fp.right_x3;
            else if (x_no == 4) x = save.fp.right_x4;
            else if (x_no == 5) x = save.fp.right_x5;
            else if (x_no == 6) x = save.fp.right_x6;
            else if (x_no == 7) x = save.fp.right_x7;
            else if (x_no == 8) x = save.fp.right_x8;
            else if (x_no == 9) x = save.fp.right_x9;

            if (y_no == 1) y = save.fp.right_y1;
            else if (y_no == 2) y = save.fp.right_y2;
            else if (y_no == 3) y = save.fp.right_y3;
            else if (y_no == 4) y = save.fp.right_y4;
            else if (y_no == 5) y = save.fp.right_y5;
            else if (y_no == 6) y = save.fp.right_y6;
            else if (y_no == 7) y = save.fp.right_y7;
            else if (y_no == 8) y = save.fp.right_y8;
            else if (y_no == 9) y = save.fp.right_y9;
        }
        else
        {
            if (x_no < 1 || x_no > save.fs.left_x ||
                y_no < 1 || y_no > save.fs.left_y)
            {
                nak(s, "bad_data");
                break;
            }

            if (x_no == 1) x = save.fp.left_x1;
            else if (x_no == 2) x = save.fp.left_x2;
            else if (x_no == 3) x = save.fp.left_x3;
            else if (x_no == 4) x = save.fp.left_x4;
            else if (x_no == 5) x = save.fp.left_x5;
            else if (x_no == 6) x = save.fp.left_x6;
            else if (x_no == 7) x = save.fp.left_x7;
            else if (x_no == 8) x = save.fp.left_x8;
            else if (x_no == 9) x = save.fp.left_x9;

            if (y_no == 1) y = save.fp.left_y1;
            else if (y_no == 2) y = save.fp.left_y2;
            else if (y_no == 3) y = save.fp.left_y3;
            else if (y_no == 4) y = save.fp.left_y4;
            else if (y_no == 5) y = save.fp.left_y5;
            else if (y_no == 6) y = save.fp.left_y6;
            else if (y_no == 7) y = save.fp.left_y7;
            else if (y_no == 8) y = save.fp.left_y8;
            else if (y_no == 9) y = save.fp.left_y9;
        }

        ack(s);                                                 /* 받았다 */
        Status_RUN(rack);                                       /* 운전 중 */
        CMD_Done(s, PO_event(rack, x, y, y_no,                  /* 분배 + 상황 (event.c) → 결과로 완료응답 */
                             xy_speed, tilt_speed,
                             move_delay, return_delay,
                             save.fp.tilt_angle, save.fp.tilting_y, save.fp.tilting_y_speed));
        break;
        /* 상태 조회 : S_1_W&S_2_A_03&F_1_0001&F_2_0000 */
        case CMD_C:
        {
            char tx[80];
            char r1[8];
            char r2[8];

            rack_text(r1, sizeof(r1), status_1, alarm_1);
            rack_text(r2, sizeof(r2), status_2, alarm_2);

            int len = snprintf(tx, sizeof(tx),
                    "%c%c%c%cS_1_%s&S_2_%s&F_1_%d%d%d%d&F_2_%d%d%d%d%c",
                    0x02,
                    s[0], s[1],
                    0x06,
                    r1, r2,
                    full_1_1, full_1_2, full_1_3, full_1_4,
                    full_2_1, full_2_2, full_2_3, full_2_4,
                    0x03);

            send(TCP_SOCK, (uint8_t *)tx, len);
            break;
        }

        /* stop */
        case CMD_S:

            if (strcmp(s + 2, "S_1") != 0)
            {
                nak(s, "bad_data");
                break;
            }

            Status_PAUSE(1);            /* 일시정지 : 빨간불 */
            Status_PAUSE(2);
            pause_why = 'M';            /* 이유 : 사용자 */
            ack(s);
            break;

        /* 만재 일시정지 억지로 풀기 : D (센서가 만재여도 이어서 진행) */
        case CMD_D:

            if (strcmp(s + 2, "D") != 0)
            {
                nak(s, "bad_data");
                break;
            }

            if (pause_why == 'F') Status_Resume();      /* 만재로 멈춘 것만 */
            ack(s);
            break;

      /* home */
        case CMD_I:

            if (strcmp(s + 2, "I") != 0)
            {
                nak(s, "bad_data");
                break;
            }

            ack(s);                                     /* 받았다 */
            Status_HOME();                              /* 원점 중 */
            CMD_Done(s, motor_basic_init());            /* 초기화 + 원점 → homing done (실패면 초기상태) */
            break;

        /* 램프 : 01LL_번호_색_모드_시간 (번호 1~9 홀수 렉1 / 짝수 렉2, 색 1 적 2 녹 3 황, 모드 0 끔 1 켬 2 깜빡, 시간 초 0 = 계속) */
        case CMD_LAMP:
        {
            int lamp_no, color, mode, sec;

            if (sscanf(s + 2, "LL_%d_%d_%d_%d", &lamp_no, &color, &mode, &sec) != 4 ||
                lamp_no < 1 || lamp_no > 9 || color < 1 || color > 3 ||
                mode < 0 || mode > 2 || sec < 0 || sec > 60)
            {
                nak(s, "bad_data");
                break;
            }

            Lamp_Tcp(lamp_no % 2 == 1 ? 1 : 2, color, mode, sec);
            ack(s);
            break;
        }

        /* 카드 조회 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 */
        case CMD_RFID:
        {
            char tx[64];
            char card[48];

            Rfid_Text(card, sizeof(card));

            int len = snprintf(tx, sizeof(tx), "%c%c%c%c%s%c",
                    0x02,
                    s[0], s[1],
                    0x06,
                    card,
                    0x03);

            send(TCP_SOCK, (uint8_t *)tx, len);
            break;
        }

        default:
        nak(s, "bad_command");
        break;
    }
}
