/*
 * cmd.c : PC 명령 확인 → 틀리면 NAK / 맞으면 ACK + 그 파일 함수 실행 (움직임은 Motor_Task 초인종으로)
 *         그리고 PC 로 가는 글자 (대답 · 완료응답 · 이벤트) 만들기. 움직이는 함수는 run.c, 보내기는 net.c NET_Send
 *
 *  글자 모양 : STX + 번호 2글자 + 내용 + ETX  (번호는 net.c 가 붙여서 줌 → 대답에 그대로)
 *
 *  ── 함수 ──
 *   ack · nak         : 받았다 / 못 받았다 대답
 *   rack_text         : C 대답의 렉 상태 한 칸 (W · R · I · P / 알람 A_05)
 *   event_send        : 이벤트 한 줄 (새 번호 Roder_Number 붙임)
 *   CMD_Event         : (Comm_Task) 쪽지들 → PC  — 만재 FF · 일시정지 PPAUSE · 카드 UT · 알람 S · 완료응답 반복 · homing done
 *   CMD_Done          : (Motor_Task) 움직임 끝 → 상태 대기 / 초기상태 · 부저 끄기 · 완료응답 글자 · 로그
 *   order_xy          : 렉 · 열 · 단 → FRAM 좌표 (입고 표 / 홀수 렉 오른쪽 표 / 짝수 렉 왼쪽 표)
 *   CMD_Run           : (Comm_Task) 명령 확인
 *                       FS · FP · FI · FD (설정 저장) / MI · MO · PO · I (움직임 → 초인종) / C (상태) / S (일시정지)
 *                       D (억지로 풀기) / LL (램프) / R (카드) / B (부저) / 번호 <ACK> AI… (완료 승인)
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#include "cmd.h"
#include "save.h"
#include "net.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "event.h"
#include "alarm.h"
#include "rfid.h"
#include "lamp.h"
#include "buzzer.h"
#include "cli.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "cmsis_os2.h"

#include <stdio.h>
#include <string.h>
#include <stdint.h>

#define CMD_FS  (('F' << 8) | 'S')
#define CMD_FP  (('F' << 8) | 'P')
#define CMD_FI  (('F' << 8) | 'I')
#define CMD_C   ('C' << 8)
#define CMD_FD  (('F' << 8) | 'D')
#define CMD_RFID ('R' << 8)
#define CMD_LAMP (('L' << 8) | 'L')
#define CMD_D   ('D' << 8)
#define CMD_BUZZER (('B' << 8) | '_')   /* 01B_렉_1 켬 / 01B_렉_0 끔 */

static char done_text[32];  /* 완료응답 "05AI_1_1_2" : PC 승인 올 때까지 1초마다, 승인 오면 비움 */
static uint32_t done_time;  /* 완료응답 마지막으로 보낸 시각 */
static char home_text[24];  /* 원점 완료 "05<ACK>homing done" : 한 번 보내고 비움 */
static char order_no[2];    /* 동작 명령의 PC 번호 2글자 (완료응답에 그대로) */
static uint32_t move_start; /* PC 동작 명령 시작 시각 : 로그에 걸린 시간 */



static void ack(char *s)
{
    char tx[160];

    int len = snprintf(tx, sizeof(tx),
            "%c%c%c%c%s%c",
            STX,
            s[0], s[1],
            ACK,
            s + 2,
            ETX);

    NET_Send((uint8_t *)tx, len);
}


static void nak(char *s, char *error)
{
    char tx[80];

    int len = snprintf(tx, sizeof(tx),
            "%c%c%c%c%s%c",
            STX,
            s[0], s[1],
            NAK,
            error,
            ETX);

    NET_Send((uint8_t *)tx, len);
}

/* 렉 상태 한 칸 : W, R, I, P / 알람이면 A_01 */
static void rack_text(char *b, int size, char status, int alarm)
{
    if (status == ALARM)
        snprintf(b, size, "A_%02d", alarm);
    else
        snprintf(b, size, "%c", status);
}

/* PC 로 이벤트 1개 : STX + 일련번호(01~99, PC 명령과 같은 번호를 이어서) + 내용 + ETX */
static void event_send(const char *text)
{
    char tx[80];
    int len;

    len = snprintf(tx, sizeof(tx), "%c%02d%s%c", STX, Roder_Number(), text, ETX);
    NET_Send((uint8_t *)tx, len);
}

/* 이벤트 : 표시가 있으면 PC 로 먼저 보냄 (Comm_Task 1ms 마다) */
void CMD_Event(void)
{
    char b[64];
    char card[48];

    /* 만재 : FF_1_0001&F_2_0000 */
    if (full_event_on) {
        full_event_on = 0;
        snprintf(b, sizeof(b), "FF_1_%d%d%d%d&F_2_%d%d%d%d",
                 manjae_on(1, 1), manjae_on(1, 2), manjae_on(1, 3), manjae_on(1, 4),
                 manjae_on(2, 1), manjae_on(2, 2), manjae_on(2, 3), manjae_on(2, 4));
        event_send(b);
    }

    /* 일시정지 : PPAUSE:M */
    if (pause_event_on) {
        pause_event_on = 0;
        snprintf(b, sizeof(b), "PPAUSE:%c", pause_why);
        event_send(b);
    }

    /* 카드 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 (T = 있음, U = 없음) */
    if (card_event_on) {
        card_event_on = 0;
        snprintf(card, sizeof(card), "U%c_1_%02X%02X%02X%02X%02X%02X%02X&U%c_2_%02X%02X%02X%02X%02X%02X%02X",
                 card_ok_1 ? 'T' : 'U', uid_1[0], uid_1[1], uid_1[2], uid_1[3], uid_1[4], uid_1[5], uid_1[6],
                 card_ok_2 ? 'T' : 'U', uid_2[0], uid_2[1], uid_2[2], uid_2[3], uid_2[4], uid_2[5], uid_2[6]);
        event_send(card);
    }

    /* 알람 : 렉 수(rack_channel)까지, 걸린 렉만 이어서 S_1_A_09&S_3_A_05 */
    if (alarm_event_on) {
        int n = 0;                  /* b 에 쓴 글자 수 */

        alarm_event_on = 0;
        b[0] = 0;
        if (alarm_1 != 0 && save.fs.rack_channel >= 1) n += snprintf(b + n, sizeof(b) - n, "&S_1_A_%02d", alarm_1);
        if (alarm_2 != 0 && save.fs.rack_channel >= 2) n += snprintf(b + n, sizeof(b) - n, "&S_2_A_%02d", alarm_2);
        if (alarm_3 != 0 && save.fs.rack_channel >= 3) n += snprintf(b + n, sizeof(b) - n, "&S_3_A_%02d", alarm_3);
        if (alarm_4 != 0 && save.fs.rack_channel >= 4) n += snprintf(b + n, sizeof(b) - n, "&S_4_A_%02d", alarm_4);
        if (n > 0) event_send(b + 1);   /* 맨 앞 & 하나 빼고 보냄 */
    }

    /* 완료응답 : PC 승인 올 때까지 1초마다 (긴급정지면 버림) */
    if (estop == 1) done_text[0] = 0;

    if (done_text[0] != 0 && osKernelGetTickCount() - done_time >= 1000) {
        done_time = osKernelGetTickCount();
        snprintf(b, sizeof(b), "%c%s%c", STX, done_text, ETX);
        NET_Send((uint8_t *)b, strlen(b));
    }

    /* 원점 완료 : 한 번만 (승인 필요 없음) */
    if (home_text[0] != 0) {
        snprintf(b, sizeof(b), "%c%s%c", STX, home_text, ETX);
        NET_Send((uint8_t *)b, strlen(b));
        home_text[0] = 0;
    }
}

/* 완료응답 (Motor_Task 가 Motor_Run 끝나고 부름) : 울린 초인종 flag, 결과 ok(1 / 0)
   PC 원점 → 성공이면 homing done (원점 끝 정리 : 대기 · 부저 끔은 run.c Motor_Run)
   입고 · 출고 · 분배 → 성공 대기 + 05AI_1_1_2 / 05AO_… / 05EO_… (보내는 건 CMD_Event) */
void CMD_Done(int flag, int ok)
{
    uint32_t sec = (osKernelGetTickCount() - move_start) / 1000;   /* 걸린 시간 (PC 명령) */
    char b[48];                                                     /* 로그 한 줄 */

    /* 원점 : PC 가 시킨 I 였으면(번호 있음) 성공일 때 homing done (켤 때 · HMI 는 번호 없음 → 대답 없음) */
    if (flag & MOTOR_FLAG) {
        if (ok && order_no[0] != 0) snprintf(home_text, sizeof(home_text), "%c%c%choming done", order_no[0], order_no[1], ACK);
        order_no[0] = 0;                                            /* 번호 다 씀 */
        return;
    }

    /* 입고 · 출고 · 분배 : 로그 */
    snprintf(b, sizeof(b), "%s  %s  %lus", (flag & MI_FLAG) ? "MI" : (flag & MO_FLAG) ? "MO" : "PO", ok ? "done" : "FAIL", sec);
    Log_Port(b);

    if (ok) {                                                       /* 실패면 대답 없음 (상태 그대로) */
        Status_WAIT(order_rack);                                    /* 끝 → 대기 */
        snprintf(done_text, sizeof(done_text), "%c%c%c%c_%d_%d_%d", /* 번호 + (PO 면 E, 아니면 A) + (입고 I / 출고 · 분배 O) */
                 order_no[0], order_no[1], (flag & PO_FLAG) ? 'E' : 'A', (flag & MI_FLAG) ? 'I' : 'O',
                 order_rack, order_col, order_dan);
        done_time = osKernelGetTickCount() - 1000;                  /* 바로 첫 전송 */
    }
    order_no[0] = 0;                                                /* 번호 다 씀 */
}

/* 렉 · 열 · 단 → FRAM 좌표 order_x, order_y (입고 = 입고 표 / 홀수 렉 = 오른쪽 표 / 짝수 렉 = 왼쪽 표) */
static void order_xy(int cmd)
{
    if (cmd == CMD_MI)                                      /* 입고 */
    {
        order_x = save.fp.in_x;

        if (order_dan == 1) order_y = save.fp.in_y1;
        else if (order_dan == 2) order_y = save.fp.in_y2;
        else if (order_dan == 3) order_y = save.fp.in_y3;
        else if (order_dan == 4) order_y = save.fp.in_y4;
        else if (order_dan == 5) order_y = save.fp.in_y5;
        return;
    }

    if (order_rack % 2 == 1)                                /* 홀수 렉 = 오른쪽 표 */
    {
        if (order_col == 1) order_x = save.fp.right_x1;
        else if (order_col == 2) order_x = save.fp.right_x2;
        else if (order_col == 3) order_x = save.fp.right_x3;
        else if (order_col == 4) order_x = save.fp.right_x4;
        else if (order_col == 5) order_x = save.fp.right_x5;
        else if (order_col == 6) order_x = save.fp.right_x6;
        else if (order_col == 7) order_x = save.fp.right_x7;
        else if (order_col == 8) order_x = save.fp.right_x8;
        else if (order_col == 9) order_x = save.fp.right_x9;

        if (order_dan == 1) order_y = save.fp.right_y1;
        else if (order_dan == 2) order_y = save.fp.right_y2;
        else if (order_dan == 3) order_y = save.fp.right_y3;
        else if (order_dan == 4) order_y = save.fp.right_y4;
        else if (order_dan == 5) order_y = save.fp.right_y5;
        else if (order_dan == 6) order_y = save.fp.right_y6;
        else if (order_dan == 7) order_y = save.fp.right_y7;
        else if (order_dan == 8) order_y = save.fp.right_y8;
        else if (order_dan == 9) order_y = save.fp.right_y9;
    }
    else                                                    /* 짝수 렉 = 왼쪽 표 */
    {
        if (order_col == 1) order_x = save.fp.left_x1;
        else if (order_col == 2) order_x = save.fp.left_x2;
        else if (order_col == 3) order_x = save.fp.left_x3;
        else if (order_col == 4) order_x = save.fp.left_x4;
        else if (order_col == 5) order_x = save.fp.left_x5;
        else if (order_col == 6) order_x = save.fp.left_x6;
        else if (order_col == 7) order_x = save.fp.left_x7;
        else if (order_col == 8) order_x = save.fp.left_x8;
        else if (order_col == 9) order_x = save.fp.left_x9;

        if (order_dan == 1) order_y = save.fp.left_y1;
        else if (order_dan == 2) order_y = save.fp.left_y2;
        else if (order_dan == 3) order_y = save.fp.left_y3;
        else if (order_dan == 4) order_y = save.fp.left_y4;
        else if (order_dan == 5) order_y = save.fp.left_y5;
        else if (order_dan == 6) order_y = save.fp.left_y6;
        else if (order_dan == 7) order_y = save.fp.left_y7;
        else if (order_dan == 8) order_y = save.fp.left_y8;
        else if (order_dan == 9) order_y = save.fp.left_y9;
    }
}

/* 명령 받기 (Comm_Task) : 명령이 맞나 확인 → 아니면 NAK / 맞으면 ACK + 그 파일 함수 실행. 움직이는 명령은 Motor_Task 에 넘기고 바로 돌아감 */
void CMD_Run(char *s)
{
    int cmd;

    int rack;
    char type;
    int rack_channel;

    int in_x, in_y;
    int left_x, left_y;
    int right_x, right_y;
    char log_line[64];      /* 로그 한 줄 */

    int no;
    int value[9];
    int count;

    /* 완료응답 승인 : 05 <ACK> AI_1_1_2 (화면엔 05-AI_… 처럼 보임) → 번호, 내용이 같으면 반복 끝 */
    if (s[2] == ACK) {
        if (done_text[0] != 0 && s[0] == done_text[0] && s[1] == done_text[1] &&
            strcmp(s + 3, done_text + 2) == 0)
            done_text[0] = 0;
        return;
    }

    cmd = (s[2] << 8) | s[3];

    switch (cmd)

    {
    /* FS */
    case CMD_FS:

        if (sscanf(s + 2,
                "FS_%d_%c_%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &type,
                &rack_channel,
                &in_x,
                &in_y,
                &left_x,
                &left_y,
                &right_x,
                &right_y) != 9)
        {
            nak(s, "bad_data");
            break;
        }

        if (FS(rack, type, rack_channel,
               in_x, in_y,
               left_x, left_y,
               right_x, right_y))
            ack(s);
        else
            nak(s, "bad_data");

        break;


    /* FP */
    case CMD_FP:

        count = sscanf(s + 2,
                "FP_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &no,
                &value[0],
                &value[1],
                &value[2],
                &value[3],
                &value[4],
                &value[5],
                &value[6],
                &value[7],
                &value[8]);

        count -= 2;

        if (count < 1)
        {
            nak(s, "bad_data");
            break;
        }

        if (FP(rack, no, value, count))
            ack(s);
        else
            nak(s, "bad_data");

        break;


    /* FI */
    case CMD_FI:

        /* FI 1~4 : IP 형식 */
        if (sscanf(s + 2,
                "FI_1_%d_%d.%d.%d.%d",
                &no,
                &value[0],
                &value[1],
                &value[2],
                &value[3]) == 5)
        {
            if (FI(no, value, 4))
                ack(s);
            else
                nak(s, "bad_data");

            break;
        }

        /* FI 5~7 : 숫자 하나 */
        if (sscanf(s + 2,
                "FI_1_%d_%d",
                &no,
                &value[0]) == 2)
        {
            if (FI(no, value, 1))
                ack(s);
            else
                nak(s, "bad_data");

            break;
        }

        nak(s, "bad_data");
        break;


    /* FD */
    case CMD_FD:

        if (strcmp(s + 2, "FD_1") != 0)
        {
            nak(s, "bad_data");
            break;
        }

        if (FD())
            ack(s);
        else
            nak(s, "fram_error");

        break;


    /* 입고 · 출고 · 분배 : 01MI_렉_열_단_XY속도_틸트속도_이동후대기_쏟는시간 → 확인 → 맞으면 Motor_Task 에 넘김 (실행은 run.c MI · MO · PO) */
    case CMD_MI:
    case CMD_MO:
    case CMD_PO:

        if (status_1 != WAIT || status_2 != WAIT || status_3 != WAIT || status_4 != WAIT ||   /* 동작 중 · 원점 중 · 대기 아님 */
            manual == 1 || done_text[0] != 0)                                             /* 대기 아님 / 수동 / 완료응답 승인 전 */
        {
            nak(s, "can_not_command");
            break;
        }

        if (sscanf(s + 5, "%d_%d_%d_%d_%d_%d_%d",                                         /* 숫자 7개 → 주문서 칸 (run.c) */
                &order_rack,
                &order_col,
                &order_dan,
                &order_xy_speed,
                &order_tilt_speed,
                &order_move_delay,
                &order_return_delay) != 7)
        {
            nak(s, "bad_data");
            break;
        }

        if (order_rack < 1 || order_rack > save.fs.rack_channel)                          /* 렉 : 1 ~ 렉 수(FS rack_channel) */
        {
            nak(s, "bad_data");
            break;
        }

        if (cmd == CMD_MI && (order_col != 1 ||                                           /* 입고 : 열 1, 단 범위 */
                              order_dan < 1 || order_dan > save.fs.in_y))
        {
            nak(s, "bad_data");
            break;
        }

        if (cmd != CMD_MI && order_rack % 2 == 1 &&                                       /* 홀수 렉 = 오른쪽 표 : 열 · 단 범위 */
            (order_col < 1 || order_col > save.fs.right_x || order_dan < 1 || order_dan > save.fs.right_y))
        {
            nak(s, "bad_data");
            break;
        }

        if (cmd != CMD_MI && order_rack % 2 == 0 &&                                       /* 짝수 렉 = 왼쪽 표 : 열 · 단 범위 */
            (order_col < 1 || order_col > save.fs.left_x || order_dan < 1 || order_dan > save.fs.left_y))
        {
            nak(s, "bad_data");
            break;
        }

        order_xy(cmd);                                          /* 렉 · 열 · 단 → 좌표 order_x, order_y */
        ack(s);                                                 /* 받았다 */
        order_no[0] = s[0];                                     /* 완료응답에 쓸 PC 번호 */
        order_no[1] = s[1];
        Status_RUN(order_rack);                                 /* 운전 중 */

        snprintf(log_line, sizeof(log_line), "%c%c  rack %d (%s)  col %d  floor %d  start",     /* 로그 : PO  rack 1 (right)  col 2  floor 3  start */
                 s[2], s[3], order_rack, order_rack % 2 == 1 ? "right" : "left", order_col, order_dan);
        Log_Port(log_line);
        move_start = osKernelGetTickCount();

        if (cmd == CMD_MI) osThreadFlagsSet(Motor_TaskHandle, MI_FLAG);   /* 초인종 : Motor_Task 가 MI */
        if (cmd == CMD_MO) osThreadFlagsSet(Motor_TaskHandle, MO_FLAG);   /*                       MO */
        if (cmd == CMD_PO) osThreadFlagsSet(Motor_TaskHandle, PO_FLAG);   /*                       PO */
        break;

    /* 상태 조회 : 렉 수(rack_channel)만큼 S_1_W&S_2_A_03&S_3_W … + 만재 F_1_0001&F_2_0000 */
    case CMD_C:
    {
        char tx[120];
        char r[8];
        int len;

        len = snprintf(tx, sizeof(tx), "%c%c%c%c", STX, s[0], s[1], ACK);   /* 번호 + ACK */

        rack_text(r, sizeof(r), status_1, alarm_1);                          /* 렉 1 */
        len += snprintf(tx + len, sizeof(tx) - len, "S_1_%s", r);

        if (save.fs.rack_channel >= 2) {                                     /* 렉 2 */
            rack_text(r, sizeof(r), status_2, alarm_2);
            len += snprintf(tx + len, sizeof(tx) - len, "&S_2_%s", r);
        }
        if (save.fs.rack_channel >= 3) {                                     /* 렉 3 */
            rack_text(r, sizeof(r), status_3, alarm_3);
            len += snprintf(tx + len, sizeof(tx) - len, "&S_3_%s", r);
        }
        if (save.fs.rack_channel >= 4) {                                     /* 렉 4 */
            rack_text(r, sizeof(r), status_4, alarm_4);
            len += snprintf(tx + len, sizeof(tx) - len, "&S_4_%s", r);
        }

        len += snprintf(tx + len, sizeof(tx) - len, "&F_1_%d%d%d%d&F_2_%d%d%d%d%c",   /* 만재 : 센서 있는 렉 1 · 2 */
                manjae_on(1, 1), manjae_on(1, 2), manjae_on(1, 3), manjae_on(1, 4),
                manjae_on(2, 1), manjae_on(2, 2), manjae_on(2, 3), manjae_on(2, 4),
                ETX);

        NET_Send((uint8_t *)tx, len);
        break;
    }

    /* 일시정지 : S_1 → 모든 렉 멈춤 표시 (이유 M 사용자). MI 도착 · PO 정지선에서 섬, HMI RUN 으로 풂 */
    case CMD_S:

        if (strcmp(s + 2, "S_1") != 0)
        {
            nak(s, "bad_data");
            break;
        }

        Status_PAUSE(0, 'M');       /* 일시정지 : 모든 렉, 이유 사용자 */
        ack(s);
        break;

    /* 억지로 풀기 : D → 만재(F) · 틸트(T) 로 멈춘 것만 이어서 진행 (센서가 만재여도) */
    case CMD_D:

        if (strcmp(s + 2, "D") != 0)
        {
            nak(s, "bad_data");
            break;
        }

        if (pause_why == 'F'|| pause_why == 'T')
            Status_Resume();      /* 만재 · 틸트로 멈춘 것만 */
        ack(s);
        break;

    /* 원점 : I → 확인 → 원점 중 + 부저 → Motor_Task (run.c motor_basic_init) */
    case CMD_I:

        if (strcmp(s + 2, "I") != 0)
        {
            nak(s, "bad_data");
            break;
        }

        if (status_1 == HOME ||                                         /* 원점 중 */
            status_1 == RUN   || status_2 == RUN   || status_3 == RUN   || status_4 == RUN ||      /* 동작 중 */
            status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE)      /* 동작 중 멈춤 (PO 정지선) */
        {
            nak(s, "can_not_command");
            break;
        }

        ack(s);                                     /* 받았다 */
        order_no[0] = s[0];                         /* homing done 에 쓸 PC 번호 */
        order_no[1] = s[1];
        osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);   /* 원점 해 (상태 · 부저 · 움직임은 run.c Motor_Run) */
        break;

    /* 램프 : 01LL_렉_램프_모드시간&L_렉_램프_모드시간… (램프 1 적 2 녹 3 황, 모드 0 끔 1 켬 2 깜빡, 시간 '0'~'l' = 0~60초, 0 = 계속) */
    case CMD_LAMP:
    {
        char *p = s + 3;                        /* 첫 L 건너뜀 → "L_1_1_25&L_1_2_31" */
        int rack, color;
        char mode, sec;

        if (sscanf(p, "L_%d_%d_%c%c", &rack, &color, &mode, &sec) != 4) { nak(s, "bad_data"); break; }   /* 하나도 못 읽음 */

        while (sscanf(p, "L_%d_%d_%c%c", &rack, &color, &mode, &sec) == 4) {   /* 하나씩 */
            if (rack < 1 || rack > save.fs.rack_channel || color < 1 || color > 3 ||
                mode < '0' || mode > '2' || sec < '0' || sec > 'l') { nak(s, "bad_data"); return; }
            Lamp_Tcp(rack % 2 == 1 ? 1 : 2, color, mode - '0', sec - '0');     /* 홀수 렉 = 램프1, 짝수 = 램프2 */
            p = strchr(p, '&');                 /* 다음 & */
            if (p == NULL) break;
            p++;
        }
        ack(s);
        break;
    }

    /* 카드 조회 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 */
    case CMD_RFID:
    {
        char tx[64];
        char card[48];

        snprintf(card, sizeof(card), "U%c_1_%02X%02X%02X%02X%02X%02X%02X&U%c_2_%02X%02X%02X%02X%02X%02X%02X",
                 card_ok_1 ? 'T' : 'U', uid_1[0], uid_1[1], uid_1[2], uid_1[3], uid_1[4], uid_1[5], uid_1[6],
                 card_ok_2 ? 'T' : 'U', uid_2[0], uid_2[1], uid_2[2], uid_2[3], uid_2[4], uid_2[5], uid_2[6]);

        int len = snprintf(tx, sizeof(tx), "%c%c%c%c%s%c",
                STX,
                s[0], s[1],
                ACK,
                card,
                ETX);

        NET_Send((uint8_t *)tx, len);
        break;
    }

    /* 부저 : 01B_렉_켜기(1) / 끄기(0) — 부저가 하나라 렉 번호는 확인만 */
    case CMD_BUZZER:
    {
        int rack, on;

        if (sscanf(s + 2, "B_%d_%d", &rack, &on) != 2 || rack < 1 || rack > save.fs.rack_channel || on < 0 || on > 1) {
            nak(s, "bad_data");
            break;
        }
        if (on == 1) Buzzer_On();
        else         Buzzer_Off();
        ack(s);
        break;
    }

    default:
        nak(s, "bad_command");
        break;
    }
}
