/*
 * cmd.c
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#include "cmd.h"
#include "save.h"
#include "net.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "event.h"
#include "alarm.h"
#include "rfid.h"
#include "lamp.h"
#include "buzzer.h"
#include "cli.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "cmsis_os2.h"

#include <stdio.h>
#include <string.h>
#include <stdint.h>

#define CMD_FS  (('F' << 8) | 'S')
#define CMD_FP  (('F' << 8) | 'P')
#define CMD_FI  (('F' << 8) | 'I')
#define CMD_C   ('C' << 8)
#define CMD_FD  (('F' << 8) | 'D')
#define CMD_RFID ('R' << 8)
#define CMD_LAMP (('L' << 8) | 'L')
#define CMD_D   ('D' << 8)
#define CMD_BUZZER (('B' << 8) | '_')   /* 01B_렉_1 켬 / 01B_렉_0 끔 */

static char done_text[32];  /* 완료응답 "05AI_1_1_2" : PC 승인 올 때까지 1초마다, 승인 오면 비움 */
static uint32_t done_time;  /* 완료응답 마지막으로 보낸 시각 */
static char home_text[24];  /* 원점 완료 "05<ACK>homing done" : 한 번 보내고 비움 */

extern osThreadId_t Motor_TaskHandle;   /* 깨울 태스크 (app_freertos.c) */

static char order[160];         /* 주문서 : Motor_Task 에 넘길 동작 명령 한 줄 (01PO_1_3_2_…) */
static volatile int order_on;   /* 벨 : 1 = 동작 중 (CMD_Run 이 켜고, CMD_Move 가 다 하고 끔) */


static void ack(char *s)
{
    char tx[160];

    int len = snprintf(tx, sizeof(tx),
            "%c%c%c%c%s%c",
            STX,
            s[0], s[1],
            ACK,
            s + 2,
            ETX);

    NET_Send((uint8_t *)tx, len);
}


static void nak(char *s, char *error)
{
    char tx[80];

    int len = snprintf(tx, sizeof(tx),
            "%c%c%c%c%s%c",
            STX,
            s[0], s[1],
            NAK,
            error,
            ETX);

    NET_Send((uint8_t *)tx, len);
}

/* 렉 상태 한 칸 : W, R, I, P / 알람이면 A_01 */
static void rack_text(char *b, int size, char status, int alarm)
{
    if (status == ALARM)
        snprintf(b, size, "A_%02d", alarm);
    else
        snprintf(b, size, "%c", status);
}

/* PC 로 이벤트 1개 : STX + 일련번호(01~99) + 내용 + ETX */
static void event_send(const char *text)
{
    static int number = 0;      /* 이벤트 일련번호 : 보낼 때마다 1 늘림, 99 다음 01 */
    char tx[80];
    int len;

    number++;                   /* 다음 번호 */
    if (number > 99) number = 1;

    len = snprintf(tx, sizeof(tx), "%c%02d%s%c", STX, number, text, ETX);
    NET_Send((uint8_t *)tx, len);
}

/* 이벤트 : 표시가 있으면 PC 로 먼저 보냄 (Comm_Task 1ms 마다) */
void CMD_Event(void)
{
    char b[64];
    char card[48];

    /* 만재 : FF_1_0001&F_2_0000 */
    if (full_event_on) {
        full_event_on = 0;
        snprintf(b, sizeof(b), "FF_1_%d%d%d%d&F_2_%d%d%d%d",
                 manjae_on(1, 1), manjae_on(1, 2), manjae_on(1, 3), manjae_on(1, 4),
                 manjae_on(2, 1), manjae_on(2, 2), manjae_on(2, 3), manjae_on(2, 4));
        event_send(b);
    }

    /* 일시정지 : PPAUSE:M */
    if (pause_event_on) {
        pause_event_on = 0;
        snprintf(b, sizeof(b), "PPAUSE:%c", pause_why);
        event_send(b);
    }

    /* 카드 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 */
    if (rfid_new) {
        rfid_new = 0;
        Rfid_Text(card, sizeof(card));
        event_send(card);
    }

    /* 알람 : 렉 수(rack_channel)까지, 걸린 렉만 이어서 S_1_A_09&S_3_A_05 */
    if (alarm_event_on) {
        int n = 0;                  /* b 에 쓴 글자 수 */

        alarm_event_on = 0;
        b[0] = 0;
        if (alarm_1 != 0 && save.fs.rack_channel >= 1) n += snprintf(b + n, sizeof(b) - n, "&S_1_A_%02d", alarm_1);
        if (alarm_2 != 0 && save.fs.rack_channel >= 2) n += snprintf(b + n, sizeof(b) - n, "&S_2_A_%02d", alarm_2);
        if (alarm_3 != 0 && save.fs.rack_channel >= 3) n += snprintf(b + n, sizeof(b) - n, "&S_3_A_%02d", alarm_3);
        if (alarm_4 != 0 && save.fs.rack_channel >= 4) n += snprintf(b + n, sizeof(b) - n, "&S_4_A_%02d", alarm_4);
        if (n > 0) event_send(b + 1);   /* 맨 앞 & 하나 빼고 보냄 */
    }

    /* 완료응답 : PC 승인 올 때까지 1초마다 (긴급정지면 버림) */
    if (estop == 1) done_text[0] = 0;

    if (done_text[0] != 0 && osKernelGetTickCount() - done_time >= 1000) {
        done_time = osKernelGetTickCount();
        snprintf(b, sizeof(b), "%c%s%c", STX, done_text, ETX);
        NET_Send((uint8_t *)b, strlen(b));
    }

    /* 원점 완료 : 한 번만 (승인 필요 없음) */
    if (home_text[0] != 0) {
        snprintf(b, sizeof(b), "%c%s%c", STX, home_text, ETX);
        NET_Send((uint8_t *)b, strlen(b));
        home_text[0] = 0;
    }
}

/* 완료응답 만들기 : 받은 명령 s 와 결과 ok 로. MI→AI, MO→AO, PO→EO, I→homing done / 보내는 건 CMD_Event 가 */
void CMD_Done(char *s, int ok)
{
    int rack = 0;
    int yeol= 0;
    int dan = 0;

    /* 원점 (01I) : 성공 → 대기 + homing done, 실패 → 초기상태 */
    if (s[2] == 'I') {
        if (ok == 0) { if (status_1 != ALARM) { Status_INIT(); Buzzer_Off(); } return; }   /* 실패 : 알람(10 등)이면 상태 · 부저 그대로 */
        Status_WAIT(1);
        Status_WAIT(2);
        Status_WAIT(3);
        Status_WAIT(4);
        Buzzer_Off();               /* 원점 끝 : 부저 끔 */
        snprintf(home_text, sizeof(home_text), "%c%c%choming done", s[0], s[1], ACK);
        return;
    }

    /* MI / MO / PO : 못 했으면 완료 아님 */
    if (ok == 0) return;

    /* 01MI_렉_열_단_… 에서 렉 · 열 · 단 */
    sscanf(s + 5, "%d_%d_%d", &rack, &yeol, &dan);
    Status_WAIT(rack);                                      /* 끝 → 대기 */

    /* 번호 2글자 + (PO 면 E, 아니면 A) + (I 또는 O) : 05AI_1_1_2 / 05AO_… / 05EO_… */
    snprintf(done_text, sizeof(done_text), "%c%c%c%c_%d_%d_%d",
             s[0], s[1], s[2] == 'P' ? 'E' : 'A', s[3], rack, yeol, dan);

    done_time = osKernelGetTickCount() - 1000;              /* 바로 첫 전송 */
}

/* 동작 하기 (Motor_Task 가 10ms 마다) : 주문서(order)에 MI · MO · PO · I 가 있으면 움직이고 완료응답 */
void CMD_Move(void)
{
    int cmd;
    int x = 0;              /* 갈 곳 : FRAM 에서 찾은 좌표 */
    int y = 0;

    int rack;
    int x_no;
    int y_no;
    int xy_speed;
    int tilt_speed;
    int move_delay;
    int return_delay;

    /* 원점 요청 (켤 때 · HMI RUN) : PC 명령이 아니라 상태(HOME)로 옴 → 초기화 + 원점 → 대기, 실패면 초기상태 */
    if (status_1 == HOME && order_on == 0) {
        Buzzer_On();                /* 부저 켬 (원점 중) */
        IM_MapInit();               /* 드라이브 설정 다시 (긴급정지로 드라이브 전원이 끊겼어도) */
        AM_Init();
        TM_Init();
        if (motor_basic_init() == 1) { Status_WAIT(1); Status_WAIT(2); Status_WAIT(3); Status_WAIT(4); CLI_Start(1); Buzzer_Off(); }
        else                         { if (status_1 != ALARM) { Status_INIT(); Buzzer_Off(); } CLI_Start(0); }   /* 실패 : 알람(10 등)이면 상태 · 부저 그대로 */
        return;
    }

    /* 할 일 있나 (벨) */
    if (order_on == 0) return;

    cmd = (order[2] << 8) | order[3];

    /* 01MI_렉_열_단_XY속도_틸트속도_이동후대기_쏟는시간 (CMD_Run 이 이미 확인함) */
    sscanf(order + 5, "%d_%d_%d_%d_%d_%d_%d",
            &rack,
            &x_no,
            &y_no,
            &xy_speed,
            &tilt_speed,
            &move_delay,
            &return_delay);

    switch (cmd)
    {
    /* 입고 */
    case CMD_MI:

        x = save.fp.in_x;

        if (y_no == 1) y = save.fp.in_y1;
        else if (y_no == 2) y = save.fp.in_y2;
        else if (y_no == 3) y = save.fp.in_y3;
        else if (y_no == 4) y = save.fp.in_y4;
        else if (y_no == 5) y = save.fp.in_y5;

        CMD_Done(order, MI(x, y, xy_speed, tilt_speed));        /* 움직이고 → 결과로 완료응답 */
        break;


    /* 출고 */
    case CMD_MO:

        if (rack % 2 == 1)                                      /* 홀수 렉 = 오른쪽 표 */
        {
            if (x_no == 1) x = save.fp.right_x1;
            else if (x_no == 2) x = save.fp.right_x2;
            else if (x_no == 3) x = save.fp.right_x3;
            else if (x_no == 4) x = save.fp.right_x4;
            else if (x_no == 5) x = save.fp.right_x5;
            else if (x_no == 6) x = save.fp.right_x6;
            else if (x_no == 7) x = save.fp.right_x7;
            else if (x_no == 8) x = save.fp.right_x8;
            else if (x_no == 9) x = save.fp.right_x9;

            if (y_no == 1) y = save.fp.right_y1;
            else if (y_no == 2) y = save.fp.right_y2;
            else if (y_no == 3) y = save.fp.right_y3;
            else if (y_no == 4) y = save.fp.right_y4;
            else if (y_no == 5) y = save.fp.right_y5;
            else if (y_no == 6) y = save.fp.right_y6;
            else if (y_no == 7) y = save.fp.right_y7;
            else if (y_no == 8) y = save.fp.right_y8;
            else if (y_no == 9) y = save.fp.right_y9;
        }
        else                                                    /* 짝수 렉 = 왼쪽 표 */
        {
            if (x_no == 1) x = save.fp.left_x1;
            else if (x_no == 2) x = save.fp.left_x2;
            else if (x_no == 3) x = save.fp.left_x3;
            else if (x_no == 4) x = save.fp.left_x4;
            else if (x_no == 5) x = save.fp.left_x5;
            else if (x_no == 6) x = save.fp.left_x6;
            else if (x_no == 7) x = save.fp.left_x7;
            else if (x_no == 8) x = save.fp.left_x8;
            else if (x_no == 9) x = save.fp.left_x9;

            if (y_no == 1) y = save.fp.left_y1;
            else if (y_no == 2) y = save.fp.left_y2;
            else if (y_no == 3) y = save.fp.left_y3;
            else if (y_no == 4) y = save.fp.left_y4;
            else if (y_no == 5) y = save.fp.left_y5;
            else if (y_no == 6) y = save.fp.left_y6;
            else if (y_no == 7) y = save.fp.left_y7;
            else if (y_no == 8) y = save.fp.left_y8;
            else if (y_no == 9) y = save.fp.left_y9;
        }

        CMD_Done(order, MO(x, y, xy_speed, tilt_speed));        /* 움직이고 → 결과로 완료응답 */
        break;


    /* 분배 */
    case CMD_PO:

        if (rack % 2 == 1)                                      /* 홀수 렉 = 오른쪽 표 */
        {
            if (x_no == 1) x = save.fp.right_x1;
            else if (x_no == 2) x = save.fp.right_x2;
            else if (x_no == 3) x = save.fp.right_x3;
            else if (x_no == 4) x = save.fp.right_x4;
            else if (x_no == 5) x = save.fp.right_x5;
            else if (x_no == 6) x = save.fp.right_x6;
            else if (x_no == 7) x = save.fp.right_x7;
            else if (x_no == 8) x = save.fp.right_x8;
            else if (x_no == 9) x = save.fp.right_x9;

            if (y_no == 1) y = save.fp.right_y1;
            else if (y_no == 2) y = save.fp.right_y2;
            else if (y_no == 3) y = save.fp.right_y3;
            else if (y_no == 4) y = save.fp.right_y4;
            else if (y_no == 5) y = save.fp.right_y5;
            else if (y_no == 6) y = save.fp.right_y6;
            else if (y_no == 7) y = save.fp.right_y7;
            else if (y_no == 8) y = save.fp.right_y8;
            else if (y_no == 9) y = save.fp.right_y9;
        }
        else                                                    /* 짝수 렉 = 왼쪽 표 */
        {
            if (x_no == 1) x = save.fp.left_x1;
            else if (x_no == 2) x = save.fp.left_x2;
            else if (x_no == 3) x = save.fp.left_x3;
            else if (x_no == 4) x = save.fp.left_x4;
            else if (x_no == 5) x = save.fp.left_x5;
            else if (x_no == 6) x = save.fp.left_x6;
            else if (x_no == 7) x = save.fp.left_x7;
            else if (x_no == 8) x = save.fp.left_x8;
            else if (x_no == 9) x = save.fp.left_x9;

            if (y_no == 1) y = save.fp.left_y1;
            else if (y_no == 2) y = save.fp.left_y2;
            else if (y_no == 3) y = save.fp.left_y3;
            else if (y_no == 4) y = save.fp.left_y4;
            else if (y_no == 5) y = save.fp.left_y5;
            else if (y_no == 6) y = save.fp.left_y6;
            else if (y_no == 7) y = save.fp.left_y7;
            else if (y_no == 8) y = save.fp.left_y8;
            else if (y_no == 9) y = save.fp.left_y9;
        }

        CMD_Done(order, PO(rack, x, y, y_no,                    /* 분배 (run.c) → 결과로 완료응답 */
                           xy_speed, tilt_speed,
                           move_delay, return_delay,
                           save.fp.tilt_angle, save.fp.tilting_y, save.fp.tilting_y_speed));
        break;


    /* home */
    case CMD_I:

        Status_HOME();                                          /* 원점 중 */
        Buzzer_On();                                            /* 부저 켬 (원점 중, 끝나면 CMD_Done 이 끔) */
        CMD_Done(order, motor_basic_init());                    /* 초기화 + 원점 → homing done (실패면 초기상태) */
        break;
    }

    order_on = 0;           /* 끝 : 벨 끄기 → 다음 명령 받음 */
}

/* 명령 받기 (Comm_Task) : 확인 → ack / nak. 움직이는 명령은 주문서에 넘기고 바로 돌아감 */
void CMD_Run(char *s)
{
    int cmd;

    int rack;
    char type;
    int rack_channel;

    int in_x, in_y;
    int left_x, left_y;
    int right_x, right_y;

    int x_no;
    int y_no;
    int xy_speed;
    int tilt_speed;
    int move_delay;
    int return_delay;

    int no;
    int value[9];
    int count;

    /* 완료응답 승인 : 05-AI_1_1_2 → 번호, 내용이 같으면 반복 끝 */
    if (s[2] == '-') {
        if (done_text[0] != 0 && s[0] == done_text[0] && s[1] == done_text[1] &&
            strcmp(s + 3, done_text + 2) == 0)
            done_text[0] = 0;
        return;
    }

    cmd = (s[2] << 8) | s[3];

    switch (cmd)

    {
    /* FS */
    case CMD_FS:

        if (sscanf(s + 2,
                "FS_%d_%c_%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &type,
                &rack_channel,
                &in_x,
                &in_y,
                &left_x,
                &left_y,
                &right_x,
                &right_y) != 9)
        {
            nak(s, "bad_data");
            break;
        }

        if (FS(rack, type, rack_channel,
               in_x, in_y,
               left_x, left_y,
               right_x, right_y))
            ack(s);
        else
            nak(s, "bad_data");

        break;


    /* FP */
    case CMD_FP:

        count = sscanf(s + 2,
                "FP_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &no,
                &value[0],
                &value[1],
                &value[2],
                &value[3],
                &value[4],
                &value[5],
                &value[6],
                &value[7],
                &value[8]);

        count -= 2;

        if (count < 1)
        {
            nak(s, "bad_data");
            break;
        }

        if (FP(rack, no, value, count))
            ack(s);
        else
            nak(s, "bad_data");

        break;


    /* FI */
    case CMD_FI:

        /* FI 1~4 : IP 형식 */
        if (sscanf(s + 2,
                "FI_1_%d_%d.%d.%d.%d",
                &no,
                &value[0],
                &value[1],
                &value[2],
                &value[3]) == 5)
        {
            if (FI(no, value, 4))
                ack(s);
            else
                nak(s, "bad_data");

            break;
        }

        /* FI 5~7 : 숫자 하나 */
        if (sscanf(s + 2,
                "FI_1_%d_%d",
                &no,
                &value[0]) == 2)
        {
            if (FI(no, value, 1))
                ack(s);
            else
                nak(s, "bad_data");

            break;
        }

        nak(s, "bad_data");
        break;


    /* FD */
    case CMD_FD:

        if (strcmp(s + 2, "FD_1") != 0)
        {
            nak(s, "bad_data");
            break;
        }

        if (FD())
            ack(s);
        else
            nak(s, "fram_error");

        break;


    /* 입고 */
    case CMD_MI:

        if (order_on == 1 ||                                                              /* 동작 중 (벨 켜짐) */
            status_1 != WAIT || status_2 != WAIT || status_3 != WAIT || status_4 != WAIT ||
            manual == 1 || done_text[0] != 0)                                             /* 대기 아님 / 수동 / 완료응답 승인 전 */
        {
            nak(s, "can_not_command");
            break;
        }

        if (sscanf(s + 5, "%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &x_no,
                &y_no,
                &xy_speed,
                &tilt_speed,
                &move_delay,
                &return_delay) != 7)
        {
            nak(s, "bad_data");
            break;
        }

        if (rack < 1 || rack > save.fs.rack_channel ||          /* 렉 : 1 ~ 렉 수(FS rack_channel) */
            x_no != 1 || y_no < 1 || y_no > save.fs.in_y)
        {
            nak(s, "bad_data");
            break;
        }

        ack(s);                                                 /* 받았다 */
        Status_RUN(rack);                                       /* 운전 중 */
        strcpy(order, s);                                       /* 주문서에 받은 글자 → 움직이는 건 CMD_Move (Motor_Task) */
        order_on = 1;                                           /* 벨 : Motor_Task 에 넘김 */
        osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);         /* 초인종 : Motor_Task 깨우기 */
        break;


    /* 출고 */
    case CMD_MO:

        if (order_on == 1 ||                                                              /* 동작 중 (벨 켜짐) */
            status_1 != WAIT || status_2 != WAIT || status_3 != WAIT || status_4 != WAIT ||
            manual == 1 || done_text[0] != 0)                                             /* 대기 아님 / 수동 / 완료응답 승인 전 */
        {
            nak(s, "can_not_command");
            break;
        }

        if (sscanf(s + 5, "%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &x_no,
                &y_no,
                &xy_speed,
                &tilt_speed,
                &move_delay,
                &return_delay) != 7)
        {
            nak(s, "bad_data");
            break;
        }

        if (rack < 1 || rack > save.fs.rack_channel)            /* 렉 : 1 ~ 렉 수(FS rack_channel) */
        {
            nak(s, "bad_data");
            break;
        }

        if (rack % 2 == 1 && (x_no < 1 || x_no > save.fs.right_x ||     /* 홀수 렉 = 오른쪽 표 : 열 · 단 범위 */
                              y_no < 1 || y_no > save.fs.right_y))
        {
            nak(s, "bad_data");
            break;
        }

        if (rack % 2 == 0 && (x_no < 1 || x_no > save.fs.left_x ||      /* 짝수 렉 = 왼쪽 표 : 열 · 단 범위 */
                              y_no < 1 || y_no > save.fs.left_y))
        {
            nak(s, "bad_data");
            break;
        }

        ack(s);                                                 /* 받았다 */
        Status_RUN(rack);                                       /* 운전 중 */
        strcpy(order, s);                                       /* 주문서에 받은 글자 → 움직이는 건 CMD_Move (Motor_Task) */
        order_on = 1;                                           /* 벨 : Motor_Task 에 넘김 */
        osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);         /* 초인종 : Motor_Task 깨우기 */
        break;


    /* 분배 */
    case CMD_PO:

        if (order_on == 1 ||                                                              /* 동작 중 (벨 켜짐) */
            status_1 != WAIT || status_2 != WAIT || status_3 != WAIT || status_4 != WAIT ||
            manual == 1 || done_text[0] != 0)                                             /* 대기 아님 / 수동 / 완료응답 승인 전 */
        {
            nak(s, "can_not_command");
            break;
        }

        if (sscanf(s + 5, "%d_%d_%d_%d_%d_%d_%d",
                &rack,
                &x_no,
                &y_no,
                &xy_speed,
                &tilt_speed,
                &move_delay,
                &return_delay) != 7)
        {
            nak(s, "bad_data");
            break;
        }

        if (rack < 1 || rack > save.fs.rack_channel)            /* 렉 : 1 ~ 렉 수(FS rack_channel) */
        {
            nak(s, "bad_data");
            break;
        }

        if (rack % 2 == 1 && (x_no < 1 || x_no > save.fs.right_x ||     /* 홀수 렉 = 오른쪽 표 : 열 · 단 범위 */
                              y_no < 1 || y_no > save.fs.right_y))
        {
            nak(s, "bad_data");
            break;
        }

        if (rack % 2 == 0 && (x_no < 1 || x_no > save.fs.left_x ||      /* 짝수 렉 = 왼쪽 표 : 열 · 단 범위 */
                              y_no < 1 || y_no > save.fs.left_y))
        {
            nak(s, "bad_data");
            break;
        }

        ack(s);                                                 /* 받았다 */
        Status_RUN(rack);                                       /* 운전 중 */
        strcpy(order, s);                                       /* 주문서에 받은 글자 → 움직이는 건 CMD_Move (Motor_Task) */
        order_on = 1;                                           /* 벨 : Motor_Task 에 넘김 */
        osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);         /* 초인종 : Motor_Task 깨우기 */
        break;
        /* 상태 조회 : 렉 수(rack_channel)만큼 S_1_W&S_2_A_03&S_3_W … + 만재 F_1_0001&F_2_0000 */
        case CMD_C:
        {
            char tx[120];
            char r[8];
            int len;

            len = snprintf(tx, sizeof(tx), "%c%c%c%c", STX, s[0], s[1], ACK);   /* 번호 + ACK */

            rack_text(r, sizeof(r), status_1, alarm_1);                          /* 렉 1 */
            len += snprintf(tx + len, sizeof(tx) - len, "S_1_%s", r);

            if (save.fs.rack_channel >= 2) {                                     /* 렉 2 */
                rack_text(r, sizeof(r), status_2, alarm_2);
                len += snprintf(tx + len, sizeof(tx) - len, "&S_2_%s", r);
            }
            if (save.fs.rack_channel >= 3) {                                     /* 렉 3 */
                rack_text(r, sizeof(r), status_3, alarm_3);
                len += snprintf(tx + len, sizeof(tx) - len, "&S_3_%s", r);
            }
            if (save.fs.rack_channel >= 4) {                                     /* 렉 4 */
                rack_text(r, sizeof(r), status_4, alarm_4);
                len += snprintf(tx + len, sizeof(tx) - len, "&S_4_%s", r);
            }

            len += snprintf(tx + len, sizeof(tx) - len, "&F_1_%d%d%d%d&F_2_%d%d%d%d%c",   /* 만재 : 센서 있는 렉 1 · 2 */
                    manjae_on(1, 1), manjae_on(1, 2), manjae_on(1, 3), manjae_on(1, 4),
                    manjae_on(2, 1), manjae_on(2, 2), manjae_on(2, 3), manjae_on(2, 4),
                    ETX);

            NET_Send((uint8_t *)tx, len);
            break;
        }

        /* stop */
        case CMD_S:

            if (strcmp(s + 2, "S_1") != 0)
            {
                nak(s, "bad_data");
                break;
            }

            Status_PAUSE(0);            /* 일시정지 : 모든 렉 빨간불 */
            pause_why = 'M';            /* 이유 : 사용자 */
            ack(s);
            break;

        /* 만재, 틸팅에러 억지로 풀기 : D,T (센서가 만재여도 이어서 진행) */
        case CMD_D:

            if (strcmp(s + 2, "D") != 0)
            {
                nak(s, "bad_data");
                break;
            }

            if (pause_why == 'F'|| pause_why == 'T')
            	Status_Resume();      /* 만재로 멈춘 것만 */
            ack(s);
            break;

      /* home */
        case CMD_I:

            if (strcmp(s + 2, "I") != 0)
            {
                nak(s, "bad_data");
                break;
            }

            if (order_on == 1)                          /* 동작 중 (벨 켜짐) */
            {
                nak(s, "can_not_command");
                break;
            }

            ack(s);                                     /* 받았다 */
            strcpy(order, s);                           /* 주문서 → 원점은 CMD_Move (Motor_Task) */
            order_on = 1;                               /* 벨 : Motor_Task 에 넘김 */
            osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);   /* 초인종 : Motor_Task 깨우기 */
            break;

        /* 램프 : 01LL_렉_램프_모드시간&L_렉_램프_모드시간… (램프 1 적 2 녹 3 황, 모드 0 끔 1 켬 2 깜빡, 시간 '0'~'l' = 0~60초, 0 = 계속) */
        case CMD_LAMP:
        {
            char *p = s + 3;                        /* 첫 L 건너뜀 → "L_1_1_25&L_1_2_31" */
            int rack, color;
            char mode, sec;

            if (sscanf(p, "L_%d_%d_%c%c", &rack, &color, &mode, &sec) != 4) { nak(s, "bad_data"); break; }   /* 하나도 못 읽음 */

            while (sscanf(p, "L_%d_%d_%c%c", &rack, &color, &mode, &sec) == 4) {   /* 하나씩 */
                if (rack < 1 || rack > save.fs.rack_channel || color < 1 || color > 3 ||
                    mode < '0' || mode > '2' || sec < '0' || sec > 'l') { nak(s, "bad_data"); return; }
                Lamp_Tcp(rack % 2 == 1 ? 1 : 2, color, mode - '0', sec - '0');     /* 홀수 렉 = 램프1, 짝수 = 램프2 */
                p = strchr(p, '&');                 /* 다음 & */
                if (p == NULL) break;
                p++;
            }
            ack(s);
            break;
        }

        /* 카드 조회 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 */
        case CMD_RFID:
        {
            char tx[64];
            char card[48];

            Rfid_Text(card, sizeof(card));

            int len = snprintf(tx, sizeof(tx), "%c%c%c%c%s%c",
                    STX,
                    s[0], s[1],
                    ACK,
                    card,
                    ETX);

            NET_Send((uint8_t *)tx, len);
            break;
        }

        /* 부저 : 01B_렉_켜기(1) / 끄기(0) — 부저가 하나라 렉 번호는 확인만 */
        case CMD_BUZZER:
        {
            int rack, on;

            if (sscanf(s + 2, "B_%d_%d", &rack, &on) != 2 || rack < 1 || rack > save.fs.rack_channel || on < 0 || on > 1) {
                nak(s, "bad_data");
                break;
            }
            if (on == 1) Buzzer_On();
            else         Buzzer_Off();
            ack(s);
            break;
        }

        default:
        nak(s, "bad_command");
        break;
    }
}
