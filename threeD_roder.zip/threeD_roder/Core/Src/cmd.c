/*
 * cmd.c : PC 명령 확인 → 틀리면 NAK / 맞으면 ACK + 그 파일 함수 실행 (움직임은 Motor_Task 초인종으로)
 *         프로토콜 글자는 그 파일에 : 만재 manjae.c · 카드 rfid.c · 상태 status.c · 램프 lamp.c · 부저 buzzer.c · MI/MO/PO 숫자 run.c
 *         PC 로 먼저 알림(FF · UT · PPAUSE · S)도 그 파일 *_PC() 가 (Comm_Task 반복문, app_freertos.c)
 *
 *  글자 모양 : STX + 번호 2글자 + (ACK / NAK) + 내용 + ETX  (번호는 net.c 가 CMD_Run(no, s) 로 따로 줌 → 대답에 그대로)
 *
 *  ── 함수 ──
 *   cmd_answer        : 명령 대답 (그 명령 번호 + ACK 받았다 / NAK 못 받았다)
 *   CMD_Run           : (Comm_Task) 명령 확인 (완료응답 · PC 승인은 cmd.c 가 안 함 → net.c 에서 새로)
 *                       FS · FP · FI · FD (설정 저장) / MI · MO · PO · I (움직임 → 초인종) / C (상태) / S (일시정지)
 *                       D (억지로 풀기) / LL (램프) / R (카드) / B (부저) / AI… (완료 승인) / ALL_거래처 (FS + FP 기본 설정 저장)
 *
 *  Created on: Sep 15, 2026
 *      Author: HWNOT
 */
#include "cmd.h"
#include "save.h"
#include "net.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "event.h"
#include "alarm.h"
#include "rfid.h"
#include "lamp.h"
#include "buzzer.h"
#include "debug.h"

#include <stdio.h>
#include <string.h>

#define CMD_FS  (('F' << 8) | 'S')
#define CMD_FP  (('F' << 8) | 'P')
#define CMD_FI  (('F' << 8) | 'I')
#define CMD_C   ('C' << 8)
#define CMD_FD  (('F' << 8) | 'D')
#define CMD_RFID ('R' << 8)
#define CMD_LAMP (('L' << 8) | 'L')
#define CMD_D   ('D' << 8)
#define CMD_BUZZER (('B' << 8) | '_')   /* 01B_렉_1 켬 / 01B_렉_0 끔 */
#define CMD_ALL (('A' << 8) | 'L')      /* ALL_거래처 : 그 거래처 기본 설정(FS + FP) 한 번에 저장 */



/* 명령 대답 : STX + 번호(그 명령 번호 그대로) + A_N + 글자 + ETX
   A_N : ACK 받았다 (08<ACK>MI_1_1_2) / NAK 못 받았다 (08<NAK>bad_data) / 0 완료응답 (08AI_1_1_2) */
static void cmd_answer(int no, char A_N, char *text)
{
    char tx[170];
    int len;

    if (A_N == 0) len = snprintf(tx, sizeof(tx), "%c%02d%s%c", STX, no, text, ETX);           /* 완료응답 : 가운데 글자 없음 */
    else          len = snprintf(tx, sizeof(tx), "%c%02d%c%s%c", STX, no, A_N, text, ETX);    /* ACK / NAK */
    send_socket((uint8_t *)tx, len);
}



/* 명령 받기 (Comm_Task) : 명령이 맞나 확인 → 아니면 NAK / 맞으면 ACK + 그 파일 함수 실행. 움직이는 명령은 Motor_Task 에 넘기고 바로 돌아감
   no = 로더가 붙인 번호 (net.c send_cmd), s = PC 가 보낸 내용만 (STX · ETX · 번호 없음)  예) CMD_Run(8, "MI_1_1_2") */
void CMD_Run(int PC_num, char *s)
{
    int cmd;

    int rack;
    char type;
    int rack_channel;

    int in_x, in_y;
    int left_x, left_y;
    int right_x, right_y;
    int option;               /* FS 옵션 5자리 (10000 ~ 00001, 마지막 = 틸팅 검사) */
    int fi_no;                /* FI 의 항목 번호 */
    char fp_no;              /* FP 의 항목 글자 ('1' ~ '9', ':' 10 ';' 11 '<' 12 '=' 13) */
    int value[9];
    MOVE m;                   /* 모터 주문 (MI · MO · PO · I) → run.c Motor_Request */
    int n;                    /* 읽은 숫자 개수 */

    /* 번호는 로더가 붙임 : PC 가 번호를 붙여 보냄 (52MI_…) → 거절 */
    if (s[0] >= '0' && s[0] <= '9') { cmd_answer(PC_num, NAK, "wrong_number"); return; }

    cmd = (s[0] << 8) | s[1];

    switch (cmd)

    {
    /* FS */
    case CMD_FS:

        if (sscanf(s, "FS_%d_%c_%d_%d_%d_%d_%d_%d_%d_%d",
                   &rack, &type, &rack_channel,
                   &in_x, &in_y, &left_x, &left_y,
                   &right_x, &right_y, &option) == 10 &&
            FS(rack, type, rack_channel,
               in_x, in_y, left_x, left_y,
               right_x, right_y, option))
            cmd_answer(PC_num, ACK, s);
        else
            cmd_answer(PC_num, NAK, "bad_data");

        break;


        /* FP : 설정번호 확인 → 데이터 개수 확인 → 저장 */
        case CMD_FP:
        {
            int need = 0;    /* 데이터 넣는 수가 각자 다르기 때문에  */

            if (sscanf(s, "FP_%d_%c", &rack, &fp_no) != 2) {
                cmd_answer(PC_num, NAK, "bad_data");
                break;
            }

            switch (fp_no) {
            case '1': case '8': case '9': case ':':
                need = 1;
                break;

            case '2': need = save.fs.in_y;    break;
            case '3': need = save.fs.left_x;  break;
            case '4': need = save.fs.left_y;  break;
            case '5': need = save.fs.right_x; break;
            case '6': need = save.fs.right_y; break;

            case '7': need = 5; break;

            case ';': case '<':
                need = 3;
                break;

            case '=':
                need = save.fs.in_y + 1;
                break;
            }

            if (rack != 1 || need < 1 ||
                sscanf(s, "FP_%d_%c_%d_%d_%d_%d_%d_%d_%d_%d_%d",
                       &rack, &fp_no,
                       &value[0], &value[1], &value[2],
                       &value[3], &value[4], &value[5],
                       &value[6], &value[7], &value[8]) != need + 2)
            {
                cmd_answer(PC_num, NAK, "bad_data");
                break;
            }

            if (FP(rack, fp_no, value))
                cmd_answer(PC_num, ACK, s);
            else
                cmd_answer(PC_num, NAK, "bad_data");

            break;
        }

    /* FI */
    case CMD_FI:

        /* FI 1~4 : IP 형식 */
        if (sscanf(s,
                "FI_1_%d_%d.%d.%d.%d",
                &fi_no,
                &value[0],
                &value[1],
                &value[2],
                &value[3]) == 5)
        {
            if (FI(fi_no, value))
                cmd_answer(PC_num, ACK, s);
            else
                cmd_answer(PC_num, NAK, "bad_data");

            break;
        }

        /* FI 5~7 : 숫자 하나 */
        if (sscanf(s,
                "FI_1_%d_%d",
                &fi_no,
                &value[0]) == 2)
        {
            if (FI(fi_no, value))
                cmd_answer(PC_num, ACK, s);
            else
                cmd_answer(PC_num, NAK, "bad_data");

            break;
        }

        cmd_answer(PC_num, NAK, "bad_data");
        break;


    /* FD */
    case CMD_FD:

        if (strcmp(s, "FD_1") != 0)
        {
            cmd_answer(PC_num, NAK, "bad_data");
            break;
        }

        if (FD())
            cmd_answer(PC_num, ACK, s);
        else
            cmd_answer(PC_num, NAK, "fram_error");

        break;


    /* 입고 · 출고 · 분배 : MO_1_2_3_080_080_500_050_045 (PO 는 끝에 _틸팅검사) → 확인 → 모터 문 run.c Motor_Request (실행은 MI · MO · PO) */
    case CMD_MI:
    case CMD_MO:
    case CMD_PO:

        /* 숫자 읽기 : 렉_열_단_리프트속도_틸트속도_동작대기_틸트복귀대기_틸팅각도 (+ PO 만 _틸팅검사) */
        m.cmd = cmd;
        m.tilt_check = 0;
        n = sscanf(s + 3, "%d_%d_%d_%d_%d_%d_%d_%d_%d",
                   &m.rack, &m.col, &m.dan, &m.lift_speed, &m.tilt_speed,
                   &m.delay, &m.return_delay, &m.tilt_angle, &m.tilt_check);

        /* 검사 : 개수 (MI · MO 8개, PO 9개) · 렉 · 열 · 단 · 속도 10~100 · 동작 대기 0 이상
                  PO 만 : 복귀 대기 20~300 (0.2 ~ 3초) · 각도 20~90 · 틸팅 검사 0 / 1 */
        if (n != (cmd == CMD_PO ? 9 : 8) ||
            m.rack < 1 || m.rack > save.fs.rack_channel ||
            (cmd == CMD_MI && (m.col != 1 || m.dan < 1 || m.dan > save.fs.in_y)) ||
            (cmd != CMD_MI && m.rack % 2 == 1 && (m.col < 1 || m.col > save.fs.right_x || m.dan < 1 || m.dan > save.fs.right_y)) ||
            (cmd != CMD_MI && m.rack % 2 == 0 && (m.col < 1 || m.col > save.fs.left_x  || m.dan < 1 || m.dan > save.fs.left_y))  ||
            m.lift_speed < 10 || m.lift_speed > 100 || m.tilt_speed < 10 || m.tilt_speed > 100 || m.delay < 0 ||
            (cmd == CMD_PO && (m.return_delay < 20 || m.return_delay > 300 ||
                               m.tilt_angle < 20 || m.tilt_angle > 90 || m.tilt_check < 0 || m.tilt_check > 1)))
        {
            cmd_answer(PC_num, NAK, "bad_data");
            break;
        }

        /* 수동 · 모터가 하는 중 · 알람 · 초기화(I) 중 → 못 받음 */
        if (manual || Motor_Request(m) == 0)
        {
            cmd_answer(PC_num, NAK, "can_not_command");
            break;
        }

        cmd_answer(PC_num, ACK, s);                                             /* 받았다 */
        Log_Debug(LOG_MOVE, s[0], s[1], m.rack, m.col, m.dan);                  /* 로그 : MI  rack 1  Block 2  floor 3  Move */
        break;

    /* 상태 조회 : 렉 수(rack_channel)만큼 S_1_W&S_2_A_03&S_3_W … + 만재 F_1_0001&F_2_0000 */
    case CMD_C:
    {
        char st[80];                                /* 렉 상태 (status.c) */
        char mj[24];                                /* 만재 (manjae.c) */
        char tx[110];

        Log_Debug(LOG_CHECK_PC);
        Status_Text(st, sizeof(st));
        Manjae_Text(mj, sizeof(mj));
        snprintf(tx, sizeof(tx), "%s&%s", st, mj);
        cmd_answer(PC_num, ACK, tx);
        break;
    }

    /* 일시정지 : S_1 → 모든 렉 멈춤 표시 (이유 M 사용자). MI 도착 · PO 정지선에서 섬, HMI RUN 으로 풂 */
    case CMD_S:

        if (strcmp(s, "S_1") != 0)
        {
            cmd_answer(PC_num, NAK, "bad_data");
            break;
        }

        Pause_Set(0, 'M');          /* 일시정지 : 모든 렉, 이유 사용자 (+ 부저 · 로그) */
        Log_Debug(LOG_PAUSE_PC);    /* PC S 로 멈춤 */
        cmd_answer(PC_num, ACK, s);
        break;

    /* 억지로 풀기 : D → 만재(F) · 틸트(T) 로 멈춘 것만 이어서 진행 (센서가 만재여도) */
    case CMD_D:

        if (strcmp(s, "D") != 0)
        {
            cmd_answer(PC_num, NAK, "bad_data");
            break;
        }

        if (pause_why == 'F'|| pause_why == 'T')
            Pause_Clear();          /* 만재 · 틸트로 멈춘 것만 풀기 (+ 부저 끔 · 로그) */
        cmd_answer(PC_num, ACK, s);
        break;

    /* 원점 : I → 확인 → 모터 문 run.c Motor_Request (실행은 motor_basic_init) */
    case CMD_I:

        if (strcmp(s, "I") != 0)
        {
            cmd_answer(PC_num, NAK, "bad_data");
            break;
        }

        /* 수동 · 모터가 하는 중 (원점 중 · 동작 중 · 일시정지) · 알람 → 못 받음 */
        m.cmd = CMD_I;
        if (manual || Motor_Request(m) == 0)
        {
            cmd_answer(PC_num, NAK, "can_not_command");
            break;
        }

        cmd_answer(PC_num, ACK, s);                         /* 받았다 */
        break;

    /* 램프 : 01LL_렉_램프_모드시간&L_렉_램프_모드시간… (램프 1 적 2 녹 3 황, 모드 0 끔 1 켬 2 깜빡, 시간 '0'~'l' = 0~60초, 0 = 계속) */
    case CMD_LAMP:
        if (Lamp_Cmd(s)) cmd_answer(PC_num, ACK, s);        /* 풀기 · 확인 · 켜기 (lamp.c) */
        else             cmd_answer(PC_num, NAK, "bad_data");
        break;

    /* 카드 조회 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 (글자는 rfid.c) */
    case CMD_RFID:
    {
        char card[48];

        Log_Debug(LOG_RFID_PC);
        Rfid_Text(card, sizeof(card));
        cmd_answer(PC_num, ACK, card);
        break;
    }

    /* 부저 : 01B_렉_켜기(1) / 끄기(0) (buzzer.c) */
    case CMD_BUZZER:
        if (Buzzer_Cmd(s)) cmd_answer(PC_num, ACK, s);
        else               cmd_answer(PC_num, NAK, "bad_data");
        break;

    /* 거래처 기본 설정 : ALL_거래처 → FS + FP 를 그 거래처 값으로 한 번에 저장 (값은 save.c Setting_Default_거래처)
       거래처 추가 : 아래 if 줄을 복사해서 글자와 함수 이름만 바꿈 */
    case CMD_ALL:
        if (strcmp(s, "ALL_PIMZ") == 0 && Setting_Default_PIMZ()) { cmd_answer(PC_num, ACK, s); break; }   /* 거래처 PIMZ */

        cmd_answer(PC_num, NAK, "bad_data");                /* 모르는 거래처 · FRAM 저장 실패 */
        break;

    default:
        cmd_answer(PC_num, NAK, "bad_command");
        break;
    }
}
