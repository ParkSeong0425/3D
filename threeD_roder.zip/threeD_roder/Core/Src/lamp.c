/*
 * lamp.c  : 램프 2개
 * OUT 1~4 : 1렉
 * OUT 5~8 : 2렉
 */
#include "lamp.h"
#include "event.h"
#include "status.h"
#include "manjae.h"
#include "net.h"
#include "rfid.h"
#include "run.h"
#include "save.h"
#include "cmsis_os2.h"
#include <stdio.h>
#include <string.h>

#define FAST_MS     125     /* 긴급정지 : 125ms 켬 / 125ms 끔 (총 250) */
#define SLOW_MS     250     /* 원점, 일시정지, 만재, 카드 없음 : 250ms 켬 / 250ms 끔 (총 500) */

/* 램프 하나 : LAMP_ON = 켬, LAMP_OFF = 끔 (렉1 = 오른쪽, 렉2 = 왼쪽) */
static void Lamp_R1(int on) { HAL_GPIO_WritePin(R_1_GPIO_Port, R_1_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
static void Lamp_Y1(int on) { HAL_GPIO_WritePin(Y_1_GPIO_Port, Y_1_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
static void Lamp_G1(int on) { HAL_GPIO_WritePin(G_1_GPIO_Port, G_1_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
static void Lamp_R2(int on) { HAL_GPIO_WritePin(R_2_GPIO_Port, R_2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
static void Lamp_Y2(int on) { HAL_GPIO_WritePin(Y_2_GPIO_Port, Y_2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
static void Lamp_G2(int on) { HAL_GPIO_WritePin(G_2_GPIO_Port, G_2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }

/* 깜빡 : 시간으로 켬/끔을 정한다 → 렉1, 렉2 가 항상 같은 박자 */
static int blink(uint32_t ms)
{
    if ((osKernelGetTickCount() / ms) % 2 == 0)
        return LAMP_ON;
    return LAMP_OFF;
}

/* R 빠르게 깜빡 (앞에서 정한 R 을 덮어씀) : 긴급정지 · 알람 = 두 램프 (PC 연결 중에도) / 일시정지 = 멈춘 렉 램프만 (PC 연결 중엔 PC 가)
   (PO 가 그 렉에서 만재 F · 카드 S · 틸트 T 로 멈추면 그 렉, STOP M 은 모든 렉이 P 라 두 램프. 홀수 렉 = 램프1, 짝수 = 램프2) */
void lamp_alarm(void)
{
    int all = Motor_Stop();                                                          /* 긴급정지 · 알람 = 두 램프 */
    int pause = (tcp_on == 0 && state.now == 'S');                               /* 멈춤 램프는 PC(2500) 안 연결일 때만 */

    if (all || (pause && (state.why == 'M' || state.rack % 2 == 1))) Lamp_R1(blink(FAST_MS));    /* 모두(일시정지 M) · 렉 1 · 3 */
    if (all || (pause && (state.why == 'M' || state.rack % 2 == 0))) Lamp_R2(blink(FAST_MS));    /* 모두(일시정지 M) · 렉 2 · 4 */
}

/* 원점 중 : 6개 전부 느리게 깜빡 (맨 끝에 불러서 다른 램프를 다 덮어씀)
   원점 전(RESET 뒤 · 켜자마자 RUN 기다림)은 평소 램프 → 정말 원점 갈 때만 깜빡 */
void lamp_home(void)
{
    if (state.now == 'H') {
        int on = blink(SLOW_MS);
        Lamp_R1(on); Lamp_Y1(on); Lamp_G1(on);
        Lamp_R2(on); Lamp_Y2(on); Lamp_G2(on);
    }
}

/* 카드 : Y 담당 / 있으면 Y 켬, 없으면 끔 */
static void lamp_rfid(void)
{
    if (card_on(1)) Lamp_Y1(LAMP_ON);
    else            Lamp_Y1(LAMP_OFF);

    if (card_on(2)) Lamp_Y2(LAMP_ON);
    else            Lamp_Y2(LAMP_OFF);
}

/* 만재 : 알림 중인 렉의 R 느리게 깜빡 (렉1 · 렉2 : 1 = 알림 중, event.c 가 정함). PC 연결 중엔 PC 가 */
void lamp_manjae(int rack1, int rack2)
{
    if (tcp_on) return;                     /* PC(2500) 연결 중 */
    if (rack1) Lamp_R1(blink(SLOW_MS));     /* 렉1 */
    if (rack2) Lamp_R2(blink(SLOW_MS));     /* 렉2 */
}

/* PC 램프 명령 : [렉][색] 색 1 적, 2 녹, 3 황 */
static uint8_t tcp_mode[2][3];      /* 0 끔, 1 켬, 2 깜빡 (0~2 뿐이라 1바이트) */
static uint32_t tcp_end[2][3];      /* 끝나는 시각, 0 = 계속 */

/* PC 램프 명령 저장 : 렉 1~2, 색 1~3, 모드 0~2, 시간 초 (0 = 계속) */
static void Lamp_Tcp(int rack, int color, int mode, int sec)
{
    tcp_mode[rack - 1][color - 1] = mode;

    if (sec > 0) tcp_end[rack - 1][color - 1] = osKernelGetTickCount() + sec * 1000;
    else         tcp_end[rack - 1][color - 1] = 0;
}

/* PC 램프 기억 전부 지우기 (net.c : PC 접속 순간) → 다시 연결하면 꺼진 상태에서 PC 가 LL 로 새로 정함 */
void Lamp_Clear(void)
{
    memset(tcp_mode, 0, sizeof(tcp_mode));
    memset(tcp_end, 0, sizeof(tcp_end));
}

/* PC 램프 명령 (cmd.c 가 부름) : LL_렉_램프_모드시간&L_렉_램프_모드시간…
   렉(컨트롤러 ID) 한 글자 '1'~':' (1~10), 램프 한 글자 '1' 적 '2' 녹 '3' 황, 모드 '0' 끔 '1' 켬 '2' 깜빡, 시간 '0'~'l' = 0~60초 ('0' = 계속)
   홀수 렉 = 램프1, 짝수 = 램프2. 맞으면 1 / 하나라도 틀리면 0 (앞 묶음은 이미 켜짐) */
int Lamp_Cmd(char *s)
{
    char *p = s + 1;                        /* 첫 L 건너뜀 → "L_1_1_25&L_1_2_31" */
    char rack, color, mode, sec;            /* 전부 한 글자 ('0' 을 빼면 숫자 : ':' − '0' = 10) */

    for (;;) {                                                                      /* 묶음 하나씩 */
        if (sscanf(p, "L_%c_%c_%c%c", &rack, &color, &mode, &sec) != 4) return 0;   /* 못 읽음 */
        if (rack < '1' || rack - '0' > save.fs.rack_channel || color < '1' || color > '3' ||
            mode < '0' || mode > '2' || sec < '0' || sec > 'l') return 0;           /* 범위 밖 */
        Lamp_Tcp((rack - '0') % 2 == 1 ? 1 : 2, color - '0', mode - '0', sec - '0');
        p = strchr(p, '&');                 /* 다음 & */
        if (p == NULL) return 1;            /* 더 없음 → 다 맞음 */
        p++;
    }
}

/* PC 가 정한 램프 하나 : 시간 지나면 끔 */
static int tcp_lamp(int r, int c)
{
    if (tcp_end[r][c] != 0 && osKernelGetTickCount() - tcp_end[r][c] < 0x80000000) {
        tcp_mode[r][c] = 0;         /* 시간 끝 */
        tcp_end[r][c] = 0;
    }

    if (tcp_mode[r][c] == 1) return LAMP_ON;
    if (tcp_mode[r][c] == 2) return blink(SLOW_MS);
    return LAMP_OFF;
}

/* 평소 램프 : PC(2500) 연결 = 6개 전부 PC 가 정한 대로 (LL, 연결 순간 전부 끔) / 안 연결 = R · G 끔, Y 는 끊긴 지 2초 뒤 카드로
   노트북 서비스(58080) · 로그(50001) 연결은 램프와 상관없음 */
void lamp_tcp(void)
{
    static uint32_t tcp_last;               /* 마지막으로 PC 가 연결돼 있던 시각 */

    if (tcp_on) {
        tcp_last = osKernelGetTickCount();
        Lamp_R1(tcp_lamp(0, 0)); Lamp_G1(tcp_lamp(0, 1)); Lamp_Y1(tcp_lamp(0, 2));
        Lamp_R2(tcp_lamp(1, 0)); Lamp_G2(tcp_lamp(1, 1)); Lamp_Y2(tcp_lamp(1, 2));
        return;
    }

    Lamp_R1(LAMP_OFF); Lamp_G1(LAMP_OFF);
    Lamp_R2(LAMP_OFF); Lamp_G2(LAMP_OFF);
    if (osKernelGetTickCount() - tcp_last >= 2000) lamp_rfid();     /* 끊긴 지 2초 뒤 : Y = 카드 */
}
