/*
 * lamp.c  : 램프 2개
 * OUT 1~4 : 1렉
 * OUT 5!8 : 2렉
 */
#include "lamp.h"
#include "cli.h"
#include "event.h"
#include "status.h"
#include "manjae.h"
#include "net.h"
#include "rfid.h"
#include "run.h"
#include "cmsis_os2.h"
#include <stdio.h>
#include <string.h>

#define FAST_MS     125     /* 긴급정지 : 125ms 켬 / 125ms 끔 (총 250) */
#define SLOW_MS     250     /* 원점, 일시정지, 만재, 카드 없음 : 250ms 켬 / 250ms 끔 (총 500) */

/* 램프 하나 : LAMP_ON = 켬, LAMP_OFF = 끔 (렉1 = 오른쪽, 렉2 = 왼쪽) */
void Lamp_R1(int on) { HAL_GPIO_WritePin(R_1_GPIO_Port, R_1_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_Y1(int on) { HAL_GPIO_WritePin(Y_1_GPIO_Port, Y_1_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_G1(int on) { HAL_GPIO_WritePin(G_1_GPIO_Port, G_1_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_R2(int on) { HAL_GPIO_WritePin(R_2_GPIO_Port, R_2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_Y2(int on) { HAL_GPIO_WritePin(Y_2_GPIO_Port, Y_2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_G2(int on) { HAL_GPIO_WritePin(G_2_GPIO_Port, G_2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }

/* 깜빡 : 시간으로 켬/끔을 정한다 → 렉1, 렉2 가 항상 같은 박자 */
static int blink(uint32_t ms)
{
    if ((osKernelGetTickCount() / ms) % 2 == 0)
        return LAMP_ON;
    return LAMP_OFF;
}

/* 긴급정지 / 알람 / 원점 / 일시정지 : 전부 같이 깜빡 → 1 (나머지 램프 일 안 함) */
int lamp_alarm_home(void)
{
    int on;

    /* 긴급정지 / 알람 (긴급정지 풀린 뒤 RUN 전까지) : 빠르게 */
    if (estop == 1 || status_1 == ALARM || status_2 == ALARM || status_3 == ALARM || status_4 == ALARM)
        on = blink(FAST_MS);

    /* 원점 중 / 일시정지 : 느리게 */
    else if (status_1 == HOME  || status_2 == HOME  || status_3 == HOME  || status_4 == HOME ||
             status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE)
        on = blink(SLOW_MS);

    else
        return 0;

    Lamp_R1(on); Lamp_Y1(on); Lamp_G1(on);
    Lamp_R2(on); Lamp_Y2(on); Lamp_G2(on);
    return 1;
}

/* 카드 : Y 담당 / 있으면 Y 켬, 없으면 끔 */
void lamp_rfid(void)
{
    if (card_ok_1 == 1) Lamp_R1(LAMP_ON);
    else                Lamp_R1(LAMP_OFF);

    if (card_ok_2 == 1) Lamp_R2(LAMP_ON);
    else                Lamp_R2(LAMP_OFF);
}

/* 만재 / 카드 없음 : R 깜빡 (끄는 건 부르는 쪽에서) */
void lamp_manjae(void)
{
    if (manjae_on(1, 1) || manjae_on(1, 2) || manjae_on(1, 3) || manjae_on(1, 4) || card_ok_1 == 0) {   /* 렉1 만재 · 카드 없음 */
        Lamp_Y1(blink(SLOW_MS));
    }
    else {
        Lamp_Y1(LAMP_OFF);
    }

    if (manjae_on(2, 1) || manjae_on(2, 2) || manjae_on(2, 3) || manjae_on(2, 4) || card_ok_2 == 0) {   /* 렉2 만재 · 카드 없음 */
        Lamp_Y2(blink(SLOW_MS));
    }
    else {
        Lamp_Y2(LAMP_OFF);
    }
}

/* PC 램프 명령 : [렉][색] 색 1 적, 2 녹, 3 황 */
static int tcp_mode[2][3];          /* 0 끔, 1 켬, 2 깜빡 */
static uint32_t tcp_end[2][3];      /* 끝나는 시각, 0 = 계속 */

/* PC 램프 명령 저장 : 렉 1~2, 색 1~3, 모드 0~2, 시간 초 (0 = 계속) */
void Lamp_Tcp(int rack, int color, int mode, int sec)
{
    tcp_mode[rack - 1][color - 1] = mode;

    if (sec > 0) tcp_end[rack - 1][color - 1] = osKernelGetTickCount() + sec * 1000;
    else         tcp_end[rack - 1][color - 1] = 0;
}

/* PC 가 정한 램프 하나 : 시간 지나면 끔 */
static int tcp_lamp(int r, int c)
{
    if (tcp_end[r][c] != 0 && osKernelGetTickCount() - tcp_end[r][c] < 0x80000000) {
        tcp_mode[r][c] = 0;         /* 시간 끝 */
        tcp_end[r][c] = 0;
    }

    if (tcp_mode[r][c] == 1) return LAMP_ON;
    if (tcp_mode[r][c] == 2) return blink(SLOW_MS);
    return LAMP_OFF;
}

/* PC 명령 받은 뒤 : 6개 전부 PC 가 정한 대로 */
void lamp_tcp(void)
{
    Lamp_R1(tcp_lamp(0, 0)); Lamp_G1(tcp_lamp(0, 1)); Lamp_Y1(tcp_lamp(0, 2));
    Lamp_R2(tcp_lamp(1, 0)); Lamp_G2(tcp_lamp(1, 1)); Lamp_Y2(tcp_lamp(1, 2));
}
