/*
 * lamp.c  : 램프 2개
 * OUT 1~4 : 1렉
 * OUT 5!8 : 2렉
 */
#include "lamp.h"
#include "cli.h"
#include "event.h"
#include "status.h"
#include "manjae.h"
#include "net.h"
#include "rfid.h"
#include "run.h"
#include "save.h"
#include "cmsis_os2.h"
#include <stdio.h>
#include <string.h>

#define FAST_MS     125     /* 긴급정지 : 125ms 켬 / 125ms 끔 (총 250) */
#define SLOW_MS     250     /* 원점, 일시정지, 만재, 카드 없음 : 250ms 켬 / 250ms 끔 (총 500) */

/* 램프 하나 : LAMP_ON = 켬, LAMP_OFF = 끔 (렉1 = 오른쪽, 렉2 = 왼쪽) */
void Lamp_R1(int on) { HAL_GPIO_WritePin(R_1_GPIO_Port, R_1_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_Y1(int on) { HAL_GPIO_WritePin(Y_1_GPIO_Port, Y_1_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_G1(int on) { HAL_GPIO_WritePin(G_1_GPIO_Port, G_1_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_R2(int on) { HAL_GPIO_WritePin(R_2_GPIO_Port, R_2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_Y2(int on) { HAL_GPIO_WritePin(Y_2_GPIO_Port, Y_2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }
void Lamp_G2(int on) { HAL_GPIO_WritePin(G_2_GPIO_Port, G_2_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET); }

/* 깜빡 : 시간으로 켬/끔을 정한다 → 렉1, 렉2 가 항상 같은 박자 */
static int blink(uint32_t ms)
{
    if ((osKernelGetTickCount() / ms) % 2 == 0)
        return LAMP_ON;
    return LAMP_OFF;
}

/* 긴급정지 / 알람 / 일시정지 (틸트 T · 만재 F · 시딩월 S · 사용자 M) : R 만 빠르게 깜빡 (앞에서 정한 R 을 덮어씀) */
void lamp_alarm(void)
{
    if (estop == 1 || status_1 == ALARM || status_2 == ALARM || status_3 == ALARM || status_4 == ALARM ||
        status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE) {
        Lamp_R1(blink(FAST_MS));
        Lamp_R2(blink(FAST_MS));
    }
}

/* 원점 중 : 6개 전부 느리게 깜빡 (맨 끝에 불러서 다른 램프를 다 덮어씀) */
void lamp_home(void)
{
    if (status_1 == HOME || status_2 == HOME || status_3 == HOME || status_4 == HOME) {
        int on = blink(SLOW_MS);
        Lamp_R1(on); Lamp_Y1(on); Lamp_G1(on);
        Lamp_R2(on); Lamp_Y2(on); Lamp_G2(on);
    }
}

/* 카드 : Y 담당 / 있으면 Y 켬, 없으면 끔 */
void lamp_rfid(void)
{
    if (card_ok_1 == 1) Lamp_Y1(LAMP_ON);
    else                Lamp_Y1(LAMP_OFF);

    if (card_ok_2 == 1) Lamp_Y2(LAMP_ON);
    else                Lamp_Y2(LAMP_OFF);
}

/* 만재 / 카드 없음 : R 깜빡 — 만재 센서가 바뀐 뒤 2초 동안은 기다림 (스침이면 안 켜짐) */
void lamp_manjae(void)
{
    if (osTimerIsRunning(Manjae_TimerHandle)) return;      /* 바뀐 지 2초 안 : R 은 앞에서 정한 대로 */

    if (manjae_on(1, 1) || manjae_on(1, 2) || manjae_on(1, 3) || manjae_on(1, 4) || card_ok_1 == 0) {   /* 렉1 만재 · 카드 없음 */
        Lamp_R1(blink(SLOW_MS));
    }
    else {
        Lamp_R1(LAMP_OFF);
    }

    if (manjae_on(2, 1) || manjae_on(2, 2) || manjae_on(2, 3) || manjae_on(2, 4) || card_ok_2 == 0) {   /* 렉2 만재 · 카드 없음 */
        Lamp_R2(blink(SLOW_MS));
    }
    else {
        Lamp_R2(LAMP_OFF);
    }
}

/* PC 램프 명령 : [렉][색] 색 1 적, 2 녹, 3 황 */
static int tcp_mode[2][3];          /* 0 끔, 1 켬, 2 깜빡 */
static uint32_t tcp_end[2][3];      /* 끝나는 시각, 0 = 계속 */

/* PC 램프 명령 저장 : 렉 1~2, 색 1~3, 모드 0~2, 시간 초 (0 = 계속) */
void Lamp_Tcp(int rack, int color, int mode, int sec)
{
    tcp_mode[rack - 1][color - 1] = mode;

    if (sec > 0) tcp_end[rack - 1][color - 1] = osKernelGetTickCount() + sec * 1000;
    else         tcp_end[rack - 1][color - 1] = 0;
}

/* PC 램프 명령 (cmd.c 가 부름) : LL_렉_램프_모드시간&L_렉_램프_모드시간…
   램프 1 적 2 녹 3 황, 모드 '0' 끔 '1' 켬 '2' 깜빡, 시간 '0'~'l' = 0~60초 ('0' = 계속), 홀수 렉 = 램프1, 짝수 = 램프2
   맞으면 1 / 하나라도 틀리면 0 (앞 묶음은 이미 켜짐) */
int Lamp_Cmd(char *s)
{
    char *p = s + 1;                        /* 첫 L 건너뜀 → "L_1_1_25&L_1_2_31" */
    int rack, color;
    char mode, sec;

    if (sscanf(p, "L_%d_%d_%c%c", &rack, &color, &mode, &sec) != 4) return 0;     /* 하나도 못 읽음 */

    while (sscanf(p, "L_%d_%d_%c%c", &rack, &color, &mode, &sec) == 4) {        /* 하나씩 */
        if (rack < 1 || rack > save.fs.rack_channel || color < 1 || color > 3 ||
            mode < '0' || mode > '2' || sec < '0' || sec > 'l') return 0;
        Lamp_Tcp(rack % 2 == 1 ? 1 : 2, color, mode - '0', sec - '0');
        p = strchr(p, '&');                 /* 다음 & */
        if (p == NULL) break;
        p++;
    }
    return 1;
}

/* PC 가 정한 램프 하나 : 시간 지나면 끔 */
static int tcp_lamp(int r, int c)
{
    if (tcp_end[r][c] != 0 && osKernelGetTickCount() - tcp_end[r][c] < 0x80000000) {
        tcp_mode[r][c] = 0;         /* 시간 끝 */
        tcp_end[r][c] = 0;
    }

    if (tcp_mode[r][c] == 1) return LAMP_ON;
    if (tcp_mode[r][c] == 2) return blink(SLOW_MS);
    return LAMP_OFF;
}

/* 평소 램프 : PC 연결 = 6개 전부 PC 가 정한 대로 (LL) / 안 연결 = R · G 끔, Y 는 끊긴 지 2초 뒤 카드로 */
void lamp_tcp(void)
{
    static uint32_t tcp_last;               /* 마지막으로 PC 가 연결돼 있던 시각 */

    if (tcp_on == 1) {
        tcp_last = osKernelGetTickCount();
        Lamp_R1(tcp_lamp(0, 0)); Lamp_G1(tcp_lamp(0, 1)); Lamp_Y1(tcp_lamp(0, 2));
        Lamp_R2(tcp_lamp(1, 0)); Lamp_G2(tcp_lamp(1, 1)); Lamp_Y2(tcp_lamp(1, 2));
        return;
    }

    Lamp_R1(LAMP_OFF); Lamp_G1(LAMP_OFF);
    Lamp_R2(LAMP_OFF); Lamp_G2(LAMP_OFF);
    if (osKernelGetTickCount() - tcp_last >= 2000) lamp_rfid();     /* 끊긴 지 2초 뒤 : Y = 카드 */
}
