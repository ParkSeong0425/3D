/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "run.h"
#include "cli.h"
#include "net.h"
#include "fram.h"
#include "event.h"
#include "save.h"
#include "status.h"
#include "manjae.h"
#include "hmi.h"
#include "cmd.h"
#include "dwt.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
osMutexId_t Uart2LockHandle;    /* UART2 모터 버스 : 한 번에 한 태스크만 */
/* USER CODE END Variables */
/* Definitions for Event_Task */
osThreadId_t Event_TaskHandle;
const osThreadAttr_t Event_Task_attributes = {
  .name = "Event_Task",
  .priority = (osPriority_t) osPriorityHigh,
  .stack_size = 512 * 4
};
/* Definitions for Motor_Task */
osThreadId_t Motor_TaskHandle;
const osThreadAttr_t Motor_Task_attributes = {
  .name = "Motor_Task",
  .priority = (osPriority_t) osPriorityAboveNormal,
  .stack_size = 512 * 4
};
/* Definitions for Comm_Task */
osThreadId_t Comm_TaskHandle;
const osThreadAttr_t Comm_Task_attributes = {
  .name = "Comm_Task",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 1024 * 4
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void Start_Event_Task(void *argument);
void Start_Motor_Task(void *argument);
void Start_Comm_Task(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
  DWT_Init();
  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  Uart2LockHandle = osMutexNew(NULL);
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of Event_Task */
  Event_TaskHandle = osThreadNew(Start_Event_Task, NULL, &Event_Task_attributes);

  /* creation of Motor_Task */
  Motor_TaskHandle = osThreadNew(Start_Motor_Task, NULL, &Motor_Task_attributes);

  /* creation of Comm_Task */
  Comm_TaskHandle = osThreadNew(Start_Comm_Task, NULL, &Comm_Task_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_Start_Event_Task */
/**
  * @brief  Function implementing the Event_Task thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_Start_Event_Task */
void Start_Event_Task(void *argument)
{
  /* USER CODE BEGIN Start_Event_Task */
	Event_Run();
  /* USER CODE END Start_Event_Task */
}

/* USER CODE BEGIN Header_Start_Motor_Task */
/**
* @brief Function implementing the Motor_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Motor_Task */
void Start_Motor_Task(void *argument)
{
  /* USER CODE BEGIN Start_Motor_Task */
    for (;;)
    {
        osThreadFlagsWait(MOTOR_FLAG, osFlagsWaitAny, osWaitForever);   /* 초인종 올 때까지 잠 (PC 동작 명령 · 원점 요청이 깨움) */
        CMD_Move();      /* 원점 요청 · PC 동작 명령 (MI · MO · PO · I) */
    }

  /* USER CODE END Start_Motor_Task */
}

/* USER CODE BEGIN Header_Start_Comm_Task */
/**
* @brief Function implementing the Comm_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Comm_Task */
void Start_Comm_Task(void *argument)
{
  /* USER CODE BEGIN Start_Comm_Task */

	Save_Init();
	NET_Init();
	Status_HOME();       /* 켜질 때 : 원점부터 (FRAM 읽은 뒤 → Motor_Task 가 함) */
	osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);   /* 초인종 : Motor_Task 깨우기 */

    for (;;)
    {
        CLI_Run();
        NET_Run();       /* PC 명령 받기 : 움직이는 명령은 주문서에 넘기고 바로 돌아옴 */
        CMD_Event();     /* 만재 · 일시정지 · 카드 · 알람 · 완료응답 → PC */

        osDelay(1);
    }

  /* USER CODE END Start_Comm_Task */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

