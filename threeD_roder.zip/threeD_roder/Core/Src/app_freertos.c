/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "run.h"
#include "queue.h"      /* xQueuePeek (Motor_Task : 주문 보기만) */
#include "cli.h"
#include "net.h"
#include "fram.h"
#include "event.h"
#include "save.h"
#include "status.h"
#include "manjae.h"
#include "buzzer.h"
#include "rfid.h"
#include "hmi.h"
#include "cmd.h"
#include "dwt.h"
#include "alarm.h"
#include "flag.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
/* USER CODE END Variables */
/* Definitions for Event_Task */
osThreadId_t Event_TaskHandle;
const osThreadAttr_t Event_Task_attributes = {
  .name = "Event_Task",
  .priority = (osPriority_t) osPriorityHigh,
  .stack_size = 512 * 4
};
/* Definitions for Motor_Task */
osThreadId_t Motor_TaskHandle;
const osThreadAttr_t Motor_Task_attributes = {
  .name = "Motor_Task",
  .priority = (osPriority_t) osPriorityAboveNormal,
  .stack_size = 512 * 4
};
/* Definitions for Comm_Task */
osThreadId_t Comm_TaskHandle;
const osThreadAttr_t Comm_Task_attributes = {
  .name = "Comm_Task",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 1024 * 4
};
/* Definitions for Bus_Task */
osThreadId_t Bus_TaskHandle;
const osThreadAttr_t Bus_Task_attributes = {
  .name = "Bus_Task",
  .priority = (osPriority_t) osPriorityAboveNormal,
  .stack_size = 512 * 4
};
/* Definitions for MoveQueue */
osMessageQueueId_t MoveQueueHandle;
const osMessageQueueAttr_t MoveQueue_attributes = {
  .name = "MoveQueue"
};
/* Definitions for CommQueue */
osMessageQueueId_t CommQueueHandle;
const osMessageQueueAttr_t CommQueue_attributes = {
  .name = "CommQueue"
};
/* Definitions for EventQueue */
osMessageQueueId_t EventQueueHandle;
const osMessageQueueAttr_t EventQueue_attributes = {
  .name = "EventQueue"
};
/* Definitions for BusQueue */
osMessageQueueId_t BusQueueHandle;
const osMessageQueueAttr_t BusQueue_attributes = {
  .name = "BusQueue"
};
/* Definitions for Manjae_Timer */
osTimerId_t Manjae_TimerHandle;
const osTimerAttr_t Manjae_Timer_attributes = {
  .name = "Manjae_Timer"
};
/* Definitions for Rfid_Timer */
osTimerId_t Rfid_TimerHandle;
const osTimerAttr_t Rfid_Timer_attributes = {
  .name = "Rfid_Timer"
};
/* Definitions for Uart2Lock */
osMutexId_t Uart2LockHandle;
const osMutexAttr_t Uart2Lock_attributes = {
  .name = "Uart2Lock"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void Start_Event_Task(void *argument);
void Start_Motor_Task(void *argument);
void Start_Comm_Task(void *argument);
void Start_Bus_Task(void *argument);
void Callback_Manjae_Timer(void *argument);
void Callback_Rfid_Timer(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
  DWT_Init();
  /* USER CODE END Init */
  /* Create the mutex(es) */
  /* creation of Uart2Lock */
  Uart2LockHandle = osMutexNew(&Uart2Lock_attributes);

  /* USER CODE BEGIN RTOS_MUTEX */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* creation of Manjae_Timer */
  Manjae_TimerHandle = osTimerNew(Callback_Manjae_Timer, osTimerOnce, NULL, &Manjae_Timer_attributes);

  /* creation of Rfid_Timer */
  Rfid_TimerHandle = osTimerNew(Callback_Rfid_Timer, osTimerPeriodic, NULL, &Rfid_Timer_attributes);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of MoveQueue */
  MoveQueueHandle = osMessageQueueNew (1, sizeof(MOVE), &MoveQueue_attributes);

  /* creation of CommQueue */
  CommQueueHandle = osMessageQueueNew (8, sizeof(uint8_t), &CommQueue_attributes);

  /* creation of EventQueue */
  EventQueueHandle = osMessageQueueNew (8, sizeof(uint8_t), &EventQueue_attributes);

  /* creation of BusQueue */
  BusQueueHandle = osMessageQueueNew (4, sizeof(uint8_t), &BusQueue_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of Event_Task */
  Event_TaskHandle = osThreadNew(Start_Event_Task, NULL, &Event_Task_attributes);

  /* creation of Motor_Task */
  Motor_TaskHandle = osThreadNew(Start_Motor_Task, NULL, &Motor_Task_attributes);

  /* creation of Comm_Task */
  Comm_TaskHandle = osThreadNew(Start_Comm_Task, NULL, &Comm_Task_attributes);

  /* creation of Bus_Task */
  Bus_TaskHandle = osThreadNew(Start_Bus_Task, NULL, &Bus_Task_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_Start_Event_Task */
/**
  * @brief  Function implementing the Event_Task thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_Start_Event_Task */
void Start_Event_Task(void *argument)
{
  /* USER CODE BEGIN Start_Event_Task */
	Event_Run();
  /* USER CODE END Start_Event_Task */
}

/* USER CODE BEGIN Header_Start_Motor_Task */
/**
* @brief Function implementing the Motor_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Motor_Task */
void Start_Motor_Task(void *argument)
{
  /* USER CODE BEGIN Start_Motor_Task */
    MOVE task_copy;     /* 큐로 넘어온 주문서 복사본 */

    for (;;)
    {
        xQueuePeek((QueueHandle_t)MoveQueueHandle, &task_copy, portMAX_DELAY);  /* 주문 올 때까지 잠, 보기만 (큐에 남음 = 동작 중) */
        Motor_Run(task_copy);                                                   /* run.c : 원점 / MI · MO · PO */
        osMessageQueueGet(MoveQueueHandle, &task_copy, NULL, 0);                /* 끝 → 꺼냄 (큐 빔 = 다음 주문 받음) */
    }

  /* USER CODE END Start_Motor_Task */
}

/* USER CODE BEGIN Header_Start_Comm_Task */
/**
* @brief Function implementing the Comm_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Comm_Task */
void Start_Comm_Task(void *argument)
{
  /* USER CODE BEGIN Start_Comm_Task */

	MOVE home = { CMD_I };                            /* 원점 주문 (나머지 칸 0) */

	Save_Init();
	NET_Init();
	Motor_Request(home);                              /* 켜질 때 : 원점 (FRAM 읽은 뒤, run.c 모터 문) */

    uint8_t task_copy;     /* 큐로 넘어온 주문서 복사본 (무엇 : F 만재 · U 카드 · P 일시정지 · A 알람 · N W6100) */

    for (;;)
    {
        if (osMessageQueueGet(CommQueueHandle, &task_copy, NULL, 1) == osOK)   /* 주문 오면 바로, 안 와도 1ms 뒤 (CLI · 20초 시계 · 완료응답 보러) */
            CMD_Event(task_copy);                                                 /* 무엇이면 그 파일 함수로 PC 에 (cmd.c) */
        CLI_Run();             /* UART1 CLI (cli.c) */
        NET_Run();             /* PC 명령 받기 · 2500 · 58080 · 50001 : 움직이는 명령은 run.c Motor_Request 에 넘기고 바로 돌아옴 */
        CMD_Done();            /* 완료응답 AI · AO · EO → PC (cmd.c : ANS_1 승인까지 1초마다) */
    }

  /* USER CODE END Start_Comm_Task */
}

/* USER CODE BEGIN Header_Start_Bus_Task */
/**
* @brief Function implementing the Bus_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Bus_Task */
void Start_Bus_Task(void *argument)
{
  /* USER CODE BEGIN Start_Bus_Task */
    /* 모터 선(UART2) 확인 담당 (11/16 시작) : 지금은 드라이브 알람 확인만 (전엔 Event_Task 가 함)
       위치 · 이동 명령은 다음 단계에 옮김 → 다 옮기면 열쇠(Uart2Lock) 삭제 */
    for (;;)
    {
        osDelay(20);            /* 20ms 한 바퀴 (Event_Task 와 같은 박자) */
        Alarm_Drive();          /* 드라이브 알람 02 ~ 04 · 통신 11 : 1초마다 (alarm.c) */
    }
  /* USER CODE END Start_Bus_Task */
}

/* Callback_Manjae_Timer function */
void Callback_Manjae_Timer(void *argument)
{
  /* USER CODE BEGIN Callback_Manjae_Timer */
	Manjae_Timer_2s();      /* 만재 바뀐 뒤 2초 조용 → 확정 · 렉 알림 · 부저 (manjae.c) */
  /* USER CODE END Callback_Manjae_Timer */
}

/* Callback_Rfid_Timer function */
void Callback_Rfid_Timer(void *argument)
{
  /* USER CODE BEGIN Callback_Rfid_Timer */
	Rfid_Check();
  /* USER CODE END Callback_Rfid_Timer */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

