/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "run.h"
#include "usart.h"      /* UART4_Start (터치 화면 받기) */
#include "cli.h"
#include "net.h"
#include "fram.h"
#include "event.h"
#include "save.h"
#include "status.h"
#include "manjae.h"
#include "buzzer.h"
#include "rfid.h"
#include "hmi.h"
#include "cmd.h"
#include "dwt.h"
#include "alarm.h"
#include "flag.h"
#include "i_motor.h"    /* IM_Read (Bus_Task 칠판) */
#include "a_motor.h"    /* AM_Read */
#include "t_motor.h"    /* TM_Read */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
/* USER CODE END Variables */
/* Definitions for Event_Task */
osThreadId_t Event_TaskHandle;
const osThreadAttr_t Event_Task_attributes = {
  .name = "Event_Task",
  .priority = (osPriority_t) osPriorityHigh,
  .stack_size = 512 * 4
};
/* Definitions for Motor_Task */
osThreadId_t Motor_TaskHandle;
const osThreadAttr_t Motor_Task_attributes = {
  .name = "Motor_Task",
  .priority = (osPriority_t) osPriorityAboveNormal,
  .stack_size = 512 * 4
};
/* Definitions for Comm_Task */
osThreadId_t Comm_TaskHandle;
const osThreadAttr_t Comm_Task_attributes = {
  .name = "Comm_Task",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 1024 * 4
};
/* Definitions for Bus_Task */
osThreadId_t Bus_TaskHandle;
const osThreadAttr_t Bus_Task_attributes = {
  .name = "Bus_Task",
  .priority = (osPriority_t) osPriorityAboveNormal,
  .stack_size = 512 * 4
};
/* Definitions for MoveQueue */
osMessageQueueId_t MoveQueueHandle;
const osMessageQueueAttr_t MoveQueue_attributes = {
  .name = "MoveQueue"
};
/* Definitions for CommQueue */
osMessageQueueId_t CommQueueHandle;
const osMessageQueueAttr_t CommQueue_attributes = {
  .name = "CommQueue"
};
/* Definitions for EventQueue */
osMessageQueueId_t EventQueueHandle;
const osMessageQueueAttr_t EventQueue_attributes = {
  .name = "EventQueue"
};
/* Definitions for BusQueue */
osMessageQueueId_t BusQueueHandle;
const osMessageQueueAttr_t BusQueue_attributes = {
  .name = "BusQueue"
};
/* Definitions for Manjae_Timer */
osTimerId_t Manjae_TimerHandle;
const osTimerAttr_t Manjae_Timer_attributes = {
  .name = "Manjae_Timer"
};
/* Definitions for Rfid_Timer */
osTimerId_t Rfid_TimerHandle;
const osTimerAttr_t Rfid_Timer_attributes = {
  .name = "Rfid_Timer"
};
/* Definitions for Uart2Lock */
osMutexId_t Uart2LockHandle;
const osMutexAttr_t Uart2Lock_attributes = {
  .name = "Uart2Lock"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void Start_Event_Task(void *argument);
void Start_Motor_Task(void *argument);
void Start_Comm_Task(void *argument);
void Start_Bus_Task(void *argument);
void Callback_Manjae_Timer(void *argument);
void Callback_Rfid_Timer(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
  DWT_Init();
  /* USER CODE END Init */
  /* Create the mutex(es) */
  /* creation of Uart2Lock */
  Uart2LockHandle = osMutexNew(&Uart2Lock_attributes);

  /* USER CODE BEGIN RTOS_MUTEX */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* creation of Manjae_Timer */
  Manjae_TimerHandle = osTimerNew(Callback_Manjae_Timer, osTimerOnce, NULL, &Manjae_Timer_attributes);

  /* creation of Rfid_Timer */
  Rfid_TimerHandle = osTimerNew(Callback_Rfid_Timer, osTimerPeriodic, NULL, &Rfid_Timer_attributes);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of MoveQueue */
  MoveQueueHandle = osMessageQueueNew (1, sizeof(MOVE), &MoveQueue_attributes);

  /* creation of CommQueue */
  CommQueueHandle = osMessageQueueNew (8, sizeof(uint8_t), &CommQueue_attributes);

  /* creation of EventQueue */
  EventQueueHandle = osMessageQueueNew (8, sizeof(uint8_t), &EventQueue_attributes);

  /* creation of BusQueue */
  BusQueueHandle = osMessageQueueNew (4, sizeof(uint8_t), &BusQueue_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of Event_Task */
  Event_TaskHandle = osThreadNew(Start_Event_Task, NULL, &Event_Task_attributes);

  /* creation of Motor_Task */
  Motor_TaskHandle = osThreadNew(Start_Motor_Task, NULL, &Motor_Task_attributes);

  /* creation of Comm_Task */
  Comm_TaskHandle = osThreadNew(Start_Comm_Task, NULL, &Comm_Task_attributes);

  /* creation of Bus_Task */
  Bus_TaskHandle = osThreadNew(Start_Bus_Task, NULL, &Bus_Task_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_Start_Event_Task */
/**
  * @brief  Function implementing the Event_Task thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_Start_Event_Task */
void Start_Event_Task(void *argument)
{
  /* USER CODE BEGIN Start_Event_Task */
    /* ── 스위치판 : [기능] 줄을 주석 처리하면 그 기능이 통째로 꺼짐 (사무실 : 리더 · 화면 · 만재 없음) ── */
    Rfid_Init();            /* [기능] 카드 리더 (CAN 켜기 · 0.5초 묻기). 끄면 카드 늘 "있음" */
    UART4_Start();          /*        터치 화면 받기 시작 */
    for (;;)
    {
        Event_Wait();       /* 주문 오면 바로, 없어도 20ms (버튼 · 긴급정지 · 만재가 깨움) */
        estop_event();      /* [기능] 긴급정지 */
        manjae_change();    /* [기능] 만재 센서 → PC FF · 2초 알림 */
        hmi_event();        /*        터치 버튼 (받은 버튼 처리 · X JOG 다시 쓰기) */
        A_01();             /*        터치 끊김 알람 (화면 끄면 안 물어서 저절로 안 걸림) */
        HMI_Send();         /* [기능] 터치 화면 (20ms 마다 물음). 끄면 버튼 · 화면 없음 */
        lamp_event();       /* [기능] 램프 */
    }
  /* USER CODE END Start_Event_Task */
}

/* USER CODE BEGIN Header_Start_Motor_Task */
/**
* @brief Function implementing the Motor_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Motor_Task */
void Start_Motor_Task(void *argument)
{
  /* USER CODE BEGIN Start_Motor_Task */
    for (;;)
    {
        Motor_Run();        /* 주문 올 때까지 잠 → 하나 실행 (원점 / MI · MO · PO) → 꺼냄 (run.c) */
    }
  /* USER CODE END Start_Motor_Task */
}

/* USER CODE BEGIN Header_Start_Comm_Task */
/**
* @brief Function implementing the Comm_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Comm_Task */
void Start_Comm_Task(void *argument)
{
  /* USER CODE BEGIN Start_Comm_Task */
    Save_Init();            /*        FRAM 읽기 (설정 · 좌표) — 맨 먼저 */
    NET_Init();             /* [기능] PC 이더넷 켜기 */
    btn_run();              /*        켤 때 = 시작 버튼 누른 것처럼 → 원점 (FRAM 읽은 뒤라 여기) */
    for (;;)
    {
        CMD_Event();        /*        PC 알림 주문 기다림 (오면 바로, 없어도 1ms) → FF · UT · PPAUSE · 알람 보냄 */
        CLI_Run();          /* [기능] 노트북 CLI (UART1) */
        NET_Run();          /* [기능] PC 명령 받기 (2500 · 58080 · 50001) */
        CMD_Done();         /*        완료응답 AI · AO · EO (ANS_1 승인까지 1초마다) */
    }
  /* USER CODE END Start_Comm_Task */
}

/* USER CODE BEGIN Header_Start_Bus_Task */
/**
* @brief Function implementing the Bus_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Bus_Task */
void Start_Bus_Task(void *argument)
{
  /* USER CODE BEGIN Start_Bus_Task */
    /* 모터 선(UART2) 담당 (11/17) : 40ms 마다 4대에게 한 번씩 물어 칠판에 적음
       ── 칠판 지도 (고칠 때 볼 곳) ──
         모양 · 숫자    usart.h  MOTOR (pos · state · alarm · miss) · BUS_MS 40 · BUS_RX_MS 5
         적는 곳        i_motor.c IM_Read (X1 · X2 → im1 · im2) / a_motor.c AM_Read (Y → am) / t_motor.c TM_Read (틸트 → tm)
         보는 곳        도착 IM_Arrive · IM_Pass · AM_Arrive · TM_Arrive / X 출발 기울기 IM_MoveSoft / 원점 전 거리 IM_Home · AM_Home
                        run.c MI (MI → MI 판단) · move_done (끝 위치 로그)
                        알람 alarm.c Alarm_Drive (놓침 3번 → 05 ~ 07 · 4대 다 11 · X 차이 50mm 05 · 드라이브 알람 02 ~ 04)
         알람 숫자      alarm.h BUS_MISS 3 · X_SKEW_MM 50 [현장]
       남은 단계 : C = 이동 · JOG · 멈춤 명령도 여기로 → 열쇠(Uart2Lock) · UART2_Send 삭제 */
    uint32_t tick = osKernelGetTickCount();     /* 다음에 깰 시각 */
    for (;;)
    {
        tick += BUS_MS;
        osDelayUntil(tick); /*        40ms 눈금마다 깸 (일한 시간과 상관없이 늘 40ms, usart.h BUS_MS) */
        IM_Read();          /*        X1 · X2 → 칠판 im1 · im2 */
        AM_Read();          /*        Y → 칠판 am */
        TM_Read();          /*        틸트 → 칠판 tm */
        Alarm_Drive();      /* [기능] 드라이브 알람 02 ~ 04 · 모터 통신 11 (1초마다, alarm.c) */
    }
  /* USER CODE END Start_Bus_Task */
}

/* Callback_Manjae_Timer function */
void Callback_Manjae_Timer(void *argument)
{
  /* USER CODE BEGIN Callback_Manjae_Timer */
	Manjae_Timer_2s();      /* 만재 바뀐 뒤 2초 조용 → 확정 · 렉 알림 · 부저 (manjae.c) */
  /* USER CODE END Callback_Manjae_Timer */
}

/* Callback_Rfid_Timer function */
void Callback_Rfid_Timer(void *argument)
{
  /* USER CODE BEGIN Callback_Rfid_Timer */
	Rfid_Check();
  /* USER CODE END Callback_Rfid_Timer */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

