#include "run.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "event.h"
#include "cli.h"
#include "cmsis_os2.h"
#include "status.h"
#include "cmd.h"
#include "alarm.h"
#include "manjae.h"
#include "rfid.h"

#define AXIS_WAIT    300    /* 축 사이 간격 */
#define INIT_RETRY   3      /* 초기화 재시도 횟수 */
#define GAP          10     /* 도착 판정 오차 : X,Y는 mm */
#define TILT_GAP     2      /* 도착 판정 오차 : TILT는 도 */

static int x_ok;
static int y_ok;
static int t_ok;

/* 드라이브가 깨어날 때까지 기다린 뒤 실패한 축만 다시 시도 */
int motor_basic_init(void)
{
    for (int n = 1; n <= INIT_RETRY; n++) {
        if (x_ok == 0) x_ok = IM_MapInit();
        osDelay(AXIS_WAIT);

        if (y_ok == 0) y_ok = AM_Init();
        osDelay(AXIS_WAIT);

        if (t_ok == 0) t_ok = TM_Init();
        osDelay(AXIS_WAIT);

        if (x_ok && y_ok && t_ok) break;
    }

    /* 한 축이라도 실패하면 원점복귀 안 함 (응답 없는 축에서 멈추지 않게) */
    if (x_ok == 0 || y_ok == 0 || t_ok == 0) return 0;

    return I();
}

/* 기본 모터 시험 (CLI X Y C R L) : 명령만 보냄 (도착은 안 기다림) */
int motor_basic_run(int command, int32_t pulse, int deg , int rpm)
{
    if      (command == 'X') return IM_Move(pulse, rpm);
    else if (command == 'Y') return AM_Move(pulse, rpm);
    else if (command == 'C') return TM_C(rpm);
    else if (command == 'R') return TM_R(deg, rpm);
    else if (command == 'L') return TM_L(deg, rpm);
    return 0;
}

/* X, Y 도착 대기 : 위치를 묻는 통신(3~5ms) 동안 잠들어 있다 */
int wait_xy(int x, int y)
{
    int32_t x_now = 0;
    int32_t y_now = 0;
    uint32_t start = osKernelGetTickCount();

    for (;;) {
        int x_ok = (IM_Pos(&x_now) == 1 && x_now > x - GAP && x_now < x + GAP);    /* X 도착? */
        int y_ok = (AM_Pos(&y_now) == 1 && y_now > y - GAP && y_now < y + GAP);    /* Y 도착? */
        if (x_ok == 1 && y_ok == 1) return 1;

        if (A_05(start, x_ok) == 1 || A_06(start, y_ok) == 1) return 0;          /* 10초 못 감 → 알람 05 · 06 */
        if (estop == 1 || status_1 == ALARM) return 0;          /* 긴급정지 · 알람 : 바로 그만 */
    }
}

/* TILT 도착 대기 : 부호 상관없이 각도 크기로 비교 */
int wait_tilt(int deg)
{
    int32_t now = 0;
    uint32_t start = osKernelGetTickCount();

    for (;;) {
        if (TM_Pos(&now)) {
            if (now < 0) now = -now;
            if (now >= deg - TILT_GAP && now <= deg + TILT_GAP && TM_Done())
                return 1;
        }
        if (A_07(start, 0) == 1) return 0;                     /* 10초 못 감 → 알람 07 */
        if (estop == 1 || status_1 == ALARM) return 0;          /* 긴급정지 · 알람 : 바로 그만 */
    }
}

/* 입고 : 긴급정지 · 알람이 걸리면 그 뒤 이동 · 기다림은 모터 함수가 알아서 안 함 → 마지막에 결과만 */
int MI(int x, int y, int xy_speed, int tilt_speed)
{
    /* 1. 틸트 중앙 */
    TM_C(tilt_speed);
    wait_tilt(0);

    /* 2. X, Y 이동 */
    IM_Move(x, xy_speed);
    AM_Move(y, xy_speed);
    wait_xy(x, y);

    /* 3. 정지선 : 일시정지면 RUN 까지 기다림 */
    while ((status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE) && estop == 0 && status_1 != ALARM) osDelay(20);

    return (estop == 0 && status_1 != ALARM);   /* 멈춘 적 없으면 성공 */
}

/* 출고 : 동작은 입고와 같다 */
int MO(int x, int y, int xy_speed, int tilt_speed)
{
    return MI(x, y, xy_speed, tilt_speed);
}

/* PO 정지선 (틸트 전) : 그 단 만재 · 그 렉 카드 없음이면 틸트 안 하고 멈춤, 풀리면 이어서 (긴급정지 · 알람이면 0) */
static int PO_pause(int rack, int dan)
{
    if (estop == 1 || status_1 == ALARM) return 0;         /* 이미 멈춤 : 상태를 덮어쓰지 않게 */
    if (rack > 2) return 1;                                /* 렉 3 · 4 : 만재 · 카드 센서 아직 없음 */

    if (manjae_on(rack, dan))        { Status_PAUSE(rack); pause_why = 'F'; pause_event_on = 1; }   /* 만재 → PC 한 번 */
    if (rack == 1 && card_ok_1 == 0) { Status_PAUSE(rack); pause_why = 'S'; pause_event_on = 1; }   /* 카드 없음 */
    if (rack == 2 && card_ok_2 == 0) { Status_PAUSE(rack); pause_why = 'S'; pause_event_on = 1; }

    while (status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE) {     /* 풀릴 때까지 */
        if (pause_why == 'F' && manjae_off(rack, dan))      Status_RUN(rack);                      /* 만재 풀림 (PC D 도 풀어 줌) */
        if (pause_why == 'S' && ((rack == 1 && card_ok_1 == 1) || (rack == 2 && card_ok_2 == 1))) Status_RUN(rack);   /* 카드 들어옴 */
        if (estop == 1 || status_1 == ALARM) return 0;                                              /* 긴급정지 · 알람 : 그만 */
        osDelay(20);
    }
    return 1;
}

/* PO 틸트 확인 : 쏟는 동안(touch_time ms) 그 단 센서에 한 번도 안 닿으면 기울인 채 멈춤 → HMI RUN 까지 (긴급정지 · 알람이면 0) */
static int PO_tilt(int rack, int dan, int touch_time)
{
    int touch = 0;                                              /* 닿았나 : 처음엔 안 닿음 */

    if (estop == 1 || status_1 == ALARM) return 0;              /* 이미 멈춤 : 상태를 덮어쓰지 않게 */
    if (rack > 2) return 1;                                     /* 렉 3 · 4 : 센서 아직 없음 */

    for (int i = 0; i < touch_time && estop == 0; i += 20) {    /* 쏟는 동안 20ms 마다 */
        if (manjae_on(rack, dan)) touch = 1;                    /* 한 번이라도 닿으면 기억 */
        osDelay(20);
    }
    if (touch == 0) { Status_PAUSE(rack); pause_why = 'T'; pause_event_on = 1; }   /* 안 닿음 → 멈춤 + PC 한 번 */

    while (status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE) {   /* RUN 까지 (STOP 도 여기서 섬) */
        if (estop == 1 || status_1 == ALARM) return 0;
        osDelay(20);
    }
    if (estop == 1) return 0;
    return 1;
}

/* 분배 : 이동 → 정지선(만재 · 카드) → 틸트 → 쏟기 확인 → 복귀 */
int PO(int rack, int x, int y, int dan,
       int xy_speed, int tilt_speed,
       int move_delay, int return_delay,
       int tilt_angle, int tilting_y, int tilting_y_speed)
{
    /* 1. 이동 (MI / MO 와 같음) */
    MO(x, y, xy_speed, tilt_speed);
    osDelay(move_delay);

    /* 2. 정지선 : 그 단 만재 · 그 렉 카드 없음이면 멈춤 → 풀리면 이어서 */
    PO_pause(rack, dan);

    /* 3. Y 올리면서 틸트 : Y 가 절반 올라가면 틸트 출발 */
    AM_Move(y + tilting_y, tilting_y_speed);
    wait_xy(x, y + tilting_y / 2);
    if (rack % 2 == 1) { TM_R(tilt_angle, tilting_y_speed); }     /* 홀수 렉 = 오른쪽 */
    else { TM_L(tilt_angle, tilting_y_speed); }                    /* 짝수 렉 = 왼쪽 */
    wait_xy(x, y + tilting_y);
    wait_tilt(tilt_angle);

    /* 4. 쏟기 : 쏟는 동안 센서 안 닿으면 · STOP 이면 기울인 채 RUN 까지 */
    PO_tilt(rack, dan, return_delay * 10);   /* touch_time = 쏟는 시간 (x10ms) */
    PO_pause(rack, dan);


    /* 5. Y, 틸트 복귀 */
    TM_C(tilting_y_speed);
    AM_Move(y, tilting_y_speed);
    wait_tilt(0);
    wait_xy(x, y);

    return (estop == 0 && status_1 != ALARM);   /* 멈춘 적 없으면 성공 */
}

/* 원점 : Tilt -> X -> Y 순서. 하나라도 실패하면 거기서 멈추고 0 */
int I(void)
{
    return TM_Home()      /* 1. 틸트 */
        && IM_Home()      /* 2. X */
        && AM_Home();     /* 3. Y */
}

/* 긴급정지 : 세 축 모두 멈춤. 하나가 통신 실패해도 나머지는 꼭 보냄 (IM_Stop 과 같은 방식) */
int E_S (void)
{
	int t = TM_Stop();     /* 1. 틸트 */
	int x = IM_Stop();     /* 2. X */
	int y = AM_Stop();   /* 3. Y */

	return t && x && y;    /* 하나라도 실패면 0 */
}

