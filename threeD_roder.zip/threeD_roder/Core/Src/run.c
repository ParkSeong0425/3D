#include "run.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "debug.h"
#include "event.h"
#include "cmsis_os2.h"
#include "status.h"
#include "cmd.h"
#include "alarm.h"
#include "manjae.h"
#include "rfid.h"
#include "buzzer.h"
#include "save.h"
#include "net.h"
#include <stdio.h>

/* Motor_Task 에 넘길 숫자 (주문서) : cmd.c CMD_Run 이 확인하고 채움 → Motor_Run 이 run 함수에 넣음 */
int order_rack;                 /* 렉 */
int order_col;                  /* 열 (cmd.c : 열 → X 좌표, 완료응답 AI_렉_열_단) */
int order_dan;                 /* 단 */
int order_x;                    /* 갈 좌표 X */
int order_y;                    /* 갈 좌표 Y */
int order_xy_speed;             /* XY 속도 % */
int order_tilt_speed;           /* 틸트 속도 % */
int order_move_delay;           /* 이동 후 대기 ms */
int order_return_delay;         /* 쏟는 시간 (x10ms) */

/* 렉 · 열 · 단 → FRAM 좌표 order_x, order_y (입고 = 입고 표 / 홀수 렉 = 오른쪽 표 / 짝수 렉 = 왼쪽 표) */
static void order_xy(int cmd)
{
    if (cmd == CMD_MI)                                      /* 입고 */
    {
        order_x = save.fp.in_x;

        if (order_dan == 1) order_y = save.fp.in_y1;
        else if (order_dan == 2) order_y = save.fp.in_y2;
        else if (order_dan == 3) order_y = save.fp.in_y3;
        else if (order_dan == 4) order_y = save.fp.in_y4;
        else if (order_dan == 5) order_y = save.fp.in_y5;
        return;
    }

    if (order_rack % 2 == 1)                                /* 홀수 렉 = 오른쪽 표 */
    {
        if (order_col == 1) order_x = save.fp.right_x1;
        else if (order_col == 2) order_x = save.fp.right_x2;
        else if (order_col == 3) order_x = save.fp.right_x3;
        else if (order_col == 4) order_x = save.fp.right_x4;
        else if (order_col == 5) order_x = save.fp.right_x5;
        else if (order_col == 6) order_x = save.fp.right_x6;
        else if (order_col == 7) order_x = save.fp.right_x7;
        else if (order_col == 8) order_x = save.fp.right_x8;
        else if (order_col == 9) order_x = save.fp.right_x9;

        if (order_dan == 1) order_y = save.fp.right_y1;
        else if (order_dan == 2) order_y = save.fp.right_y2;
        else if (order_dan == 3) order_y = save.fp.right_y3;
        else if (order_dan == 4) order_y = save.fp.right_y4;
        else if (order_dan == 5) order_y = save.fp.right_y5;
        else if (order_dan == 6) order_y = save.fp.right_y6;
        else if (order_dan == 7) order_y = save.fp.right_y7;
        else if (order_dan == 8) order_y = save.fp.right_y8;
        else if (order_dan == 9) order_y = save.fp.right_y9;
    }
    else                                                    /* 짝수 렉 = 왼쪽 표 */
    {
        if (order_col == 1) order_x = save.fp.left_x1;
        else if (order_col == 2) order_x = save.fp.left_x2;
        else if (order_col == 3) order_x = save.fp.left_x3;
        else if (order_col == 4) order_x = save.fp.left_x4;
        else if (order_col == 5) order_x = save.fp.left_x5;
        else if (order_col == 6) order_x = save.fp.left_x6;
        else if (order_col == 7) order_x = save.fp.left_x7;
        else if (order_col == 8) order_x = save.fp.left_x8;
        else if (order_col == 9) order_x = save.fp.left_x9;

        if (order_dan == 1) order_y = save.fp.left_y1;
        else if (order_dan == 2) order_y = save.fp.left_y2;
        else if (order_dan == 3) order_y = save.fp.left_y3;
        else if (order_dan == 4) order_y = save.fp.left_y4;
        else if (order_dan == 5) order_y = save.fp.left_y5;
        else if (order_dan == 6) order_y = save.fp.left_y6;
        else if (order_dan == 7) order_y = save.fp.left_y7;
        else if (order_dan == 8) order_y = save.fp.left_y8;
        else if (order_dan == 9) order_y = save.fp.left_y9;
    }
}

/* 주문서 채우기 (cmd.c 가 부름) : "MI_렉_열_단_XY속도_틸트속도_이동후대기_쏟는시간" → 숫자 7개 · 범위 확인 · 좌표. 맞으면 1 / 틀리면 0 */
int Order_Set(int cmd, char *s)
{
    if (sscanf(s + 3, "%d_%d_%d_%d_%d_%d_%d",                                             /* 숫자 7개 → 주문서 칸 */
               &order_rack, &order_col, &order_dan,
               &order_xy_speed, &order_tilt_speed, &order_move_delay, &order_return_delay) != 7)
        return 0;

    if (order_rack < 1 || order_rack > save.fs.rack_channel) return 0;                    /* 렉 : 1 ~ 렉 수 (FS rack_channel) */

    if (cmd == CMD_MI && (order_col != 1 ||                                               /* 입고 : 열 1, 단 범위 */
                          order_dan < 1 || order_dan > save.fs.in_y)) return 0;

    if (cmd != CMD_MI && order_rack % 2 == 1 &&                                           /* 홀수 렉 = 오른쪽 표 : 열 · 단 범위 */
        (order_col < 1 || order_col > save.fs.right_x || order_dan < 1 || order_dan > save.fs.right_y)) return 0;

    if (cmd != CMD_MI && order_rack % 2 == 0 &&                                           /* 짝수 렉 = 왼쪽 표 : 열 · 단 범위 */
        (order_col < 1 || order_col > save.fs.left_x || order_dan < 1 || order_dan > save.fs.left_y)) return 0;

    order_xy(cmd);                                                                        /* 렉 · 열 · 단 → 좌표 */
    return 1;
}

/* 원점 (켤 때 · HMI RUN · PC I · CLI INIT) : 원점 중 표시 → 드라이브 설정 (세 축 따로 다 보냄) → 원점 → 대기 / 초기상태. 도착 1 / 실패 0 */
int motor_basic_init(void)
{
    Status_HOME();                      /* 원점 중 → 램프 원점 깜빡 */
    Log_Debug(LOG_HOME_START);

    int x = IM_MapInit();               /* X 설정 */
    int y = AM_Init();                  /* Y 설정 */
    int t = TM_Init();                  /* 틸트 설정 */
    if (x == 0) Log_Debug(LOG_HOME_X_NO_ANSWER);
    if (y == 0) Log_Debug(LOG_HOME_Y_NO_ANSWER);
    if (t == 0) Log_Debug(LOG_HOME_T_NO_ANSWER);

    if (x && y && t && I()) {           /* 설정 다 됨 → 원점 도착 */
        Status_WAIT(1);                 /* 대기 → 램프 rfid */
        Status_WAIT(2);
        Status_WAIT(3);
        Status_WAIT(4);
    	Log_Debug(LOG_HOME_DONE);
        return 1;
    }

    if (status_1 != ALARM) { Status_INIT(); Buzzer_Off(); }     /* 못 감 → 초기상태 (알람이면 상태 · 부저 그대로) */
    Log_Debug(LOG_HOME_FAIL);
    return 0;
}

/* 기본 모터 시험 (CLI X Y C R L) : 명령만 보냄 (도착은 안 기다림) */
int motor_basic_run(int command, int32_t pulse, int deg , int rpm)
{
    if      (command == 'X') return IM_Move(pulse, rpm);
    else if (command == 'Y') return AM_Move(pulse, rpm);
    else if (command == 'C') return TM_C(rpm);
    else if (command == 'R') return TM_R(deg, rpm);
    else if (command == 'L') return TM_L(deg, rpm);
    return 0;
}

/* 입고 : 긴급정지 · 알람이 걸리면 그 뒤 이동 · 기다림은 모터 함수가 알아서 안 함 → 마지막에 결과만 */
int MI(int x, int y, int xy_speed, int tilt_speed)
{
    /* 1. 틸트 중앙 */
    TM_C(tilt_speed);
    A_07(TM_Arrive(0));         /* 틸트 가운데 도착 기다림 (최대 MOVE_MS) → 못 갔으면 알람 07 */

    /* 2. X, Y 이동 : 같이 움직이니 X 기다린 뒤 Y 기다려도 시간은 같음 (MOVE_MS 넘으면 그 자리에서 멈춤) */
    IM_Move(x, xy_speed);
    AM_Move(y, xy_speed);
    A_05(IM_Arrive(x));         /* X 도착 기다림 → 못 갔으면 알람 05 (뒤 AM_Arrive 는 알람이라 바로 나옴) */
    A_06(AM_Arrive(y));         /* Y 도착 기다림 → 못 갔으면 알람 06 */

    /* 3. 정지선 : 일시정지면 RUN 까지 기다림 */
    while (pause_why) osDelay(20);          /* 일시정지면 풀릴 때까지 (알람이 되면 0 이라 바로 나옴) */

    return (estop == 0 && status_1 != ALARM);   /* 멈춘 적 없으면 성공 */
}

/* 출고 : 동작은 입고와 같다 */
int MO(int x, int y, int xy_speed, int tilt_speed)
{
    return MI(x, y, xy_speed, tilt_speed);
}

/* PO 정지선 (틸트 전) : 그 단 만재(2초 그대로) · 그 렉 카드 없음이면 멈춤 → 둘 다 풀리면 이어서 (STOP 은 HMI RUN 까지) */
static void PO_pause(int rack, int dan)
{
    if (manjae_on(rack, dan)) { Status_PAUSE(rack, 'F'); Log_Debug(LOG_MANJAE, 'P', 'O', rack, order_col, dan); }   /* 만재 → PPAUSE:F */
    if (card_on(rack) == 0)   { Status_PAUSE(rack, 'S'); Log_Debug(LOG_RFID, 'P', 'O', rack); }                    /* 카드 없음 → PPAUSE:S */

    while (pause_why) {                                         /* 풀릴 때까지 (알람이면 0 이라 바로 나옴) */
        if (pause_why != 'M' && manjae_off(rack, dan) && card_on(rack)) { Status_RUN(rack); Log_Debug(LOG_CLEAR); Buzzer_Off(); }   /* 만재 풀림 + 카드 있음 → 이어서 + 부저 끔 */
        osDelay(20);
    }
}

/* PO 쏟기 : 쏟는 시간(touch_time ms) 동안 20ms 마다 그 단 센서 확인 → 한 번도 안 닿으면 T → 풀릴 때까지 */
static void PO_tilt(int rack, int dan, int touch_time)
{
    int touch = 0;                                              /* 닿았나 */

    for (; touch_time > 0; touch_time -= 20) {                  /* 쏟는 시간을 20ms 씩 줄이며 */
        if (manjae_on(rack, dan)) touch = 1;                    /* 한 번이라도 닿으면 기억 */
        osDelay(20);
    }
    if (touch == 0 && rack <= 2) { Status_PAUSE(rack, 'T'); Log_Debug(LOG_Tilting_error, 'P', 'O', rack, order_col, dan); }   /* 안 닿음 → PPAUSE:T (렉 3 · 4 는 센서 없음) */
    while (pause_why) osDelay(20);                              /* T · STOP 이면 풀릴 때까지 */
}

/* 분배 : 이동 → 정지선(만재 · 카드) → 틸트 → 쏟기 확인 → 복귀 */
int PO(int rack, int x, int y, int dan,
       int xy_speed, int tilt_speed,
       int move_delay, int return_delay,
       int tilt_angle, int tilting_y, int tilting_y_speed)
{
    /* 1. 이동 (MI / MO 와 같음) */
    MO(x, y, xy_speed, tilt_speed);
    osDelay(move_delay);

    /* 2. 정지선 : 그 단 만재 · 그 렉 카드 없음이면 멈춤 → 풀리면 이어서 */
    PO_pause(rack, dan);

    /* 3. Y 올리면서 틸트 : Y 가 절반 올라가면 틸트 출발 */
    Log_Debug(LOG_Tilting, 'P', 'O', rack, order_col, dan);
    AM_Move(y + tilting_y, tilting_y_speed);
    AM_Arrive(y + tilting_y / 2);                                  /* Y 절반 기다림 (X 는 서 있음) */
    if (rack % 2 == 1) { TM_R(tilt_angle, tilting_y_speed); }     /* 홀수 렉 = 오른쪽 */
    else { TM_L(tilt_angle, tilting_y_speed); }                    /* 짝수 렉 = 왼쪽 */
    A_06(AM_Arrive(y + tilting_y));                                /* Y 끝 기다림 → 못 갔으면 알람 06 */
    A_07(TM_Arrive(tilt_angle));                                   /* 기울기 도착 기다림 → 못 갔으면 알람 07 */

    /* 4. 쏟기 : 쏟는 동안 센서 안 닿으면 · STOP 이면 기울인 채 RUN 까지 */
    PO_tilt(rack, dan, return_delay * 10);   /* touch_time = 쏟는 시간 (x10ms) */
    PO_pause(rack, dan);

    /* 5. Y, 틸트 복귀 */
    TM_C(tilting_y_speed);
    AM_Move(y, tilting_y_speed);
    A_07(TM_Arrive(0));                                            /* 틸트 가운데 → 못 갔으면 알람 07 */
    A_06(AM_Arrive(y));                                            /* Y 제자리 → 못 갔으면 알람 06 */

    return (estop == 0 && status_1 != ALARM);   /* 멈춘 적 없으면 성공 */
}

/* 원점 : Tilt -> X -> Y 순서. 하나라도 실패하면 거기서 멈추고 0 */
int I(void)
{
    return TM_Home()      /* 1. 틸트 */
        && IM_Home()      /* 2. X */
        && AM_Home();     /* 3. Y */
}

/* 긴급정지 : 세 축 모두 멈춤. 하나가 통신 실패해도 나머지는 꼭 보냄 (IM_Stop 과 같은 방식) */
int E_S (void)
{
	int t = TM_Stop();     /* 1. 틸트 */
	int x = IM_Stop();     /* 2. X */
	int y = AM_Stop();   /* 3. Y */

	return t && x && y;    /* 하나라도 실패면 0 */
}

/* Motor_Task : 울린 초인종에 맞는 함수 하나 → 성공하면 그 렉 대기 + 로그 (실패 = 알람 · 긴급정지, 상태 그대로)
   PC 완료응답(AI · AO · EO · homing done)은 cmd.c CMD_Event 가 상태판(R → W)을 보고 보냄 */
void Motor_Run(int flag)
{
    char *name = "";                        /* 로그용 명령 이름 */
    int ok = 0;                             /* 끝까지 감 */

    if (flag & MOTOR_FLAG) { motor_basic_init(); return; }                                                   /* 원점 (시작 · 끝 처리도 안에서) */

    if (flag & MI_FLAG) { name = "MI"; ok = MI(order_x, order_y, order_xy_speed, order_tilt_speed); }        /* 입고 */
    if (flag & MO_FLAG) { name = "MO"; ok = MO(order_x, order_y, order_xy_speed, order_tilt_speed); }        /* 출고 */
    if (flag & PO_FLAG) { name = "PO"; ok = PO(order_rack, order_x, order_y, order_dan,                       /* 분배 */
                                               order_xy_speed, order_tilt_speed, order_move_delay, order_return_delay,
                                               save.fp.tilt_angle, save.fp.tilting_y, save.fp.tilting_y_speed); }
    if (ok == 0) return;                    /* 알람 · 긴급정지로 멈춤 : 상태 그대로 (알람 로그는 alarm.c) */

    Status_WAIT(order_rack);                /* 끝 → 대기 (CMD_Event 가 보고 완료응답) */
    Log_Debug(LOG_MOVE_DONE, name[0], name[1], order_rack, order_col, order_dan);
}

