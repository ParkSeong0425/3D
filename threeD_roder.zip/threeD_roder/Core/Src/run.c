#include "run.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "event.h"
#include "cli.h"
#include "cmsis_os2.h"
#include "status.h"
#include "cmd.h"
#include "alarm.h"

#define AXIS_WAIT    300    /* 축 사이 간격 */
#define INIT_RETRY   3      /* 초기화 재시도 횟수 */
#define GAP          10     /* 도착 판정 오차 : X,Y는 mm */
#define TILT_GAP     2      /* 도착 판정 오차 : TILT는 도 */

static int x_ok;
static int y_ok;
static int t_ok;

/* 드라이브가 깨어날 때까지 기다린 뒤 실패한 축만 다시 시도 */
int motor_basic_init(void)
{
    for (int n = 1; n <= INIT_RETRY; n++) {
        if (x_ok == 0) x_ok = IM_MapInit();
        osDelay(AXIS_WAIT);

        if (y_ok == 0) y_ok = AM_Init();
        osDelay(AXIS_WAIT);

        if (t_ok == 0) t_ok = TM_Init();
        osDelay(AXIS_WAIT);

        if (x_ok && y_ok && t_ok) break;
    }

    /* 한 축이라도 실패하면 원점복귀 안 함 (응답 없는 축에서 멈추지 않게) */
    if (x_ok == 0 || y_ok == 0 || t_ok == 0) return 0;

    return I();
}

/* 기본 모터 시험 (CLI X Y C R L) : 명령만 보냄 (도착은 안 기다림) */
int motor_basic_run(int command, int32_t pulse, int deg , int rpm)
{
    if      (command == 'X') return IM_Move(pulse, rpm);
    else if (command == 'Y') return AM_Move(pulse, rpm);
    else if (command == 'C') return TM_C(rpm);
    else if (command == 'R') return TM_R(deg, rpm);
    else if (command == 'L') return TM_L(deg, rpm);
    return 0;
}

/* X, Y 도착 대기 : 위치를 묻는 통신(3~5ms) 동안 잠들어 있다 */
int wait_xy(int x, int y)
{
    int32_t x_now = 0;
    int32_t y_now = 0;
    uint32_t start = osKernelGetTickCount();

    for (;;) {
        if (IM_Pos(&x_now) && AM_Pos(&y_now) &&
            x_now > x - GAP && x_now < x + GAP &&
            y_now > y - GAP && y_now < y + GAP)
            return 1;

        if (osKernelGetTickCount() - start > 30000) {           /* 30초 : 못 간 축 알람 */
            if (x_now <= x - GAP || x_now >= x + GAP) A_05(0);  /* X 못 감 */
            else                                      A_06(0);  /* Y 못 감 */
            return 0;
        }
        if (estop == 1) return 0;                               /* 긴급정지 : 바로 그만 */
    }
}

/* TILT 도착 대기 : 부호 상관없이 각도 크기로 비교 */
int wait_tilt(int deg)
{
    int32_t now = 0;
    uint32_t start = osKernelGetTickCount();

    for (;;) {
        if (TM_Pos(&now)) {
            if (now < 0) now = -now;
            if (now >= deg - TILT_GAP && now <= deg + TILT_GAP && TM_Done())
                return 1;
        }
        if (osKernelGetTickCount() - start > 30000) { A_07(0); return 0; }   /* 30초 : 틸트 못 감 */
        if (estop == 1) return 0;                               /* 긴급정지 : 바로 그만 */
    }
}

/* 입고 */
int MI(int x, int y, int xy_speed, int tilt_speed)
{
    /* 1. 틸트 중앙 */
    TM_C(tilt_speed);
    if (wait_tilt(0) == 0) return 0;           /* 못 감 (알람) · 긴급정지 → 그만 */

    /* 2. X, Y 이동 */
    IM_Move(x, xy_speed);
    AM_Move(y, xy_speed);
    if (wait_xy(x, y) == 0) return 0;

    /* 3. 정지선 : 일시정지면 RUN 까지 기다림 */
    while ((status_1 == PAUSE || status_2 == PAUSE || status_3 == PAUSE || status_4 == PAUSE) && estop == 0) osDelay(20);

    return 1;
}

/* 출고 : 동작은 입고와 같다 */
int MO(int x, int y, int xy_speed, int tilt_speed)
{
    return MI(x, y, xy_speed, tilt_speed);
}

/* 분배 : 이동 → 기다림 → 틸트 → 쏟기 → 기다림 → 복귀 */
int PO(int rack, int x, int y, int dan,
       int xy_speed, int tilt_speed,
       int move_delay, int return_delay,
       int tilt_angle, int tilting_y, int tilting_y_speed)
{
    /* 1. 이동 (MI / MO 와 같음) */
    if (MO(x, y, xy_speed, tilt_speed) == 0) return 0;   /* 못 감 (알람) · 긴급정지 → 그만 */
    osDelay(move_delay);

    /* 2. 도착 : 만재 · 카드 (event.c) */
    if (PO_event(rack, dan, 1, 0) == 0) return 0;                          /* 도착 : move_done 1 */

    /* 3. Y 올리면서 틸트 : Y 가 절반 올라가면 틸트 출발 (MO 끝 정지선을 지나서 옴) */
    AM_Move(y + tilting_y, tilting_y_speed);
    if (wait_xy(x, y + tilting_y / 2) == 0) return 0;
    if (rack % 2 == 1) { TM_R(tilt_angle, tilting_y_speed); }     /* 홀수 렉 = 오른쪽 */
    else { TM_L(tilt_angle, tilting_y_speed); }                    /* 짝수 렉 = 왼쪽 */
    if (wait_xy(x, y + tilting_y) == 0) return 0;
    if (wait_tilt(tilt_angle) == 0) return 0;

    /* 4. 쏟기 : 쏟는 동안 센서 → 틸트 · STOP 이면 기울인 채 RUN 까지 (event.c) */
    if (PO_event(rack, dan, 0, return_delay * 10) == 0) return 0;          /* 쏟기 : sensor_check = 쏟는 시간 */

    /* 5. Y, 틸트 복귀 */
    TM_C(tilting_y_speed);
    AM_Move(y, tilting_y_speed);
    if (wait_tilt(0) == 0) return 0;
    if (wait_xy(x, y) == 0) return 0;

    return 1;
}

/* 원점 : Tilt -> X -> Y 순서. 하나라도 실패하면 거기서 멈추고 0 */
int I(void)
{
    return TM_Home()      /* 1. 틸트 */
        && IM_Home()      /* 2. X */
        && AM_Home();     /* 3. Y */
}

/* 긴급정지 : 세 축 모두 멈춤. 하나가 통신 실패해도 나머지는 꼭 보냄 (IM_Stop 과 같은 방식) */
int E_S (void)
{
	int t = TM_Stop();     /* 1. 틸트 */
	int x = IM_Stop();     /* 2. X */
	int y = AM_Stop();   /* 3. Y */

	return t && x && y;    /* 하나라도 실패면 0 */
}

