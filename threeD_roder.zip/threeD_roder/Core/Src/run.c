/*
 * run.c : 로더 동작 — 모터 파일(i · a · t_motor)의 기본 움직임을 모아 원점 · MI · MO · PO 를 만듦
 *   주문     Motor_Request (아무 태스크 : 큐 MoveQueue 에 넣기) → Motor_Run (Motor_Task : 주문서 flag 하나 실행 → move_done 완료응답 · 로그)
 *   동작     motor_basic_init · I · MI · MO · PO · E_S   (MI · MO · PO 는 좌표 · 높이 숫자를 받음, 표 찾기는 Motor_Run 한 곳)
 *   블록     po_stop (만재 F · 카드 S) · tilt_pour (쏟기) · pour_wait (기울인 채)
 *   정지선   while (state.now == 'S') osDelay(20);  멈춤(S)이면 풀릴 때까지 (MI · MO 끝 · PO 쏟기 전 · 쏟은 뒤)
 *
 *  ── 시험 때 증상 → 볼 곳 ──
 *   도착했는데 8초 뒤 ALARM 05          → i_motor.c IM_Arrive (멈춤 비트 IM_PATH_DONE 확인 줄)
 *   입고대에서 나올 때 너무 빠름 · 느림  → i_motor.h OUT_SPEED (safe_x 에서 %)
 *   입고대로 들어갈 때 속도              → i_motor.h SAFE_SPEED (safe_x 에서 %, 그 뒤 줄어 in_x 에 섬)
 *   천천히 구간 길이 (in_x − safe_x)     → 코드 아님 : FRAM FP 13 safe_x (PC FP_1_=_…)
 *   MI 에서 판이 입고대에 걸림           → Y 가 X 보다 늦음 (MI 4번 : 같이 출발) · FRAM FP 13 safe_y
 */
#include "run.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "debug.h"
#include "event.h"
#include "cmsis_os2.h"
#include "FreeRTOS.h"
#include "queue.h"          /* xQueuePeek (주문 보기만) */
#include "status.h"
#include "cmd.h"
#include "alarm.h"
#include "manjae.h"
#include "rfid.h"
#include "save.h"
#include <stdio.h>

/* 원점 (켤 때 · 시작 · PC I) : H → 드라이브 설정 (세 축 따로 다 보냄) → 원점 → W / 못 가면 알람 10. 도착 1 / 실패 0 */
int motor_basic_init(void)
{
    state.now = 'H';                  /* 원점 중 → 램프 원점 깜빡 · 화면 원점설정 */
    Log_Debug(LOG_HOME_START);

    int x = IM_MapInit();               /* X 설정 */
    int y = AM_Init();                  /* Y 설정 */
    int t = TM_Init();                  /* 틸트 설정 */
    if (x == 0) Log_Debug(LOG_HOME_X_NO_ANSWER);
    if (y == 0) Log_Debug(LOG_HOME_Y_NO_ANSWER);
    if (t == 0) Log_Debug(LOG_HOME_T_NO_ANSWER);

    if (x && y && t && I() && Motor_Stop() == 0) {   /* 설정 다 됨 → 원점 도착 (도중에 알람 · 긴급정지 없었음) */
        state.now = 'W';              /* 대기 → 램프 rfid */
        Log_Debug(LOG_HOME_DONE);
        return 1;
    }

    A_10(0, 0);                        /* 못 감 → 알람 10 (이미 알람이면 그대로) : RESET → RUN 으로 다시 */
    Log_Debug(LOG_HOME_FAIL);
    return 0;
}


/* ── 블록 (PO 가 부름) : 판단(if · while)이 들어간 것만. 모터 한 줄짜리는 모터 함수를 그대로 부름 ── */

/* PO 정지선 : 그 단 만재 → 2초 확인 → F (비우고 RUN · 억지로는 PC D) / 그 렉 카드 없음 → S (카드 들어오면 저절로 · RUN). MI · MO 는 상관없음 */
static void po_stop(int rack, int dan)
{
    while (manjae_on(rack, dan) && manjae_2s(rack, dan) == 0) osDelay(20);       /* 만재인데 2초 확정 전 : 스침인지 기다림 (최대 2초) */
    if (manjae_on(rack, dan)) Pause_Set(rack, 'F');                               /* 아직 만재 = 스침 아님 → PPAUSE:F */
    while (state.now == 'S') osDelay(20);                                     /* 정지선 : 시작 (그 칸 비었을 때만, event.c btn_run) · D 까지 */
    if (card_on(rack) == 0) Pause_Set(rack, 'S');                                 /* [현장] 그 렉 카드 없음 → PPAUSE:S (사무실 : 리더 없으면 주석) */
    while (state.now == 'S' && state.why == 'S' && card_on(rack) == 0) osDelay(20);   /* 카드 들어올 때까지 (시작으로도 풀림) */
    if (state.now == 'S' && state.why == 'S') Pause_Clear();                  /* 카드 들어옴 → 저절로 이어서 */
}

/* PO 쏟기 : Y 를 FP 7 tilting_y 만큼 올리며 절반에서 틸트 (홀수 렉 오른쪽 · 짝수 렉 왼쪽) → 둘 다 도착. 속도는 FP 7 tilting_y_speed
   (Y · 틸트 동시 출발은 11/6 시험에서 틸트가 껴서 되돌림) */
static void tilt_pour(int rack, int y, int angle)
{
    AM_Move(y + save.fp.tilting_y, save.fp.tilting_y_speed);
    AM_Arrive(y + save.fp.tilting_y / 2);                                       /* Y 절반 기다림 (X 는 서 있음) */
    if (rack % 2 == 1) TM_R(angle, save.fp.tilting_y_speed);                    /* 홀수 렉 = 오른쪽 */
    else               TM_L(angle, save.fp.tilting_y_speed);                    /* 짝수 렉 = 왼쪽 */
    A_06(AM_Arrive(y + save.fp.tilting_y));                                     /* 못 갔으면 알람 06 */
    A_07(TM_Arrive(angle));                                                     /* 못 갔으면 알람 07 */
}

/* PO 기울인 채 : 틸팅 검사면 검사 시간(FP 7 tilt_check_time) 안에 그 단 센서가 닿아야 함 (안 닿으면 PPAUSE:T → RUN · D 까지)
   검사 아니면 복귀 대기(return_delay × 10ms)만. 검사 = FS 옵션 마지막 자리 1 && 명령 틸팅검사 1 && 렉 1 · 2 */
static void pour_wait(int rack, int dan, int return_delay, int tilt_check)
{
    int check = (save.fs.option[4] == 1 && tilt_check == 1 && rack <= 2);       /* 검사할까 */
    int ms = 0;                                                                 /* 기다린 시간 */

    if (check == 0) { osDelay(return_delay * 10); return; }                     /* 검사 안 함 : 복귀 대기만 */

    while (manjae_on(rack, dan) == 0 && ms < save.fp.tilt_check_time) {         /* 닿을 때까지 (최대 검사 시간) */
        osDelay(20);
        ms += 20;
    }
    if (manjae_on(rack, dan) == 0) Pause_Set(rack, 'T');                        /* 끝까지 안 닿음 → PPAUSE:T */
    while (state.now == 'S') osDelay(20);                                   /* 정지선 : 기울인 채 시작 · D 까지 */
}


/* ── 동작 (좌표 · 높이 숫자를 받음, 나머지는 프로토콜 순서 그대로. 안 쓰는 칸도 받음) ──
   긴급정지 · 알람이 걸리면 그 뒤 이동 · 기다림은 모터 함수가 알아서 안 함 (문 2, status.c Motor_Stop) → 마지막에 결과만 */

/* 입고 : y = 그 단 안전 높이. X · Y 같이 출발 → X 는 한 번에 진입 (safe_x 부터 줄어 in_x 에 섬, 안 섬). 끝 높이 = 안전 높이
   Y 는 X 가 입구까지 가는 동안 끝난다고 봄 (11/12 사용자). MI → MI 면 입고대 안에서 천천히 나와 (섬) → 같은 방식으로 진입 */
int MI(int y, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle)
{
    int32_t x1 = 0, x2 = 0;                                                     /* 못 읽으면 0 = 밖으로 봄 */
    osDelay(delay);                                                             /* 0. 출발 대기 */
    TM_C(tilt_speed);                                                           /* 1. 틸트 가운데 */
    A_07(TM_Arrive(0));
    IM_Pos(&x1, &x2);
    if (x1 > save.fp.safe_x) {                                                  /* 2. MI → MI : 입고대 안이면 */
        IM_MoveSoft(save.fp.safe_x - 10, lift_speed);                           /*    천천히 나와서 */
        A_05(IM_Arrive(save.fp.safe_x - 10));                                   /*    섬 (가는 중엔 새 명령 안 받음) */
    }
    AM_Move(y, lift_speed);                                                     /* 3. Y 그 단 안전 높이로 출발 */
    IM_MoveSoft(save.fp.in_x, lift_speed);                                      /* 4. X 같이 출발, 한 번에 진입 (안 섬) */
    A_06(AM_Arrive(y));
    A_05(IM_Arrive(save.fp.in_x));
    while (state.now == 'S') osDelay(20);                                   /* 5. 정지선 */
    return Motor_Stop() == 0;                                                   /* 긴급정지 · 알람 없었으면 성공 */
}

/* 출고 : 렉 좌표 (x, y) 로 (이동만). X · Y 같이 출발 (입고대 안이면 X 는 천천히 → safe_x 지나며 빨라짐) */
int MO(int x, int y, int lift_speed, int tilt_speed, int delay, int return_delay, int tilt_angle)
{
    osDelay(delay);                                                             /* 0. 출발 대기 */
    TM_C(tilt_speed);                                                           /* 1. 틸트 가운데 */
    A_07(TM_Arrive(0));
    IM_MoveSoft(x, lift_speed);                                                 /* 2. X 렉으로 (입고대 안이면 천천히 → 빨라짐) */
    AM_Move(y, lift_speed);                                                     /*    Y 같이 출발 (11/12 : 입고대 지날 때까지 안 기다림) */
    A_05(IM_Arrive(x));                                                         /*    둘 다 도착 */
    A_06(AM_Arrive(y));
    while (state.now == 'S') osDelay(20);                                   /* 4. 정지선 */
    return Motor_Stop() == 0;                                                   /* 긴급정지 · 알람 없었으면 성공 */
}

/* 분배 : 렉으로 → 정지선 → 쏟기 → 기울인 채 → 틸트 가운데 → 렉 자리로 (끝 = MO 위치) */
int PO(int rack, int x, int y, int dan, int lift_speed, int tilt_speed,
       int delay, int return_delay, int tilt_angle, int tilt_check)
{
    MO(x, y, lift_speed, tilt_speed, delay, return_delay, tilt_angle);  /* 1. 렉으로 */
    po_stop(rack, dan);                                                 /* 2. 정지선 : 만재 F · 카드 S */
    tilt_pour(rack, y, tilt_angle);                                     /* 3. Y 올리며 틸트 */
    pour_wait(rack, dan, return_delay, tilt_check);                     /* 4. 기울인 채 : 틸팅 검사 / 복귀 대기 */
    TM_C(save.fp.tilting_y_speed);                                      /* 5. 틸트 C + Y 원래 자리 같이 출발 (틸트를 먼저 보냄 → 판이 먼저 펴짐) */
    AM_Move(y, lift_speed);
    A_07(TM_Arrive(0));                                                 /*    둘 다 도착 (못 가면 알람 07 · 06) */
    A_06(AM_Arrive(y));
    return Motor_Stop() == 0;                                           /* 긴급정지 · 알람 없었으면 성공 */
}

/* 원점 : Tilt -> X -> Y 순서. 하나라도 실패하면 거기서 멈추고 0 */
int I(void)
{
    if (TM_Home() == 0) { Log_Debug(LOG_HOME_T_FAIL); return 0; }     /* 1. 틸트 */
    if (IM_Home() == 0) { Log_Debug(LOG_HOME_X_FAIL); return 0; }     /* 2. X */
    if (AM_Home() == 0) { Log_Debug(LOG_HOME_Y_FAIL); return 0; }     /* 3. Y */
    return 1;
}

/* 긴급정지 : 세 축 모두 멈춤. 하나가 통신 실패해도 나머지는 꼭 보냄 (IM_Stop 과 같은 방식) */
int E_S (void)
{
	int t = TM_Stop();     /* 1. 틸트 */
	int x = IM_Stop();     /* 2. X */
	int y = AM_Stop();   /* 3. Y */

	return t && x && y;    /* 하나라도 실패면 0 */
}

/* ======================= 모터 문 : 주문 큐 MoveQueue (ioc, 1칸) → Motor_Task =======================
   Motor_Task 는 주문을 "보기만" 하고 실행 → 끝나면 꺼냄. 그래서 큐에 1개 있음 = 동작 중 (다음 주문은 넣기 실패 = NAK) */

/* 주문 받기 (아무 태스크) : 지금 상태에서 받을 수 있고 큐가 비었으면 넣고 1 (Motor_Task 가 깸) / 아니면 0 (= NAK)
   'W' 대기 : 원점 · MI · MO · PO / 'I' 초기상태 : 원점만 / 'R' 운전 : MI · MO · PO 만 (MO 뒤 PO) / 그 밖 ('H' 'S' 'M' 'E' 'A') 못 받음 */
int Motor_Request(MOVE flag)
{
    int ok = 0;                                                         /* 1 = 지금 상태에서 받을 수 있음 */
    int move = (flag.cmd == CMD_MI || flag.cmd == CMD_MO || flag.cmd == CMD_PO);   /* 1 = 움직이는 명령 (0 = 원점) */

    if (state.now == 'W') ok = 1;
    if (state.now == 'I' && move == 0) ok = 1;
    if (state.now == 'R' && move == 1) ok = 1;
    if (ok == 0) return 0;
    return osMessageQueuePut(MoveQueueHandle, &flag, 0, 0) == osOK;   /* 동작 중이면 큐가 차 있어 실패 */
}

/* 동작 끝 : 성공이면 완료응답 AI · AO · EO (cmd.c 가 보내고 W 도 cmd.c) + 완료 로그 (걸린 시간 · 끝난 위치 · X 두 모터 차이) */
static void move_done(MOVE flag, uint32_t start, int ok)
{
    char done[24];
    int32_t x1 = 0, x2 = 0, y = 0, t = 0;

    if (ok) {
        snprintf(done, sizeof(done), "%c%c_%d_%d_%d", flag.cmd == CMD_PO ? 'E' : 'A', flag.cmd & 0xFF, flag.rack, flag.col, flag.dan);
        Done_Send(done);                                                /* AI_1_1_2 / AO_1_3_2 / EO_1_3_2 */
    }
    IM_Pos(&x1, &x2);  AM_Pos(&y);  TM_Pos(&t);                         /* 끝난 위치 (버스 약 20ms, 명령마다 한 번) */
    Log_Debug(LOG_MOVE_DONE, flag.cmd >> 8, flag.cmd & 0xFF, flag.rack, flag.col, flag.dan,
              ok ? "Complete" : "FAIL", (unsigned long)(osKernelGetTickCount() - start));
    Log_Debug(LOG_MOVE_POS, (long)x1, (long)x2, (long)(x1 - x2), (long)y, (long)t);
}

/* Motor_Task : 주문서(flag) 하나 실행. 원점이면 motor_basic_init / 아니면 FRAM 표에서 좌표 찾기 → 표시 R → MI · MO · PO → move_done
   표 찾기는 여기 한 곳 : FRAM 표는 1 번 칸부터라 열 · 단 번호 그대로 (2 열 = [2]) */
void Motor_Run(MOVE flag)
{
    if (flag.cmd == CMD_I) { motor_basic_init(); return; }             /* 원점 : 시작 · 끝 다 motor_basic_init */

    uint32_t start = osKernelGetTickCount();
    int x, y;                                                          /* 렉 좌표 (FRAM 표) */
    if (flag.rack % 2 == 1) { x = save.fp.right_x[flag.col]; y = save.fp.right_y[flag.dan]; }   /* 홀수 렉 = 오른쪽 표 */
    else                    { x = save.fp.left_x[flag.col];  y = save.fp.left_y[flag.dan];  }   /* 짝수 렉 = 왼쪽 표 */
    int safe_y = save.fp.safe_y[flag.dan];                         /* 입고대 그 단 안전 높이 (MI) */

    state.rack = flag.rack;                                            /* 이 렉 운전 */
    if (state.now == 'S') state.prev = 'R';                     /* 출발 직전에 일시정지 눌림 : 풀면 운전 (첫 정지선에서 섬) */
    else state.now = 'R';
    if (flag.cmd == CMD_MI) move_done(flag, start, MI(safe_y, flag.lift_speed, flag.tilt_speed, flag.delay, flag.return_delay, flag.tilt_angle));
    if (flag.cmd == CMD_MO) move_done(flag, start, MO(x, y, flag.lift_speed, flag.tilt_speed, flag.delay, flag.return_delay, flag.tilt_angle));
    if (flag.cmd == CMD_PO) move_done(flag, start, PO(flag.rack, x, y, flag.dan, flag.lift_speed, flag.tilt_speed,
                                                        flag.delay, flag.return_delay, flag.tilt_angle, flag.tilt_check));
}

/* PO 가 서 있는 그 칸이 아직 만재면 1 (event.c btn_run 이 일시정지 풀기 전에 물음 → 치우고 RUN, 억지로는 PC D)
   지금 주문서는 큐에 남아 있으니 꺼내지 않고 보기만 (xQueuePeek, 0 = 안 기다림) */
int PO_manjae(void)
{
    MOVE flag;
    return xQueuePeek((QueueHandle_t)MoveQueueHandle, &flag, 0) == pdTRUE && flag.cmd == CMD_PO && manjae_on(flag.rack, flag.dan);
}
