#include "save.h"
#include "fram.h"
#include <string.h>

#define SAVE_MAGIC      0x0425  /* 우리 FRAM 표시 */
#define SAVE_VERSION    8       /* 구조 번호 : 7 = 덩어리마다 주소 (10/27). 6 은 통째로 0번지 → 7 로 처음 켜면 기본값 */
#define SPEED_MAX       3000    /* FP 11 : 모터 속도 최대 rpm (넘으면 저장 안 함) */

SAVE_Data save;               /* 설정 전체 (RAM). 저장은 바꾼 덩어리만 FRAM_Write(그 덩어리 주소, …) */


/* 네트워크 기본값 */
static void Network_Default(void)
{
    save.fi.ip[0] = 172;
    save.fi.ip[1] = 20;
    save.fi.ip[2] = 0;
    save.fi.ip[3] = 1;

    save.fi.sn[0] = 255;
    save.fi.sn[1] = 255;
    save.fi.sn[2] = 255;
    save.fi.sn[3] = 0;

    save.fi.gw[0] = 0;
    save.fi.gw[1] = 0;
    save.fi.gw[2] = 0;
    save.fi.gw[3] = 0;

    save.fi.dip[0] = 172;
    save.fi.dip[1] = 20;
    save.fi.dip[2] = 0;
    save.fi.dip[3] = 100;

    save.fi.port = 2500;
    save.fi.mode = 0;
    save.fi.timeout = 20000;
}

/* 거래처 PIMZ 기본 설정 (PC ALL_PIMZ) : FS + FP 를 이 값으로 → FRAM 저장. 성공 1 / 실패 0 (네트워크 FI 는 안 바꿈)
   거래처 추가 : 이 함수를 통째로 복사 → 이름(Setting_Default_거래처) · 값만 바꿈 → save.h 선언 + cmd.c CMD_ALL 에 한 줄 */

int Setting_Default_PIMZ(void)
{
    /* FS : 장비 / 위치 개수 */
    save.fs.rack = 1;
    save.fs.type = 'S';
    save.fs.rack_channel = 2;
    save.fs.in_x = 1;
    save.fs.in_y = 2;
    save.fs.left_x = 5;
    save.fs.left_y = 4;
    save.fs.right_x = 5;
    save.fs.right_y = 4;

    for (int i = 0; i < 5; i++)
        save.fs.option[i] = 0;

    /* FP 1 : 입고 X */
    save.fp.in_x = 1710;

    /* FP 2 : 입고 Y */
    save.fp.in_y[0] = 40;
    save.fp.in_y[1] = 690;
    save.fp.in_y[2] = 0;
    save.fp.in_y[3] = 0;
    save.fp.in_y[4] = 0;

    /* FP 3 : Left X */
    save.fp.left_x[0] = 1500;
    save.fp.left_x[1] = 1236;
    save.fp.left_x[2] = 824;
    save.fp.left_x[3] = 412;
    save.fp.left_x[4] = 0;
    save.fp.left_x[5] = 0;
    save.fp.left_x[6] = 0;
    save.fp.left_x[7] = 0;
    save.fp.left_x[8] = 0;

    /* FP 4 : Left Y */
    save.fp.left_y[0] = 0;
    save.fp.left_y[1] = 515;
    save.fp.left_y[2] = 1030;
    save.fp.left_y[3] = 1540;
    save.fp.left_y[4] = 0;
    save.fp.left_y[5] = 0;
    save.fp.left_y[6] = 0;
    save.fp.left_y[7] = 0;
    save.fp.left_y[8] = 0;

    /* FP 5 : Right X */
    save.fp.right_x[0] = 1500;
    save.fp.right_x[1] = 1236;
    save.fp.right_x[2] = 824;
    save.fp.right_x[3] = 412;
    save.fp.right_x[4] = 0;
    save.fp.right_x[5] = 0;
    save.fp.right_x[6] = 0;
    save.fp.right_x[7] = 0;
    save.fp.right_x[8] = 0;

    /* FP 6 : Right Y */
    save.fp.right_y[0] = 0;
    save.fp.right_y[1] = 515;
    save.fp.right_y[2] = 1030;
    save.fp.right_y[3] = 1540;
    save.fp.right_y[4] = 0;
    save.fp.right_y[5] = 0;
    save.fp.right_y[6] = 0;
    save.fp.right_y[7] = 0;
    save.fp.right_y[8] = 0;

    /* FP 7 : 리프트 / 틸팅 */
    save.fp.lift_y_offset = 0;
    save.fp.tilt_angle = 55;
    save.fp.tilting_y = 240;
    save.fp.tilting_y_speed = 60;
    save.fp.tilt_check_time = 3000;

    /* FP 8 ~ 10 : 오프셋 */
    save.fp.y_offset = 0;
    save.fp.tilt_offset = 0;
    save.fp.x_offset = 0;

    /* FP 11 : 속도 */
    save.fp.speed_x = 1000;
    save.fp.speed_tilt = 3000;
    save.fp.speed_y = 3000;

    /* FP 12 : 가감속 */
    save.fp.accdec_x = 0;
    save.fp.accdec_tilt = 0;
    save.fp.accdec_y = 0;

    /* FP 13 : 안전 위치 */
    save.fp.safe_x = 1618;
    save.fp.safe_y[0] = 0;
    save.fp.safe_y[1] = 650;
    save.fp.safe_y[2] = 0;
    save.fp.safe_y[3] = 0;
    save.fp.safe_y[4] = 0;

    return FRAM_Write(FS_ADDR, &save.fs, sizeof(save.fs))
        && FRAM_Write(FP_ADDR, &save.fp, sizeof(save.fp));
}


int Save_Init(void)
{
    /* HEAD 읽기 */
    if (FRAM_Read(HEAD_ADDR, &save.magic, sizeof(save.magic)) == 0)
        return 0;

    if (FRAM_Read(VER_ADDR, &save.version, sizeof(save.version)) == 0)
        return 0;

    /* 기존 설정 사용 */
    if (save.magic == SAVE_MAGIC && save.version == SAVE_VERSION)
    {
        return FRAM_Read(FS_ADDR, &save.fs, sizeof(save.fs))
            && FRAM_Read(FP_ADDR, &save.fp, sizeof(save.fp))
            && FRAM_Read(FI_ADDR, &save.fi, sizeof(save.fi));
    }

    /* 새로운 저장 구조 초기화 */
    memset(&save, 0, sizeof(save));

    save.magic = SAVE_MAGIC;
    save.version = SAVE_VERSION;
    Network_Default();

    /* FRAM 저장 */
    return FRAM_Write(FS_ADDR, &save.fs, sizeof(save.fs))
        && FRAM_Write(FP_ADDR, &save.fp, sizeof(save.fp))
        && FRAM_Write(FI_ADDR, &save.fi, sizeof(save.fi))
        && FRAM_Write(HEAD_ADDR, &save.magic, sizeof(save.magic))
        && FRAM_Write(VER_ADDR, &save.version, sizeof(save.version));
}
/* 장비 / 위치 개수 저장 */
int FS(int rack, char type, int rack_channel,
       int in_x, int in_y,
       int left_x, int left_y,
       int right_x, int right_y, int option)
{
    if (rack != 1)
        return 0;

    if (type != 'S' && type != 'I')
        return 0;

    if (rack_channel < 1 || rack_channel > 4)
        return 0;

    if (in_x != 1)
        return 0;

    if (in_y < 1 || in_y > 5)
        return 0;

    if (left_x < 1 || left_x > 9)
        return 0;

    if (left_y < 1 || left_y > 9)
        return 0;

    if (right_x < 1 || right_x > 9)
        return 0;

    if (right_y < 1 || right_y > 9)
        return 0;


    save.fs.rack = rack;

    /* 위치 개수가 바뀐 FP 그룹만 초기화 */
    if (save.fs.in_y != in_y) {
        memset(save.fp.in_y, 0, sizeof(save.fp.in_y));
        memset(save.fp.safe_y, 0, sizeof(save.fp.safe_y));
    }

    if (save.fs.left_x != left_x)
        memset(save.fp.left_x, 0, sizeof(save.fp.left_x));

    if (save.fs.left_y != left_y)
        memset(save.fp.left_y, 0, sizeof(save.fp.left_y));

    if (save.fs.right_x != right_x)
        memset(save.fp.right_x, 0, sizeof(save.fp.right_x));

    if (save.fs.right_y != right_y)
        memset(save.fp.right_y, 0, sizeof(save.fp.right_y));


    save.fs.type = type;
    save.fs.rack_channel = rack_channel;

    save.fs.in_x = in_x;
    save.fs.in_y = in_y;

    save.fs.left_x = left_x;
    save.fs.left_y = left_y;

    save.fs.right_x = right_x;
    save.fs.right_y = right_y;

    save.fs.option[0] = option / 10000 % 10;
    save.fs.option[1] = option / 1000 % 10;
    save.fs.option[2] = option / 100 % 10;
    save.fs.option[3] = option / 10 % 10;
    save.fs.option[4] = option % 10;          /* 틸팅검사 옵션 */

    return FRAM_Write(FS_ADDR, &save.fs, sizeof(save.fs))       /* FS 저장 */
        && FRAM_Write(FP_ADDR, &save.fp, sizeof(save.fp));      /* 안 쓰는 칸 0 으로 바꾼 FP 도 */
}

/* 위치값 저장 */
int FP(int rack, char no, int value[])
{
    rack = 1;

    switch (no)
    {
    case '1':   /* 입고 X */
        save.fp.in_x = value[0];
        break;

    case '2':  /* 입고 Y */
        memset(save.fp.in_y, 0, sizeof(save.fp.in_y));
        memcpy(save.fp.in_y, value,
               save.fs.in_y * sizeof(value[0]));
        break;

    case '3':  /* Left X */
        memset(save.fp.left_x, 0, sizeof(save.fp.left_x));
        memcpy(save.fp.left_x, value,
               save.fs.left_x * sizeof(value[0]));
        break;

    case '4':  /* Left Y */
        memset(save.fp.left_y, 0, sizeof(save.fp.left_y));
        memcpy(save.fp.left_y, value,
               save.fs.left_y * sizeof(value[0]));
        break;

    case '5':  /* Right X */
        memset(save.fp.right_x, 0, sizeof(save.fp.right_x));
        memcpy(save.fp.right_x, value,
               save.fs.right_x * sizeof(value[0]));
        break;

    case '6':  /* Right Y */
        memset(save.fp.right_y, 0, sizeof(save.fp.right_y));
        memcpy(save.fp.right_y, value,
               save.fs.right_y * sizeof(value[0]));
        break;

    case '7':  /* 리프트 / 틸팅 설정 */
        save.fp.lift_y_offset   = value[0];
        save.fp.tilt_angle      = value[1];
        save.fp.tilting_y       = value[2];
        save.fp.tilting_y_speed = value[3];
        save.fp.tilt_check_time = value[4];
        break;

    case '8':  /* Y offset */
        save.fp.y_offset += value[0];

        for (int i = 0; i < save.fs.in_y; i++)
            save.fp.in_y[i] += value[0];

        for (int i = 0; i < save.fs.left_y; i++)
            save.fp.left_y[i] += value[0];

        for (int i = 0; i < save.fs.right_y; i++)
            save.fp.right_y[i] += value[0];

        break;

    case '9':   /* Tilt offset */
        save.fp.tilt_offset += value[0];
        save.fp.tilt_angle += value[0];
        break;

    case ':':  /* 10 : X offset */
        save.fp.x_offset += value[0];
        save.fp.in_x += value[0];
        save.fp.safe_x += value[0];         /* 빠지는 점도 입고대와 같이 옮김 (빠지는 거리 in_x − safe_x 그대로) */

        for (int i = 0; i < save.fs.left_x; i++)
            save.fp.left_x[i] += value[0];

        for (int i = 0; i < save.fs.right_x; i++)
            save.fp.right_x[i] += value[0];

        break;

    case ';':   /* 11 : Speed : X, Tilt, Y (rpm, 0 = 기본값) */

        if (value[0] < 0 || value[0] > SPEED_MAX ||
            value[1] < 0 || value[1] > SPEED_MAX ||
            value[2] < 0 || value[2] > SPEED_MAX)
            return 0;               /* 범위 밖 : 저장 안 함 (NAK) */

        save.fp.speed_x    = value[0];
        save.fp.speed_tilt = value[1];
        save.fp.speed_y    = value[2];
        break;

    case '<':   /* 12 : Acc/Dec : X, Tilt, Y */

        save.fp.accdec_x    = value[0];
        save.fp.accdec_tilt = value[1];
        save.fp.accdec_y    = value[2];
        break;

    case '=':  /* 13 : 안전 X + 입고 단 수만큼 안전 Y */
        save.fp.safe_x = value[0];

        memset(save.fp.safe_y, 0, sizeof(save.fp.safe_y));
        memcpy(save.fp.safe_y, &value[1],
               save.fs.in_y * sizeof(value[0]));
        break;
    default:
        return 0;
    }

    return FRAM_Write(FP_ADDR, &save.fp, sizeof(save.fp));      /* FP 저장 */
}

/* 네트워크 설정 저장 */
int FI(int no, int value[])
{
    switch (no)
    {
    case 1:     /* IP */

        if (value[0] < 0 || value[0] > 255 ||
            value[1] < 0 || value[1] > 255 ||
            value[2] < 0 || value[2] > 255 ||
            value[3] < 0 || value[3] > 255)
            return 0;

        save.fi.ip[0] = value[0];
        save.fi.ip[1] = value[1];
        save.fi.ip[2] = value[2];
        save.fi.ip[3] = value[3];

        break;


    case 2:     /* Subnet Mask */

        if (value[0] < 0 || value[0] > 255 ||
            value[1] < 0 || value[1] > 255 ||
            value[2] < 0 || value[2] > 255 ||
            value[3] < 0 || value[3] > 255)
            return 0;

        save.fi.sn[0] = value[0];
        save.fi.sn[1] = value[1];
        save.fi.sn[2] = value[2];
        save.fi.sn[3] = value[3];

        break;


    case 3:     /* Gateway */

        if (value[0] < 0 || value[0] > 255 ||
            value[1] < 0 || value[1] > 255 ||
            value[2] < 0 || value[2] > 255 ||
            value[3] < 0 || value[3] > 255)
            return 0;

        save.fi.gw[0] = value[0];
        save.fi.gw[1] = value[1];
        save.fi.gw[2] = value[2];
        save.fi.gw[3] = value[3];

        break;


    case 4:     /* Destination IP */

        if (value[0] < 0 || value[0] > 255 ||
            value[1] < 0 || value[1] > 255 ||
            value[2] < 0 || value[2] > 255 ||
            value[3] < 0 || value[3] > 255)
            return 0;

        save.fi.dip[0] = value[0];
        save.fi.dip[1] = value[1];
        save.fi.dip[2] = value[2];
        save.fi.dip[3] = value[3];

        break;

    case 5:     /* PORT */

        if (value[0] < 1 || value[0] > 65535)
            return 0;

        save.fi.port = value[0];

        break;

    case 6:     /* MODE : 0=Server, 1=Client */

        if (value[0] < 0 || value[0] > 1)
            return 0;

        save.fi.mode = value[0];

        break;

    case 7:     /* Timeout : 10000~60000ms */

        if (value[0] < 10000 || value[0] > 60000)
            return 0;

        save.fi.timeout = value[0];

        break;


    default:
        return 0;
    }


    return FRAM_Write(FI_ADDR, &save.fi, sizeof(save.fi));      /* FI 저장 (재부팅 후 적용) */
}

/* 네트워크 기본값 복구 */
int FD(void)
{
    Network_Default();

    return FRAM_Write(FI_ADDR, &save.fi, sizeof(save.fi));      /* FI 저장 (재부팅 후 적용) */
}

