#include "save.h"
#include "fram.h"
#include <string.h>

#define SAVE_MAGIC      0x0425  /* 우리 FRAM 표시 */
#define SAVE_VERSION    7       /* 구조 번호 : 7 = 덩어리마다 주소 (10/27). 6 은 통째로 0번지 → 7 로 처음 켜면 기본값 */
#define SPEED_MAX       3000    /* FP 11 : 모터 속도 최대 rpm (넘으면 저장 안 함) */

SAVE_Data save;               /* 설정 전체 (RAM). 저장은 바꾼 덩어리만 FRAM_Write(그 덩어리 주소, …) */


/* 네트워크 기본값 */
static void Network_Default(void)
{
    save.fi.ip[0] = 172;
    save.fi.ip[1] = 20;
    save.fi.ip[2] = 0;
    save.fi.ip[3] = 1;

    save.fi.sn[0] = 255;
    save.fi.sn[1] = 255;
    save.fi.sn[2] = 255;
    save.fi.sn[3] = 0;

    save.fi.gw[0] = 0;
    save.fi.gw[1] = 0;
    save.fi.gw[2] = 0;
    save.fi.gw[3] = 0;

    save.fi.dip[0] = 172;
    save.fi.dip[1] = 20;
    save.fi.dip[2] = 0;
    save.fi.dip[3] = 100;

    save.fi.port = 2500;
    save.fi.mode = 0;
    save.fi.timeout = 20000;
}

/* 거래처 PIMZ 기본 설정 (PC ALL_PIMZ) : FS + FP 를 이 값으로 → FRAM 저장. 성공 1 / 실패 0 (네트워크 FI 는 안 바꿈)
   거래처 추가 : 이 함수를 통째로 복사 → 이름(Setting_Default_거래처) · 값만 바꿈 → save.h 선언 + cmd.c CMD_ALL 에 한 줄 */
int Setting_Default_PIMZ(void)
{
    /* FS : 장비 / 위치 개수 */
    save.fs.rack = 1;
    save.fs.type = 'S';
    save.fs.rack_channel = 2;
    save.fs.in_x = 1;
    save.fs.in_y = 2;
    save.fs.left_x = 5;
    save.fs.left_y = 4;
    save.fs.right_x = 5;
    save.fs.right_y = 4;

    /* FP 1 : 입고 X */
    save.fp.in_x = 1710;

    /* FP 2 : 입고 Y */
    save.fp.in_y1 = 40;
    save.fp.in_y2 = 690;
    save.fp.in_y3 = 0;
    save.fp.in_y4 = 0;
    save.fp.in_y5 = 0;

    /* FP 3 : Left X */
    save.fp.left_x1 = 1500;
    save.fp.left_x2 = 1236;
    save.fp.left_x3 = 824;
    save.fp.left_x4 = 412;
    save.fp.left_x5 = 0;
    save.fp.left_x6 = 0;
    save.fp.left_x7 = 0;
    save.fp.left_x8 = 0;
    save.fp.left_x9 = 0;

    /* FP 4 : Left Y */
    save.fp.left_y1 = 0;
    save.fp.left_y2 = 515;
    save.fp.left_y3 = 1030;
    save.fp.left_y4 = 1540;
    save.fp.left_y5 = 0;
    save.fp.left_y6 = 0;
    save.fp.left_y7 = 0;
    save.fp.left_y8 = 0;
    save.fp.left_y9 = 0;

    /* FP 5 : Right X */
    save.fp.right_x1 = 1500;
    save.fp.right_x2 = 1236;
    save.fp.right_x3 = 824;
    save.fp.right_x4 = 412;
    save.fp.right_x5 = 0;
    save.fp.right_x6 = 0;
    save.fp.right_x7 = 0;
    save.fp.right_x8 = 0;
    save.fp.right_x9 = 0;

    /* FP 6 : Right Y */
    save.fp.right_y1 = 0;
    save.fp.right_y2 = 515;
    save.fp.right_y3 = 1030;
    save.fp.right_y4 = 1540;
    save.fp.right_y5 = 0;
    save.fp.right_y6 = 0;
    save.fp.right_y7 = 0;
    save.fp.right_y8 = 0;
    save.fp.right_y9 = 0;

    /* FP 7 : 리프트 옵셋 · 틸팅 각도 · 틸팅 Y · 틸팅 속도 */
    save.fp.lift_y_offset = 0;
    save.fp.tilt_angle = 55;
    save.fp.tilting_y = 240;
    save.fp.tilting_y_speed = 60;

    /* FP 8 · 9 · 10 : Y · 틸트 · X offset */
    save.fp.y_offset = 0;
    save.fp.tilt_offset = 0;
    save.fp.x_offset = 0;

    /* FP 11 : 속도 X · 틸트 · Y (rpm) */
    save.fp.speed_x = 1000;
    save.fp.speed_tilt = 3000;
    save.fp.speed_y = 3000;

    /* FP 12 : 가감속 X · 틸트 · Y (0 = 기본값) */
    save.fp.accdec_x = 0;
    save.fp.accdec_tilt = 0;
    save.fp.accdec_y = 0;

    /* FP 13 : 안전 위치 X · Y */
    save.fp.safe_x = 1618;
    save.fp.safe_y = 0;

    return FRAM_Write(FS_ADDR, &save.fs, sizeof(save.fs))       /* FS 저장 */
        && FRAM_Write(FP_ADDR, &save.fp, sizeof(save.fp));      /* FP 저장 */
}

/* 전원 켤 때 한 번 (Comm_Task) : FRAM 지도대로 덩어리마다 읽기 → 우리 표시 · 구조 번호 맞으면 그대로 */
int Save_Init(void)
{
    if (FRAM_Read(HEAD_ADDR, &save.magic, sizeof(save.magic)) &&
        FRAM_Read(HEAD_ADDR + 2, &save.version, sizeof(save.version)) &&
        FRAM_Read(FS_ADDR, &save.fs, sizeof(save.fs)) &&
        FRAM_Read(FP_ADDR, &save.fp, sizeof(save.fp)) &&
        FRAM_Read(FI_ADDR, &save.fi, sizeof(save.fi)) &&
        save.magic == SAVE_MAGIC && save.version == SAVE_VERSION)
        return 1;

    /* 처음 켬 · 구조 번호 바뀜 : 전부 0 + 네트워크 기본값 → 전부 저장 (FS · FP 는 PC 에서 다시 넣기, ALL_PIMZ) */
    memset(&save, 0, sizeof(save));
    save.magic = SAVE_MAGIC;
    save.version = SAVE_VERSION;
    Network_Default();

    return FRAM_Write(HEAD_ADDR, &save.magic, sizeof(save.magic))
        && FRAM_Write(HEAD_ADDR + 2, &save.version, sizeof(save.version))
        && FRAM_Write(FS_ADDR, &save.fs, sizeof(save.fs))
        && FRAM_Write(FP_ADDR, &save.fp, sizeof(save.fp))
        && FRAM_Write(FI_ADDR, &save.fi, sizeof(save.fi));
}

/* 장비 / 위치 개수 저장 */
int FS(int rack, char type, int rack_channel,
       int in_x, int in_y,
       int left_x, int left_y,
       int right_x, int right_y)
{
    if (rack != 1)
        return 0;

    if (type != 'S' && type != 'I')
        return 0;

    if (rack_channel < 1 || rack_channel > 4)
        return 0;

    if (in_x != 1)
        return 0;

    if (in_y < 1 || in_y > 5)
        return 0;

    if (left_x < 1 || left_x > 9)
        return 0;

    if (left_y < 1 || left_y > 9)
        return 0;

    if (right_x < 1 || right_x > 9)
        return 0;

    if (right_y < 1 || right_y > 9)
        return 0;

    save.fs.rack = rack;
    save.fs.type = type;
    save.fs.rack_channel = rack_channel;

    save.fs.in_x = in_x;
    save.fs.in_y = in_y;

    save.fs.left_x = left_x;
    save.fs.left_y = left_y;

    save.fs.right_x = right_x;
    save.fs.right_y = right_y;

    /* FS에서 사용하지 않는 위치는 0 */
    if (in_y < 5) save.fp.in_y5 = 0;
    if (in_y < 4) save.fp.in_y4 = 0;
    if (in_y < 3) save.fp.in_y3 = 0;
    if (in_y < 2) save.fp.in_y2 = 0;

    if (left_x < 9) save.fp.left_x9 = 0;
    if (left_x < 8) save.fp.left_x8 = 0;
    if (left_x < 7) save.fp.left_x7 = 0;
    if (left_x < 6) save.fp.left_x6 = 0;
    if (left_x < 5) save.fp.left_x5 = 0;
    if (left_x < 4) save.fp.left_x4 = 0;
    if (left_x < 3) save.fp.left_x3 = 0;
    if (left_x < 2) save.fp.left_x2 = 0;

    if (left_y < 9) save.fp.left_y9 = 0;
    if (left_y < 8) save.fp.left_y8 = 0;
    if (left_y < 7) save.fp.left_y7 = 0;
    if (left_y < 6) save.fp.left_y6 = 0;
    if (left_y < 5) save.fp.left_y5 = 0;
    if (left_y < 4) save.fp.left_y4 = 0;
    if (left_y < 3) save.fp.left_y3 = 0;
    if (left_y < 2) save.fp.left_y2 = 0;

    if (right_x < 9) save.fp.right_x9 = 0;
    if (right_x < 8) save.fp.right_x8 = 0;
    if (right_x < 7) save.fp.right_x7 = 0;
    if (right_x < 6) save.fp.right_x6 = 0;
    if (right_x < 5) save.fp.right_x5 = 0;
    if (right_x < 4) save.fp.right_x4 = 0;
    if (right_x < 3) save.fp.right_x3 = 0;
    if (right_x < 2) save.fp.right_x2 = 0;

    if (right_y < 9) save.fp.right_y9 = 0;
    if (right_y < 8) save.fp.right_y8 = 0;
    if (right_y < 7) save.fp.right_y7 = 0;
    if (right_y < 6) save.fp.right_y6 = 0;
    if (right_y < 5) save.fp.right_y5 = 0;
    if (right_y < 4) save.fp.right_y4 = 0;
    if (right_y < 3) save.fp.right_y3 = 0;
    if (right_y < 2) save.fp.right_y2 = 0;

    return FRAM_Write(FS_ADDR, &save.fs, sizeof(save.fs))       /* FS 저장 */
        && FRAM_Write(FP_ADDR, &save.fp, sizeof(save.fp));      /* 안 쓰는 칸 0 으로 바꾼 FP 도 */
}

/* 위치값 저장 */
int FP(int rack, char no, int value[], int count)
{
    rack = 1;

    switch (no)
    {
    case '1':   /* 입고 X */
        if (count != 1)
            return 0;

        save.fp.in_x = value[0];
        break;

    case '2':   /* 입고 Y */
        if (count != save.fs.in_y)
            return 0;

        save.fp.in_y1 = 0;
        save.fp.in_y2 = 0;
        save.fp.in_y3 = 0;
        save.fp.in_y4 = 0;
        save.fp.in_y5 = 0;

        if (count >= 1) save.fp.in_y1 = value[0];
        if (count >= 2) save.fp.in_y2 = value[1];
        if (count >= 3) save.fp.in_y3 = value[2];
        if (count >= 4) save.fp.in_y4 = value[3];
        if (count >= 5) save.fp.in_y5 = value[4];
        break;

    case '3':   /* Left X */
        if (count != save.fs.left_x)
            return 0;

        save.fp.left_x1 = 0;
        save.fp.left_x2 = 0;
        save.fp.left_x3 = 0;
        save.fp.left_x4 = 0;
        save.fp.left_x5 = 0;
        save.fp.left_x6 = 0;
        save.fp.left_x7 = 0;
        save.fp.left_x8 = 0;
        save.fp.left_x9 = 0;

        if (count >= 1) save.fp.left_x1 = value[0];
        if (count >= 2) save.fp.left_x2 = value[1];
        if (count >= 3) save.fp.left_x3 = value[2];
        if (count >= 4) save.fp.left_x4 = value[3];
        if (count >= 5) save.fp.left_x5 = value[4];
        if (count >= 6) save.fp.left_x6 = value[5];
        if (count >= 7) save.fp.left_x7 = value[6];
        if (count >= 8) save.fp.left_x8 = value[7];
        if (count >= 9) save.fp.left_x9 = value[8];
        break;

    case '4':   /* Left Y */
        if (count != save.fs.left_y)
            return 0;

        save.fp.left_y1 = 0;
        save.fp.left_y2 = 0;
        save.fp.left_y3 = 0;
        save.fp.left_y4 = 0;
        save.fp.left_y5 = 0;
        save.fp.left_y6 = 0;
        save.fp.left_y7 = 0;
        save.fp.left_y8 = 0;
        save.fp.left_y9 = 0;

        if (count >= 1) save.fp.left_y1 = value[0];
        if (count >= 2) save.fp.left_y2 = value[1];
        if (count >= 3) save.fp.left_y3 = value[2];
        if (count >= 4) save.fp.left_y4 = value[3];
        if (count >= 5) save.fp.left_y5 = value[4];
        if (count >= 6) save.fp.left_y6 = value[5];
        if (count >= 7) save.fp.left_y7 = value[6];
        if (count >= 8) save.fp.left_y8 = value[7];
        if (count >= 9) save.fp.left_y9 = value[8];
        break;

    case '5':   /* Right X */
        if (count != save.fs.right_x)
            return 0;

        save.fp.right_x1 = 0;
        save.fp.right_x2 = 0;
        save.fp.right_x3 = 0;
        save.fp.right_x4 = 0;
        save.fp.right_x5 = 0;
        save.fp.right_x6 = 0;
        save.fp.right_x7 = 0;
        save.fp.right_x8 = 0;
        save.fp.right_x9 = 0;

        if (count >= 1) save.fp.right_x1 = value[0];
        if (count >= 2) save.fp.right_x2 = value[1];
        if (count >= 3) save.fp.right_x3 = value[2];
        if (count >= 4) save.fp.right_x4 = value[3];
        if (count >= 5) save.fp.right_x5 = value[4];
        if (count >= 6) save.fp.right_x6 = value[5];
        if (count >= 7) save.fp.right_x7 = value[6];
        if (count >= 8) save.fp.right_x8 = value[7];
        if (count >= 9) save.fp.right_x9 = value[8];
        break;

    case '6':   /* Right Y */
        if (count != save.fs.right_y)
            return 0;

        save.fp.right_y1 = 0;
        save.fp.right_y2 = 0;
        save.fp.right_y3 = 0;
        save.fp.right_y4 = 0;
        save.fp.right_y5 = 0;
        save.fp.right_y6 = 0;
        save.fp.right_y7 = 0;
        save.fp.right_y8 = 0;
        save.fp.right_y9 = 0;

        if (count >= 1) save.fp.right_y1 = value[0];
        if (count >= 2) save.fp.right_y2 = value[1];
        if (count >= 3) save.fp.right_y3 = value[2];
        if (count >= 4) save.fp.right_y4 = value[3];
        if (count >= 5) save.fp.right_y5 = value[4];
        if (count >= 6) save.fp.right_y6 = value[5];
        if (count >= 7) save.fp.right_y7 = value[6];
        if (count >= 8) save.fp.right_y8 = value[7];
        if (count >= 9) save.fp.right_y9 = value[8];
        break;

    case '7':   /* Lift / Tilt */
        if (count != 4)
            return 0;

        save.fp.lift_y_offset   = value[0];
        save.fp.tilt_angle      = value[1];
        save.fp.tilting_y       = value[2];
        save.fp.tilting_y_speed = value[3];
        break;

    case '8':   /* Y offset */
        if (count != 1)
            return 0;

        save.fp.y_offset += value[0];

        if (save.fs.in_y >= 1) save.fp.in_y1 += value[0];
        if (save.fs.in_y >= 2) save.fp.in_y2 += value[0];
        if (save.fs.in_y >= 3) save.fp.in_y3 += value[0];
        if (save.fs.in_y >= 4) save.fp.in_y4 += value[0];
        if (save.fs.in_y >= 5) save.fp.in_y5 += value[0];

        if (save.fs.left_y >= 1) save.fp.left_y1 += value[0];
        if (save.fs.left_y >= 2) save.fp.left_y2 += value[0];
        if (save.fs.left_y >= 3) save.fp.left_y3 += value[0];
        if (save.fs.left_y >= 4) save.fp.left_y4 += value[0];
        if (save.fs.left_y >= 5) save.fp.left_y5 += value[0];
        if (save.fs.left_y >= 6) save.fp.left_y6 += value[0];
        if (save.fs.left_y >= 7) save.fp.left_y7 += value[0];
        if (save.fs.left_y >= 8) save.fp.left_y8 += value[0];
        if (save.fs.left_y >= 9) save.fp.left_y9 += value[0];

        if (save.fs.right_y >= 1) save.fp.right_y1 += value[0];
        if (save.fs.right_y >= 2) save.fp.right_y2 += value[0];
        if (save.fs.right_y >= 3) save.fp.right_y3 += value[0];
        if (save.fs.right_y >= 4) save.fp.right_y4 += value[0];
        if (save.fs.right_y >= 5) save.fp.right_y5 += value[0];
        if (save.fs.right_y >= 6) save.fp.right_y6 += value[0];
        if (save.fs.right_y >= 7) save.fp.right_y7 += value[0];
        if (save.fs.right_y >= 8) save.fp.right_y8 += value[0];
        if (save.fs.right_y >= 9) save.fp.right_y9 += value[0];
        break;

    case '9':   /* Tilt offset */
        if (count != 1)
            return 0;

        save.fp.tilt_offset += value[0];
        save.fp.tilt_angle += value[0];
        break;

    case ':':   /* 10 : X offset */
        if (count != 1)
            return 0;

        save.fp.x_offset += value[0];
        save.fp.in_x += value[0];

        if (save.fs.left_x >= 1) save.fp.left_x1 += value[0];
        if (save.fs.left_x >= 2) save.fp.left_x2 += value[0];
        if (save.fs.left_x >= 3) save.fp.left_x3 += value[0];
        if (save.fs.left_x >= 4) save.fp.left_x4 += value[0];
        if (save.fs.left_x >= 5) save.fp.left_x5 += value[0];
        if (save.fs.left_x >= 6) save.fp.left_x6 += value[0];
        if (save.fs.left_x >= 7) save.fp.left_x7 += value[0];
        if (save.fs.left_x >= 8) save.fp.left_x8 += value[0];
        if (save.fs.left_x >= 9) save.fp.left_x9 += value[0];

        if (save.fs.right_x >= 1) save.fp.right_x1 += value[0];
        if (save.fs.right_x >= 2) save.fp.right_x2 += value[0];
        if (save.fs.right_x >= 3) save.fp.right_x3 += value[0];
        if (save.fs.right_x >= 4) save.fp.right_x4 += value[0];
        if (save.fs.right_x >= 5) save.fp.right_x5 += value[0];
        if (save.fs.right_x >= 6) save.fp.right_x6 += value[0];
        if (save.fs.right_x >= 7) save.fp.right_x7 += value[0];
        if (save.fs.right_x >= 8) save.fp.right_x8 += value[0];
        if (save.fs.right_x >= 9) save.fp.right_x9 += value[0];
        break;

    case ';':   /* 11 : Speed : X, Tilt, Y (rpm, 0 = 기본값) */
        if (count != 3)
            return 0;
        if (value[0] < 0 || value[0] > SPEED_MAX ||
            value[1] < 0 || value[1] > SPEED_MAX ||
            value[2] < 0 || value[2] > SPEED_MAX)
            return 0;               /* 범위 밖 : 저장 안 함 (NAK) */

        save.fp.speed_x    = value[0];
        save.fp.speed_tilt = value[1];
        save.fp.speed_y    = value[2];
        break;

    case '<':   /* 12 : Acc/Dec : X, Tilt, Y */
        if (count != 3)
            return 0;

        save.fp.accdec_x    = value[0];
        save.fp.accdec_tilt = value[1];
        save.fp.accdec_y    = value[2];
        break;

    case '=':   /* 13 : 안전위치 : X, Y */
        if (count != 2)
            return 0;

        save.fp.safe_x = value[0];
        save.fp.safe_y = value[1];

        break;

    default:
        return 0;
    }

    return FRAM_Write(FP_ADDR, &save.fp, sizeof(save.fp));      /* FP 저장 */
}

/* 네트워크 설정 저장 */
int FI(int no, int value[], int count)
{
    switch (no)
    {
    case 1:     /* IP */

        if (value[0] < 0 || value[0] > 255 ||
            value[1] < 0 || value[1] > 255 ||
            value[2] < 0 || value[2] > 255 ||
            value[3] < 0 || value[3] > 255)
            return 0;

        save.fi.ip[0] = value[0];
        save.fi.ip[1] = value[1];
        save.fi.ip[2] = value[2];
        save.fi.ip[3] = value[3];

        break;


    case 2:     /* Subnet Mask */

        if (value[0] < 0 || value[0] > 255 ||
            value[1] < 0 || value[1] > 255 ||
            value[2] < 0 || value[2] > 255 ||
            value[3] < 0 || value[3] > 255)
            return 0;

        save.fi.sn[0] = value[0];
        save.fi.sn[1] = value[1];
        save.fi.sn[2] = value[2];
        save.fi.sn[3] = value[3];

        break;


    case 3:     /* Gateway */

        if (value[0] < 0 || value[0] > 255 ||
            value[1] < 0 || value[1] > 255 ||
            value[2] < 0 || value[2] > 255 ||
            value[3] < 0 || value[3] > 255)
            return 0;

        save.fi.gw[0] = value[0];
        save.fi.gw[1] = value[1];
        save.fi.gw[2] = value[2];
        save.fi.gw[3] = value[3];

        break;


    case 4:     /* Destination IP */

        if (value[0] < 0 || value[0] > 255 ||
            value[1] < 0 || value[1] > 255 ||
            value[2] < 0 || value[2] > 255 ||
            value[3] < 0 || value[3] > 255)
            return 0;

        save.fi.dip[0] = value[0];
        save.fi.dip[1] = value[1];
        save.fi.dip[2] = value[2];
        save.fi.dip[3] = value[3];

        break;

    case 5:     /* PORT */

        if (value[0] < 1 || value[0] > 65535)
            return 0;

        save.fi.port = value[0];

        break;

    case 6:     /* MODE : 0=Server, 1=Client */

        if (value[0] < 0 || value[0] > 1)
            return 0;

        save.fi.mode = value[0];

        break;

    case 7:     /* Timeout : 10000~60000ms */

        if (value[0] < 10000 || value[0] > 60000)
            return 0;

        save.fi.timeout = value[0];

        break;


    default:
        return 0;
    }


    return FRAM_Write(FI_ADDR, &save.fi, sizeof(save.fi));      /* FI 저장 (재부팅 후 적용) */
}

/* 네트워크 기본값 복구 */
int FD(void)
{
    Network_Default();

    return FRAM_Write(FI_ADDR, &save.fi, sizeof(save.fi));      /* FI 저장 (재부팅 후 적용) */
}

/* 좌표 찾기 (run.c Order_Set 이 부름) : 렉 · 열 · 단 → FRAM 표의 x, y (in 1 = 입고 표 / 홀수 렉 = 오른쪽 표 / 짝수 렉 = 왼쪽 표) */
void Save_XY(int in, int rack, int col, int dan, int *x, int *y)
{
    if (in)                                      /* 입고 */
    {
        *x = save.fp.in_x;

        if (dan == 1) *y = save.fp.in_y1;
        else if (dan == 2) *y = save.fp.in_y2;
        else if (dan == 3) *y = save.fp.in_y3;
        else if (dan == 4) *y = save.fp.in_y4;
        else if (dan == 5) *y = save.fp.in_y5;
        return;
    }

    if (rack % 2 == 1)                                /* 홀수 렉 = 오른쪽 표 */
    {
        if (col == 1) *x = save.fp.right_x1;
        else if (col == 2) *x = save.fp.right_x2;
        else if (col == 3) *x = save.fp.right_x3;
        else if (col == 4) *x = save.fp.right_x4;
        else if (col == 5) *x = save.fp.right_x5;
        else if (col == 6) *x = save.fp.right_x6;
        else if (col == 7) *x = save.fp.right_x7;
        else if (col == 8) *x = save.fp.right_x8;
        else if (col == 9) *x = save.fp.right_x9;

        if (dan == 1) *y = save.fp.right_y1;
        else if (dan == 2) *y = save.fp.right_y2;
        else if (dan == 3) *y = save.fp.right_y3;
        else if (dan == 4) *y = save.fp.right_y4;
        else if (dan == 5) *y = save.fp.right_y5;
        else if (dan == 6) *y = save.fp.right_y6;
        else if (dan == 7) *y = save.fp.right_y7;
        else if (dan == 8) *y = save.fp.right_y8;
        else if (dan == 9) *y = save.fp.right_y9;
    }
    else                                                    /* 짝수 렉 = 왼쪽 표 */
    {
        if (col == 1) *x = save.fp.left_x1;
        else if (col == 2) *x = save.fp.left_x2;
        else if (col == 3) *x = save.fp.left_x3;
        else if (col == 4) *x = save.fp.left_x4;
        else if (col == 5) *x = save.fp.left_x5;
        else if (col == 6) *x = save.fp.left_x6;
        else if (col == 7) *x = save.fp.left_x7;
        else if (col == 8) *x = save.fp.left_x8;
        else if (col == 9) *x = save.fp.left_x9;

        if (dan == 1) *y = save.fp.left_y1;
        else if (dan == 2) *y = save.fp.left_y2;
        else if (dan == 3) *y = save.fp.left_y3;
        else if (dan == 4) *y = save.fp.left_y4;
        else if (dan == 5) *y = save.fp.left_y5;
        else if (dan == 6) *y = save.fp.left_y6;
        else if (dan == 7) *y = save.fp.left_y7;
        else if (dan == 8) *y = save.fp.left_y8;
        else if (dan == 9) *y = save.fp.left_y9;
    }
}
