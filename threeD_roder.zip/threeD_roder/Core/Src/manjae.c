/*
 * manjae.c
 *
 *  Created on: Oct 1, 2026
 *      Author: HWNOT
 */
#include "main.h"
#include "manjae.h"
#include "event.h"
#include "run.h"
#include <stdio.h>

volatile int full_event_on;   /* 1 = 보낼 만재 이벤트 있음 */

/* 만재 : 0 = 빈칸, 1 = 만재 */
int full_1_1 = 0;
int full_1_2 = 0;
int full_1_3 = 0;
int full_1_4 = 0;

int full_2_1 = 0;
int full_2_2 = 0;
int full_2_3 = 0;
int full_2_4 = 0;

int full_1 = 0;         /* 1 = 렉1 만재 칸 하나라도 */
int full_2 = 0;         /* 1 = 렉2 만재 칸 하나라도 */


/* 만재 센서 읽기 (Event_Task) : 바뀐 게 있으면 칸마다 변수에 적고 1. 0V(LOW) = 만재 */
int Full_Read(void)
{
    static uint32_t last = 0;                 /* 지난번 센서 8칸 */
    uint32_t now = GPIOE->IDR & 0x7F80;       /* 지금 센서 8칸 (E 포트 7~14 번 핀을 한 번에) */

    if (now == last) return 0;                /* 하나도 안 바뀜 : 할 일 없음 */
    last = now;

    /* 바뀜 : 칸마다 적기 (LOW = 만재) */
    /* 렉1 (오른쪽) : DI1~4 */
    full_1_1 = HAL_GPIO_ReadPin(FULL_1_1_GPIO_Port, FULL_1_1_Pin) ? 0 : 1;
    full_1_2 = HAL_GPIO_ReadPin(FULL_1_2_GPIO_Port, FULL_1_2_Pin) ? 0 : 1;
    full_1_3 = HAL_GPIO_ReadPin(FULL_1_3_GPIO_Port, FULL_1_3_Pin) ? 0 : 1;
    full_1_4 = HAL_GPIO_ReadPin(FULL_1_4_GPIO_Port, FULL_1_4_Pin) ? 0 : 1;

    /* 렉2 (왼쪽) : DI5~8 */
    full_2_1 = HAL_GPIO_ReadPin(FULL_2_1_GPIO_Port, FULL_2_1_Pin) ? 0 : 1;
    full_2_2 = HAL_GPIO_ReadPin(FULL_2_2_GPIO_Port, FULL_2_2_Pin) ? 0 : 1;
    full_2_3 = HAL_GPIO_ReadPin(FULL_2_3_GPIO_Port, FULL_2_3_Pin) ? 0 : 1;
    full_2_4 = HAL_GPIO_ReadPin(FULL_2_4_GPIO_Port, FULL_2_4_Pin) ? 0 : 1;

    full_1 = full_1_1 || full_1_2 || full_1_3 || full_1_4;
    full_2 = full_2_1 || full_2_2 || full_2_3 || full_2_4;
    return 1;
}

/* 그 렉 그 단 만재 : 1 = 만재 (단 1~4, 렉1 = 오른쪽 / 렉2 = 왼쪽) */
int floor_full(int rack, int dan)
{
    if (rack == 1) {
        if (dan == 1) return full_1_1;
        if (dan == 2) return full_1_2;
        if (dan == 3) return full_1_3;
        if (dan == 4) return full_1_4;
    }
    else {
        if (dan == 1) return full_2_1;
        if (dan == 2) return full_2_2;
        if (dan == 3) return full_2_3;
        if (dan == 4) return full_2_4;
    }
    return 0;
}


