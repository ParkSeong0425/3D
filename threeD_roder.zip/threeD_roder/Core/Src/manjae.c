/*
 * manjae.c : 만재 센서 읽기만 (핀을 그때그때 직접 읽음)
 *
 *  manjae_off(rack, dan) : 그 단 빈칸이면 1   (핀 그대로 : 3.3V = 빈칸)
 *  manjae_on(rack, dan)  : 그 단 만재면 1     (빈칸의 반대)
 *  manjae_change()       : 8칸 중 하나라도 바뀌었으면 1 (PC 알림 · 부저용)
 *  Manjae_Text(b, size)  : 프로토콜 글자 F_1_0001&F_2_0000 (FF 이벤트 · C 대답)
 *  Manjae_PC()           : (Comm_Task) 바뀌었으면 PC 로 FF_1_0001&F_2_0000
 *
 *  렉1 = 오른쪽 (DI1~4), 렉2 = 왼쪽 (DI5~8)
 *
 *  Created on: Oct 1, 2026
 *      Author: HWNOT
 */
#include "main.h"
#include "manjae.h"
#include "net.h"
#include <stdio.h>

volatile int full_event_on;   /* 1 = 보낼 만재 이벤트 있음 */


/* 그 렉 그 단 빈칸 : 1 = 빈칸 (핀 그대로 : 3.3V = 빈칸, 0V = 만재) */
int manjae_off(int rack, int dan)
{
    if (rack == 1 && dan == 1) return HAL_GPIO_ReadPin(FULL_1_1_GPIO_Port, FULL_1_1_Pin);    /* 렉1 (오른쪽) */
    if (rack == 1 && dan == 2) return HAL_GPIO_ReadPin(FULL_1_2_GPIO_Port, FULL_1_2_Pin);
    if (rack == 1 && dan == 3) return HAL_GPIO_ReadPin(FULL_1_3_GPIO_Port, FULL_1_3_Pin);
    if (rack == 1 && dan == 4) return HAL_GPIO_ReadPin(FULL_1_4_GPIO_Port, FULL_1_4_Pin);

    if (rack == 2 && dan == 1) return HAL_GPIO_ReadPin(FULL_2_1_GPIO_Port, FULL_2_1_Pin);    /* 렉2 (왼쪽) */
    if (rack == 2 && dan == 2) return HAL_GPIO_ReadPin(FULL_2_2_GPIO_Port, FULL_2_2_Pin);
    if (rack == 2 && dan == 3) return HAL_GPIO_ReadPin(FULL_2_3_GPIO_Port, FULL_2_3_Pin);
    if (rack == 2 && dan == 4) return HAL_GPIO_ReadPin(FULL_2_4_GPIO_Port, FULL_2_4_Pin);

    return 1;                   /* 없는 칸 (렉 3 · 4, 5단) = 빈칸 */
}

/* 그 렉 그 단 만재 : 1 = 만재 (빈칸의 반대) */
int manjae_on(int rack, int dan)
{
    return manjae_off(rack, dan) == 0;
}

/* 만재 바뀜 : 센서 8칸 (PE7 ~ PE14) 중 하나라도 지난번과 다르면 1 */
int manjae_change(void)
{
    static uint32_t last;                       /* 지난번 8칸 */
    uint32_t now = GPIOE->IDR & 0x7F80;         /* 지금 8칸 한 번에 */

    if (now == last) return 0;                  /* 그대로 */
    last = now;
    return 1;                                   /* 바뀜 */
}

/* 프로토콜 글자 : F_1_0001&F_2_0000 (렉1 · 렉2 의 1 ~ 4단, 1 = 만재) — FF 이벤트 · C 대답이 같이 씀 */
void Manjae_Text(char *b, int size)
{
    snprintf(b, size, "F_1_%d%d%d%d&F_2_%d%d%d%d",
             manjae_on(1, 1), manjae_on(1, 2), manjae_on(1, 3), manjae_on(1, 4),
             manjae_on(2, 1), manjae_on(2, 2), manjae_on(2, 3), manjae_on(2, 4));
}

/* PC 로 FF (Comm_Task) : 센서가 바뀌었으면(full_event_on, event.c) FF_1_0001&F_2_0000 */
void Manjae_PC(void)
{
    char b[32];

    if (full_event_on == 0) return;             /* 보낼 것 없음 */
    full_event_on = 0;                          /* 보내기 전에 0 */
    b[0] = 'F';                                 /* FF = F + F_1_… */
    Manjae_Text(b + 1, sizeof(b) - 1);
    send_event(b);
}
