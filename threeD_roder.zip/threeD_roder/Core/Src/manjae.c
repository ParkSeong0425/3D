/*
 * manjae.c : 만재 센서 8칸 — 만재 변수 · 판단은 전부 여기 (다른 파일은 함수 부르기 · 읽기만)
 *
 *  manjae_on(rack, dan)        지금 만재면 1                         ← PO 틸트 확인 · 정지선 · 글자
 *  manjae_2s(rack, dan)        2초 그대로였던 만재면 1 (스침 X)      ← PO 정지선 · HMI 칸
 *  manjae_change()             (Event_Task) 바뀌면 FF 쪽지 + 2초 타이머 다시
 *  Manjae_Timer_2s()           (타이머 : 바뀐 뒤 2초 조용) 확정 값 · 렉 알림 · 로그 · 부저
 *  Manjae_check_text(b, size)  프로토콜 글자 F_1_0001&F_2_0000       ← C 대답 · FF
 *  Manjae_event_text()         (Comm_Task) 쪽지 있으면 PC 로 FF
 *
 *  렉1 = 오른쪽 (FULL_1_x, DI1~4), 렉2 = 왼쪽 (FULL_2_x, DI5~8), 전부 GPIOE · 핀 0V = 만재
 *
 *  Created on: Oct 1, 2026
 *      Author: HWNOT
 */
#include "main.h"
#include "manjae.h"
#include "net.h"
#include "buzzer.h"
#include "debug.h"
#include "cmsis_os2.h"
#include <stdio.h>

#define MANJAE_PINS (FULL_1_1_Pin | FULL_1_2_Pin | FULL_1_3_Pin | FULL_1_4_Pin | \
                     FULL_2_1_Pin | FULL_2_2_Pin | FULL_2_3_Pin | FULL_2_4_Pin)     /* 만재 8칸 (GPIOE) */

/* ── 만재 변수 (전부 여기) ── */
int manjae_1;                               /* 1 = 렉1 만재 알림 중 (2초 넘게 만재) : HMI RUN 이 지움 */
int manjae_2;                               /* 1 = 렉2 */
static volatile int ff_on;                  /* 1 = PC 로 FF 보낼 것 있음 (Event_Task 켬 → Comm_Task 보내고 끔) */
static uint16_t full_2s = MANJAE_PINS;      /* 2초 그대로였던 8칸 핀 값 (처음 = 전부 빈칸) */


/* 칸 → 핀 : 없는 칸 (렉 3 · 4, 5단) = 0 */
static uint16_t manjae_pin(int rack, int dan)
{
    if (rack == 1 && dan == 1) return FULL_1_1_Pin;     /* 렉1 (오른쪽) */
    if (rack == 1 && dan == 2) return FULL_1_2_Pin;
    if (rack == 1 && dan == 3) return FULL_1_3_Pin;
    if (rack == 1 && dan == 4) return FULL_1_4_Pin;

    if (rack == 2 && dan == 1) return FULL_2_1_Pin;     /* 렉2 (왼쪽) */
    if (rack == 2 && dan == 2) return FULL_2_2_Pin;
    if (rack == 2 && dan == 3) return FULL_2_3_Pin;
    if (rack == 2 && dan == 4) return FULL_2_4_Pin;

    return 0;
}

/* 지금 만재 : 1 = 만재 (없는 칸 = 빈칸) */
int manjae_on(int rack, int dan)
{
    uint16_t pin = manjae_pin(rack, dan);
    return pin != 0 && (GPIOE->IDR & pin) == 0;
}

/* 2초 확정 만재 : Manjae_Timer_2s 가 찍은 값으로 (스침은 안 보임) */
int manjae_2s(int rack, int dan)
{
    uint16_t pin = manjae_pin(rack, dan);
    return pin != 0 && (full_2s & pin) == 0;
}

/* 그 렉 1 ~ 4단 중 하나라도 만재 */
static int manjae_rack(int rack)
{
    return manjae_on(rack, 1) || manjae_on(rack, 2) || manjae_on(rack, 3) || manjae_on(rack, 4);
}

/* (Event_Task) 8칸 중 하나라도 바뀌면 : PC 로 FF 바로 + 2초 다시 재기 (켤 때 첫 번째는 바뀜 → FF 한 번) */
void manjae_change(void)
{
    static uint16_t last = 0xFFFF;                      /* 지난번 8칸 (처음엔 없는 값) */
    uint16_t now = GPIOE->IDR & MANJAE_PINS;

    if (now == last) return;                            /* 그대로 */
    last = now;
    ff_on = 1;                                          /* PC FF (Comm_Task 가 보냄) */
    osTimerStart(Manjae_TimerHandle, MANJAE_MS);        /* 2초 (바뀔 때마다 처음부터) */
}

/* (타이머 : 바뀐 뒤 2초 조용) 확정 값 찍기 → 만재 렉 알림 (RUN 까지) · 로그 · 부저 (빨간불은 event.c lamp_event) */
void Manjae_Timer_2s(void)
{
    full_2s = GPIOE->IDR & MANJAE_PINS;                 /* 2초 그대로였던 값 */

    if (manjae_rack(1)) manjae_1 = 1;                   /* 렉1 */
    if (manjae_rack(2)) manjae_2 = 1;                   /* 렉2 */
    if (manjae_rack(1) || manjae_rack(2)) {
        Log_Debug(LOG_MANJAE_FULL);
        Buzzer_On();                                    /* PC 연결 중이면 안 켜짐 (buzzer.c) */
    }
}

/* 프로토콜 글자 : F_1_0001&F_2_0000 (렉1 · 렉2 의 1 ~ 4단, 1 = 만재) — C 대답 · FF 가 같이 씀 */
void Manjae_check_text(char *b, int size)
{
    snprintf(b, size, "F_1_%d%d%d%d&F_2_%d%d%d%d",
             manjae_on(1, 1), manjae_on(1, 2), manjae_on(1, 3), manjae_on(1, 4),
             manjae_on(2, 1), manjae_on(2, 2), manjae_on(2, 3), manjae_on(2, 4));
}

/* (Comm_Task) 쪽지 있으면 PC 로 FF_1_0001&F_2_0000 */
void Manjae_event_text(void)
{
    char b[32] = "F";                                   /* FF = F + F_1_… */

    if (ff_on == 0) return;                             /* 보낼 것 없음 */
    ff_on = 0;                                          /* 보내기 전에 0 */
    Manjae_check_text(b + 1, sizeof(b) - 1);
    send_event(b);
}
