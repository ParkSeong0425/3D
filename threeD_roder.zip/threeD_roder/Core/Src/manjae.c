/*
 * manjae.c : 만재 센서 읽기만 (핀을 그때그때 직접 읽음)
 *
 *  manjae_off(rack, dan) : 그 단 빈칸이면 1   (핀 그대로 : 3.3V = 빈칸)
 *  manjae_on(rack, dan)  : 그 단 만재면 1     (빈칸의 반대)
 *  manjae_change()       : 8칸 중 하나라도 바뀌었으면 1 (PC 알림 · 부저용), 바뀐 칸은 그 칸 시각 기록
 *  manjae_stable(렉, 단) : 그 칸이 2초 동안 그대로면 1 (PO) / (0, 0) = 8칸 다 그대로면 1 (HMI · 알림)
 *  Manjae_Text(b, size)  : 프로토콜 글자 F_1_0001&F_2_0000 (FF 이벤트 · C 대답)
 *  Manjae_PC()           : (Comm_Task) 바뀌었으면 PC 로 FF_1_0001&F_2_0000
 *
 *  렉1 = 오른쪽 (DI1~4), 렉2 = 왼쪽 (DI5~8)
 *
 *  Created on: Oct 1, 2026
 *      Author: HWNOT
 */
#include "main.h"
#include "manjae.h"
#include "net.h"
#include "cmsis_os2.h"
#include <stdio.h>

volatile int full_event_on;   /* 1 = 보낼 만재 이벤트 있음 */


/* 그 렉 그 단 빈칸 : 1 = 빈칸 (핀 그대로 : 3.3V = 빈칸, 0V = 만재) */
int manjae_off(int rack, int dan)
{
    if (rack == 1 && dan == 1) return HAL_GPIO_ReadPin(FULL_1_1_GPIO_Port, FULL_1_1_Pin);    /* 렉1 (오른쪽) */
    if (rack == 1 && dan == 2) return HAL_GPIO_ReadPin(FULL_1_2_GPIO_Port, FULL_1_2_Pin);
    if (rack == 1 && dan == 3) return HAL_GPIO_ReadPin(FULL_1_3_GPIO_Port, FULL_1_3_Pin);
    if (rack == 1 && dan == 4) return HAL_GPIO_ReadPin(FULL_1_4_GPIO_Port, FULL_1_4_Pin);

    if (rack == 2 && dan == 1) return HAL_GPIO_ReadPin(FULL_2_1_GPIO_Port, FULL_2_1_Pin);    /* 렉2 (왼쪽) */
    if (rack == 2 && dan == 2) return HAL_GPIO_ReadPin(FULL_2_2_GPIO_Port, FULL_2_2_Pin);
    if (rack == 2 && dan == 3) return HAL_GPIO_ReadPin(FULL_2_3_GPIO_Port, FULL_2_3_Pin);
    if (rack == 2 && dan == 4) return HAL_GPIO_ReadPin(FULL_2_4_GPIO_Port, FULL_2_4_Pin);

    return 1;                   /* 없는 칸 (렉 3 · 4, 5단) = 빈칸 */
}

/* 그 렉 그 단 만재 : 1 = 만재 (빈칸의 반대) */
int manjae_on(int rack, int dan)
{
    return manjae_off(rack, dan) == 0;
}

/* 칸마다 따로 : [렉 - 1][단 - 1] (렉 1 · 2, 단 1 ~ 4) */
static int last_on[2][4] = { { -1, -1, -1, -1 }, { -1, -1, -1, -1 } };   /* 지난번 만재 (-1 = 켤 때 아직 안 읽음 → 첫 번째는 바뀜) */
static uint32_t changed_at[2][4];                                       /* 그 칸 센서가 마지막으로 바뀐 시각 (manjae_stable 이 봄) */

/* 만재 바뀜 : 8칸 중 하나라도 지난번과 다르면 1 (바뀐 칸은 그 칸 시각을 새로) */
int manjae_change(void)
{
    int changed = 0;

    for (int rack = 1; rack <= 2; rack++) {
        for (int dan = 1; dan <= 4; dan++) {
            if (manjae_on(rack, dan) == last_on[rack - 1][dan - 1]) continue;   /* 그 칸 그대로 */
            last_on[rack - 1][dan - 1] = manjae_on(rack, dan);
            changed_at[rack - 1][dan - 1] = osKernelGetTickCount();             /* 그 칸 바뀐 시각 */
            changed = 1;
        }
    }
    return changed;
}

/* 만재 센서가 2초(MANJAE_MS) 동안 안 바뀌었으면 1 (스침 = 0) : 렉 · 단 = 그 칸만 / (0, 0) = 8칸 다 */
int manjae_stable(int rack, int dan)
{
    uint32_t now = osKernelGetTickCount();

    /* 0 = 8칸 다 : 하나라도 2초 안에 바뀌었으면 0 (HMI 화면 · 만재 알림 — 전과 같은 뜻) */
    if (rack == 0) {
        for (int r = 0; r < 2; r++)
            for (int d = 0; d < 4; d++)
                if (now - changed_at[r][d] < MANJAE_MS) return 0;
        return 1;
    }

    if (rack < 1 || rack > 2 || dan < 1 || dan > 4) return 1;            /* 센서 없는 칸 (렉 3 · 4) */
    return now - changed_at[rack - 1][dan - 1] >= MANJAE_MS;              /* 그 칸만 (PO) */
}

/* 그 렉 만재 : 그 렉 1 ~ 4단 중 하나라도 만재면 1 */
int manjae_rack(int rack)
{
    return manjae_on(rack, 1) || manjae_on(rack, 2) || manjae_on(rack, 3) || manjae_on(rack, 4);
}

/* 만재 하나라도 있음 : 렉1 · 렉2 중 하나라도 만재면 1 */
int manjae_full(void)
{
    return manjae_rack(1) || manjae_rack(2);
}

/* 프로토콜 글자 : F_1_0001&F_2_0000 (렉1 · 렉2 의 1 ~ 4단, 1 = 만재) — FF 이벤트 · C 대답이 같이 씀 */
void Manjae_Text(char *b, int size)
{
    snprintf(b, size, "F_1_%d%d%d%d&F_2_%d%d%d%d",
             manjae_on(1, 1), manjae_on(1, 2), manjae_on(1, 3), manjae_on(1, 4),
             manjae_on(2, 1), manjae_on(2, 2), manjae_on(2, 3), manjae_on(2, 4));
}

/* PC 로 FF (Comm_Task) : 센서가 바뀌었으면(full_event_on, event.c) FF_1_0001&F_2_0000 */
void Manjae_PC(void)
{
    char b[32];

    if (full_event_on == 0) return;             /* 보낼 것 없음 */
    full_event_on = 0;                          /* 보내기 전에 0 */
    b[0] = 'F';                                 /* FF = F + F_1_… */
    Manjae_Text(b + 1, sizeof(b) - 1);
    send_event(b);
}
