/*
 * rfid.c : 시딩월 카드 (렉1 · 렉2 리더, CAN) — 카드 변수 · 판단은 전부 여기 (다른 파일은 함수 부르기 · 읽기만)
 *
 *  Rfid_Save(rack, data)       (CAN 인터럽트) 리더 대답 → 카드 있음 / 없음 · 번호 · PC 쪽지
 *  card_on(rack)               지금 카드 있음 1                      ← PO 정지선 · 램프 Y
 *  Rfid_Check()                (Rfid_Timer 0.5초) 리더에 'C' 묻기 + 2초 넘게 없으면 그 렉 알림 (RUN 까지)
 *  Rfid_check_text(b, size)    프로토콜 글자 UT_1_…&UU_2_…           ← R 대답 · UT · UU
 *  Rfid_event_text()           (Comm_Task) 쪽지 있으면 PC 로 UT · UU
 *  Rfid_Init()                 (켤 때 한 번) CAN 켜기 → 바로 묻기 → 0.5초 타이머
 */
#include <string.h>
#include <stdio.h>
#include "rfid.h"
#include "fdcan.h"
#include "net.h"
#include "save.h"
#include "debug.h"
#include "cmsis_os2.h"

#define RFID_CAN_ID_1 201       /* 렉1 리더 : 200 + DIP 번호 (FDCAN1) */
#define RFID_CAN_ID_2 201       /* 렉2 리더 : 200 + DIP 번호 (FDCAN2) */
#define UID_LEN       7         /* 카드 번호 7칸 */
#define ASK_MS        500       /* 리더에 묻는 간격 */
#define CARD_MS       2000      /* 카드 없음 확정 : 이만큼 계속 없어야 알림 (만재 MANJAE_MS 와 같은 뜻) */

/* ── 카드 변수 (전부 여기) ── */
volatile int card_ok_1;         /* 렉1 지금 카드 있음 1 / 없음 0 (CAN 인터럽트가 바꿈, 밖은 card_on 으로) */
volatile int card_ok_2;         /* 렉2 */
volatile int card_event_on;     /* 1 = PC 로 UT · UU 보낼 것 있음 (net.c 접속 때도 켬) */
int card_1;                     /* 1 = 렉1 시딩월 이탈 알림 중 (2초 넘게 없음) : HMI RUN 이 지움 */
int card_2;                     /* 1 = 렉2 */
static uint8_t uid_1[UID_LEN];  /* 렉1 카드 번호 */
static uint8_t uid_2[UID_LEN];  /* 렉2 */
static int out_1;               /* 렉1 카드 없음 연속 횟수 (0.5초마다 +1, 4 = 2초) */
static int out_2;               /* 렉2 */


/* (CAN 인터럽트) 리더 대답 : 카드 번호가 오면 있음, 0000000 이면 없음 → 바뀔 때만 번호 · PC 쪽지 */
void Rfid_Save(int rack, uint8_t *data)
{
    int on = (data[0] != 0);                    /* 번호 있음 1 / 0000000 = 없음 0 */

    if (rack == 1 && on != card_ok_1) { card_ok_1 = on; memcpy(uid_1, data, UID_LEN); card_event_on = 1; }   /* 렉1 바뀜 → UT / UU */
    if (rack == 2 && on != card_ok_2) { card_ok_2 = on; memcpy(uid_2, data, UID_LEN); card_event_on = 1; }   /* 렉2 */
}

/* 그 렉 카드 있음 1 / 없음 0 (렉 3 · 4 는 리더 없음 = 있음으로) */
int card_on(int rack)
{
    if (rack == 1) return card_ok_1;
    if (rack == 2) return card_ok_2;
    return 1;
}

/* (Rfid_Timer 0.5초) 렉1 · 렉2 리더에 'C' 묻기 (선이 따로라 두 번) → 카드 없음 2초 (4번 연속) 면 그 렉 알림 한 번
   못 보냄 = 선 빠짐 · 리더 꺼짐 (대답 없어서 보내기 칸 3개가 참, 약 2초) → 0000000 받은 것처럼 = 없음 */
void Rfid_Check(void)
{
    uint8_t cmd = 'C';
    uint8_t none[UID_LEN] = {0};

    if (Send_to_Reader(&hfdcan1, RFID_CAN_ID_1, &cmd, 1) == 0) Rfid_Save(1, none);    /* 렉1 리더 */
    if (Send_to_Reader(&hfdcan2, RFID_CAN_ID_2, &cmd, 1) == 0) Rfid_Save(2, none);    /* 렉2 리더 */

    if (card_ok_1) out_1 = 0; else out_1++;     /* 있으면 처음부터, 없으면 +1 */
    if (card_ok_2) out_2 = 0; else out_2++;
    if (out_1 == CARD_MS / ASK_MS) { card_1 = 1; Log_Debug(LOG_CARD_OUT); }                                   /* 렉1 2초 없음 (== 라서 한 번만) */
    if (out_2 == CARD_MS / ASK_MS && save.fs.rack_channel >= 2) { card_2 = 1; Log_Debug(LOG_CARD_OUT); }     /* 렉2 (렉 2개 이상일 때만) */
}

/* 프로토콜 글자 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 (T = 있음, U = 없음) — R 대답 · UT · UU 가 같이 씀 */
void Rfid_check_text(char *b, int size)
{
    snprintf(b, size, "U%c_1_%02X%02X%02X%02X%02X%02X%02X&U%c_2_%02X%02X%02X%02X%02X%02X%02X",
             card_ok_1 ? 'T' : 'U', uid_1[0], uid_1[1], uid_1[2], uid_1[3], uid_1[4], uid_1[5], uid_1[6],
             card_ok_2 ? 'T' : 'U', uid_2[0], uid_2[1], uid_2[2], uid_2[3], uid_2[4], uid_2[5], uid_2[6]);
}

/* (Comm_Task) 쪽지 있으면 PC 로 UT_1_…&UU_2_… */
void Rfid_event_text(void)
{
    char b[48];

    if (card_event_on == 0) return;             /* 보낼 것 없음 */
    card_event_on = 0;                          /* 보내기 전에 0 */
    Rfid_check_text(b, sizeof(b));
    send_event(b);
}

/* 켤 때 한 번 : CAN 켜기 → 바로 한 번 묻기 → 0.5초 타이머 */
void Rfid_Init(void)
{
    CAN_On(&hfdcan1);                               /* 렉1 CAN 켜기 */
    CAN_On(&hfdcan2);                               /* 렉2 CAN 켜기 */
    Rfid_Check();                                   /* 바로 한 번 묻기 */
    osTimerStart(Rfid_TimerHandle, ASK_MS);         /* 0.5초마다 Rfid_Check */
}
