#include <stdio.h>
#include <string.h>
#include "rfid.h"
#include "fdcan.h"
#include "event.h"
#include "cli.h"

#define RFID_CAN_ID_1 201       /* 렉1 리더 : 200 + DIP 번호 (FDCAN1) */
#define RFID_CAN_ID_2 201       /* 렉2 리더 : 200 + DIP 번호 (FDCAN2) */
#define UID_LEN       7         /* 리더는 항상 7바이트로 보냄 */
#define ASK_MS        500       /* 리더에 지금 카드 묻는 간격 */
#define LOST_MS       2000      /* 이 시간 동안 카드 인식 없으면 카드 없음 */

volatile int card_ok_1;
volatile int card_ok_2;
volatile int rfid_new;          /* 1 = 보낼 카드 이벤트 있음 → CMD_Event */
static volatile int rfid_show;  /* 1 = CLI 로 보여줄 것 있음 → Rfid_Check */
static uint8_t uid_1[7];
static uint8_t uid_2[7];
static volatile uint32_t seen_1;    /* 렉1 마지막으로 카드 인식된 시각 */
static volatile uint32_t seen_2;    /* 렉2 */

/* 카드 상태 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 (T = 있음, U = 없음) */
void Rfid_Text(char *b, int size)
{
    snprintf(b, size,
             "U%c_1_%02X%02X%02X%02X%02X%02X%02X&U%c_2_%02X%02X%02X%02X%02X%02X%02X",
             card_ok_1 ? 'T' : 'U',
             uid_1[0], uid_1[1], uid_1[2], uid_1[3], uid_1[4], uid_1[5], uid_1[6],
             card_ok_2 ? 'T' : 'U',
             uid_2[0], uid_2[1], uid_2[2], uid_2[3], uid_2[4], uid_2[5], uid_2[6]);
}

/* 시작할 때 한 번 : CAN 켜고 지금 카드 물어보기 */
void Rfid_Init(void)
{
    uint8_t cmd = 'C';

    CAN_Start(&hfdcan1);
    CAN_Start(&hfdcan2);

    CAN_Send(&hfdcan1, RFID_CAN_ID_1, &cmd, 1);
    CAN_Send(&hfdcan2, RFID_CAN_ID_2, &cmd, 1);
}

/* CAN 수신 인터럽트에서 : 받은 UID 저장, 바뀌었으면 이벤트 */
void Rfid_Save(int rack, uint8_t *data)
{
    int ok = 0;

    /* 7바이트가 전부 0 이면 카드 없음 */
    for (int i = 0; i < UID_LEN; i++)
        if (data[i] != 0) ok = 1;

    /* 카드 없음 응답은 무시 : 리더가 가끔 못 읽어도 바로 없음으로 안 함 (2초 확인은 Rfid_Check) */
    if (ok == 0) return;

    /* 카드 인식된 시각 : 같은 카드여도 기록 */
    if (rack == 1) seen_1 = HAL_GetTick();
    else           seen_2 = HAL_GetTick();

    if (rack == 1) {
        if (memcmp(uid_1, data, UID_LEN) == 0) return;
        memcpy(uid_1, data, UID_LEN);
        card_ok_1 = ok;
    }
    else {
        if (memcmp(uid_2, data, UID_LEN) == 0) return;
        memcpy(uid_2, data, UID_LEN);
        card_ok_2 = ok;
    }

    rfid_new = 1;
    rfid_show = 1;
}

/* 2초 동안 인식 없음 : 카드 없음으로 바꾸고 이벤트 */
static void card_lost(int rack)
{
    if (rack == 1) { memset(uid_1, 0, UID_LEN); card_ok_1 = 0; }
    else           { memset(uid_2, 0, UID_LEN); card_ok_2 = 0; }

    rfid_new = 1;
    rfid_show = 1;
}

/* Event_Task : 리더에 계속 묻고, 2초 동안 인식 없으면 카드 없음, 바뀌었으면 CLI 로 보여주기 */
void Rfid_Check(void)
{
    static uint32_t ask_last;
    uint8_t cmd = 'C';
    char b[64];

    /* 1. 리더에 지금 카드 묻기 */
    CAN_Send(&hfdcan1, RFID_CAN_ID_1, &cmd, 1);
    CAN_Send(&hfdcan2, RFID_CAN_ID_2, &cmd, 1);

    /* 2. 2초 동안 인식 없으면 카드 없음 */
    if (card_ok_1 == 1 && HAL_GetTick() - seen_1 >= LOST_MS) card_lost(1);
    if (card_ok_2 == 1 && HAL_GetTick() - seen_2 >= LOST_MS) card_lost(2);

    /* 3. 바뀌었으면 CLI */
    if (rfid_show == 0)
        return;

    rfid_show = 0;
    Rfid_Text(b, sizeof(b));
    CLI_Print(b);
    CLI_Print("\r\n");
}
