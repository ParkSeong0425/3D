#include <string.h>
#include "rfid.h"
#include "fdcan.h"
#include "cmsis_os2.h"

#define RFID_CAN_ID_1 201       /* 렉1 리더 : 200 + DIP 번호 (FDCAN1) */
#define RFID_CAN_ID_2 201       /* 렉2 리더 : 200 + DIP 번호 (FDCAN2) */
#define UID_LEN       7         /* 카드 번호 7칸 */
#define ASK_MS        500       /* 리더에 묻는 간격 */

volatile int card_ok_1;         /* 렉1 카드 있음 1 / 없음 0 */
volatile int card_ok_2;         /* 렉2 */
volatile int card_event_on;     /* 1 = PC 로 카드 글자 보내 줘 (cmd.c CMD_Event 가 보내고 0) */
uint8_t uid_1[7];               /* 렉1 카드 번호 (cmd.c 가 PC 글자에 씀) */
uint8_t uid_2[7];               /* 렉2 */


/* 리더 대답 (CAN 인터럽트) : 카드 번호가 오면 있음, 0000000 이면 없음 → 바뀔 때만 PC 로 */
void Rfid_Save(int rack, uint8_t *data)
{
    if (rack == 1 && data[0] != 0 && card_ok_1 == 0) { card_ok_1 = 1; memcpy(uid_1, data, UID_LEN); card_event_on = 1; }   /* 렉1 들어옴 → UT */
    if (rack == 1 && data[0] == 0 && card_ok_1 == 1) { card_ok_1 = 0; memset(uid_1, 0, UID_LEN);    card_event_on = 1; }   /* 렉1 빠짐 → UU */
    if (rack == 2 && data[0] != 0 && card_ok_2 == 0) { card_ok_2 = 1; memcpy(uid_2, data, UID_LEN); card_event_on = 1; }   /* 렉2 들어옴 */
    if (rack == 2 && data[0] == 0 && card_ok_2 == 1) { card_ok_2 = 0; memset(uid_2, 0, UID_LEN);    card_event_on = 1; }   /* 렉2 빠짐 */
}

/* 그 렉 카드 있음 1 / 없음 0 (manjae_on 처럼 읽기만, 렉 3 · 4 는 리더 없음 = 있음으로) */
int card_on(int rack)
{
    if (rack == 1) return card_ok_1;
    if (rack == 2) return card_ok_2;
    return 1;
}

/* 0.5초마다 (Rfid_Timer) : 렉1 · 렉2 리더에 'C' 묻기 (선이 따로라 두 번)
   못 보냄 = 선 빠짐 · 리더 꺼짐 (대답 없어서 보내기 칸 3개가 참, 약 2초) → 0000000 받은 것처럼 = 빠짐 */
void Rfid_Check(void)
{
    uint8_t cmd = 'C';
    uint8_t none = 0;

    if (Send_to_Reader(&hfdcan1, RFID_CAN_ID_1, &cmd, 1) == 0) Rfid_Save(1, &none);    /* 렉1 리더 */
    if (Send_to_Reader(&hfdcan2, RFID_CAN_ID_2, &cmd, 1) == 0) Rfid_Save(2, &none);    /* 렉2 리더 */
}

/* 켤 때 한 번 : CAN 켜기 → 바로 한 번 묻기 → 0.5초 타이머 */
void Rfid_Init(void)
{
    CAN_On(&hfdcan1);                               /* 렉1 CAN 켜기 */
    CAN_On(&hfdcan2);                               /* 렉2 CAN 켜기 */
    Rfid_Check();                                   /* 바로 한 번 묻기 */
    osTimerStart(Rfid_TimerHandle, ASK_MS);         /* 0.5초마다 Rfid_Check */
}
