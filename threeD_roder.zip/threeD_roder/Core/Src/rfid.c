#include <string.h>
#include <stdio.h>
#include "rfid.h"
#include "fdcan.h"
#include "net.h"
#include "save.h"
#include "cmsis_os2.h"

#define RFID_CAN_ID_1 201       /* 렉1 리더 : 200 + DIP 번호 (FDCAN1) */
#define RFID_CAN_ID_2 201       /* 렉2 리더 : 200 + DIP 번호 (FDCAN2) */
#define UID_LEN       7         /* 카드 번호 7칸 */
#define ASK_MS        500       /* 리더에 묻는 간격 */

volatile int card_ok_1;         /* 렉1 카드 있음 1 / 없음 0 */
volatile int card_ok_2;         /* 렉2 */
volatile int card_event_on;     /* 1 = PC 로 카드 글자 보내 줘 (Rfid_PC 가 보내고 0) */
uint8_t uid_1[7];               /* 렉1 카드 번호 (Rfid_Text 가 PC 글자에 씀) */
uint8_t uid_2[7];               /* 렉2 */


/* 리더 대답 (CAN 인터럽트) : 카드 번호가 오면 있음, 0000000 이면 없음 → 바뀔 때만 PC 로 */
void Rfid_Save(int rack, uint8_t *data)
{
    if (rack == 1 && data[0] != 0 && card_ok_1 == 0) { card_ok_1 = 1; memcpy(uid_1, data, UID_LEN); card_event_on = 1; }   /* 렉1 들어옴 → UT */
    if (rack == 1 && data[0] == 0 && card_ok_1 == 1) { card_ok_1 = 0; memset(uid_1, 0, UID_LEN);    card_event_on = 1; }   /* 렉1 빠짐 → UU */
    if (rack == 2 && data[0] != 0 && card_ok_2 == 0) { card_ok_2 = 1; memcpy(uid_2, data, UID_LEN); card_event_on = 1; }   /* 렉2 들어옴 */
    if (rack == 2 && data[0] == 0 && card_ok_2 == 1) { card_ok_2 = 0; memset(uid_2, 0, UID_LEN);    card_event_on = 1; }   /* 렉2 빠짐 */
}

/* 그 렉 카드 있음 1 / 없음 0 (manjae_on 처럼 읽기만, 렉 3 · 4 는 리더 없음 = 있음으로) */
int card_on(int rack)
{
    if (rack == 1) return card_ok_1;
    if (rack == 2) return card_ok_2;
    return 1;
}

/* 카드 빠짐 : 렉1 카드 없음 / 렉2 카드 없음 (렉 수 2 이상일 때만) 이면 1 */
int card_out(void)
{
    return card_on(1) == 0 || (save.fs.rack_channel >= 2 && card_on(2) == 0);
}

/* 0.5초마다 (Rfid_Timer) : 렉1 · 렉2 리더에 'C' 묻기 (선이 따로라 두 번)
   못 보냄 = 선 빠짐 · 리더 꺼짐 (대답 없어서 보내기 칸 3개가 참, 약 2초) → 0000000 받은 것처럼 = 빠짐 */
void Rfid_Check(void)
{
    uint8_t cmd = 'C';
    uint8_t none = 0;

    if (Send_to_Reader(&hfdcan1, RFID_CAN_ID_1, &cmd, 1) == 0) Rfid_Save(1, &none);    /* 렉1 리더 */
    if (Send_to_Reader(&hfdcan2, RFID_CAN_ID_2, &cmd, 1) == 0) Rfid_Save(2, &none);    /* 렉2 리더 */
}

/* 프로토콜 글자 : UT_1_A1B1C1D1A2B2C2&UU_2_00000000000000 (T = 있음, U = 없음) — 이벤트 · R 대답이 같이 씀 */
void Rfid_Text(char *b, int size)
{
    snprintf(b, size, "U%c_1_%02X%02X%02X%02X%02X%02X%02X&U%c_2_%02X%02X%02X%02X%02X%02X%02X",
             card_ok_1 ? 'T' : 'U', uid_1[0], uid_1[1], uid_1[2], uid_1[3], uid_1[4], uid_1[5], uid_1[6],
             card_ok_2 ? 'T' : 'U', uid_2[0], uid_2[1], uid_2[2], uid_2[3], uid_2[4], uid_2[5], uid_2[6]);
}

/* PC 로 카드 (Comm_Task) : 들어옴 · 빠짐(card_event_on) 이면 UT_1_…&UU_2_… */
void Rfid_PC(void)
{
    char b[48];

    if (card_event_on == 0) return;             /* 보낼 것 없음 */
    card_event_on = 0;                          /* 보내기 전에 0 */
    Rfid_Text(b, sizeof(b));
    send_event(b);
}

/* 켤 때 한 번 : CAN 켜기 → 바로 한 번 묻기 → 0.5초 타이머 */
void Rfid_Init(void)
{
    CAN_On(&hfdcan1);                               /* 렉1 CAN 켜기 */
    CAN_On(&hfdcan2);                               /* 렉2 CAN 켜기 */
    Rfid_Check();                                   /* 바로 한 번 묻기 */
    osTimerStart(Rfid_TimerHandle, ASK_MS);         /* 0.5초마다 Rfid_Check */
}
