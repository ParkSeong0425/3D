#include "i_motor.h"
#include "usart.h"
#include "cmsis_os2.h"
#include "event.h"
#include "save.h"
#include "status.h"
#include "alarm.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* 통신 */
#define IM_1_ID      3       /* DIP 스위치로 설정한 주소 */
#define IM_2_ID      4       /* [현장] 4 (X 2번 모터) / 사무실 3 (X 모터 하나) */
#define IM_ALL_ID    0       /* [현장] 0 (브로드캐스트 : ID 3 · 4 가 같이 받음, 대답 없음) / 사무실 3 (X 모터 하나, 대답 확인) */

/* 데이터시트 레지스터 */
#define R_STATE       0x1003   /* Motion state */
#define R_FB_POS_H    0x1014   /* Feedback position H */
#define R_FB_POS_L    0x1015   /* Feedback position L */
#define SET_ZERO      0x0021   /* Set Zero */
#define R_ALARM       0x2203   /* Current alarm */
#define R_CONTROL     0x1801   /* Control word */
#define R_CTRL        0x6002   /* Pr8.02 Trigger register */
#define R_HOME_MODE   0x600A   /* Pr8.10 Homing mode */
#define R_HOME_HI     0x600F   /* Pr8.15 Homing high velocity */
#define R_STOP_TIME   0x6017   /* Pr8.23 quick stop 감속 시간 ms */
#define R_HOME_WARN   0x601D   /* Pr8.29 PR warning */
#define R_PR0  0x6200   /* Pr9.00 ~ Pr9.07 */
#define R_REAL_POS_H  0x602C   /* Pr8.44 Actual position H */

/* Mapping: 설정 0x0F10~, 데이터시트 예제 읽기 0x0F00~ */
#define R_MAP_SET     0x0F10
#define MAP_COUNT     5

/* Trigger 값 */
#define PR_POSITION   0x0001   /* TYPE=1 Position, Bit6=0 Absolute */
#define START_PR0     0x0010
#define START_HOME    0x0020
#define QUICK_STOP    0x0040
#define ALARM_RESET   0x1111   /* R_CONTROL : 현재 알람 리셋 */
#define R_JOG_SPEED   0x01E1   /* Pr6.00 JOG 속도 rpm (RS485 JOG) */
#define JOG_CW        0x4001   /* R_CONTROL : JOG + (50ms 안에 다시 써야 계속 감) */
#define JOG_CCW       0x4002   /* R_CONTROL : JOG - */

/* Modbus RTU CRC16 */
static uint16_t crc16(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++)
            crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
    }
    return crc;
}


/* FC06 : 16비트 레지스터 1개 쓰기 */
static int write16(uint8_t id, uint16_t reg, uint16_t val)
{
    uint8_t tx[8], rx[8];
    uint16_t crc;
    tx[0] = id; tx[1] = 0x06;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = val >> 8; tx[5] = (uint8_t)val;
    crc = crc16(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);

    if (id == 0) return UART2_Send(tx, 8);     /* 브로드캐스트 : 대답 없이 한 번만 보냄 */

    for (uint8_t retry = 0; retry < MOTOR_RETRY; retry++) {
        if (UART2_Xfer(tx, 8, rx, 8, X_RX_MS) && memcmp(rx, tx, 8) == 0) return 1;
    }
    return 0;
}

/* FC03 : 연속 레지스터 읽기 */
static int read_reg(uint8_t id, uint16_t reg, uint8_t qty, uint16_t *out)
{
    uint8_t tx[8], rx[32];
    uint16_t n = 5 + qty * 2, crc;
    tx[0] = id; tx[1] = 0x03;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = 0; tx[5] = qty;
    crc = crc16(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);

    for (uint8_t retry = 0; retry < MOTOR_RETRY; retry++) {
        if (UART2_Xfer(tx, 8, rx, n, X_RX_MS) == 0) continue;
        crc = crc16(rx, n - 2);
        if (rx[0] != id || rx[1] != 0x03 || rx[2] != qty * 2) continue;
        if (rx[n - 2] != (uint8_t)crc || rx[n - 1] != (uint8_t)(crc >> 8)) continue;
        for (uint8_t i = 0; i < qty; i++)
            out[i] = ((uint16_t)rx[3 + i * 2] << 8) | rx[4 + i * 2];
        return 1;
    }
    return 0;
}

/* FC10 : 연속 레지스터 여러 개 쓰기 */
static int write_multi(uint8_t id, uint16_t reg, const uint16_t *data, uint8_t qty)
{
    uint8_t tx[32], rx[8];
    uint16_t n = 7 + qty * 2, crc;
    tx[0] = id; tx[1] = 0x10;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = 0; tx[5] = qty; tx[6] = qty * 2;
    for (uint8_t i = 0; i < qty; i++) {
        tx[7 + i * 2] = data[i] >> 8;
        tx[8 + i * 2] = (uint8_t)data[i];
    }
    crc = crc16(tx, n);
    tx[n] = (uint8_t)crc; tx[n + 1] = (uint8_t)(crc >> 8);

    if (id == 0) return UART2_Send(tx, n + 2);     /* 브로드캐스트 : 대답 없이 한 번만 보냄 */

    for (uint8_t retry = 0; retry < MOTOR_RETRY; retry++) {
        if (UART2_Xfer(tx, n + 2, rx, 8, X_RX_MS) == 0) continue;
        crc = crc16(rx, 6);
        if (rx[0] == id && rx[1] == 0x10 && rx[2] == tx[2] && rx[3] == tx[3]
                && rx[4] == 0 && rx[5] == qty && rx[6] == (uint8_t)crc
                && rx[7] == (uint8_t)(crc >> 8)) return 1;
    }
    return 0;
}

/* mm -> pulse */
static int32_t move_pos(int32_t mm)
{
    return mm * X_PULSE / X_PI;                         /* 32비트로 충분 (2000mm × 10000 = 2천만 < 21억) */
}

/* (디버그 · CLI) X 레지스터 읽기 : motor 1 = IM_1_ID / 2 = IM_2_ID, qty 1 = 16bit · 2 = 32bit (높은 칸 먼저). 읽으면 1 / 대답 없음 0 */
int IM_ReadReg(int motor, uint16_t reg, uint16_t *out, uint8_t qty)
{
    return read_reg(motor == 1 ? IM_1_ID : IM_2_ID, reg, qty, out);
}

/* 32비트 값 읽기 : High + Low */
static int read32(uint8_t id, uint16_t reg, int32_t *value)
{
    uint16_t data[2];

    if (read_reg(id, reg, 2, data) == 0)
        return 0;

    *value = (int32_t)(((uint32_t)data[0] << 16) | data[1]);

    return 1;
}

/* 현재 위치 mm */
static int read_pos(uint8_t id, int32_t *mm)
{
    int32_t pulse;

    if (read32(id, R_REAL_POS_H, &pulse) == 0)
        return 0;

    *mm = pulse * X_PI / X_PULSE;                       /* 32비트로 충분 (20만 펄스 × 100 = 2천만) */

    return 1;
}

/* % → rpm : 100% = FP 11 X 속도 (0 이면 IM_MAX_RPM) */
static int speed_rpm(int percent)
{
    if (save.fp.speed_x == 0) return percent * IM_MAX_RPM / 100;    /* 안 정함 : 기본값 */
    return percent * save.fp.speed_x / 100;                         /* FP 11 */
}

/* 가감속 ms : FP 12 X (0 이면 IM_ACC_MS) */
static int accdec_ms(void)
{
    if (save.fp.accdec_x == 0) return IM_ACC_MS;    /* 안 정함 : 기본값 */
    return save.fp.accdec_x;                        /* FP 12 */
}

/* PR0 Immediate Trigger : 위치 + 속도 rpm + 가속 · 감속 (ms/1000rpm, 부르는 쪽이 정함) */
static int write_move(uint8_t id, uint16_t reg, int32_t pulse, int rpm, int acc, int dec, uint16_t mode)
{
    uint32_t raw = (uint32_t)pulse;
    uint16_t data[8] = {
            mode, (uint16_t)(raw >> 16),
            (uint16_t)raw, (uint16_t)rpm,
            acc, dec, 0, START_PR0
        };

    if (reg == R_PR0)
            return write_multi(id, reg, data, 8);

    return write_multi(id, reg, data, 7);
}


/* 모터 기능 : 3번, 4번 같이 */
/* mm 단위 절대위치 이동 : 움직이기라 && (위 실패하면 아래 출발 안 함). 긴급정지 · 알람이면 안 움직임 (알람이어도 수동 모드면 움직임 : 끼임 풀기) */
int IM_Move(int32_t mm, int percent)
{
    if (Motor_Stop()) return 0;                             /* 문 2 : 긴급정지 · 알람이면 안 움직임 (status.c) */
    return write_move(IM_ALL_ID, R_PR0, move_pos(mm), speed_rpm(percent), accdec_ms(), accdec_ms(), PR_POSITION);  /* 두 모터 동시에 (브로드캐스트), FP 11 · 12 */
}

/* 입고대 드나들기 끊김 없이 : IM_Move 와 같은데 기울기만 다름 (가는 중엔 새 명령을 안 받아서 한 번에 정함)
   입구 = FRAM FP 13 safe_x
   나올 때 (지금 입고대 안) : safe_x 에 닿을 때 OUT_SPEED 가 되는 출발 기울기 → 지나며 percent 까지
   들어갈 때 (목표가 입고대 안) : safe_x 에서 SAFE_SPEED 로 줄어 목표에 서는 도착 기울기 (MO → MI 안 섬)
   둘 다 평소(FP 12)보다 가파르게는 안 함. 통로 → 통로면 IM_Move 와 같음
   기울기(ms/1000rpm) = 120,000,000 × 거리 ÷ (X_PI × rpm²)   ← v² = 2·a·d 를 드라이브 단위로
   예) 거리 92mm · 27%(270rpm) → 1514  /  FP 12 가 1500 이면 거의 평소 그대로 */
int IM_MoveSoft(int32_t mm, int percent)
{
    int32_t x1, x2;                                             /* 두 모터 지금 위치 */
    int32_t safe = save.fp.safe_x;                              /* 입구 */
    uint32_t out = speed_rpm(OUT_SPEED)  * speed_rpm(OUT_SPEED);    /* 나올 때 rpm² */
    uint32_t in  = speed_rpm(SAFE_SPEED) * speed_rpm(SAFE_SPEED);   /* 들어갈 때 rpm² */
    int32_t acc = accdec_ms();                                  /* 출발 기울기 : 평소 (FP 12) */
    int32_t dec = accdec_ms();                                  /* 도착 기울기 : 평소 (FP 12) */

    /* 120,000,000 ÷ X_PI(100) = 1,200,000 을 먼저 나눠서 32비트로 (거리 3500mm 까지 안 넘침, 64비트 나눗셈 함수 760B 안 씀) */
    if (Motor_Stop()) return 0;                             /* 문 2 : 긴급정지 · 알람이면 안 움직임 (status.c) */
    if (IM_Pos(&x1, &x2)) {                                     /* 위치 읽음 (못 읽으면 평소 기울기로 그냥 감) */
        if (x2 > x1) x1 = x2;                                   /* 더 안쪽 모터 기준 */
        if (x1 > safe) acc = (120000000u / X_PI) * (uint32_t)(x1 - safe) / out;   /* 나올 때 */
    }
    if (mm > safe) dec = (120000000u / X_PI) * (uint32_t)(mm - safe) / in;        /* 들어갈 때 */

    if (acc < accdec_ms()) acc = accdec_ms();                   /* 평소보다 가파르면 평소 */
    if (dec < accdec_ms()) dec = accdec_ms();
    if (acc > 60000) acc = 60000;                               /* 레지스터 칸 16비트 */
    if (dec > 60000) dec = 60000;

    return write_move(IM_ALL_ID, R_PR0, move_pos(mm), speed_rpm(percent), acc, dec, PR_POSITION);
}

/* 멈춤 : 누른 순간부터 IM_DEC_MS 동안 천천히 (가는 중엔 quick stop 만 받음). 감속 시간 → 멈춤, 두 모터 동시에 (브로드캐스트) */
int IM_Stop(void)
{
    write16(IM_ALL_ID, R_STOP_TIME, IM_DEC_MS);       /* 1. 감속 시간 */
    return write16(IM_ALL_ID, R_CTRL, QUICK_STOP);    /* 2. 멈춤 */
}

/* 수동 JOG (매뉴얼 5.3.2) : 0x1801 ← 0x4001 / 0x4002, 두 모터 동시에 (브로드캐스트)
   50ms 안에 다시 쓰면 계속 감 → 손 떼면 안 쓰면 됨 (드라이브가 Pr6.03 기울기로 감속해서 섬, 정지 명령 없음) */
int IM_Jog(int dir, int percent)
{
    if (Motor_Stop()) return 0;                                         /* 문 2 : 긴급정지 · 알람이면 안 움직임 */
    if (dir > 0) return write16(IM_ALL_ID, R_JOG_SPEED, speed_rpm(percent))
                     && write16(IM_ALL_ID, R_CONTROL, JOG_CW);          /* 앞 (+) */
    return write16(IM_ALL_ID, R_JOG_SPEED, speed_rpm(percent))
        && write16(IM_ALL_ID, R_CONTROL, JOG_CCW);                      /* 뒤 (-) */
}

/* 드라이브 알람 리셋 : 두 모터 동시에 (과전류는 전원 껐다 켜야 함) */
int IM_AlarmReset(void)
{
    return write16(IM_ALL_ID, R_CONTROL, ALARM_RESET);
}

/* 상태 읽기 : 두 모터 모두 켜진 비트만 1 */
static uint16_t IM_State(void)
{
    uint16_t a = 0, b = 0;
    read_reg(IM_1_ID, R_STATE, 1, &a);
    read_reg(IM_2_ID, R_STATE, 1, &b);
    return a & b;
}

/* 토크 원점 -> 100mm 이동 -> 0점 : 최대 60초 */
int IM_Home(void)
{
    int32_t far = 0;
    int32_t far2 = 0;                               /* 2번 모터(ID 4) 위치 : IM_Pos 가 같이 줌 (여기선 안 씀) */
    IM_Pos(&far, &far2);                            /* 원점 시작 전 위치 = 원점까지 거리 (켠 직후는 0) */
    uint32_t start = osKernelGetTickCount();

    write16(IM_ALL_ID, R_HOME_MODE, IM_HOME_TORQUE | IM_HOME_DIR);              /* 두 모터 동시에 (브로드캐스트) */
    write_multi(IM_ALL_ID, R_HOME_HI, IM_HOME_DATA, IM_HOME_COUNT);

    if (write16(IM_ALL_ID, R_CTRL, START_HOME) == 0) return 0;                  /* 원점 시작 (못 보내면 바로 실패) */

    while ((IM_State() & IM_HOMED) == 0) {
        if (osKernelGetTickCount() - start > 60000) { IM_Stop(); return 0; }
        if (state.now == 'E') return 0;                   /* 긴급정지 : 바로 그만 */
        osDelay(ARRIVE_MS);                         /* 쉬었다 다시 묻기 (버스 비워 두기) */
    }
    if (A_10(far, start) == 1) return 0;            /* 너무 빨리 닿음 = 걸림 → 알람 10 */

    write_move(IM_ALL_ID, R_PR0, move_pos(100), 100, IM_ACC_MS, IM_ACC_MS, PR_POSITION);  /* 원점 후 100mm : 두 모터 동시에, 기본 가감속 (FP 11 · 12 와 상관없음) */

    osDelay(IM_ACC_MS);                             /* 출발할 때까지 한 번만 (이동 완료를 너무 일찍 보면 착각) */

    while ((IM_State() & IM_PATH_DONE) == 0) {      /* 100mm 이동 끝날 때까지 */
        if (osKernelGetTickCount() - start > 60000) { IM_Stop(); return 0; }
        if (state.now == 'E') return 0;                   /* 긴급정지 : 바로 그만 */
        osDelay(ARRIVE_MS);                         /* 쉬었다 다시 묻기 (버스 비워 두기) */
    }

    write16(IM_ALL_ID, R_CTRL, SET_ZERO);           /* 지금 자리를 0 으로 : 두 모터 동시에 */

    return 1;
}

/* X 두 모터 위치 mm (ID 3 · ID 4) : 둘 다 대답 1 / 하나라도 대답 없음 0 */
int IM_Pos(int32_t *mm1, int32_t *mm2)
{
    int a = read_pos(IM_1_ID, mm1);
    int b = read_pos(IM_2_ID, mm2);
    return a && b;
}

/* X 가 x(mm) 에 도착해 멈출 때까지 기다림 (최대 MOVE_MS) : 두 모터 다 x ± 10mm + 경로 완료(멈춤)면 1 / 못 감 · 긴급정지 · 알람 0 (알람은 run.c 가 A_05)
   멈춤까지 보는 이유 : 가는 중엔 드라이브가 새 명령을 안 받음 → 다음 명령(입고대 20% 진입 등)이 버려지지 않게. 상태는 가까워진 뒤에만 물음 (버스) */
int IM_Arrive(int x)
{
    int32_t mm1 = 0, mm2 = 0;                   /* 두 모터 위치 */
    uint32_t start = osKernelGetTickCount();

    while (IM_Pos(&mm1, &mm2) == 0 || abs(mm1 - x) >= 10 || abs(mm2 - x) >= 10        /* 못 읽음 · 하나라도 아직 10mm 넘게 멂 */
           || (IM_State() & IM_PATH_DONE) == 0) {                                     /* 가까운데 아직 움직이는 중 */
        if (osKernelGetTickCount() - start > MOVE_MS) return 0;         /* MOVE_MS 넘음 */
        if (Motor_Stop()) return 0;                                                  /* 긴급정지 · 알람 */
        osDelay(ARRIVE_MS);                                             /* 쉬었다 다시 묻기 (버스 비워 두기) */
    }
    return 1;
}

/* 드라이브 알람 (0x2203) : 두 모터 따로 읽고 합침 (알람은 비트라서 | 로 합쳐도 됨). 둘 다 대답하면 1, 하나라도 대답 없으면 0
   1번이 3번 물어도 대답 없으면 2번은 안 물음 → 선이 빠졌을 때 3번 만에 알람 11 (전 : 6번) */
int IM_Alarm(uint16_t *code)
{
    uint16_t a = 0, b = 0;

    if (read_reg(IM_1_ID, R_ALARM, 1, &a) == 0) return 0;   /* 1번 모터 */
    if (read_reg(IM_2_ID, R_ALARM, 1, &b) == 0) return 0;   /* 2번 모터 */
    *code = a | b;
    return 1;
}

/* Register Mapping 설정 : 0x0F00 부터 상태 · 위치 · 알람 · 경고를 한 번에 읽을 수 있게 (두 모터 동시에, 브로드캐스트) */
int IM_MapInit(void)
{
    const uint16_t data[MAP_COUNT] = { R_STATE, R_FB_POS_H, R_FB_POS_L, R_ALARM, R_HOME_WARN };

    return write_multi(IM_ALL_ID, R_MAP_SET, data, MAP_COUNT);
}

