#include "i_motor.h"
#include "usart.h"
#include "cmsis_os2.h"
#include "cli.h"
#include "event.h"
#include "save.h"
#include "status.h"
#include "alarm.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define GAP     10      /* 도착 판정 오차 (mm) */

/* 통신 */
#define RETRY        3
#define BUS_GAP      2       /* ms : 프레임 사이 쉬는 시간 */
#define RX_TIMEOUT   500
#define IM_1_ID      3       /* DIP 스위치로 설정한 주소 */
#define IM_2_ID      4

/* 데이터시트 레지스터 */
#define R_STATE       0x1003   /* Motion state */
#define R_FB_POS_H    0x1014   /* Feedback position H */
#define R_FB_POS_L    0x1015   /* Feedback position L */
#define SET_ZERO      0x0021   /* Set Zero */
#define R_ALARM       0x2203   /* Current alarm */
#define R_CONTROL     0x1801   /* Control word */
#define R_CTRL        0x6002   /* Pr8.02 Trigger register */
#define R_HOME_MODE   0x600A   /* Pr8.10 Homing mode */
#define R_HOME_HI     0x600F   /* Pr8.15 Homing high velocity */
#define R_STOP_TIME   0x6017   /* Pr8.23 quick stop 감속 시간 ms */
#define R_HOME_WARN   0x601D   /* Pr8.29 PR warning */
#define R_PR0         0x6200   /* Pr9.00 ~ Pr9.07 */
#define R_REAL_POS_H  0x602C   /* Pr8.44 Actual position H */

/* Mapping: 설정 0x0F10~, 데이터시트 예제 읽기 0x0F00~ */
#define R_MAP_DATA    0x0F00
#define R_MAP_SET     0x0F10
#define MAP_COUNT     5

/* Trigger 값 */
#define PR_POSITION   0x0001   /* TYPE=1 Position, Bit6=0 Absolute */
#define START_PR0     0x0010
#define START_HOME    0x0020
#define QUICK_STOP    0x0040
#define ALARM_RESET   0x1111   /* R_CONTROL : 현재 알람 리셋 */

/* Modbus RTU CRC16 */
static uint16_t crc16(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++)
            crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
    }
    return crc;
}

/* UART2 Hardware RS485 송수신 : 응답 올 때까지 잠든다 (DMA) */
static int bus_xfer(uint8_t *tx, uint16_t tn, uint8_t *rx, uint16_t rn)
{
    HAL_StatusTypeDef r;
    r = UART2_Xfer(tx, tn, rx, rn, RX_TIMEOUT);
    osDelay(BUS_GAP);
    return r == HAL_OK;
}

/* FC06 : 16비트 레지스터 1개 쓰기 */
static int write16(uint8_t id, uint16_t reg, uint16_t val)
{
    uint8_t tx[8], rx[8];
    uint16_t crc;
    tx[0] = id; tx[1] = 0x06;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = val >> 8; tx[5] = (uint8_t)val;
    crc = crc16(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);
    for (uint8_t retry = 0; retry < RETRY; retry++) {
        if (bus_xfer(tx, 8, rx, 8) && memcmp(rx, tx, 8) == 0) return 1;
    }
    return 0;
}

/* FC03 : 연속 레지스터 읽기 */
static int read_reg(uint8_t id, uint16_t reg, uint8_t qty, uint16_t *out)
{
    uint8_t tx[8], rx[32];
    uint16_t n = 5 + qty * 2, crc;
    tx[0] = id; tx[1] = 0x03;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = 0; tx[5] = qty;
    crc = crc16(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);

    for (uint8_t retry = 0; retry < RETRY; retry++) {
        if (bus_xfer(tx, 8, rx, n) == 0) continue;
        crc = crc16(rx, n - 2);
        if (rx[0] != id || rx[1] != 0x03 || rx[2] != qty * 2) continue;
        if (rx[n - 2] != (uint8_t)crc || rx[n - 1] != (uint8_t)(crc >> 8)) continue;
        for (uint8_t i = 0; i < qty; i++)
            out[i] = ((uint16_t)rx[3 + i * 2] << 8) | rx[4 + i * 2];
        return 1;
    }
    return 0;
}

/* FC10 : 연속 레지스터 여러 개 쓰기 */
static int write_multi(uint8_t id, uint16_t reg, const uint16_t *data, uint8_t qty)
{
    uint8_t tx[32], rx[8];
    uint16_t n = 7 + qty * 2, crc;
    tx[0] = id; tx[1] = 0x10;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = 0; tx[5] = qty; tx[6] = qty * 2;
    for (uint8_t i = 0; i < qty; i++) {
        tx[7 + i * 2] = data[i] >> 8;
        tx[8 + i * 2] = (uint8_t)data[i];
    }
    crc = crc16(tx, n);
    tx[n] = (uint8_t)crc; tx[n + 1] = (uint8_t)(crc >> 8);

    for (uint8_t retry = 0; retry < RETRY; retry++) {
        if (bus_xfer(tx, n + 2, rx, 8) == 0) continue;
        crc = crc16(rx, 6);
        if (rx[0] == id && rx[1] == 0x10 && rx[2] == tx[2] && rx[3] == tx[3]
                && rx[4] == 0 && rx[5] == qty && rx[6] == (uint8_t)crc
                && rx[7] == (uint8_t)(crc >> 8)) return 1;
    }
    return 0;
}

/* mm -> pulse */
static int32_t move_pos(int32_t mm)
{
    return (int32_t)((int64_t)mm * X_PULSE / X_PI);
}

/* 32비트 값 읽기 : High + Low */
static int read32(uint8_t id, uint16_t reg, int32_t *value)
{
    uint16_t data[2];

    if (read_reg(id, reg, 2, data) == 0)
        return 0;

    *value = (int32_t)(((uint32_t)data[0] << 16) | data[1]);

    return 1;
}

/* 현재 위치 mm */
static int read_pos(uint8_t id, int32_t *mm)
{
    int32_t pulse;

    if (read32(id, R_REAL_POS_H, &pulse) == 0)
        return 0;

    *mm = (int32_t)((int64_t)pulse * X_PI / X_PULSE );

    return 1;
}

/* % → rpm : 100% = FP 11 X 속도 (0 이면 IM_MAX_RPM) */
static int speed_rpm(int percent)
{
    if (save.fp.speed_x == 0) return percent * IM_MAX_RPM / 100;    /* 안 정함 : 기본값 */
    return percent * save.fp.speed_x / 100;                         /* FP 11 */
}

/* 가감속 ms : FP 12 X (0 이면 IM_ACC_MS) */
static int accdec_ms(void)
{
    if (save.fp.accdec_x == 0) return IM_ACC_MS;    /* 안 정함 : 기본값 */
    return save.fp.accdec_x;                        /* FP 12 */
}

/* PR0 Immediate Trigger : 위치 + 속도 rpm + 가감속 ms (부르는 쪽이 정함) */
static int write_move(uint8_t id, uint16_t reg, int32_t pulse, int rpm, int acc)
{
    uint32_t raw = (uint32_t)pulse;
    uint16_t data[8] = {
        PR_POSITION, (uint16_t)(raw >> 16), (uint16_t)raw, (uint16_t)rpm,
        acc, acc, 0, START_PR0
    };
    return write_multi(id, reg, data, 8);
}

/* Mapping 설정 */
static int write_map(uint8_t id)
{
    const uint16_t data[MAP_COUNT] = {
        R_STATE,
        R_FB_POS_H,
        R_FB_POS_L,
        R_ALARM,
        R_HOME_WARN
    };

    return write_multi(id, R_MAP_SET, data, MAP_COUNT);
}

static int read_map(uint8_t id, IM_Info *info)
{
    uint16_t data[MAP_COUNT];

    if (read_reg(id, R_MAP_DATA, MAP_COUNT, data) == 0)
        return 0;

    info->state = data[0];
    info->pos   = (int32_t)(((uint32_t)data[1] << 16) | data[2]);
    info->alarm = data[3];
    info->warn  = data[4];

    return 1;
}
/* 모터 기능 : 3번, 4번 같이 */
/* mm 단위 절대위치 이동 : 움직이기라 && (위 실패하면 아래 출발 안 함). 긴급정지 · 알람이면 안 움직임 */
int IM_Move(int32_t mm, int percent)
{
    if (estop == 1 || status_1 == ALARM) return 0;
    return write_move(IM_1_ID, R_PR0, move_pos(mm), speed_rpm(percent), accdec_ms())     /* FP 11 · 12 */
        && write_move(IM_2_ID, R_PR0, move_pos(mm), speed_rpm(percent), accdec_ms());
}

/* 멈춤 : 누른 순간부터 IM_DEC_MS 동안 천천히 (가는 중엔 quick stop 만 받음). 감속 시간 먼저 두 모터 → 멈춤 두 모터 */
int IM_Stop(void)
{
    write16(IM_1_ID, R_STOP_TIME, IM_DEC_MS);         /* 1. 감속 시간 */
    write16(IM_2_ID, R_STOP_TIME, IM_DEC_MS);
    int a = write16(IM_1_ID, R_CTRL, QUICK_STOP);     /* 2. 멈춤 */
    int b = write16(IM_2_ID, R_CTRL, QUICK_STOP);
    return a && b;
}

/* 드라이브 알람 리셋 : 두 모터 (과전류는 전원 껐다 켜야 함) */
int IM_AlarmReset(void)
{
    int a = write16(IM_1_ID, R_CONTROL, ALARM_RESET);
    int b = write16(IM_2_ID, R_CONTROL, ALARM_RESET);
    return a && b;
}

/* 현재 위치를 0으로 */
static int IM_Zero(void)
{
    int a = write16(IM_1_ID, R_CTRL, SET_ZERO);
    int b = write16(IM_2_ID, R_CTRL, SET_ZERO);
    return a && b;
}

/* 상태 읽기 : 두 모터 모두 켜진 비트만 1 */
static uint16_t IM_State(void)
{
    uint16_t a = 0, b = 0;
    read_reg(IM_1_ID, R_STATE, 1, &a);
    read_reg(IM_2_ID, R_STATE, 1, &b);
    return a & b;
}

/* PR 이동 완료 */
static int IM_Done(void)
{
    return (IM_State() & IM_PATH_DONE);
}

/* 토크 원점 -> 100mm 이동 -> 0점 : 최대 60초 */
int IM_Home(void)
{
    int32_t far = 0;
    IM_Pos(&far);                                   /* 원점 시작 전 위치 = 원점까지 거리 (켠 직후는 0) */
    uint32_t start = osKernelGetTickCount();

    write16(IM_1_ID, R_HOME_MODE, IM_HOME_TORQUE | IM_HOME_DIR);
    write16(IM_2_ID, R_HOME_MODE, IM_HOME_TORQUE | IM_HOME_DIR);

    write_multi(IM_1_ID, R_HOME_HI, IM_HOME_DATA, IM_HOME_COUNT);
    write_multi(IM_2_ID, R_HOME_HI, IM_HOME_DATA, IM_HOME_COUNT);

    if ((write16(IM_1_ID, R_CTRL, START_HOME) && write16(IM_2_ID, R_CTRL, START_HOME)) == 0) return 0;   /* 원점 시작 (못 보내면 바로 실패) */

    while ((IM_State() & IM_HOMED) == 0) {
        if (osKernelGetTickCount() - start > 60000) { IM_Stop(); return 0; }
        if (estop == 1) return 0;                   /* 긴급정지 : 바로 그만 */
        osDelay(20);
    }
    if (A_10(far, start) == 1) return 0;            /* 너무 빨리 닿음 = 걸림 → 알람 10 */

    write_move(IM_1_ID, R_PR0, move_pos(100), 100, IM_ACC_MS);   /* 원점 후 100mm : 150rpm, 기본 가감속 (FP 11 · 12 와 상관없음) */
    write_move(IM_2_ID, R_PR0, move_pos(100), 100, IM_ACC_MS);

    while (IM_Done() == 0) {
        if (osKernelGetTickCount() - start > 60000) { IM_Stop(); return 0; }
        if (estop == 1) return 0;                   /* 긴급정지 : 바로 그만 */
        osDelay(IM_ACC_MS);  // 이동 완료를 너무 일찍 하면  문제가 생길 수 있음.
    }

    IM_Zero();

    return 1;
}

/* 상태 읽기 : 3번 모터 기준 */
int IM_Pos(int32_t *mm){ return read_pos(IM_1_ID, mm); }

/* X 가 x(mm) 에 도착했나 : 한 번 보고 1 / 0 (위치 못 읽으면 0) */
int IM_Arrive(int x)
{
    int32_t now = 0;
    return IM_Pos(&now) && abs(now - x) < GAP;
}

/* 드라이브 알람 (0x2203) : 두 모터 따로 읽고 합침 (알람은 비트라서 | 로 합쳐도 됨). 둘 다 대답하면 1, 하나라도 대답 없으면 0 */
int IM_Alarm(uint16_t *code)
{
    uint16_t a = 0, b = 0;
    int ok_a = read_reg(IM_1_ID, R_ALARM, 1, &a);       /* 1번 모터 */
    int ok_b = read_reg(IM_2_ID, R_ALARM, 1, &b);       /* 2번 모터 */

    *code = a | b;
    return ok_a && ok_b;
}

/* Register Mapping : 설정은 두 모터, 읽기는 3번 */
int IM_MapInit(void)
{
    int a = write_map(IM_1_ID);
    int b = write_map(IM_2_ID);
    return a && b;
}

int IM_MapRead(IM_Info *info) { return read_map(IM_1_ID, info); }    /* 상태+위치+알람 한 번에 : 알람 만들 때 사용 */
