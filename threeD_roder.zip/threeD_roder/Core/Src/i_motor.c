#include "i_motor.h"
#include "usart.h"
#include "cmsis_os2.h"
#include "event.h"
#include "save.h"
#include "status.h"
#include "alarm.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* 통신 */
#define IM_1_ID      3       /* DIP 스위치로 설정한 주소 */
#define IM_2_ID      4       /* [현장] 4 (X 2번 모터) / 사무실 3 (X 모터 하나) */
#define IM_ALL_ID    0       /* [현장] 0 (브로드캐스트 : ID 3 · 4 가 같이 받음, 대답 없음) / 사무실 3 (X 모터 하나, 대답 확인) */

/* 데이터시트 레지스터 */
#define R_STATE       0x1003   /* Motion state */
#define R_POS_H       0x602C   /* Pr8.44 Actual position H (방향 설정 반영 → X1 · X2 같은 부호. 0x1014 Feedback 은 X2 가 - 로 나옴, 11/18) */
#define R_POS_L       0x602D   /* Pr8.44 Actual position L */
#define SET_ZERO      0x0021   /* Set Zero */
#define R_ALARM       0x2203   /* Current alarm */
#define R_CONTROL     0x1801   /* Control word */
#define R_CTRL        0x6002   /* Pr8.02 Trigger register */
#define R_HOME_MODE   0x600A   /* Pr8.10 Homing mode */
#define R_HOME_HI     0x600F   /* Pr8.15 Homing high velocity */
#define R_STOP_TIME   0x6017   /* Pr8.23 quick stop 감속 시간 ms */
#define R_HOME_WARN   0x601D   /* Pr8.29 PR warning */
#define R_PR0  0x6200   /* Pr9.00 ~ Pr9.07 */

/* Mapping: 설정 0x0F10~, 데이터시트 예제 읽기 0x0F00~ */
#define R_MAP_SET     0x0F10
#define R_MAP_READ    0x0F00   /* 모아 둔 5칸 읽는 곳 : 상태 · 위치 H · 위치 L · 알람 · 경고 */
#define MAP_COUNT     5

volatile MOTOR im1;     /* 칠판 : X1 (ID 3) — Bus_Task IM_Read 가 40ms 마다 적음 */
volatile MOTOR im2;     /* 칠판 : X2 (ID 4) */

/* Trigger 값 */
#define PR_POSITION   0x0001   /* TYPE=1 Position, Bit6=0 Absolute */
#define START_PR0     0x0010
#define START_HOME    0x0020
#define QUICK_STOP    0x0040
#define ALARM_RESET   0x1111   /* R_CONTROL : 현재 알람 리셋 */
#define R_JOG_SPEED   0x01E1   /* Pr6.00 JOG 속도 rpm (RS485 JOG) */
#define JOG_CW        0x4001   /* R_CONTROL : JOG + (50ms 안에 다시 써야 계속 감) */
#define JOG_CCW       0x4002   /* R_CONTROL : JOG - */

/* Modbus RTU CRC16 */
static uint16_t crc16(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++)
            crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
    }
    return crc;
}


/* FC06 : 16비트 레지스터 1개 쓰기 */
static int write16(uint8_t id, uint16_t reg, uint16_t val)
{
    uint8_t tx[8], rx[8];
    uint16_t crc;
    tx[0] = id; tx[1] = 0x06;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = val >> 8; tx[5] = (uint8_t)val;
    crc = crc16(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);

    if (id == 0) return UART2_Send(tx, 8);     /* 브로드캐스트 : 대답 없이 한 번만 보냄 */

    for (uint8_t retry = 0; retry < MOTOR_RETRY; retry++) {
        if (UART2_Xfer(tx, 8, rx, 8, X_RX_MS) && memcmp(rx, tx, 8) == 0) return 1;
    }
    return 0;
}

/* FC03 : 연속 레지스터 읽기. tries = 묻는 횟수 · rx_ms = 대답 기다림
   (Bus_Task : 1번 · BUS_RX_MS / 그 밖 : MOTOR_RETRY · X_RX_MS) */
static int read_reg(uint8_t id, uint16_t reg, uint8_t qty, uint16_t *out, uint8_t tries, uint32_t rx_ms)
{
    uint8_t tx[8], rx[32];
    uint16_t n = 5 + qty * 2, crc;
    tx[0] = id; tx[1] = 0x03;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = 0; tx[5] = qty;
    crc = crc16(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);

    for (uint8_t retry = 0; retry < tries; retry++) {
        if (UART2_Xfer(tx, 8, rx, n, rx_ms) == 0) continue;
        crc = crc16(rx, n - 2);
        if (rx[0] != id || rx[1] != 0x03 || rx[2] != qty * 2) continue;
        if (rx[n - 2] != (uint8_t)crc || rx[n - 1] != (uint8_t)(crc >> 8)) continue;
        for (uint8_t i = 0; i < qty; i++)
            out[i] = ((uint16_t)rx[3 + i * 2] << 8) | rx[4 + i * 2];
        return 1;
    }
    return 0;
}

/* FC10 : 연속 레지스터 여러 개 쓰기 */
static int write_multi(uint8_t id, uint16_t reg, const uint16_t *data, uint8_t qty)
{
    uint8_t tx[32], rx[8];
    uint16_t n = 7 + qty * 2, crc;
    tx[0] = id; tx[1] = 0x10;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = 0; tx[5] = qty; tx[6] = qty * 2;
    for (uint8_t i = 0; i < qty; i++) {
        tx[7 + i * 2] = data[i] >> 8;
        tx[8 + i * 2] = (uint8_t)data[i];
    }
    crc = crc16(tx, n);
    tx[n] = (uint8_t)crc; tx[n + 1] = (uint8_t)(crc >> 8);

    if (id == 0) return UART2_Send(tx, n + 2);     /* 브로드캐스트 : 대답 없이 한 번만 보냄 */

    for (uint8_t retry = 0; retry < MOTOR_RETRY; retry++) {
        if (UART2_Xfer(tx, n + 2, rx, 8, X_RX_MS) == 0) continue;
        crc = crc16(rx, 6);
        if (rx[0] == id && rx[1] == 0x10 && rx[2] == tx[2] && rx[3] == tx[3]
                && rx[4] == 0 && rx[5] == qty && rx[6] == (uint8_t)crc
                && rx[7] == (uint8_t)(crc >> 8)) return 1;
    }
    return 0;
}

/* mm -> pulse */
static int32_t move_pos(int32_t mm)
{
    return mm * X_PULSE / X_PI;                         /* 32비트로 충분 (2000mm × 10000 = 2천만 < 21억) */
}

/* (디버그 · CLI) X 레지스터 읽기 : motor 1 = IM_1_ID / 2 = IM_2_ID, qty 1 = 16bit · 2 = 32bit (높은 칸 먼저). 읽으면 1 / 대답 없음 0 */
int IM_ReadReg(int motor, uint16_t reg, uint16_t *out, uint8_t qty)
{
    return read_reg(motor == 1 ? IM_1_ID : IM_2_ID, reg, qty, out, MOTOR_RETRY, X_RX_MS);
}

/* % → rpm : 100% = FP 11 X 속도 (0 이면 IM_MAX_RPM) */
static int speed_rpm(int percent)
{
    if (save.fp.speed_x == 0) return percent * IM_MAX_RPM / 100;    /* 안 정함 : 기본값 */
    return percent * save.fp.speed_x / 100;                         /* FP 11 */
}

/* 가감속 ms : FP 12 X (0 이면 IM_ACC_MS) */
static int accdec_ms(void)
{
    if (save.fp.accdec_x == 0) return IM_ACC_MS;    /* 안 정함 : 기본값 */
    return save.fp.accdec_x;                        /* FP 12 */
}

/* PR0 Immediate Trigger : 위치 + 속도 rpm + 가속 · 감속 (ms/1000rpm, 부르는 쪽이 정함) */
static int write_move(uint8_t id, uint16_t reg, int32_t pulse, int rpm, int acc, int dec, uint16_t mode)
{
    uint32_t raw = (uint32_t)pulse;
    uint16_t data[8] = {
            mode, (uint16_t)(raw >> 16),
            (uint16_t)raw, (uint16_t)rpm,
            acc, dec, 0, START_PR0
        };

    if (reg == R_PR0)
            return write_multi(id, reg, data, 8);

    return write_multi(id, reg, data, 7);
}


/* 모터 기능 : 3번, 4번 같이 */
/* X 이동 (하나뿐) : mm 절대위치, 두 모터 동시에 (브로드캐스트). 긴급정지 · 알람이면 안 움직임
   입고대(FRAM FP 13 safe_x 안쪽)를 드나들 때만 기울기를 공식으로 정함 → 입구에서 나올 땐 OUT_SPEED %, 들어갈 땐 SAFE_SPEED %
   통로 → 통로는 평소 기울기 (FP 12). X 드라이브는 가는 중엔 새 명령을 안 받아서 한 번에 정해 보냄
   공식 : 기울기(ms) = 1,200,000 × 입구까지 거리(mm) ÷ 입구 속도(rpm)²    ← v² = 2·a·d (1,200,000 = 120,000,000 ÷ 풀리 100mm)
   예) 입고대 92mm : 나올 때 27%(270rpm) → 1514 · 들어갈 때 20%(200rpm) → 2760 */
int IM_MoveSoft(int32_t mm, int percent)
{
    uint32_t out = speed_rpm(OUT_SPEED);            /* 나올 때 입구 속도 rpm (27%) */
    uint32_t in  = speed_rpm(SAFE_SPEED);           /* 들어갈 때 입구 속도 rpm (20%) */
    uint32_t acc = accdec_ms();                     /* 평소 기울기 (FP 12) */
    uint32_t dec = accdec_ms();

    if (Motor_Stop()) return 0;                     /* 긴급정지 · 알람이면 안 보냄 */
    if (im1.pos > save.fp.safe_x) acc = 1200000u * (uint32_t)(im1.pos - save.fp.safe_x) / (out * out);   /* 입고대 안에서 출발 (칠판 X1 위치) */
    if (mm > save.fp.safe_x) dec = 1200000u * (uint32_t)(mm - save.fp.safe_x) / (in * in);     /* 입고대로 들어감 */
    if (acc < accdec_ms()) acc = accdec_ms();       /* 평소보다 가파르면 평소 (입고대 중간에서 출발해도 확 안 튐) */
    if (dec < accdec_ms()) dec = accdec_ms();
    return write_move(IM_ALL_ID, R_PR0, move_pos(mm), speed_rpm(percent), acc, dec, PR_POSITION);
}

/* 멈춤 : 누른 순간부터 IM_DEC_MS 동안 직선으로 줄며 섬, 두 모터 동시에 (브로드캐스트)
   감속 시간(Pr8.23)은 가는 중엔 안 받음 → IM_MapInit 이 서 있을 때 미리 넣어 둠 (11/17) */
int IM_Stop(void)
{
    return write16(IM_ALL_ID, R_CTRL, QUICK_STOP);    /* 멈춤 (Pr8.02 ← 0x040) */
}

/* 수동 JOG (매뉴얼 5.3.2) : 0x1801 ← 0x4001 / 0x4002, 두 모터 동시에 (브로드캐스트)
   50ms 안에 다시 쓰면 계속 감 → 손 떼면 안 쓰면 됨 (드라이브가 Pr6.03 기울기로 감속해서 섬, 정지 명령 없음)
   percent : 누를 때 = 속도 % (속도 + 동작 2개) / 다시 쓰기 = 0 (동작만 1개 → 선 절반, 11/18 A1) */
int IM_Jog(int dir, int percent)
{
    if (Motor_Stop()) return 0;                                         /* 문 2 : 긴급정지 · 알람이면 안 움직임 */
    if (percent && write16(IM_ALL_ID, R_JOG_SPEED, speed_rpm(percent)) == 0) return 0;   /* 속도 : 누를 때만 */
    if (dir > 0) return write16(IM_ALL_ID, R_CONTROL, JOG_CW);          /* 앞 (+) */
    return write16(IM_ALL_ID, R_CONTROL, JOG_CCW);                      /* 뒤 (-) */
}

/* 드라이브 알람 리셋 : 두 모터 동시에 (과전류는 전원 껐다 켜야 함) */
int IM_AlarmReset(void)
{
    return write16(IM_ALL_ID, R_CONTROL, ALARM_RESET);
}

/* 상태 읽기 : 두 모터 모두 켜진 비트만 1 */
static uint16_t IM_State(void)
{
    uint16_t a = 0, b = 0;
    read_reg(IM_1_ID, R_STATE, 1, &a, MOTOR_RETRY, X_RX_MS);
    read_reg(IM_2_ID, R_STATE, 1, &b, MOTOR_RETRY, X_RX_MS);
    return a & b;
}

/* 토크 원점 -> 100mm 이동 -> 0점 : 최대 60초 */
int IM_Home(void)
{
    osDelay(2 * BUS_MS);                            /* 매핑(IM_MapInit) 넣은 뒤 칠판이 새로 적힐 때까지 (X 드라이브만 껐다 켰으면 옛 위치가 남아 있음) */
    int32_t far = im1.pos;                          /* 원점 시작 전 위치 = 원점까지 거리 → A_10 걸림 검사 (켠 직후는 0) */
    uint32_t start = osKernelGetTickCount();

    write16(IM_ALL_ID, R_HOME_MODE, IM_HOME_TORQUE | IM_HOME_DIR);              /* 두 모터 동시에 (브로드캐스트) */
    write_multi(IM_ALL_ID, R_HOME_HI, IM_HOME_DATA, IM_HOME_COUNT);

    if (write16(IM_ALL_ID, R_CTRL, START_HOME) == 0) return 0;                  /* 원점 시작 (못 보내면 바로 실패) */

    while ((IM_State() & IM_HOMED) == 0) {
        if (osKernelGetTickCount() - start > 60000) { IM_Stop(); return 0; }
        if (state.now == 'E') return 0;                   /* 긴급정지 : 바로 그만 */
        osDelay(ARRIVE_MS);                         /* 쉬었다 다시 묻기 (버스 비워 두기) */
    }
    if (A_10(far, start) == 1) return 0;            /* 너무 빨리 닿음 = 걸림 → 알람 10 */

    write_move(IM_ALL_ID, R_PR0, move_pos(25), 100, IM_ACC_MS, IM_ACC_MS, PR_POSITION);  /* 원점 후 100mm : 두 모터 동시에, 기본 가감속 (FP 11 · 12 와 상관없음) */

    osDelay(IM_ACC_MS);                             /* 출발할 때까지 한 번만 (이동 완료를 너무 일찍 보면 착각) */

    while ((IM_State() & IM_PATH_DONE) == 0) {      /* 100mm 이동 끝날 때까지 */
        if (osKernelGetTickCount() - start > 60000) { IM_Stop(); return 0; }
        if (state.now == 'E') return 0;                   /* 긴급정지 : 바로 그만 */
        osDelay(ARRIVE_MS);                         /* 쉬었다 다시 묻기 (버스 비워 두기) */
    }

    write16(IM_ALL_ID, R_CTRL, SET_ZERO);           /* 지금 자리를 0 으로 : 두 모터 동시에 */

    return 1;
}

/* X 가 x(mm) 에 도착해 멈출 때까지 기다림 (최대 MOVE_MS) : 두 모터 다 x ± 10mm + 경로 완료(멈춤)면 1 / 못 감 · 긴급정지 · 알람 0 (알람은 run.c 가 A_05)
   멈춤까지 보는 이유 : 가는 중엔 드라이브가 새 명령을 안 받음 → 다음 명령(입고대 20% 진입 등)이 버려지지 않게
   선에 묻지 않고 칠판(im1 · im2, Bus_Task 가 40ms 마다 적음)만 봄 (11/17 B1) */
int IM_Arrive(int x)
{
    uint32_t start = osKernelGetTickCount();

    while (abs(im1.pos - x) >= 10 || abs(im2.pos - x) >= 10                      /* 하나라도 아직 10mm 넘게 멂 */
           || (im1.state & im2.state & IM_PATH_DONE) == 0) {                       /* 가까운데 아직 움직이는 중 */
        if (osKernelGetTickCount() - start > MOVE_MS) return 0;         /* MOVE_MS 넘음 */
        if (Motor_Stop()) return 0;                                     /* 긴급정지 · 알람 */
        osDelay(ARRIVE_MS);                                             /* 쉬었다 다시 보기 */
    }
    return 1;
}

/* X 두 모터가 x(mm) 를 지나 바깥쪽(작은 쪽)에 올 때까지 기다림 (최대 MOVE_MS, 멈춤은 안 봄 → X 는 계속 감)
   지남 1 / 못 감 · 긴급정지 · 알람 0 (알람은 run.c 가 A_05). run.c MO 가 입고대 안에서 출발할 때 Y 를 언제 보낼지 (11/17)
   입고대 쪽이 X 큰 쪽 : "지남" = x 보다 작아짐. 이미 밖이면 바로 끝. 칠판(im1 · im2)만 봄 */
int IM_Pass(int x)
{
    uint32_t start = osKernelGetTickCount();

    while (im1.pos > x || im2.pos > x) {                                /* 하나라도 아직 안쪽 */
        if (osKernelGetTickCount() - start > MOVE_MS) return 0;         /* MOVE_MS 넘음 */
        if (Motor_Stop()) return 0;                                     /* 긴급정지 · 알람 */
        osDelay(ARRIVE_MS);                                             /* 쉬었다 다시 보기 */
    }
    return 1;
}

/* Register Mapping 설정 : 0x0F00 부터 상태 · 위치 · 알람 · 경고를 한 번에 읽을 수 있게 (두 모터 동시에, 브로드캐스트) */
int IM_MapInit(void)
{
    const uint16_t data[MAP_COUNT] = { R_STATE, R_POS_H, R_POS_L, R_ALARM, R_HOME_WARN };

    return write_multi(IM_ALL_ID, R_MAP_SET, data, MAP_COUNT)
        && write16(IM_ALL_ID, R_STOP_TIME, IM_DEC_MS);      /* 급정지 감속 시간 : 서 있을 때 미리 (가는 중엔 안 받음) */
}

/* (Bus_Task) X 두 모터 → 칠판 im1 · im2 : 0F00 부터 5칸을 한 번씩만 (BUS_RX_MS). 둘 다 받으면 1
   못 받으면 칠판은 그대로 두고 miss 만 올림 (다음 바퀴에 다시). 원점 전(매핑 전)엔 못 받는 게 정상 */
int IM_Read(void)
{
    uint16_t w[MAP_COUNT];      /* 0 상태 · 1 위치 H · 2 위치 L · 3 알람 · 4 경고 */
    int a = 0;
    int b = 0;

    if (read_reg(IM_1_ID, R_MAP_READ, MAP_COUNT, w, 1, BUS_RX_MS)) {           /* X1 */
        im1.state = w[0];
        im1.pos   = (int32_t)(((uint32_t)w[1] << 16) | w[2]) * X_PI / X_PULSE; /* 펄스 → mm */
        im1.alarm = w[3];
        im1.miss  = 0;
        a = 1;
    }
    else im1.miss++;

    if (read_reg(IM_2_ID, R_MAP_READ, MAP_COUNT, w, 1, BUS_RX_MS)) {           /* X2 */
        im2.state = w[0];
        im2.pos   = (int32_t)(((uint32_t)w[1] << 16) | w[2]) * X_PI / X_PULSE;
        im2.alarm = w[3];
        im2.miss  = 0;
        b = 1;
    }
    else im2.miss++;

    return a && b;
}

