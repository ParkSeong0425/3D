/*
 * t_motor.c
 *
 *  Created on: Sep 11, 2026
 *      Author: HWNOT
 */
#include "t_motor.h"
#include "usart.h"
#include "event.h"
#include "save.h"
#include "status.h"
#include "alarm.h"
#include "cmsis_os2.h"
#include <string.h>
#include <stdlib.h>


/* 통신 */
#define RETRY         3
#define RX_TIMEOUT    500
#define TM_ID         2       /* DIP 스위치로 설정한 주소 */

/* TL57-R 레지스터 */
#define R_STATE       0x0004   /* PA_004 Run state */
#define R_ALARM       0x0005   /* PA_005 Current alarm */
#define R_POS         0x0008   /* PA_008/009 Current position H/L */
#define R_DI0         0x0011   /* PA_011 DI0 function */
#define R_DIR         0x0022   /* PA_022 Default direction */
#define R_PPR         0x0023   /* PA_023 Subdivision */
#define R_START       0x0033   /* PA_033 Start rpm */
#define R_ACC         0x0034   /* PA_034 Acc */
#define R_DEC         0x0035   /* PA_035 Dec */
#define R_SPEED       0x0036   /* PA_036 Position rpm */
#define R_TARGET      0x0037   /* PA_037/038 Target H/L */
#define R_HOME_MODE   0x0040   /* PA_040 Home mode */
#define R_HOME_RPM    0x0041   /* PA_041 Home rpm */
#define R_CREEP_RPM   0x0042   /* PA_042 Zero search rpm */
#define R_HOME_ACC    0x0043   /* PA_043 Home acc/dec */
#define R_CTRL        0x004E   /* PA_04E Control word */
#define R_AUX         0x004F   /* PA_04F Auxiliary control */

#define GO_ABS        0x0003
#define START_HOME    0x0010   /* 원점 시작 (status.h 의 상태 HOME 과 겹치지 않게) */
#define STOP          0x0020
#define ZERO_POS      0x0400
#define ENABLE        0x0500
#define ALARM_CLEAR   0x0300   /* PA_04F : 현재 알람 지우기 */

static const uint8_t id = TM_ID;

/* Modbus RTU CRC16 */
static uint16_t crc16(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++)
            crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
    }
    return crc;
}

/* G473 UART2 Hardware RS485 DE : 응답 올 때까지 잠든다 (DMA) */
static int bus_xfer(uint8_t *tx, uint16_t tn, uint8_t *rx, uint16_t rn)
{
    HAL_StatusTypeDef r;
    r = UART2_Xfer(tx, tn, rx, rn, RX_TIMEOUT);
    return r == HAL_OK;
}

/* FC06 */
static int write16(uint16_t reg, uint16_t val)
{
    uint8_t tx[8], rx[8];
    uint16_t crc;
    tx[0] = id; tx[1] = 0x06;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = val >> 8; tx[5] = (uint8_t)val;
    crc = crc16(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);
    for (uint8_t retry = 0; retry < RETRY; retry++) {
        if (bus_xfer(tx, 8, rx, 8) && memcmp(rx, tx, 8) == 0) return 1;
    }
    return 0;
}

/* FC03 */
static int read_reg(uint16_t reg, uint8_t qty, uint16_t *out)
{
    uint8_t tx[8], rx[16];
    uint16_t n = 5 + qty * 2, crc;
    tx[0] = id; tx[1] = 0x03;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = 0; tx[5] = qty;
    crc = crc16(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);
    for (uint8_t retry = 0; retry < RETRY; retry++) {
        if (bus_xfer(tx, 8, rx, n) == 0) continue;
        crc = crc16(rx, n - 2);
        if (rx[0] != id || rx[1] != 0x03 || rx[2] != qty * 2) continue;
        if (rx[n - 2] != (uint8_t)crc || rx[n - 1] != (uint8_t)(crc >> 8)) continue;
        for (uint8_t i = 0; i < qty; i++)
            out[i] = ((uint16_t)rx[3 + i * 2] << 8) | rx[4 + i * 2];
        return 1;
    }
    return 0;
}

/* FC10 : 32bit High -> Low */
static int write32(uint16_t reg, int32_t val)
{
    uint8_t tx[13], rx[8];
    uint32_t raw = (uint32_t)val;
    uint16_t crc;
    tx[0] = id; tx[1] = 0x10;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = 0; tx[5] = 2; tx[6] = 4;
    tx[7] = (uint8_t)(raw >> 24); tx[8] = (uint8_t)(raw >> 16);
    tx[9] = (uint8_t)(raw >> 8); tx[10] = (uint8_t)raw;
    crc = crc16(tx, 11);
    tx[11] = (uint8_t)crc; tx[12] = (uint8_t)(crc >> 8);
    for (uint8_t retry = 0; retry < RETRY; retry++) {
        if (bus_xfer(tx, 13, rx, 8) == 0) continue;
        crc = crc16(rx, 6);
        if (rx[0] == id && rx[1] == 0x10 && rx[2] == tx[2] && rx[3] == tx[3]
                && rx[4] == 0 && rx[5] == 2 && rx[6] == (uint8_t)crc
                && rx[7] == (uint8_t)(crc >> 8)) return 1;
    }
    return 0;
}

/* % → rpm : 100% = FP 11 틸트 속도 (0 이면 TM_MAX_RPM) */
static int speed_rpm(int percent)
{
    if (save.fp.speed_tilt == 0) return percent * TM_MAX_RPM / 100;    /* 안 정함 : 기본값 */
    return percent * save.fp.speed_tilt / 100;                         /* FP 11 */
}

/* 가감속 ms : FP 12 틸트 (0 이면 TM_ACC_MS) */
static int accdec_ms(void)
{
    if (save.fp.accdec_tilt == 0) return TM_ACC_MS;    /* 안 정함 : 기본값 */
    return save.fp.accdec_tilt;                        /* FP 12 */
}

void TM_State(uint16_t *state)
{
    read_reg(R_STATE, 1, state);
}

/* 드라이브 알람 (PA_005) : 0 없음, 0x01 과전류, 0x02 과전압, 0x03 저전압. 대답하면 1, 없으면 0 */
int TM_Alarm(uint16_t *code)
{
    return read_reg(R_ALARM, 1, code);
}

/* PA_004 Bit0 = 도착 */
int TM_Done(void)
{
	uint16_t state = 0;     /* 읽기 실패면 0 = 도착 아님 */

	TM_State(&state);

    return (state & TM_DONE) && (state & TM_RUN) == 0;
}

int TM_Pos(int32_t *deg)
{
    uint16_t w[2];
    int32_t pulse;
    if (read_reg(R_POS, 2, w) == 0) return 0;
    pulse = (int32_t)(((uint32_t)w[0] << 16) | w[1]);
    *deg = (int32_t)((int64_t)pulse * 360 / (TM_PULSE * TM_GEAR));
    return 1;
}

/* 틸트가 deg(도) 에 도착 + 멈출 때까지 기다림 (최대 MOVE_MS, 각도는 크기로) : 도착 1 / 못 감 · 긴급정지 · 알람 0 (알람은 run.c 가 A_07) */
int TM_Arrive(int deg)
{
    int32_t now = 0;
    uint32_t start = osKernelGetTickCount();

    while (TM_Pos(&now) == 0 || abs(abs(now) - deg) > TM_GAP || TM_Done() == 0) {   /* 못 읽음 · 아직 멂 · 아직 움직임 */
        if (osKernelGetTickCount() - start > MOVE_MS) return 0;         /* MOVE_MS 넘음 */
        if (estop == 1 || status_1 == ALARM) return 0;                  /* 긴급정지 · 알람 */
        osDelay(ARRIVE_MS);                                             /* 쉬었다 다시 묻기 (버스 비워 두기) */
    }
    return 1;
}

/* 절대 각도 이동 (+ 왼쪽 / - 오른쪽) : 보통은 TM_C / TM_R / TM_L, 수동 버튼은 이걸로. 긴급정지 · 알람이면 안 움직임 (알람이어도 수동 모드면 움직임 : 끼임 풀기) */
int TM_Move(int32_t deg, int percent)
{
    if (estop == 1 || (status_1 == ALARM && manual == 0)) return 0;
    int rpm = speed_rpm(percent);
    int32_t pulse = (int32_t)((int64_t)deg * TM_PULSE * TM_GEAR / 360);
    return write16(R_ACC, accdec_ms())
        && write16(R_DEC, accdec_ms())
        && write16(R_SPEED, rpm)
        && write32(R_TARGET, pulse)
        && write16(R_CTRL, GO_ABS)
        && write16(R_CTRL, 0);
}

int TM_C(int percent) { return TM_Move(0, percent); }
int TM_R(int32_t deg, int percent) { return TM_Move(-deg, percent); }
int TM_L(int32_t deg, int percent) { return TM_Move(deg, percent); }
int TM_Stop(void) { return write16(R_CTRL, STOP); }
int TM_AlarmReset(void) { return write16(R_AUX, ALARM_CLEAR); }   /* 과전류 · 과전압 · 저전압은 전원 껐다 켜야 함 */

/* 기존 원점센서 HOME : 최대 60초 */
int TM_Home(void)
{
    uint16_t state = 0;
    uint32_t start = osKernelGetTickCount();

    write16(R_DI0, 1);
    write16(R_HOME_MODE, TM_HOME_MODE);
    write16(R_HOME_RPM, TM_HOME_RPM);
    write16(R_CREEP_RPM, TM_CREEP_RPM);
    write16(R_HOME_ACC, TM_ACC_MS);

    if (write16(R_CTRL, START_HOME) == 0) return 0;   /* 원점 시작 (못 보내면 바로 실패) */

    TM_State(&state);

    /* 원점 완료를 기다리기 위해 사용  */
    while ((state & TM_HOMED) == 0)
    {
        if (osKernelGetTickCount() - start > 60000) { TM_Stop(); return 0; }
        if (estop == 1) return 0;                   /* 긴급정지 : 바로 그만 */
        osDelay(20);
        TM_State(&state);
    }

    write16(R_CTRL, 0);
    write16(R_AUX, ZERO_POS);

    return 1;
}
/* 부팅 시 RAM 설정 */
int TM_Init(void)
{
    uint16_t state = 0;

    TM_State(&state);

    if (state & TM_FAULT)
        return 0;

    if (state & TM_RUN)
        TM_Stop();

    if ((state & TM_ENABLE) == 0)
        write16(R_AUX, ENABLE);

    return write16(R_DIR, 1)
        && write16(R_PPR, TM_PULSE)
        && write16(R_START, TM_START_RPM);
}
