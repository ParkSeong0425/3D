/*
 * debug.c : 로그 50001 의 로그 칸 — 문장은 debug.h, 보내기(W6100)는 net.c log_port
 *   Log_Debug  (아무 태스크)       : 한 줄 만들어 로그 칸에 쌓기
 *   Log_Take   (net.c, Comm_Task)  : 쌓인 것 꺼내고 칸 비우기 → net.c 가 50001 로 보냄
 */
#include "debug.h"
#include "cmsis_os2.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

static char log_text[LOG_SIZE];     /* 로그 칸 : 여러 태스크가 한 줄씩 쌓고 Log_Take 가 비움 */
static int log_len;                 /* 로그 칸에 쌓인 글자 수 */

/* 로그 한 줄 쌓기 (아무 태스크) : printf 처럼 문장 + 값 → 줄바꿈 붙여 로그 칸에. 칸이 꽉 차면 버림
   예) Log_Debug(LOG_HOME_START);  /  Log_Debug(LOG_MOVE, 'M', 'I', rack, col, dan); */
void Log_Debug(const char *fmt, ...)
{
    char line[100];                                         /* 한 줄 만들 칸 */
    va_list args;                                           /* ... 로 들어온 값들 */
    int n;

    va_start(args, fmt);
    n = vsnprintf(line, sizeof(line), fmt, args);           /* snprintf 와 같음 : %d · %c · %s 자리에 값 채우기 */
    va_end(args);
    if (n < 0) return;                                      /* 문장 틀림 */
    if (n > (int)sizeof(line) - 1) n = sizeof(line) - 1;    /* 한 줄이 칸보다 길면 잘린 만큼만 */

    osKernelLock();                                         /* 칸에 붙이는 동안 다른 태스크 못 끼게 */
    if (log_len + n + 2 <= LOG_SIZE) {                      /* 줄바꿈 2글자까지 자리 있으면 */
        memcpy(log_text + log_len, line, n);                /* 글자 붙이기 */
        log_len += n;
        log_text[log_len++] = '\r';                         /* 줄바꿈 */
        log_text[log_len++] = '\n';
    }
    osKernelUnlock();
}

/* 쌓인 로그 꺼내기 (net.c log_port) : out(LOG_SIZE 칸)에 복사하고 로그 칸 비움 → 글자 수 (없으면 0) */
int Log_Take(char *out)
{
    int n;

    osKernelLock();                                         /* 꺼내는 동안 다른 태스크 못 끼게 */
    n = log_len;
    memcpy(out, log_text, n);                               /* 빨리 복사만 하고 */
    log_len = 0;                                            /* 칸 비우기 */
    osKernelUnlock();
    return n;
}
