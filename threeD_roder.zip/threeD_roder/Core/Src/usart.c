/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.c
  * @brief   This file provides code for the configuration
  *          of the USART instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "usart.h"

/* USER CODE BEGIN 0 */
/*
 * 이 파일에서 우리가 쓴 것 (USER CODE 안만. 나머지는 CubeMX 가 만든 설정)
 *
 *   UART2 모터 (RS485)  UART2_Xfer : 묻고 대답 받기 (보내기 DMA → 대답 DMA → 말 끝남(IDLE) 인터럽트가 깨움)
 *                       UART2_Send : 보내기만 (X 브로드캐스트 ID 0 : 대답 없음)
 *   UART4 HMI           UART4_Xfer : 묻고 대답 받기 (보내기 · 받기 인터럽트)
 *   UART1 CLI           글자 1개 올 때마다 인터럽트 → cli_buf 에 넣기만 (꺼내기 · 판단은 cli.c CLI_Run)
 *
 *   묻고 대답 받기 순서 (UART2 · UART4 같음)
 *     1. 남은 찌꺼기 지우기 → 2. 보내기 → 3. 잠 (XFER_DONE 올 때까지, 최대 timeout)
 *     4. [보내기 끝 콜백] 대답 받기 시작 → 5. [대답 끝 콜백] 깨움 → 6. 길이 맞으면 성공
 */
#include "cmsis_os2.h"
#include "dwt.h"
#include <string.h>

#define XFER_DONE  0x01                 /* 대답 끝 → 기다리는 태스크 깨우는 초인종 */

/* UART2 모터 */
static uint8_t motor_tx[64];            /* 보낼 프레임 (DMA 가 읽는 칸이라 함수 밖에 둠) */
static uint8_t motor_rx[64];            /* 받은 대답 (DMA 가 쓰는 칸) */
static uint16_t motor_want;             /* 받을 길이 */
static volatile uint16_t motor_got;     /* 실제 받은 길이 (콜백이 씀) */
static osThreadId_t motor_task;         /* 대답 오면 깨울 태스크 (지금 묻는 태스크 : Motor · Event · Comm) */

/* UART4 HMI */
static uint8_t hmi_rx[8];               /* 받은 대답 */
static uint16_t hmi_want;               /* 받을 길이 */
static volatile uint16_t hmi_got;       /* 실제 받은 길이 (콜백이 씀) */
static osThreadId_t hmi_task;           /* 대답 오면 깨울 태스크 (Event_Task) */

/* UART1 CLI */
static uint8_t cli_ch;                  /* 방금 받은 글자 1개 (HAL 이 여기에 넣음) */
uint8_t cli_buf[CLI_BUF];               /* 글자 보관함 (cli.c CLI_Run 이 꺼냄) */
volatile uint8_t cli_head;              /* 보관함에 다음에 넣을 칸 */

/* 측정용 (디버그 Live Expressions 로 봄) */
volatile uint32_t uart2_us;             /* 모터 통신 1번 걸린 시간 us */
volatile uint32_t uart2_err;            /* 모터 통신 실패 횟수 */

#define BUS_GAP_US  1750                /* 모터 글 사이 조용한 시간 µs : Modbus 규격 (19200bps 넘으면 1.75ms). 통신이 불안하면 2000 처럼 늘리기 */
static uint32_t bus_end;                /* 마지막 모터 글이 끝난 시각 (DWT µs 시계) */
volatile uint32_t hmi_err;              /* HMI 통신 실패 횟수 */
/* USER CODE END 0 */

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart1_tx;
DMA_HandleTypeDef hdma_usart2_tx;
DMA_HandleTypeDef hdma_usart2_rx;

/* UART4 init function */
void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  huart4.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart4.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart4.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_RS485Ex_Init(&huart4, UART_DE_POLARITY_HIGH, 31, 16) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart4, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart4, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}
/* USART1 init function */

void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */
  HAL_UART_Receive_IT(&huart1, &cli_ch, 1);     /* CLI : 글자 1개 오면 인터럽트 → HAL_UART_RxCpltCallback */
  /* USER CODE END USART1_Init 2 */

}
/* USART2 init function */

void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_RS485Ex_Init(&huart2, UART_DE_POLARITY_HIGH, 0, 0) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
  if(uartHandle->Instance==UART4)
  {
  /* USER CODE BEGIN UART4_MspInit 0 */

  /* USER CODE END UART4_MspInit 0 */

  /** Initializes the peripherals clocks
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_UART4;
    PeriphClkInit.Uart4ClockSelection = RCC_UART4CLKSOURCE_PCLK1;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
      Error_Handler();
    }

    /* UART4 clock enable */
    __HAL_RCC_UART4_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**UART4 GPIO Configuration
    PA15     ------> UART4_DE
    PC10     ------> UART4_TX
    PC11     ------> UART4_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_15;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF8_UART4;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF5_UART4;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* UART4 interrupt Init */
    HAL_NVIC_SetPriority(UART4_IRQn, 7, 0);
    HAL_NVIC_EnableIRQ(UART4_IRQn);
  /* USER CODE BEGIN UART4_MspInit 1 */

  /* USER CODE END UART4_MspInit 1 */
  }
  else if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspInit 0 */

  /* USER CODE END USART1_MspInit 0 */

  /** Initializes the peripherals clocks
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
    PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
      Error_Handler();
    }

    /* USART1 clock enable */
    __HAL_RCC_USART1_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**USART1 GPIO Configuration
    PC4     ------> USART1_TX
    PC5     ------> USART1_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* USART1 DMA Init */
    /* USART1_TX Init */
    hdma_usart1_tx.Instance = DMA1_Channel3;
    hdma_usart1_tx.Init.Request = DMA_REQUEST_USART1_TX;
    hdma_usart1_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_usart1_tx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart1_tx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart1_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_usart1_tx.Init.Mode = DMA_NORMAL;
    hdma_usart1_tx.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_usart1_tx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmatx,hdma_usart1_tx);

    /* USART1 interrupt Init */
    HAL_NVIC_SetPriority(USART1_IRQn, 7, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
  /* USER CODE BEGIN USART1_MspInit 1 */

  /* USER CODE END USART1_MspInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspInit 0 */

  /* USER CODE END USART2_MspInit 0 */

  /** Initializes the peripherals clocks
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2;
    PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
      Error_Handler();
    }

    /* USART2 clock enable */
    __HAL_RCC_USART2_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART2 GPIO Configuration
    PA1     ------> USART2_DE
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USART2 DMA Init */
    /* USART2_TX Init */
    hdma_usart2_tx.Instance = DMA1_Channel2;
    hdma_usart2_tx.Init.Request = DMA_REQUEST_USART2_TX;
    hdma_usart2_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_usart2_tx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart2_tx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart2_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart2_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_usart2_tx.Init.Mode = DMA_NORMAL;
    hdma_usart2_tx.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_usart2_tx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmatx,hdma_usart2_tx);

    /* USART2_RX Init */
    hdma_usart2_rx.Instance = DMA1_Channel1;
    hdma_usart2_rx.Init.Request = DMA_REQUEST_USART2_RX;
    hdma_usart2_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_usart2_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_usart2_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_usart2_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_usart2_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_usart2_rx.Init.Mode = DMA_NORMAL;
    hdma_usart2_rx.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_usart2_rx) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(uartHandle,hdmarx,hdma_usart2_rx);

    /* USART2 interrupt Init */
    HAL_NVIC_SetPriority(USART2_IRQn, 6, 0);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspInit 1 */

  /* USER CODE END USART2_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==UART4)
  {
  /* USER CODE BEGIN UART4_MspDeInit 0 */

  /* USER CODE END UART4_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_UART4_CLK_DISABLE();

    /**UART4 GPIO Configuration
    PA15     ------> UART4_DE
    PC10     ------> UART4_TX
    PC11     ------> UART4_RX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_15);

    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_10|GPIO_PIN_11);

    /* UART4 interrupt Deinit */
    HAL_NVIC_DisableIRQ(UART4_IRQn);
  /* USER CODE BEGIN UART4_MspDeInit 1 */

  /* USER CODE END UART4_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspDeInit 0 */

  /* USER CODE END USART1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART1_CLK_DISABLE();

    /**USART1 GPIO Configuration
    PC4     ------> USART1_TX
    PC5     ------> USART1_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_4|GPIO_PIN_5);

    /* USART1 DMA DeInit */
    HAL_DMA_DeInit(uartHandle->hdmatx);

    /* USART1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART1_IRQn);
  /* USER CODE BEGIN USART1_MspDeInit 1 */

  /* USER CODE END USART1_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspDeInit 0 */

  /* USER CODE END USART2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART2_CLK_DISABLE();

    /**USART2 GPIO Configuration
    PA1     ------> USART2_DE
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3);

    /* USART2 DMA DeInit */
    HAL_DMA_DeInit(uartHandle->hdmatx);
    HAL_DMA_DeInit(uartHandle->hdmarx);

    /* USART2 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspDeInit 1 */

  /* USER CODE END USART2_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */

/* ======================= 함수 (태스크가 부름) ======================= */

/* 받기 칸 청소 : 지난 통신의 오류 표시 · 남은 글자 버리기 (UART2 · UART4 같이 씀) */
static void uart_clear(UART_HandleTypeDef *h)
{
    __HAL_UART_CLEAR_OREFLAG(h);                        /* 넘침 */
    __HAL_UART_CLEAR_FEFLAG(h);                         /* 틀 오류 */
    __HAL_UART_CLEAR_NEFLAG(h);                         /* 잡음 */
    __HAL_UART_CLEAR_PEFLAG(h);                         /* 패리티 */
    while (__HAL_UART_GET_FLAG(h, UART_FLAG_RXNE))      /* 남은 글자 있으면 */
        (void)h->Instance->RDR;                         /*   읽어서 버림 */
}

/* UART2 모터 : 묻고 대답 받기. 성공 1 / 실패 0
   tx · tn = 보낼 프레임 · 길이 / rx · rn = 대답 넣을 칸 · 길이 / timeout = 대답 기다릴 ms (모터 파일 RX_TIMEOUT)
   Motor · Event · Comm 세 태스크가 같이 써서 열쇠(Uart2Lock)로 한 번에 하나만 */
int UART2_Xfer(uint8_t *tx, uint16_t tn, uint8_t *rx, uint16_t rn, uint32_t timeout)
{
    int r = 0;
    uint32_t start = DWT_Now();                                         /* 걸린 시간 재기 (uart2_us) */

    osMutexAcquire(Uart2LockHandle, osWaitForever);                     /* 열쇠 */
    while (DWT_Us(bus_end) < BUS_GAP_US) { }                            /* 앞 글 끝난 뒤 1.75ms 안 지났으면 남은 만큼만 (이미 지났으면 바로) */

    uart_clear(&huart2);                                                /* 1. 찌꺼기 지우기 */
    memcpy(motor_tx, tx, tn);
    motor_want = rn;
    motor_got = 0;
    motor_task = osThreadGetId();                                       /*    대답 오면 나를 깨워 줘 */
    osThreadFlagsClear(XFER_DONE);

    if (HAL_UART_Transmit_DMA(&huart2, motor_tx, tn) == HAL_OK &&      /* 2. 보내기 (DMA) */
        (osThreadFlagsWait(XFER_DONE, osFlagsWaitAny, timeout) & XFER_DONE) &&   /* 3. 잠 : 대답 끝까지 (시간 초과면 0) */
        motor_got == rn)                                                /* 6. 길이 맞음 */
        r = 1;

    if (r) memcpy(rx, motor_rx, rn);                                    /* 성공 : 대답 넘겨 줌 */
    else { HAL_UART_Abort(&huart2); uart2_err++; }                      /* 실패 : 하던 것 멈춤 + 횟수 */

    uart2_us = DWT_Us(start);
    bus_end = DWT_Now();                                                /* 끝난 시각 기억 → 다음 글은 BUS_GAP_US 뒤에 */
    osMutexRelease(Uart2LockHandle);                                    /* 열쇠 반납 */
    return r;
}

/* UART2 모터 : 보내기만 (X 브로드캐스트 ID 0 = 드라이브가 대답 안 함). 짧아서 DMA 없이 다 보낼 때까지 */
int UART2_Send(uint8_t *tx, uint16_t tn)
{
    int r;

    osMutexAcquire(Uart2LockHandle, osWaitForever);                     /* 열쇠 */
    while (DWT_Us(bus_end) < BUS_GAP_US) { }                            /* 앞 글 끝난 뒤 1.75ms (UART2_Xfer 와 같음) */
    uart_clear(&huart2);
    r = (HAL_UART_Transmit(&huart2, tx, tn, 100) == HAL_OK);            /* 다 보낼 때까지 (31바이트 약 2.7ms) */
    bus_end = DWT_Now();                                                /* 끝난 시각 기억 */
    osMutexRelease(Uart2LockHandle);                                    /* 열쇠 반납 */
    return r;
}

/* UART4 HMI : 묻고 대답 받기 (Event_Task 만 씀 → 열쇠 없음). 순서는 UART2_Xfer 와 같음, DMA 대신 인터럽트
   tx 는 이 함수가 끝날 때까지 그대로라 부른 쪽 칸을 바로 씀 */
int UART4_Xfer(uint8_t *tx, uint16_t tn, uint8_t *rx, uint16_t rn, uint32_t timeout)
{
    int r = 0;

    uart_clear(&huart4);                                                /* 1. 찌꺼기 지우기 */
    hmi_want = rn;
    hmi_got = 0;
    hmi_task = osThreadGetId();                                         /*    대답 오면 나를 깨워 줘 */
    osThreadFlagsClear(XFER_DONE);

    if (HAL_UART_Transmit_IT(&huart4, tx, tn) == HAL_OK &&             /* 2. 보내기 */
        (osThreadFlagsWait(XFER_DONE, osFlagsWaitAny, timeout) & XFER_DONE) &&   /* 3. 잠 : 대답 끝까지 */
        hmi_got == rn)                                                  /* 6. 길이 맞음 */
        r = 1;

    if (r) memcpy(rx, hmi_rx, rn);                            /* 성공 : 대답 넘겨 줌 */
    else { HAL_UART_Abort(&huart4); hmi_err++; }                        /* 실패 : 하던 것 멈춤 + 횟수 */
    return r;
}


/* ======================= 콜백 (인터럽트 때 HAL 이 부름. 이름은 ST 가 정한 것 — 바꾸면 안 불림) ======================= */

/* 4. 보내기 끝 → 바로 대답 받기 시작 (대답이 끝나면 = 선이 조용해지면(IDLE) 아래 RxEvent) */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {                                    /* 모터 : 대답은 DMA 가 motor_rx 에 담음 */
        HAL_UARTEx_ReceiveToIdle_DMA(&huart2, motor_rx, motor_want);
        __HAL_DMA_DISABLE_IT(huart2.hdmarx, DMA_IT_HT);                 /*   "절반 받음" 알림은 안 씀 */
    }
    if (huart->Instance == UART4)                                       /* HMI : 글자마다 인터럽트로 hmi_rx 에 */
        HAL_UARTEx_ReceiveToIdle_IT(&huart4, hmi_rx, hmi_want);
}

/* 5. 대답 끝 (선이 조용해짐 = IDLE, 또는 다 받음) → 받은 길이 적고 기다리던 태스크 깨움 */
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if (huart->Instance == USART2) { motor_got = Size; osThreadFlagsSet(motor_task, XFER_DONE); }
    if (huart->Instance == UART4)  { hmi_got = Size;   osThreadFlagsSet(hmi_task, XFER_DONE); }
}

/* CLI 글자 1개 받음 → 보관함에 넣고 다음 글자 받기 다시 시작 (판단은 cli.c CLI_Run) */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1) {
        cli_buf[cli_head] = cli_ch;                                     /* 보관함에 넣기 */
        cli_head = (cli_head + 1) % CLI_BUF;                            /* 다음 칸 (끝이면 처음으로) */
        HAL_UART_Receive_IT(&huart1, &cli_ch, 1);                       /* 다음 글자 */
    }
}

/* 오류 (잡음 · 넘침) : 모터 · HMI = 기다리지 말고 바로 깨움 (길이가 달라 실패) / CLI = 받기 다시 시작 */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) osThreadFlagsSet(motor_task, XFER_DONE);
    if (huart->Instance == UART4)  osThreadFlagsSet(hmi_task, XFER_DONE);
    if (huart->Instance == USART1) HAL_UART_Receive_IT(&huart1, &cli_ch, 1);
}

/* USER CODE END 1 */
