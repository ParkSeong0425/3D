/*
 * t_baud.c : (시험 전용, 11/18) 틸트 TL57-R 보레이트 바꾸기
 *   켤 때 Comm_Task 가 TB_Baud() 한 번 → 틸트 PA_028 ← TB_SET + 저장 → STM UART2 도 그 속도 → 다시 읽어 확인
 *   ★ 바꿀 곳 = 아래 TB_SET 숫자 하나 : 0 = 115200 · 1 = 38400 (공장 기본) · 2 = 19200 · 3 = 9600
 *   조건 : 틸트 딥 SW5 ON (OFF 면 늘 115200) · ioc USART2 = 틸트가 지금 쓰는 속도 (그래야 처음 말이 들림)
 *   올린 뒤 틸트 전원 껐다 켜기 → CLI T 0028 로 번호 확인 · TJ 로 JOG 1초
 *   STM 을 다시 켜면 ioc 속도로 시작 → TB_Baud 끝에서 다시 TB_SET 속도로
 */
#include "t_motor.h"
#include "usart.h"
#include "cmsis_os2.h"
#include <string.h>

#define TB_SET      1         /* ★ 바꿀 번호 : 0 115200 · 1 38400 · 2 19200 · 3 9600 */
#define TB_ID       1         /* 틸트 ID (t_motor.c TM_ID 와 같음) */
#define R_BAUD      0x0028    /* PA_028 RS485 보레이트 번호 */
#define R_AUX       0x004F    /* PA_04F 보조 제어 */
#define SAVE        0x0200    /* PA_04F : 지금 값 저장 (전원 꺼도 남게) */
#define SAVE_MS     200       /* 저장 기다림 */

static const uint32_t baud_table[4] = {115200, 38400, 19200, 9600};   /* PA_028 번호 → 속도 */

/* Modbus RTU CRC16 (t_motor.c 와 같음) */
static uint16_t crc16(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 1) crc = (crc >> 1) ^ 0xA001;
            else         crc = crc >> 1;
        }
    }
    return crc;
}

/* FC06 한 칸 쓰기 (한 번만 물음) : 보낸 8글자가 그대로 돌아오면 1 */
static int write16(uint16_t reg, uint16_t val)
{
    uint8_t tx[8], rx[8];
    uint16_t crc;
    tx[0] = TB_ID; tx[1] = 0x06;
    tx[2] = reg >> 8; tx[3] = (uint8_t)reg;
    tx[4] = val >> 8; tx[5] = (uint8_t)val;
    crc = crc16(tx, 6);
    tx[6] = (uint8_t)crc; tx[7] = (uint8_t)(crc >> 8);
    if (UART2_Xfer(tx, 8, rx, 8, T_RX_MS) && memcmp(rx, tx, 8) == 0) return 1;
    return 0;
}

/* STM UART2 속도 바꾸기 (a_motor.c uart_speed 와 같은 방법). 열쇠 쥐고 → Bus_Task 가 보내는 중엔 안 바꿈 */
static void stm_speed(uint32_t baud)
{
    osMutexAcquire(Uart2LockHandle, osWaitForever);
    HAL_UART_DeInit(&huart2);
    huart2.Init.BaudRate = baud;
    HAL_RS485Ex_Init(&huart2, UART_DE_POLARITY_HIGH, 0, 0);
    osMutexRelease(Uart2LockHandle);
}

/* 틸트 보레이트를 TB_SET 으로 바꾸고 STM 도 따라감. 새 속도로 읽은 PA_028 이 TB_SET 이면 1
   0 이면 : 틸트가 다시 켜야 바뀌는 것 → 틸트 전원 껐다 켜고 CLI T 0028 (STM 은 이미 새 속도) */
int TB_Baud(void)
{
    uint16_t v = 0xFFFF;

    write16(R_BAUD, TB_SET);                /* 1. 틸트 PA_028 ← TB_SET (지금 속도로) */
    write16(R_AUX, SAVE);                   /* 2. 저장 (1 이 바로 먹어서 대답이 없어도 3 으로 감) */
    osDelay(SAVE_MS);

    stm_speed(baud_table[TB_SET]);          /* 3. STM 도 새 속도 */

    if (TM_ReadReg(R_BAUD, &v, 1) == 0) return 0;   /* 4. 새 속도로 읽기 (대답 없음 = 틸트 아직 옛 속도) */
    write16(R_AUX, SAVE);                   /* 5. 새 속도로 한 번 더 저장 (2 가 안 들어갔을 때 대비) */
    osDelay(SAVE_MS);
    if (v == TB_SET) return 1;
    return 0;
}
