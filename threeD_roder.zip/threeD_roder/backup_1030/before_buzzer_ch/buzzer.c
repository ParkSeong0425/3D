/*
 * buzzer.c : 부저 켜기 / 끄기만 (DO9 = PD0, 부저가 스스로 삐 · 삐 끊어서 울림)
 *
 *  주인 : PC 연결 중 = PC (B 명령만) / 안 연결 = 보드 (아래 켜기 · 끄기)
 *  켜기 : 알람 (alarm.c alarm_go) · 일시정지 (status.c Pause_Set) · 만재 2초 (event.c) · PC 끊김 때 알람 중 (net.c tcp_off)
 *  끄기 : RESET · 음소거 · RUN (event.c) · 일시정지 풀림 (status.c) · PC 연결 순간 (net.c)
 *  Buzzer_Cmd : PC 부저 명령 글자 B_렉_1/0 (cmd.c 가 부름)
 */
#include "buzzer.h"
#include "main.h"
#include "save.h"
#include "net.h"
#include <stdio.h>

/* 부저 켬 : PC 연결 중엔 안 켬 (그때 부저는 PC 가 B 명령으로) */
void Buzzer_On(void)
{
    if (tcp_on) return;
    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET);
}

/* 부저 끔 */
void Buzzer_Off(void)
{
    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
}

/* PC 부저 명령 : B_렉_1 켬 / B_렉_0 끔 — 부저가 하나라 렉 번호는 확인만. 맞으면 1 / 틀리면 0 */
int Buzzer_Cmd(char *s)
{
    int rack, on;

    if (sscanf(s, "B_%d_%d", &rack, &on) != 2 || rack < 1 || rack > save.fs.rack_channel || on < 0 || on > 1)
        return 0;
    if (on == 1) HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET);    /* PC 명령은 바로 켬 (Buzzer_On 은 PC 연결 중 막힘) */
    else         Buzzer_Off();
    return 1;
}
