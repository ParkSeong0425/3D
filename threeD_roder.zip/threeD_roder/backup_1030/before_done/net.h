/* net.h */
#ifndef INC_NET_H_
#define INC_NET_H_

#include "main.h"

extern volatile int tcp_on;
int NET_Init(void);
void NET_Run(void);
void send_socket(uint8_t *buf, int len);  /* 2500 으로 보내기 + 서비스 58080 에 [RX] 복사 (cmd.c 대답 · 이벤트) */
void send_event(char *text);              /* 이벤트 : 새 번호 붙여 STX + 번호 + 글자 + ETX → send_socket */
/* 로그 50001 로 한 줄 (어느 태스크든 : 쌓기만, 보내기는 Comm_Task). printf 처럼 문장(debug.h) + 값
   format 표시 : %d · %c 개수와 값 개수가 다르면 빌드 때 경고로 알려 줌 */
void Log_Debug(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
#endif /* INC_NET_H_ */
