/*
 * status.c
 *
 *  Created on: Sep 17, 2026
 *      Author: HWNOT
 *
 * 렉 수 = FS rack_channel (1 ~ 4). 칸은 4개까지 있고, 렉 수만큼만 PC · HMI 로 나간다.
 * "모두" (원점 · 초기상태 · 알람 · 풀기 · 렉 0) 는 1 ~ 4 를 같이 바꿈 → 안 쓰는 렉도 같은 상태라 조건이 안 꼬임
 *
 * "지금 해도 되나" 확인은 그 일을 하는 블록 맨 앞에 (Status_PAUSE 모양 : 안 되면 return)
 *   일시정지 (STOP · S · 만재 · 카드 · 틸트)  status.c  Status_PAUSE   알람 · 원점 · 초기상태 X / STOP 은 움직일 때만
 *   RESET                                   alarm.c   Alarm_Clear    긴급정지 · 동작 중 · 원점 중 X
 *   HMI RUN 원점                            event.c   btn_run        긴급정지 X · 초기상태일 때만
 *   HMI 수동 모드                           event.c   btn_manual     대기 · 알람 02 ~ 07 · 10
 *   PC MI · MO · PO                         cmd.c     CMD_Run        네 렉 다 대기 · 수동 X · 앞 명령 승인 뒤
 *   PC 원점 I                               cmd.c     CMD_Run        원점 · 동작 · 일시정지 · 수동 X
 *   (Motor_Task 가 동작 중이면 다음 동작을 못 하는 건 구조 : Motor_Run 이 끝나야 다음 초인종을 봄)
 */
#include "status.h"
#include "main.h"
#include "event.h"
#include <stdio.h>
#include "run.h"
#include "net.h"
#include "debug.h"
#include "alarm.h"
#include "save.h"
#include "buzzer.h"
#include "manjae.h"

/* 전원 켜지면 모두 초기화(I) → 원점 끝나면 W */
char status_1 = HOME;
char status_2 = HOME;
char status_3 = HOME;
char status_4 = HOME;

volatile char pause_why = 0;    /* M = STOP 버튼/S 명령, F = 만재, S = 카드 없음, T = 틸트 */
volatile int pause_event_on;         /* 1 = 보낼 일시정지 이벤트 있음 */

/* 대기 */
void Status_WAIT(int rack)
{
    if (rack == 1) status_1 = WAIT;
    if (rack == 2) status_2 = WAIT;
    if (rack == 3) status_3 = WAIT;
    if (rack == 4) status_4 = WAIT;
}

/* 이동 (일시정지였으면 풀림) */
void Status_RUN(int rack)
{
    if (rack == 1) status_1 = RUN;
    if (rack == 2) status_2 = RUN;
    if (rack == 3) status_3 = RUN;
    if (rack == 4) status_4 = RUN;
    pause_why = 0;                                       /* 일시정지 아님 */
}

/* 원점 : 기계 전체라 모두 */
void Status_HOME(void)
{
    status_1 = HOME;
    status_2 = HOME;
    status_3 = HOME;
    status_4 = HOME;
}

/* 일시정지 전 상태 (풀 때 되돌림 : 운전 중이던 렉은 R, 대기였던 렉은 W) */
static char before_1, before_2, before_3, before_4;

/* 일시정지 (상태판만) : 렉 1 ~ 4 / 0 = 모두, 이유(M 사용자 F 만재 S 카드 T 틸트) + PC 로 PPAUSE. 멈췄으면 1
   알람 · 원점 중 · 초기상태면 안 바꾸고 0 (부저 · 로그 · 램프는 부르는 자리에서) */
int Status_PAUSE(int rack, char why)
{
    if (status_1 == ALARM || status_1 == HOME) return 0;               /* 알람 · 초기화(I) */
    if (why == 'M' && status_1 != RUN && status_2 != RUN && status_3 != RUN && status_4 != RUN) return 0;   /* STOP 은 움직일 때만 (멈춰 있으면 무시) */
    if ((rack == 1 || rack == 0) && status_1 != PAUSE) { before_1 = status_1; status_1 = PAUSE; }
    if ((rack == 2 || rack == 0) && status_2 != PAUSE) { before_2 = status_2; status_2 = PAUSE; }
    if ((rack == 3 || rack == 0) && status_3 != PAUSE) { before_3 = status_3; status_3 = PAUSE; }
    if ((rack == 4 || rack == 0) && status_4 != PAUSE) { before_4 = status_4; status_4 = PAUSE; }
    pause_why = why;                                     /* 일시정지 중 + 이유 (0 = 일시정지 아님) */
    pause_event_on = 1;                                  /* PC 로 PPAUSE:이유 */
    return 1;
}

/* 일시정지 풀기 (상태판만) : 일시정지인 렉만 멈추기 전 상태로 (운전 중이었으면 R → MI · PO 가 이어서, 끝나면 W) */
void Status_Resume(void)
{
    if (status_1 == PAUSE) status_1 = before_1;
    if (status_2 == PAUSE) status_2 = before_2;
    if (status_3 == PAUSE) status_3 = before_3;
    if (status_4 == PAUSE) status_4 = before_4;
    pause_why = 0;                                       /* 일시정지 아님 */
}

/* 일시정지 걸기 (블록) : 상태 P + 이유 + PC PPAUSE + 부저 + 로그. 원점 중 · 알람이면 안 함
   모터는 안 세움 → Motor_Task 가 정지선(run.c pause_wait)에서 섬 */
void Pause_Set(int rack, char why)
{
    if (Status_PAUSE(rack, why) == 0) return;            /* 원점 중 · 초기상태 · 알람 */
    Buzzer_On();                                         /* 부저 */
    Log_Debug(LOG_PAUSE_SET, why, rack);                 /* 로그 : PAUSE F rack 1 */
}

/* 일시정지 풀기 (블록) : 멈추기 전 상태로 + 부저 끔 + 로그 → 정지선에서 기다리던 Motor_Task 가 이어서 */
void Pause_Clear(void)
{
    Status_Resume();                                     /* 멈추기 전 상태로 */
    Buzzer_Off();                                        /* 부저 끔 */
    Log_Debug(LOG_CLEAR);                                /* 로그 */
}

/* 알람 : 긴급정지, 모두 */
void Status_Alarm(void)
{
    status_1 = ALARM;
    status_2 = ALARM;
    status_3 = ALARM;
    status_4 = ALARM;
}

/* 렉 상태 한 칸 : W, R, I, P / 만재로 일시정지면 F (만재일시정지) / 카드 없어 일시정지면 S (정지) / 알람이면 A_05 */
static void rack_text(char *b, int size, char status, int alarm)
{
    if (status == ALARM)
        snprintf(b, size, "A_%02d", alarm);
    else if (status == PAUSE && pause_why == 'F')
        snprintf(b, size, "F");
    else if (status == PAUSE && pause_why == 'S')
        snprintf(b, size, "S");
    else
        snprintf(b, size, "%c", status);
}

/* 프로토콜 글자 (C 대답) : 렉 수(rack_channel)만큼 S_1_W&S_2_A_03&S_3_W … */
void Status_Text(char *b, int size)
{
    char r[8];
    int len;

    rack_text(r, sizeof(r), status_1, alarm_1);                          /* 렉 1 */
    len = snprintf(b, size, "S_1_%s", r);

    if (save.fs.rack_channel >= 2) {                                     /* 렉 2 */
        rack_text(r, sizeof(r), status_2, alarm_2);
        len += snprintf(b + len, size - len, "&S_2_%s", r);
    }
    if (save.fs.rack_channel >= 3) {                                     /* 렉 3 */
        rack_text(r, sizeof(r), status_3, alarm_3);
        len += snprintf(b + len, size - len, "&S_3_%s", r);
    }
    if (save.fs.rack_channel >= 4) {                                     /* 렉 4 */
        rack_text(r, sizeof(r), status_4, alarm_4);
        snprintf(b + len, size - len, "&S_4_%s", r);
    }
}

/* PC 로 일시정지 (Comm_Task) : Status_PAUSE 가 걸었으면(pause_event_on) PPAUSE:M · F · S · T
   만재(F)면 어느 칸인지 FF 먼저 (프로토콜 : 투입 금지 셀의 분배 명령 발생시 이벤트 송신) */
void Status_PC(void)
{
    char b[32];

    if (pause_event_on == 0) return;                     /* 보낼 것 없음 */
    pause_event_on = 0;                                  /* 보내기 전에 0 */
    if (pause_why == 'F') {                              /* 만재로 멈춤 : FF_1_0010&F_2_0000 */
        b[0] = 'F';
        Manjae_check_text(b + 1, sizeof(b) - 1);
        send_event(b);
    }
    snprintf(b, sizeof(b), "PPAUSE:%c", pause_why);
    send_event(b);
}

