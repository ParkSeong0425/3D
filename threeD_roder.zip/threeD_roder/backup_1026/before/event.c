/*
 * event.c : "이런 상황이면 이렇게" (기본 함수 파일들을 모아서 상황 처리)
 *
 *  1. Event_Task (High) : Event_Run 이 100ms 마다 돌림 (긴급정지 · 만재 인터럽트면 바로)
 *       읽기  estop_event  긴급정지 눌림 / 풀림
 *             hmi_event    HMI 통신 (실패 → 알람 01) · RUN · STOP · RESET · 수동 모드 · 음소거 (수동 움직임은 hmi.c)
 *             manjae_event 만재 알림 : 바뀌면 FF · 2초 넘게 만재면 부저 (멈춤은 PO 만, run.c PO_pause)
 *             rfid_event   카드 알림 : 빠지면 부저 (멈춤은 PO 만, run.c PO_pause)
 *             alarm_event  드라이브 알람 02 ~ 04 (1초마다)
 *       (카드 RFID 는 Rfid_Timer 가 0.5초마다 Rfid_Check)
 *       램프  lamp_event
 *  2. 인터럽트 : HAL_GPIO_EXTI_Callback (Event_Task 깨우기만)
 */

#include "event.h"
#include "hmi.h"
#include "rfid.h"
#include "run.h"
#include "status.h"
#include "manjae.h"
#include "lamp.h"
#include "cli.h"
#include "net.h"
#include "alarm.h"
#include "cmd.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "buzzer.h"
#include "debug.h"
#include "cmsis_os.h"
#include <stdio.h>

#define ESTOP_FLAG  0x02    /* 긴급정지 인터럽트 → Event_Task 깨움 */
#define FULL_FLAG   0x04    /* 만재 인터럽트 → Event_Task 깨움 */
#define EVENT_MS    100     /* 이벤트 확인 간격 */
#define ALARM_CHECK_MS 1000 /* 드라이브 알람 · 통신 확인 간격 */


volatile int estop;         /* 1 = 긴급정지 눌림 */
volatile int manual;        /* 1 = 수동 모드 (설정 → 수동 버튼) */
int manjae_1;               /* 1 = 렉1 만재 알림 중 (2초 넘게 만재 → HMI 일시정지 만재 · 부저 · 빨간불) : HMI RUN 누를 때까지 */
int manjae_2;               /* 1 = 렉2 만재 알림 중 */


/* ======================= 1. Event_Task : 100ms 마다 확인 ======================= */

/* 긴급정지 : 핀을 직접 읽음 (접점이 떨려도 한 번만) / 눌리면 멈춤, 풀리면 Y 해제 (원점은 RESET → RUN) */
static void estop_event(void)
{
    int pressed = (HAL_GPIO_ReadPin(ESTOP_GPIO_Port, ESTOP_Pin) == GPIO_PIN_SET);

    /* 눌림 (한 번) : 알람 09 (세우기 + 상태 A + 번호 + PC + 부저) */
    if (pressed == 1 && estop == 0) {
        estop = 1;
        A_09(0);
    }

    /* 풀림 (한 번) : Y 비상정지만 풀고 멈춰 있음. 알람 다시 걸어 둠 (눌린 사이 바뀌었어도 RESET → RUN 으로만) */
    if (pressed == 0 && estop == 1) {
        estop = 0;
        AM_EStop(0);
        Status_Alarm();
    }
}

/* RUN : 리셋 뒤(초기상태)면 원점 / 일시정지 M · T 면 이어서 */
static void btn_run(void)
{
    Buzzer_Off();                                       /* 부저 끔 */
    manjae_1 = 0;                                       /* 만재 알림 끝 (빨간불 끔) */
    manjae_2 = 0;

    /* 리셋 뒤 : 원점 (run.c motor_basic_init) */
    if (estop == 0 && status_1 == RESTART) {
        manual = 0;
        osThreadFlagsSet(Motor_TaskHandle, MOTOR_FLAG);
        return;
    }

    /* 일시정지 (사용자 M · 틸트 T · 만재 F · 카드 S) : 이어서 */
    if (pause_why) Pause_Clear();
}

/* STOP : 일시정지 (모든 렉, 이유 M). MI · PO 가 정지선에서 섬 */
static void btn_stop(void)
{
    Pause_Set(0, 'M');                                  /* PPAUSE:M + 부저 + 로그 */
}

/* RESET : 알람 · 수동 풀고 초기상태 (원점은 RUN). 긴급정지 · 동작 · 원점 중엔 안 함 */
static void btn_reset(void)
{
    if (estop == 1 || status_1 == RUN || status_2 == RUN || status_3 == RUN || status_4 == RUN || status_1 == HOME) return;
    manual = 0;                                         /* 수동 모드 끔 */
    Alarm_Clear();                                      /* 드라이브 알람 리셋 · 번호 지움 · 초기상태 · 부저 끔 (alarm.c) */
}

/* 수동 모드 : 켜져 있으면 끔 / 대기 · 알람 02 ~ 07 · 10 (끼임 풀기) 이면 켬. 긴급정지 중엔 안 켬 */
static void btn_manual(void)
{
    if (manual == 1) { manual = 0; return; }                                                                 /* 끄기 */
    if (status_1 == WAIT && status_2 == WAIT && status_3 == WAIT && status_4 == WAIT) manual = 1;             /* 대기 */
    if (estop == 0 && status_1 == ALARM && ((alarm_1 >= 2 && alarm_1 <= 7) || alarm_1 == 10)) manual = 1;    /* 알람 */
}

/* 터치패드 : HMI 통신 (실패 → 알람 01) → 눌린 버튼 하나 (수동 움직임은 hmi.c HMI_Manual) */
static void hmi_event(void)
{
    int button;

    button = HMI_Run();          /* 상태 보내고 버튼 받기 */
    A_01(button);                /* 통신 안 되면 알람 01 — 사무실 시험(HMI 없음)이라 꺼 둠 : 현장에선 주석 풀 것 */

    if (button == 0) return;     /* 안 눌림 */

    /* 수동 버튼 (21~26) : 수동 모드일 때만 hmi.c 가 움직임 */
    if (button >= BTN_TILT_Lift && button <= BTN_TRAVEL_Back) {
        if (manual == 1) HMI_Manual(button);
        return;
    }

    switch (button)
    {
    case BTN_RUN:       btn_run();      break;      /* 원점 / 일시정지 풀기 */
    case BTN_STOP:      btn_stop();     break;      /* 일시정지 M */
    case BTN_RESET:     btn_reset();    break;      /* 알람 풀고 초기상태 */
    case BTN_MANUAL:    btn_manual();   break;      /* 수동 모드 켜기 / 끄기 */
    case BTN_SOUND_OFF: Buzzer_Off();   break;      /* 음소거 (다음 일시정지 · 알람 때 다시 켜짐) */
    }
}

/* 만재 : 알림 (멈추지 않음 — MI · MO 는 계속, PO 는 run.c PO 가 그 단이면 틸트 안 하고 기다림)
   센서 바뀌면 바로 FF / 바뀐 뒤 2초 그대로 만재면 그 렉 알림 (부저 + 빨간불) → 센서가 풀려도 HMI RUN 까지 유지 (btn_run) */
static void manjae_event(void)
{
    static int check;                                   /* 1 = 바뀐 뒤 2초 확인 기다림 */

    /* 센서 바뀜 : PC 로 FF 바로 + 2초 다시 재기 */
    if (manjae_change()) {
        full_event_on = 1;
        check = 1;
    }

    /* 2초 그대로 : 만재인 렉 알림 */
    if (check == 1 && manjae_stable()) {
        check = 0;
        if (manjae_rack(1)) manjae_1 = 1;               /* 렉1 만재 */
        if (manjae_rack(2)) manjae_2 = 1;               /* 렉2 만재 */
        if (manjae_full()) {
            Log_Debug(LOG_MANJAE_FULL);                 /* 로그 */
            Buzzer_On();                                /* 부저 (빨간불은 lamp_event → lamp_manjae) */
        }
    }
}

/* 카드 : 로그만 (PC UU 는 rfid.c, 부저 · 램프는 PO 가 그 렉에서 막혔을 때만 — run.c PO_pause → Pause_Set) */
static void rfid_event(void)
{
    static int out;                                     /* 1 = 카드 빠짐 로그 남김 (한 번만) */

    /* 카드 빠짐 : 로그 */
    if (out == 0 && card_out()) {
        out = 1;
        Log_Debug(LOG_CARD_OUT);
    }

    /* 카드 들어옴 */
    if (card_out() == 0) out = 0;
}

/* 드라이브 알람 02 ~ 04 · 모터 통신 끊김 11 : 1초마다, 원점 중 · 대기 · 운전 · 일시정지에 물음
   (초기상태 = 아직 드라이브 설정 전 / 알람 · 긴급정지 중엔 다시 안 물음) */
static void alarm_event(void)
{
    static uint32_t last;                       /* 마지막으로 물어본 시각 */

    if (osKernelGetTickCount() - last < ALARM_CHECK_MS) return;
    last = osKernelGetTickCount();

    if (estop == 1 || status_1 == ALARM || status_1 == RESTART) return;

    if (A_02()) return;                         /* X : 걸었으면 나머지는 안 물음 */
    if (A_03()) return;                         /* Y */
    A_04();                                     /* 틸트 */
}

/* 램프 : 아래로 갈수록 우선 (뒤 함수가 앞에서 켠 램프를 덮어씀) */
static void lamp_event(void)
{
    lamp_tcp();         /* 평소 : PC 연결 = PC LL / 안 연결 = R · G 끔, Y 카드 */
    lamp_manjae(manjae_1, manjae_2);   /* 만재 알림 중인 렉 : R 느리게 깜빡 (RUN 까지) */
    lamp_alarm();       /* 긴급정지 · 알람 = 두 렉 / 일시정지 = 그 렉만 : R 빠르게 깜빡 */
    lamp_home();        /* 원점 중 : 6개 전부 느리게 깜빡 */
}

/* Event_Task 본체 : 읽기 → 램프 → 쉬기 반복 */
void Event_Run(void)
{
    Rfid_Init();                /* CAN 켜기 + 카드 0.5초 타이머 시작 (한 번만) */

    for (;;) {
        /* 1. 읽기 */
    	estop_event();          /* 긴급정지 */
        manjae_event();         /* 만재 : FF · 2초 → PPAUSE:F · 풀림 */
        rfid_event();           /* 카드 : 빠짐 → PPAUSE:S · 들어옴 */
        hmi_event();            /* 터치 버튼 */
        alarm_event();          /* 드라이브 알람 02 ~ 04 (1초마다) */

        /* 2. 램프 */
        lamp_event();

        /* 3. 100ms 쉬기 : 긴급정지, 만재면 바로 깨어남 */
        osThreadFlagsWait(ESTOP_FLAG | FULL_FLAG, osFlagsWaitAny, EVENT_MS);
    }
}


/* ============ 2. 인터럽트 : Event_Task 깨우기만 (판단은 Event_Task 가) ============ */

/* 긴급정지 인터럽트 (PD11, 누를 때 / 뗄 때) : 눌림 / 풀림 표시 + Event_Task 깨우기 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    /* 긴급정지 : 깨우기만 (눌림 / 풀림 판단은 estop_event 가 핀을 읽어서) */
    if (GPIO_Pin == ESTOP_Pin)
        osThreadFlagsSet(Event_TaskHandle, ESTOP_FLAG);

    /* 만재 (PE11 FULL_1_1 은 EXTI11 이 긴급정지라 빠짐 : 100ms 읽기로 확인) */
    if (GPIO_Pin == FULL_2_1_Pin || GPIO_Pin == FULL_2_2_Pin ||
        GPIO_Pin == FULL_2_3_Pin || GPIO_Pin == FULL_2_4_Pin ||
        GPIO_Pin == FULL_1_2_Pin || GPIO_Pin == FULL_1_3_Pin ||
        GPIO_Pin == FULL_1_4_Pin) {
        osThreadFlagsSet(Event_TaskHandle, FULL_FLAG);
    }
}
