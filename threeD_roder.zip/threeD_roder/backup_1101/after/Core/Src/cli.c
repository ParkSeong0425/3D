#include "cli.h"
#include "run.h"
#include "status.h"
#include "net.h"
#include "i_motor.h"
#include "a_motor.h"
#include "t_motor.h"
#include "save.h"
#include "lamp.h"
#include "buzzer.h"
#include "usart.h"
#include "cmsis_os2.h"
#include <stdio.h>
#include <string.h>

#define CLI_SIZE 32
#define NOTE_SIZE 256

static char note_text[NOTE_SIZE];       /* CLI 에 보여 줄 알림 칸 (CLI_Note 가 쌓고 CLI_Run 이 출력) */



/* UART1 출력 */
static void CLI_Print(const char *text)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)text, strlen(text), 100);
}


/* CLI 에 보여 줄 한 줄 쌓기 (아무 태스크) : UART1 은 Comm_Task 만 보내서 여기선 쌓기만, 칸이 차면 버림 */
void CLI_Note(const char *text)
{
    osKernelLock();
    if (strlen(note_text) + strlen(text) + 5 <= NOTE_SIZE) {
        strcat(note_text, text);
        strcat(note_text, "\r\n> ");
    }
    osKernelUnlock();
}

/* 모터 실행 결과 출력 */
static void CLI_Result(int command, int ok)
{
    char text[160];

    if (command == 'X')
        snprintf(text, sizeof(text),
                 "X_MOVE %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == 'Y')
        snprintf(text, sizeof(text),
                 "Y_MOVE %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == 'C')
        snprintf(text, sizeof(text),
                 "CENTER %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == 'R')
        snprintf(text, sizeof(text),
                 "RIGHT %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == 'L')
        snprintf(text, sizeof(text),
                 "LEFT %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == CMD_S)
        snprintf(text, sizeof(text),
                 "STOP %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == CMD_I)
        snprintf(text, sizeof(text),
                 "HOME %s\r\n> ", ok ? "OK" : "ERR");

    else if (command == CMD_INIT)
        snprintf(text, sizeof(text),
                 "INIT %s\r\n> ", ok ? "OK" : "ERR");
    else
        return;

    CLI_Print(text);
}


/* FRAM 배열 출력 */
static void CLI_List(const char *name, int32_t *data, int count, int max)
{
    char buf[32];

    CLI_Print(name);

    if (count > max)
        count = max;

    for (int i = 0; i < count; i++)
    {
        snprintf(buf, sizeof(buf), "%ld ", (long)data[i]);
        CLI_Print(buf);
    }

    CLI_Print("\r\n");
}


/* FRAM 저장값 출력 */
static void CLI_FRAM(void)
{
    char buf[500];

    snprintf(buf, sizeof(buf),
             "\r\n[FS]\r\n"
             "RACK         = %d\r\n"
             "TYPE         = %c\r\n"
             "CHANNEL      = %d\r\n"
             "IN_X         = %d\r\n"
             "IN_Y         = %d\r\n"
             "LEFT_X       = %d\r\n"
             "LEFT_Y       = %d\r\n"
             "RIGHT_X      = %d\r\n"
             "RIGHT_Y      = %d\r\n"
             "\r\n[FP]\r\n"
             "IN_X = %ld\r\n",
             save.fs.rack,
             save.fs.type,
             save.fs.rack_channel,
             save.fs.in_x,
             save.fs.in_y,
             save.fs.left_x,
             save.fs.left_y,
             save.fs.right_x,
             save.fs.right_y,
             (long)save.fp.in_x);

    CLI_Print(buf);

    CLI_List("IN_Y = ", save.fp.in_y, save.fs.in_y, 5);             /* FRAM 배열 그대로 */
    CLI_List("LEFT_X = ", save.fp.left_x, save.fs.left_x, 9);
    CLI_List("LEFT_Y = ", save.fp.left_y, save.fs.left_y, 9);
    CLI_List("RIGHT_X = ", save.fp.right_x, save.fs.right_x, 9);
    CLI_List("RIGHT_Y = ", save.fp.right_y, save.fs.right_y, 9);
    CLI_List("SAFE_Y = ", save.fp.safe_y, save.fs.in_y, 5);         /* 안전 Y : 입고 단 수만큼 */

    snprintf(buf, sizeof(buf),
             "\r\n"
             "LIFT Y OFFSET = %ld\r\n"
             "TILT ANGLE    = %ld\r\n"
             "TILTING Y     = %ld\r\n"
             "TILTING SPEED = %ld\r\n"
             "Y OFFSET      = %ld\r\n"
             "TILT OFFSET   = %ld\r\n"
             "X OFFSET      = %ld\r\n"
             "SPEED X       = %ld\r\n"
             "SPEED TILT    = %ld\r\n"
             "SPEED Y       = %ld\r\n"
             "ACCDEC X      = %ld\r\n"
             "ACCDEC TILT   = %ld\r\n"
             "ACCDEC Y      = %ld\r\n"
             "SAFE X        = %ld\r\n> ",
             (long)save.fp.lift_y_offset,
             (long)save.fp.tilt_angle,
             (long)save.fp.tilting_y,
             (long)save.fp.tilting_y_speed,
             (long)save.fp.y_offset,
             (long)save.fp.tilt_offset,
             (long)save.fp.x_offset,
             (long)save.fp.speed_x,
             (long)save.fp.speed_tilt,
             (long)save.fp.speed_y,
             (long)save.fp.accdec_x,
             (long)save.fp.accdec_tilt,
             (long)save.fp.accdec_y,
             (long)save.fp.safe_x);

    CLI_Print(buf);
}


/* 문자열 명령 처리 */
static void CLI_Command(char *text)
{
    long pulse;
    int persent;
    unsigned int reg = 0x0509;  /* (디버그) REG 주소 : 그냥 REG 면 H05_09 (Y 1회전 펄스, 320 이어야) */
    MOVE home = { CMD_I };      /* 원점 주문 (나머지 칸 0) */
    char buf[300];

    /* 네트워크 값 */
    if (!strcmp(text, "IP"))
    {
        snprintf(buf, sizeof(buf),
                 "\r\n[IP]\r\n"
                 "IP      = %d.%d.%d.%d\r\n"
                 "SUBNET  = %d.%d.%d.%d\r\n"
                 "GATEWAY = %d.%d.%d.%d\r\n"
                 "DEST IP = %d.%d.%d.%d\r\n"
                 "PORT    = %d\r\n"
                 "MODE    = %d\r\n"
                 "TIMEOUT = %lu\r\n> ",
                 save.fi.ip[0], save.fi.ip[1],
                 save.fi.ip[2], save.fi.ip[3],
                 save.fi.sn[0], save.fi.sn[1],
                 save.fi.sn[2], save.fi.sn[3],
                 save.fi.gw[0], save.fi.gw[1],
                 save.fi.gw[2], save.fi.gw[3],
                 save.fi.dip[0], save.fi.dip[1],
                 save.fi.dip[2], save.fi.dip[3],
                 save.fi.port, save.fi.mode,
                 (unsigned long)save.fi.timeout);

        CLI_Print(buf);
        return;
    }

    /* FRAM 값 */
    if (!strcmp(text, "FRAM"))
    {
        CLI_FRAM();
        return;
    }

    /* 일시정지 : 빨간불 (MI / PO 가 정지선에서 섬) */
    if (!strcmp(text, "S"))
    {
        Pause_Set(0, 'M');          /* 일시정지 : 모든 렉, 이유 사용자 (+ 부저 · 로그) */
        CLI_Result(CMD_S, 1);
        return;
    }

    /* 원점 (드라이브 설정 + 원점) : 모터 문으로 맡김 → OK = 받음 (끝은 로그 HOME done) / ERR = 하는 중 · 알람 */
    if (!strcmp(text, "INIT") || !strcmp(text, "I"))
        CLI_Result(CMD_INIT, Motor_Request(home));

    /* X 모터 : X 펄스 속도% */
    else if (sscanf(text, "X %ld %d", &pulse, &persent) == 2)
        CLI_Result('X', motor_basic_run('X', (int32_t)pulse, 0, persent));

    /* Y 모터 : Y 펄스 속도% */
    else if (sscanf(text, "Y %ld %d", &pulse, &persent) == 2)
        CLI_Result('Y', motor_basic_run('Y', (int32_t)pulse, 0, persent));

    /* Tilt 중앙 : C 속도% */
    else if (sscanf(text, "C %d", &persent) == 1)
        CLI_Result('C', motor_basic_run('C', 0, 0, persent));

    /* Tilt 오른쪽 : R 각도 속도% (읽은 숫자는 각도) */
    else if (sscanf(text, "R %ld %d", &pulse, &persent) == 2)
        CLI_Result('R', motor_basic_run('R', 0, (int)pulse, persent));

    /* Tilt 왼쪽 : L 각도 속도% */
    else if (sscanf(text, "L %ld %d", &pulse, &persent) == 2)
        CLI_Result('L', motor_basic_run('L', 0, (int)pulse, persent));

    /* (디버그) Y 레지스터 읽기 : REG = H05_09 / REG 0B22 = 그 주소 (16진수 4자리, 뒤 두 자리는 번호를 16진수로 : H0B_34 = 0B22) */
    else if (strncmp(text, "REG", 3) == 0) {
        sscanf(text + 3, "%x", &reg);       /* 뒤에 주소 있으면 그 주소, 없으면 0509 그대로 */
        int32_t v16 = 0, v32 = 0;
        int ok16 = AM_ReadReg((uint16_t)reg, &v16, 1);
        int ok32 = AM_ReadReg((uint16_t)reg, &v32, 2);
        snprintf(buf, sizeof(buf), "\r\nY reg 0x%04X : 16bit %s %ld / 32bit %s %ld\r\n> ",
                 reg, ok16 ? "=" : "FAIL", (long)v16, ok32 ? "=" : "FAIL", (long)v32);
        CLI_Print(buf);
    }

    else
        CLI_Print("BAD COMMAND\r\n> ");
}


/* 쌓인 알림 출력 (Comm_Task) : 원점 결과 · 통신 실패 */
static void note_print(void)
{
    char out[NOTE_SIZE];

    if (note_text[0] == 0) return;              /* 알림 없음 */
    osKernelLock();                             /* 꺼내는 동안 다른 태스크 못 끼게 */
    strcpy(out, note_text);
    note_text[0] = 0;
    osKernelUnlock();
    CLI_Print(out);
}

/* UART1 CLI (Comm_Task 1ms 마다) : 보관함(cli_buf, usart.c 인터럽트가 넣음)에 온 글자를 전부 꺼내 한 줄 만들기
   글자 → 줄에 붙이고 화면에 다시 보여 줌 / 지우기 → 하나 빼고 화면에서도 지움 / 엔터 → 명령 실행 */
void CLI_Run(void)
{
    static char line[CLI_SIZE];             /* 지금 치는 한 줄 */
    static uint8_t index = 0;               /* 줄에서 다음 글자 넣을 칸 */
    static uint8_t tail = 0;                /* 보관함에서 다음에 꺼낼 칸 */
    char ch[2] = {0, 0};                    /* 꺼낸 글자 1개 (화면에 다시 보낼 때 글자 + 끝) */

    note_print();                                               /* 쌓인 알림 먼저 */

    while (tail != cli_head) {                                  /* 보관함에 글자 있는 만큼 */
        ch[0] = cli_buf[tail];
        tail = (tail + 1) % CLI_BUF;                            /* 다음 칸 (끝이면 처음으로) */

        if (ch[0] == '\r' || ch[0] == '\n') {                   /* 엔터 : 한 줄 끝 */
            if (index == 0) continue;                           /*   빈 줄 (CR 뒤 LF) 은 무시 */
            line[index] = 0;
            index = 0;
            CLI_Print("\r\n");
            CLI_Command(line);
        }
        else if (ch[0] == '\b' || ch[0] == 0x7F) {              /* 지우기 (Backspace · Delete) */
            if (index == 0) continue;                           /*   지울 글자 없음 */
            index--;
            CLI_Print("\b \b");                                 /*   화면 : 한 칸 뒤로 → 빈칸으로 덮기 → 다시 뒤로 */
        }
        else if (index < CLI_SIZE - 1) {                        /* 글자 : 줄에 붙이기 (꽉 차면 무시) */
            line[index++] = ch[0];
            CLI_Print(ch);                                      /*   화면에 다시 보여 줌 (echo) */
        }
    }
}
