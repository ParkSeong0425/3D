/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "run.h"
#include "cli.h"
#include "net.h"
#include "fram.h"
#include "event.h"
#include "save.h"
#include "status.h"
#include "manjae.h"
#include "buzzer.h"
#include "rfid.h"
#include "hmi.h"
#include "cmd.h"
#include "dwt.h"
#include "alarm.h"
#include "flag.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
/* USER CODE END Variables */
/* Definitions for Event_Task */
osThreadId_t Event_TaskHandle;
const osThreadAttr_t Event_Task_attributes = {
  .name = "Event_Task",
  .priority = (osPriority_t) osPriorityHigh,
  .stack_size = 512 * 4
};
/* Definitions for Motor_Task */
osThreadId_t Motor_TaskHandle;
const osThreadAttr_t Motor_Task_attributes = {
  .name = "Motor_Task",
  .priority = (osPriority_t) osPriorityAboveNormal,
  .stack_size = 512 * 4
};
/* Definitions for Comm_Task */
osThreadId_t Comm_TaskHandle;
const osThreadAttr_t Comm_Task_attributes = {
  .name = "Comm_Task",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 1024 * 4
};
/* Definitions for Manjae_Timer */
osTimerId_t Manjae_TimerHandle;
const osTimerAttr_t Manjae_Timer_attributes = {
  .name = "Manjae_Timer"
};
/* Definitions for Rfid_Timer */
osTimerId_t Rfid_TimerHandle;
const osTimerAttr_t Rfid_Timer_attributes = {
  .name = "Rfid_Timer"
};
/* Definitions for Uart2Lock */
osMutexId_t Uart2LockHandle;
const osMutexAttr_t Uart2Lock_attributes = {
  .name = "Uart2Lock"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void Start_Event_Task(void *argument);
void Start_Motor_Task(void *argument);
void Start_Comm_Task(void *argument);
void Callback_Manjae_Timer(void *argument);
void Callback_Rfid_Timer(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
  DWT_Init();
  /* USER CODE END Init */
  /* Create the mutex(es) */
  /* creation of Uart2Lock */
  Uart2LockHandle = osMutexNew(&Uart2Lock_attributes);

  /* USER CODE BEGIN RTOS_MUTEX */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* creation of Manjae_Timer */
  Manjae_TimerHandle = osTimerNew(Callback_Manjae_Timer, osTimerOnce, NULL, &Manjae_Timer_attributes);

  /* creation of Rfid_Timer */
  Rfid_TimerHandle = osTimerNew(Callback_Rfid_Timer, osTimerPeriodic, NULL, &Rfid_Timer_attributes);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of Event_Task */
  Event_TaskHandle = osThreadNew(Start_Event_Task, NULL, &Event_Task_attributes);

  /* creation of Motor_Task */
  Motor_TaskHandle = osThreadNew(Start_Motor_Task, NULL, &Motor_Task_attributes);

  /* creation of Comm_Task */
  Comm_TaskHandle = osThreadNew(Start_Comm_Task, NULL, &Comm_Task_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_Start_Event_Task */
/**
  * @brief  Function implementing the Event_Task thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_Start_Event_Task */
void Start_Event_Task(void *argument)
{
  /* USER CODE BEGIN Start_Event_Task */
	Event_Run();
  /* USER CODE END Start_Event_Task */
}

/* USER CODE BEGIN Header_Start_Motor_Task */
/**
* @brief Function implementing the Motor_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Motor_Task */
void Start_Motor_Task(void *argument)
{
  /* USER CODE BEGIN Start_Motor_Task */
    for (;;)
    {
        osThreadFlagsWait(MOVE_FLAG, osFlagsWaitAny, osWaitForever);   /* 주문 초인종 올 때까지 잠 (run.c Motor_Request) */
        Motor_Run();        /* run.c 가 주문대로 하나 (MI · MO · PO · 원점) */
    }

  /* USER CODE END Start_Motor_Task */
}

/* USER CODE BEGIN Header_Start_Comm_Task */
/**
* @brief Function implementing the Comm_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Start_Comm_Task */
void Start_Comm_Task(void *argument)
{
  /* USER CODE BEGIN Start_Comm_Task */

	MOVE home = { CMD_I };                            /* 원점 주문 (나머지 칸 0) */

	Save_Init();
	NET_Init();
	Motor_Request(home);                              /* 켜질 때 : 원점 (FRAM 읽은 뒤, run.c 모터 문) */

    for (;;)
    {
        CLI_Run();             /* UART1 CLI (cli.c) */
        NET_Run();             /* PC 명령 받기 : 움직이는 명령은 run.c Motor_Request 에 넘기고 바로 돌아옴 */
        //Manjae_event_text();   /* [현장] 주석 풀기 : 만재 바뀜 → PC FF (manjae.c) */
       // Rfid_event_text();     /* [현장] 주석 풀기 : 카드 바뀜 → PC UT · UU (rfid.c) */
        Status_PC();           /* 일시정지 → PC (FF +) PPAUSE (status.c) */
        Alarm_PC();            /* 알람 → PC S_1_A_09 (alarm.c) */

        osThreadFlagsWait(NET_FLAG, osFlagsWaitAny, 1);   /* W6100 초인종 오면 바로, 안 와도 1ms 뒤 (쪽지 · CLI · 20초 시계 보러) */
    }

  /* USER CODE END Start_Comm_Task */
}

/* Callback_Manjae_Timer function */
void Callback_Manjae_Timer(void *argument)
{
  /* USER CODE BEGIN Callback_Manjae_Timer */
	Manjae_Timer_2s();      /* 만재 바뀐 뒤 2초 조용 → 확정 · 렉 알림 · 부저 (manjae.c) */
  /* USER CODE END Callback_Manjae_Timer */
}

/* Callback_Rfid_Timer function */
void Callback_Rfid_Timer(void *argument)
{
  /* USER CODE BEGIN Callback_Rfid_Timer */
	Rfid_Check();
  /* USER CODE END Callback_Rfid_Timer */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

