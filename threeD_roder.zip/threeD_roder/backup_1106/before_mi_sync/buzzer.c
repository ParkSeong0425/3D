/*
 * buzzer.c : 부저 켜기 / 끄기만 (DO9 = PD0, 부저가 스스로 삐 · 삐 끊어서 울림)
 *
 *  주인 : PC(2500) 연결 중 = PC (B 명령) + 알람만 보드 / 안 연결 = 보드 (아래 켜기 · 끄기)
 *  켜기 : 알람 (alarm.c alarm_go, PC 연결 중에도) · 일시정지 (status.c Pause_Set) · 만재 2초 (manjae.c) · PC 끊김 때 알람 · 일시정지 · 만재 중 (net.c tcp_off)
 *  끄기 : RESET · 음소거 · RUN (event.c) · 일시정지 풀림 (status.c) · PC 연결 순간 알람 아니면 (net.c)
 *  Buzzer_Cmd : PC 부저 명령 글자 B_채널_값@B_채널_값… (cmd.c 가 부름)
 */
#include "buzzer.h"
#include "main.h"
#include "net.h"
#include "status.h"
#include <stdio.h>
#include <string.h>

#define BUZZER_CH   1       /* 이 로더의 부저 채널 (PC 는 B_1_1@B_2_1 처럼 여러 로더 채널을 한 번에 보냄) */

/* 부저 켬 : PC 연결 중엔 알람일 때만 (그 밖의 부저는 PC 가 B 명령으로) */
void Buzzer_On(void)
{
    if (tcp_on && status_1 != ALARM && status_2 != ALARM) return;
    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET);
}

/* 부저 끔 */
void Buzzer_Off(void)
{
    HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
}

/* PC 부저 명령 : B_채널_값@B_채널_값… (채널 1~8, 값 0 무음 / 1 음향1, 묶음 사이 '@' 또는 '&')
   전부 맞으면 이 로더 채널(BUZZER_CH) 값만 부저에 → 1 / 하나라도 틀리면 아무것도 안 바꾸고 0 */
int Buzzer_Cmd(char *s)
{
    int ch, on;
    int mine = -1;                          /* 이 로더 채널 값 (-1 = 명령에 없음 → 그대로) */
    char *p = s;

    for (;;) {
        if (sscanf(p, "B_%d_%d", &ch, &on) != 2 || ch < 1 || ch > 8 || on < 0 || on > 1) return 0;
        if (ch == BUZZER_CH) mine = on;     /* 우리 채널 */
        p = strpbrk(p, "@&");               /* 다음 묶음 */
        if (p == NULL) break;
        p++;
    }

    if (mine == 1) HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET);  /* PC 명령은 바로 켬 (Buzzer_On 은 PC 연결 중 막힘) */
    if (mine == 0) Buzzer_Off();
    return 1;
}
