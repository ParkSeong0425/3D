#ifndef INC_I_MOTOR_H_
#define INC_I_MOTOR_H_

#include "main.h"

/* PR0 절대위치 운전 설정 */
#define IM_MAX_RPM        1000
#define IM_ACC_MS         1500
#define IM_DEC_MS         1500
#define X_PULSE           10000    /* 데이터시트 : 1회전 10000펄스 */
#define X_PI              100      /* 폴리 : 1회전 100mm */
#define IM_GAP            10       /* 도착 판정 오차 (mm) : IM_Arrive · A_05 */

/* 토크 원점복귀 설정 */
#define IM_HOME_DIR       0          /* 0x600A Bit0 : 방향 (실측 확인) */
#define IM_HOME_TORQUE    (3 << 2)   /* 0x600A Bit2~ : 3 = 토크 원점 */
#define IM_HOME_HI_RPM    180        /* [현장] 180 / 사무실 50 */
#define IM_HOME_LO_RPM    80        /* [현장] 80 / 사무실 30 */
#define IM_HOME_ACC_MS    1500
#define IM_HOME_DEC_MS    1500
#define IM_HOME_TIME_MS   20
#define IM_HOME_FORCE     35         /* [현장] 35 / 사무실 10 */
#define IM_HOME_LIMIT     20000

/* 0x600F ~ 0x6015 연속 홈 설정값 */
#define IM_HOME_COUNT     7
static const uint16_t IM_HOME_DATA[IM_HOME_COUNT] = {
    IM_HOME_HI_RPM,      /* 0x600F Homing high velocity */
    IM_HOME_LO_RPM,      /* 0x6010 Homing low velocity */
    IM_HOME_ACC_MS,      /* 0x6011 Homing Acc */
    IM_HOME_DEC_MS,      /* 0x6012 Homing Dec */
    IM_HOME_TIME_MS,     /* 0x6013 Torque zero return time */
    IM_HOME_FORCE,       /* 0x6014 Torque zero return value */
    IM_HOME_LIMIT        /* 0x6015 Homing over-travel */
};

/* 0x1003 Motion state */
#define IM_PATH_DONE      (1 << 5)
#define IM_HOMED          (1 << 6)

/* 기본 기능 */
int IM_Move(int32_t mm, int percent);
int IM_Move2(int32_t mm1, int percent1, int32_t mm2, int percent2);   /* mm1 까지 percent1 → 서지 않고 mm2 까지 percent2 */
int IM_Home(void);
int IM_Stop(void);
int IM_AlarmReset(void);

/* 상태 읽기 */
int IM_Pos(int32_t *mm1, int32_t *mm2);   /* X 두 모터 위치 mm (ID 3 · ID 4), 둘 다 대답 1 */
int IM_Arrive(int x);       /* 두 모터 다 x(mm) 에 올 때까지 기다림 (최대 10초, 도착 1 / 실패 0) */
int IM_ReadReg(int motor, uint16_t reg, uint16_t *out, uint8_t qty);   /* (디버그 · CLI) X 레지스터 읽기 : motor 1 · 2, qty 1 = 16bit / 2 = 32bit */
int IM_Alarm(uint16_t *code);      /* 드라이브 알람 0x2203 (두 모터 합침) : 0x01 과전류 0x02 과전압 0x40 전류측정 0x80 축잠금실패 0x100 오토튜닝 0x200 EEPROM */

/* Register Mapping */
int IM_MapInit(void);

#endif /* INC_I_MOTOR_H_ */
